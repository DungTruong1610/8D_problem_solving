﻿# @cnma/cap-core

> **CNMA CAP Core** — Foundation services for SAP CAP applications.  
> One package, all features, cherry-pick via sub-path imports.

## Quick Start

```bash
npm install @cnma/cap-core
```

## Available Modules

| Import Path | Description |
|-------------|-------------|
| `@cnma/cap-core/srv/core` | `CommonService`, `DBHandler`, `ActionResponse` |
| `@cnma/cap-core/srv/text` | `CnmaTextBundle`, `getText()`, `registerI18nMiddleware()` |
| `@cnma/cap-core/srv/destination` | `DestinationService` (BTP HTTP client) |
| `@cnma/cap-core/srv/logger` | `logger`, `getLogger()` (Winston) |
| `@cnma/cap-core/srv/response` | `ServiceResponse`, `ApiResponse`, `ValidationResponse` |
| `@cnma/cap-core/srv/enum` | `HTTP_STATUS`, `HTTP_STATUS_2XX` |
| `@cnma/cap-core/srv/interfaces` | TypeScript interfaces |
| `@cnma/cap-core/srv/middleware` | `BTPServiceLogging` |
| `@cnma/cap-core/db/*` | CDS entities (variant-setting, audit-log) |
| `@cnma/cap-core/react` | React components and hooks |

## Usage — Backend

```typescript
// server.ts
import { registerI18nMiddleware } from '@cnma/cap-core/srv/text';
const path = require('path');

cds.on('bootstrap', (app) => {
    registerI18nMiddleware(path.join(__dirname, 'src/i18n/i18n'));
});
```

```typescript
// Any handler
import { getText } from '@cnma/cap-core/srv/text';
import { CommonService } from '@cnma/cap-core/srv/core';
import { getLogger } from '@cnma/cap-core/srv/logger';
import { ActionResponse } from '@cnma/cap-core/srv/core';

const log = getLogger('MyHandler');

export class MyHandler extends CommonService {
    async onAction(req: any) {
        log.info('Processing action');
        const msg = getText().getMessage('admin.ERR_REQUIRED');
        return ActionResponse.ok(msg);
    }
}
```

## Usage — CDS

```cds
using from '@cnma/cap-core/db/variant-setting';
```

## Usage — React

```tsx
import { useBackendText } from '@cnma/cap-core/react/shared';
```

## Development

```bash
npm install                # Install dependencies
npm run build:srv          # Build backend
npm run build:react        # Build React
npm run build              # Build all
npm test                   # Run tests
```

## Architecture

```
@cnma/cap-core/
├── db/          → CDS entities (raw .cds)
├── srv/         → Backend TypeScript (core, text, destination, logger, ...)
├── react/       → React components and hooks
├── dist/        → Compiled output (JS + .d.ts)
└── i18n/        → Sample translation files
```

## License

UNLICENSED — Internal Conarum Development Kit
