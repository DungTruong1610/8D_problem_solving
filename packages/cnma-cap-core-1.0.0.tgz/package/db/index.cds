﻿// @cnma/cap-core — CDS entity entry point
// Uncomment as features are added:
// using from './variant-setting';
// using from './audit-log';
