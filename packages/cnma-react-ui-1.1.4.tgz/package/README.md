# @cnma/react-ui

Enterprise UI Components for Conarum.

## Installation

```bash
npm install @cnma/react-ui
```

## Setup

This component library uses Tailwind CSS. To ensure styles are properly applied, you need to import the CSS in your root layout or application entry file:

```javascript
// Import base styles
import '@cnma/react-ui/styles.css';

// Import theme colors (Optional: recommended for Conarum/Fiori styling)
import '@cnma/react-ui/theme.css';
```

## Features

- **Enterprise-Ready**: Built for complex business applications.
- **Accessible**: Built on top of Radix UI primitives ensuring WAI-ARIA compliance.
- **Theming**: Integrated with next-themes and supports SAP Fiori-style branding.
- **Form Integration**: Seamless support with `react-hook-form`.
- **Drag & Drop**: Sortable and draggable interfaces powered by `@dnd-kit`.
- **Interactive**: Animations driven by `framer-motion`.

## Peer Dependencies

Ensure you have the following peer dependencies installed in your project:
- `react` (^18.2.0 || ^19.0.0)
- `react-dom` (^18.2.0 || ^19.0.0)
- `react-i18next` (^16.5.8)

## Usage

Import components directly from the package:

```jsx
import { Button, Card, CardHeader, CardTitle, CardContent } from '@cnma/react-ui';

function App() {
  return (
    <Card>
      <CardHeader>
        <CardTitle>Welcome</CardTitle>
      </CardHeader>
      <CardContent>
        <Button variant="default">Get Started</Button>
      </CardContent>
    </Card>
  );
}
```

## License
Proprietary - Conarum
