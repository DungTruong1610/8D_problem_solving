/**
 * @cnma/react-ui — i18n resource injection
 *
 * Safely injects the `react-ui` namespace resources into the shared i18next
 * singleton WITHOUT calling .init() again.
 *
 * Usage (consuming app's i18n.ts):
 *   import '@cnma/react-ui/i18n';   // side-effect: adds react-ui namespace
 *
 * Components inside react-ui use:
 *   const { t } = useTranslation('react-ui');
 */

import i18n from 'i18next';
import { initReactI18next } from 'react-i18next';
import en from './locales/en.json';
import de from './locales/de.json';
import ja from './locales/ja.json';

const NS = 'react-ui';

const addReactUIResources = () => {
    i18n.addResourceBundle('en', NS, en, true, false);
    i18n.addResourceBundle('de', NS, de, true, false);
    i18n.addResourceBundle('ja', NS, ja, true, false);
};

if (i18n.isInitialized) {
    // App already called .init() — just inject resources into existing instance
    addReactUIResources();
} else {
    // Standalone mode (no consuming app) — initialize minimally
    i18n
        .use(initReactI18next)
        .init({
            fallbackLng: 'en',
            ns: [NS],
            defaultNS: NS,
            interpolation: { escapeValue: false },
            resources: {
                en: { [NS]: en },
                de: { [NS]: de },
                ja: { [NS]: ja },
            },
        });
}

export default i18n;
