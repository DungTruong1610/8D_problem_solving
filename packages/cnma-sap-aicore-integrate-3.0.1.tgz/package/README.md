# @cnma/sap-aicore-integrate

Shared CDK package for SAP AI Core integration — LLM transport, flexible model selection, model discovery, and admin UI components.

## Features

- **LLM Transport** — SAP AI Core Orchestration v2 via `@sap-ai-sdk/orchestration`, with built-in retry (429/timeout/5xx) and a concurrency semaphore
- **Flexible AI Model Selection** — config-driven, per-activity model routing
- **Model Discovery & Registry** — query AI Core tenant, auto-classify models, persist in DB
- **Admin UI Components** — React components for model management (registry page + per-activity picker)
- **Text Embeddings** — `OrchestrationEmbeddingClient`, routed by model name (1536-dim by default), with batching and a dimension guard
- **AI Core Adapter** — BTP Destination auth (env-credential fallback for local dev), resource group resolution, and a raw-inference escape hatch
- **No deployment IDs** — every call routes by model name; the package holds no deployment configuration at all

## Installation

```bash
# Server
npm install @cnma/sap-aicore-integrate @sap-ai-sdk/orchestration @sap-ai-sdk/ai-api axios

# Frontend (if using admin UI)
npm install @cnma/sap-aicore-integrate react-i18next react-hook-form lucide-react sonner
```

## Quick Start

### Server — Per-Activity Model Resolution

```typescript
import { resolveActivityModel, getLlmProvider } from '@cnma/sap-aicore-integrate/llm';
import type { CanonicalMessage } from '@cnma/sap-aicore-integrate/types';

// Resolve which model to use for an activity
const model = resolveActivityModel(config.aiAgentConfig, 'extraction');

// Send messages via AI Core Orchestration
const messages: CanonicalMessage[] = [
  { role: 'system', content: 'You are a helpful assistant.' },
  { role: 'user', content: 'Hello!' },
];
const response = await getLlmProvider().complete(messages, { model });
```

### React — AI Model Registry Page

```tsx
import { AiModelManagementPage, createAiModelApi } from '@cnma/sap-aicore-integrate/react';

const api = createAiModelApi('/admin');

function AdminPage() {
  return <AiModelManagementPage api={api} />;
}
```

### CDS — AIModels Entity

```cds
using { cnma.aicore.integrate as aicore } from '@cnma/sap-aicore-integrate/db/schema';
```

## Sub-path Imports

| Import | Content |
|--------|---------|
| `@cnma/sap-aicore-integrate/types` | `AIMessage`, `CanonicalMessage`, `ModelProfile`, `LlmProvider`, `ToolSchema` |
| `@cnma/sap-aicore-integrate/llm` | `getLlmProvider()`, `resolveActivityModel()`, `resolveModelProfile()`, `OrchestrationProvider` |
| `@cnma/sap-aicore-integrate/discovery` | `discoverFoundationModels()`, `classifyModel()`, `inferProvider()` |
| `@cnma/sap-aicore-integrate/adapter` | `aiCore` singleton (auth, embeddings) |
| `@cnma/sap-aicore-integrate/react` | `AiModelManagementPage`, `AiModelSelection`, `createAiModelApi()` |
| `@cnma/sap-aicore-integrate/react/shared` | `registerActivities()`, `getActivities()`, `getActivity()`, `AiActivity` |

> **Since 2.0.0 the package ships NO default activities.** Declare your app's activities once (an `AiActivity[]`) and call `registerActivities(...)` at bootstrap — on the backend (CAP service `init()`) **and** on the frontend (app entry, before the model-settings UI renders); the registry is per-bundle.

## Documentation

See the [`docs/`](./docs/) folder for detailed documentation.

**Technical (for developers):**

- [01-overview.md](./docs/01-overview.md) — Architecture and scope
- [02-dependencies.md](./docs/02-dependencies.md) — Dependency planning
- [03-module-reference.md](./docs/03-module-reference.md) — Full API reference
- [04-source-mapping.md](./docs/04-source-mapping.md) — Source file mapping
- [05-integration-guide.md](./docs/05-integration-guide.md) — Consumer integration guide
- [06-development-guide.md](./docs/06-development-guide.md) — Development & build guide

**Business & user guides (for admins / BAs):**

- [business/data-dictionary.md](./docs/business/data-dictionary.md) — AI Model & configuration in plain language
- [business/process-flows/model-sync.md](./docs/business/process-flows/model-sync.md) — How the model catalogue is synced
- [business/process-flows/per-activity-model-resolution.md](./docs/business/process-flows/per-activity-model-resolution.md) — How a model is chosen for an activity
- [product/user-manual/ai-model-selection.md](./docs/product/user-manual/ai-model-selection.md) — Model Selection user guide
- [product/admin-guide/ai-model-registry.md](./docs/product/admin-guide/ai-model-registry.md) — Model Registry administration guide

## License

UNLICENSED