/**
 * SAP AI Core Integration — Shared Data Model
 *
 * Defines the AIModels entity which stores the registry of foundation models.
 */
namespace cnma.aicore.integrate;

using { cuid, managed } from '@sap/cds/common';

/**
 * Admin-managed AI model registry. Models are synced from SAP AI Core via
 * the syncModels admin action. Admin controls:
 *   - active: toggle model visibility in all dropdowns
 *   - suitableActivities: restrict to specific activities (null = all)
 * Capabilities and lifecycle data are synced from AI Core's Model Library (read-only).
 */
entity AIModels : cuid, managed {
  @unique modelId          : String(100) not null;   // e.g. "gemini-2.5-pro"
  provider                 : String(50);             // e.g. "Google", "Anthropic", "OpenAI"
  displayName              : String(150);            // Human-friendly: "Gemini 2.5 Pro"
  active                   : Boolean default true;   // Admin toggle — inactive = hidden from all dropdowns
  capabilities             : LargeString;            // JSON array from AI Core: ["text-generation","reasoning","image-recognition",...]
  suitableActivities       : LargeString;            // JSON array: ["agent","extraction"] — null = all activities
  sortOrder                : Integer default 100;    // Lower = shown first in dropdowns
  deprecated               : Boolean default false;  // From AI Core: model version is deprecated
  retirementDate           : String(30);             // From AI Core: scheduled retirement date (ISO string)
  version                  : String(30);             // From AI Core: model version number
  // Rich metadata from AI Core Model Library
  contextWindow            : Integer;                // Max context length in tokens (e.g. 200000)
  inputTokenCost           : Decimal(10,5);          // Input cost in Capacity Units
  outputTokenCost          : Decimal(10,5);          // Output cost in Capacity Units
  streamingSupported       : Boolean default false;  // Whether streaming is supported
  inputTypes               : LargeString;            // JSON array: ["text","image","pdf"] — supported modalities
}
