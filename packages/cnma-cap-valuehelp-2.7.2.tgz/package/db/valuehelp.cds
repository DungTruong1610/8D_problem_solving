/**
 * @cnma/cap-valuehelp — Reusable Value Help Entity Definition
 *
 * Usage in consuming apps:
 *   using { cnma.valuehelp.ValueHelpList } from '@cnma/cap-valuehelp/db/valuehelp';
 *
 * The entity uses namespace cnma.valuehelp to prevent naming collisions.
 */
namespace cnma.valuehelp;

using { managed, cuid } from '@sap/cds/common';

/**
 * Configurable value help lists for dropdown, combobox, and search help widgets.
 * Supports 3 source types:
 *   - 'static'    : Inline JSON entries (staticEntries field)
 *   - 'reference' : Dynamic DB table lookup (referenceTable/keyColumn/textColumn)
 *   - 'external'  : Reserved for future S/4HANA OData integration
 */
@assert.unique: { valueHelpPerObject: [valueHelpID, objectType] }
entity ValueHelpList : cuid, managed {
    valueHelpID    : String(100) @mandatory;
    objectType     : String(50)  @mandatory;
    description    : String(255);

    // Source configuration
    sourceType     : String(20) default 'static';    // 'static' | 'reference' | 'external'

    // External source (S/4HANA OData or REST endpoint)
    externalEndpoint : String(500);   // Destination + path, e.g. "S4_DEST:/sap/opu/odata/CNMA/INV_SRV/F4_GLAccountSet"
    externalMethod   : String(10) default 'GET';  // 'GET' or 'POST'
    externalPayload  : LargeString;   // JSON template body for POST, supports {{variableName}} placeholders
    externalResponsePath : String(500);  // Dot-notation path to result array, e.g. "d.toOpenPurchasingDocument.results.0.toOpenPurchasingDocumentItem.results"
    externalContextFields : String(500); // Comma-separated field names to resolve from current row, e.g. "companyCode,purchaseOrderNo"

    // Static entries: JSON array [{key, text, ...extra columns}]
    staticEntries  : LargeString;

    // Reference table mapping (sourceType = 'reference')
    referenceTable : String(100);   // CDS entity name, e.g. "ASNReferenceData"
    keyColumn      : String(100);   // Column used as value key
    textColumn     : String(100);   // Column used as display text
    filterColumn   : String(100);   // Column to scope results by objectType (optional)
    defaultFilter  : String(500);   // Always-on OData $filter expression (e.g. "Language eq 'DE' or Language eq 'EN'")

    // Display formatting
    displayFormat  : String(20) default 'keyAndText';  // 'keyOnly' | 'textOnly' | 'keyAndText'
    sortBy         : String(20) default 'text';        // 'key' | 'text'

    // Cascading dependency (optional)
    dependsOn      : String(100);   // Field name of parent value help

    // Return mapping — universal, works for ALL widget types
    // JSON: [{ "sourceColumn": "col", "targetField": "field" }]
    returnMapping  : LargeString;

    // Search Help dialog config (searchHelp widget only)
    // JSON: { title, searchFields, resultColumns, returnField }
    searchConfig   : LargeString;

    // AI prompt injection control
    injectIntoPrompt : Boolean default true;

    isActive       : Boolean default true;
    disableValidation : Boolean default false;
}
