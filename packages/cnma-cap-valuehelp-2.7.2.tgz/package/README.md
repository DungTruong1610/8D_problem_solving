# @cnma/cap-valuehelp

Reusable F4 Value Help module for SAP CAP applications — CDS entities, backend handlers, React widgets, and admin UI.

## Features

- **3 source types**: Static JSON entries, dynamic reference table lookup, external (S/4HANA OData — future)
- **5 React widgets**: Select, ComboBox, MultiSelect, SearchInput, SearchHelpDialog
- **Admin UI**: Built-in `ValueHelpManager` component for CRUD management
- **AI integration**: Prompt injection + post-extraction validation for value-constrained fields
- **TypeScript + JavaScript**: Written in TS, ships `.js` + `.d.ts` — works in both TS and JS projects
- **Zero lock-in**: Entity names and reference tables are configurable via constructor injection

---

## How It Works

### What is F4 Value Help?

In SAP terminology, **F4 Help** (or "Search Help") provides a list of valid values for a field. Instead of typing a supplier code from memory, users press F4 to see a dropdown/dialog of allowed values. This package brings that concept to modern CAP applications with React frontends.

**Problem it solves**: In document extraction and data entry applications, many fields have restricted values — company codes, cost centers, tax codes, material groups, etc. Without value help:
- Users make typos and enter invalid codes
- AI models hallucinate non-existent values  
- No consistent validation across the application

**This package provides**: A centralized, database-driven registry of valid values per field + per document type, with widgets, AI integration, and admin management.

---

### Architecture Overview

```mermaid
graph TB
    subgraph PKG["📦 @cnma/cap-valuehelp"]
        direction TB

        subgraph DB["db/ — Data Layer"]
            CDS["ValueHelpList Entity<br><i>valuehelp.cds</i>"]
        end

        subgraph SRV["srv/ — Backend Layer"]
            VHH["ValueHelpHandler<br><i>getValueHelp, getValueHelpSearch, beforeSave</i>"]
            VPI["ValueHelpPromptInjector<br><i>injectConstraints</i>"]
            VHV["ValueHelpValidator<br><i>validate</i>"]
        end

        subgraph REACT["react/ — Frontend Layer"]
            direction LR
            W1["ValueHelpSelect"]
            W2["ValueHelpComboBox"]
            W3["ValueHelpMultiSelect"]
            W4["ValueHelpSearchInput"]
            W5["SearchHelpDialog"]
            W6["ValueHelpManager<br><i>Admin CRUD</i>"]
            H1["useValueHelp"]
            H2["useSearchHelp"]
        end
    end

    CDS --> VHH
    CDS --> VPI
    CDS --> VHV
    VHH --> W1 & W2 & W3 & W4 & W5
    VHH --> W6

    style PKG fill:#f0f4ff,stroke:#3b82f6,stroke-width:2px
    style DB fill:#fef3c7,stroke:#f59e0b
    style SRV fill:#dcfce7,stroke:#22c55e
    style REACT fill:#ede9fe,stroke:#8b5cf6
```

### Host Application Integration

This diagram shows how a consuming CAP application integrates with the package across all layers:

```mermaid
flowchart TB
    subgraph HOST["🏠 Host Application"]
        direction TB

        subgraph HOST_DB["db/ layer"]
            SCHEMA["schema.cds<br><i>App-specific entities</i>"]
        end

        subgraph HOST_SRV["srv/ layer"]
            SVC_CDS["service.cds<br><i>using ValueHelpList as vh_ValueHelpList</i>"]
            SVC_TS["service.ts<br><i>new ValueHelpHandler config</i>"]
            ADMIN_CDS["admin-service.cds<br><i>Full CRUD projection</i>"]
            ADMIN_TS["admin-service.ts<br><i>beforeSave validation</i>"]
            PROC["ExtractionProcessor.ts<br><i>PromptInjector + Validator</i>"]
        end

        subgraph HOST_UI["app/ layer"]
            FORM["Document Form<br><i>ValueHelpSelect, ComboBox...</i>"]
            ADMIN_UI["Admin Page<br><i>ValueHelpManager</i>"]
        end
    end

    subgraph PKG2["📦 @cnma/cap-valuehelp"]
        P_CDS["db/valuehelp.cds"]
        P_SRV["srv/ handlers"]
        P_REACT["react/ widgets"]
    end

    P_CDS -.->|import entity| SVC_CDS & ADMIN_CDS
    P_SRV -.->|import handlers| SVC_TS & ADMIN_TS & PROC
    P_REACT -.->|import components| FORM & ADMIN_UI

    FORM -->|"getValueHelp()"| SVC_TS
    ADMIN_UI -->|"CRUD /odata/v4/admin"| ADMIN_TS
    PROC -->|"injectConstraints()"| P_SRV

    SVC_TS -->|"SELECT from"| P_CDS
    ADMIN_TS -->|"SELECT/INSERT/UPDATE"| P_CDS

    style HOST fill:#f8fafc,stroke:#64748b,stroke-width:2px
    style PKG2 fill:#f0f4ff,stroke:#3b82f6,stroke-width:2px
    style HOST_DB fill:#fef3c7,stroke:#f59e0b
    style HOST_SRV fill:#dcfce7,stroke:#22c55e
    style HOST_UI fill:#ede9fe,stroke:#8b5cf6
```

### End-to-End Data Flow

How a value help request flows from the user's browser to the database and back:

```mermaid
sequenceDiagram
    participant User as 👤 User
    participant Widget as React Widget
    participant OData as CAP OData Service
    participant Handler as ValueHelpHandler
    participant DB as HANA / SQLite

    User->>Widget: Click dropdown / press F4
    Widget->>OData: POST getValueHelp(valueHelpID, objectType)
    OData->>Handler: Dispatch to handler
    Handler->>DB: SELECT from ValueHelpList WHERE ...
    DB-->>Handler: ValueHelpList definition

    alt sourceType = 'static'
        Handler->>Handler: Parse staticEntries JSON
    else sourceType = 'reference'
        Handler->>DB: SELECT key, text FROM ReferenceTable
        DB-->>Handler: Reference rows
    end

    Handler->>Handler: Apply displayFormat, sortBy
    Handler-->>OData: JSON entries [{key, text, ...}]
    OData-->>Widget: Response
    Widget-->>User: Show dropdown with entries

    User->>Widget: Select a value
    Widget->>Widget: Apply returnMapping
    Widget-->>User: Auto-fill related fields
```

---

### Source Types

Each value help definition has a **source type** that determines where the valid values come from:

#### 1. Static (`sourceType: 'static'`)
Values are stored directly as a JSON array in the `staticEntries` column.

```json
[
  { "key": "1000", "text": "conarum DE" },
  { "key": "2000", "text": "conarum US" },
  { "key": "3000", "text": "conarum CH" }
]
```

**Best for**: Short, stable lists (company codes, document types, currencies). These lists are also the ones that can be injected into AI prompts.

#### 2. Reference (`sourceType: 'reference'`)
Values are queried live from an existing database table. You specify:
- `referenceTable` — the CDS entity to query (e.g. `Suppliers`)
- `keyColumn` — column used as the value key (e.g. `supplier`)
- `textColumn` — column used as the display text (e.g. `supplierName`)
- `filterColumn` — (optional) scopes results by document type

```
referenceTable: "Suppliers"
keyColumn: "supplier"          → becomes the "key" in entries
textColumn: "supplierName"     → becomes the "text" in entries
filterColumn: "objectType"     → WHERE objectType = 'INV'
```

**Best for**: Large, frequently changing lists (suppliers, customers, materials). The handler queries the table at runtime and returns formatted `{key, text}` entries.

> ⚠️ **Security**: Reference table names are validated against an allowlist (`allowedReferenceTables` config). Arbitrary table access is not possible.

#### 3. External (`sourceType: 'external'`)
Values are fetched at runtime from an external system (e.g., S/4HANA OData F4 value helps) via a **consumer-provided callback**.

**Configuration:**
- `externalEndpoint` — Destination + path string (e.g., `"S4_DEST:/sap/opu/odata/CNMA/INV_SRV/F4_GLAccountSet"`)
- `keyColumn` — Which field from the external response maps to `key` (e.g., `"GLAccount"`)
- `textColumn` — Which field from the external response maps to `text` (e.g., `"LongText"`)
- `filterColumn` — (Optional) column for scoping/filtering

**How it works:**
1. The `ValueHelpHandler` reads the `externalEndpoint` from the DB config
2. It calls the `externalFetcher` callback (provided by the consuming app via `ValueHelpConfig`)
3. The callback makes the actual HTTP call (using SAP Cloud SDK, axios, etc.)
4. Results are mapped to `{key, text, ...extra}` using `keyColumn`/`textColumn`

**Example — F4_GLAccount from S/4HANA:**

```
externalEndpoint: "S4_QH1807:/sap/opu/odata/CNMA/INV_SRV/F4_GLAccountSet"
keyColumn:        "GLAccount"
textColumn:       "LongText"
dependsOn:        "companyCode"
```

**Best for**: Large value lists from external systems (S/4HANA F4 helps, master data services) where data should not be replicated locally.

---

### Cascading Dependencies (`dependsOn`)

Value help lists can depend on a parent field's value. For example, a "Plant" dropdown may only show plants that belong to the selected "Company Code".

```
Value Help: "plants"
dependsOn: "companyCode"
```

When the user selects company code `1000`, the Plants dropdown filters to only show plants under `1000`. This works for both static (filtered by matching key) and reference (adds a WHERE clause) source types.

**How it flows**:
1. User selects a value in the parent field (e.g., `companyCode = 1000`)
2. The child widget passes `dependsOnValue: "1000"` to the `getValueHelp` action
3. The handler filters results: static entries matching the parent key, or reference table rows where the `dependsOn` column matches

---

### Return Mapping (`returnMapping`)

When a user selects a value, you often want to **auto-fill multiple fields** — not just the bound field. Return mapping defines this behavior.

```json
[
  { "sourceColumn": "supplierName", "targetField": "senderName" },
  { "sourceColumn": "taxNumber",    "targetField": "taxId" },
  { "sourceColumn": "country",      "targetField": "senderCountry" }
]
```

**Example flow**:
1. User selects supplier `SUP001` from a dropdown
2. The widget calls `onBatchFieldUpdate` with:
   ```json
   {
     "senderName": "Acme Corp",
     "taxId": "DE123456789",
     "senderCountry": "DE"
   }
   ```
3. The form updates all 3 fields in one operation

This is especially powerful for reference-type value helps, where the handler returns extra columns from the reference table alongside each entry.

---

### Display Formats

Control how entries appear in the widget:

| Format | Display | Example |
|---|---|---|
| `keyAndText` | `1000 — conarum DE` | Most common |
| `keyOnly` | `1000` | Compact |
| `textOnly` | `conarum DE` | User-friendly |

Sorting can be by `key` (alphabetical by code) or `text` (alphabetical by description).

---

### AI Prompt Injection

For applications using AI to extract data from documents, value help entries can be **injected into the AI prompt** so the model outputs only valid values. This is the "pre-extraction" guard.

**How it works**:

```mermaid
flowchart LR
    A[Schema defines fields<br>with valueHelpID] --> B{Guard 1:<br>injectIntoPrompt?}
    B -->|true| C{Guard 2:<br>entries ≤ threshold?}
    B -->|false| D[Skip field]
    C -->|yes| E[Inject into prompt]
    C -->|no| F[Skip — too many entries]
    E --> G["AI sees:<br>For field 'companyCode',<br>match to correct key:<br>- conarum DE → 1000<br>- conarum US → 2000"]
```

**Dual-guard system**:

1. **Guard 1 — Per-list opt-in**: Each `ValueHelpList` entry has an `injectIntoPrompt` boolean. Only lists explicitly marked `true` are injected.
2. **Guard 2 — Global threshold**: A configurable maximum (`AI_VALUE_HELP_PROMPT_THRESHOLD`, default 50 entries) prevents large lists from bloating the prompt. Lists exceeding the threshold are silently skipped.

**Only static entries** are injected (reference tables may contain thousands of rows). The injected prompt takes the form:

```
For field "companyCode", match the document content to the correct key:
- "conarum DE" → 1000
- "conarum US" → 2000
- "conarum CH" → 3000
```

For array fields, the prompt instructs the AI to output an array of keys.

---

### Post-Extraction Validation

After the AI returns extracted data, the `ValueHelpValidator` checks whether the extracted values exist in the value help lists. This is the "post-extraction" guard.

**Key behaviors**:
- **Warning-only**: Validation logs warnings but **never blocks or rejects** extraction results. The AI's output is preserved even if invalid.
- **Static entries only**: Only validates against static lists (reference tables would require additional DB lookups).
- **Array-aware**: For array-type fields, each element in the extracted array is individually validated.
- **Optional log callback**: Integrates with your app's processing log system.

**Example output**:
```
[ValueHelp] Field "companyCode": extracted value "9999" not in valid list [1000, 2000, 3000]
[ValueHelp] Field "departments": extracted values [HR, INVALID_DEPT] not in valid list [HR, FI, SD, MM]
```

---

### Admin Workflow

Administrators manage value help definitions through the `ValueHelpManager` component:

1. **Create** — Define a new value help with ID, source type, entries/reference config
2. **Edit** — Modify existing definitions (JSON editor for static entries, form fields for reference config)
3. **Delete** — Remove definitions with confirmation
4. **Validate on save** — The `beforeSave` handler enforces:
   - Required fields (`valueHelpID`, `objectType`)
   - Valid JSON format for `staticEntries`, `returnMapping`, `searchConfig`
   - Reference table exists in the allowed list
   - No duplicate `(valueHelpID, objectType)` pairs (enforced by DB unique constraint)

---

### Entity Schema Reference

The `ValueHelpList` entity stores all value help definitions:

| Column | Type | Default | Description |
|---|---|---|---|
| `ID` | UUID | auto | Primary key (from `cuid`) |
| `valueHelpID` | String(100) | **required** | Unique identifier per object type (e.g. `companyCodes`) |
| `objectType` | String(50) | **required** | Document type this definition applies to (e.g. `INV`, `PO`) |
| `description` | String(255) | — | Admin-friendly description |
| `sourceType` | String(20) | `'static'` | `'static'` \| `'reference'` \| `'external'` |
| `externalEndpoint` | String(500) | — | Destination + OData path for external source |
| `staticEntries` | LargeString | — | JSON array: `[{key, text, ...extras}]` |
| `referenceTable` | String(100) | — | CDS entity name for reference lookup |
| `keyColumn` | String(100) | — | Key column in reference table |
| `textColumn` | String(100) | — | Text column in reference table |
| `filterColumn` | String(100) | — | Column to filter by `objectType` |
| `displayFormat` | String(20) | `'keyAndText'` | How entries are displayed |
| `sortBy` | String(20) | `'text'` | Sort order: `'key'` or `'text'` |
| `dependsOn` | String(100) | — | Parent field name for cascading |
| `returnMapping` | LargeString | — | JSON: `[{sourceColumn, targetField}]` |
| `searchConfig` | LargeString | — | JSON: `{title, searchFields, resultColumns, returnField}` |
| `injectIntoPrompt` | Boolean | `true` | Whether to inject into AI extraction prompt |
| `isActive` | Boolean | `true` | Soft-delete flag |

> **Unique constraint**: `(valueHelpID, objectType)` — each value help ID is unique per document type.

---

## Integration Guide

This guide walks you through integrating `@cnma/cap-valuehelp` into any SAP CAP application. Estimated time: ~30 minutes.

### Prerequisites

| Requirement | Version |
|---|---|
| Node.js | >= 18 |
| @sap/cds | >= 7.0.0 |
| React | >= 18.0.0 (frontend only) |
| lucide-react | >= 0.300.0 (admin UI only) |

---

### Step 1 — Registry & Install

The package is published to the **Conarum Azure Artifacts** feed. You must configure npm to resolve `@cnma` scoped packages from this feed.

**1a. Create `.npmrc`** in your project root:

```ini
@cnma:registry=https://pkgs.dev.azure.com/conarumdc/_packaging/cdk-npm/npm/registry/
always-auth=true
```

**1b. Authenticate** (one-time per machine):

Generate a Personal Access Token (PAT) in Azure DevOps:
1. Go to **Azure DevOps** → User Settings → Personal Access Tokens
2. Create a token with **Packaging → Read** scope
3. Encode the PAT:

```bash
node -e "console.log(Buffer.from('YOUR_PAT_HERE').toString('base64'))"
```

4. Add credentials to your **user-level** `.npmrc` (`~/.npmrc`):

```ini
//pkgs.dev.azure.com/conarumdc/_packaging/cdk-npm/npm/registry/:username=conarumdc
//pkgs.dev.azure.com/conarumdc/_packaging/cdk-npm/npm/registry/:_password=<BASE64_ENCODED_PAT>
//pkgs.dev.azure.com/conarumdc/_packaging/cdk-npm/npm/registry/:email=you@conarum.com
```

> ⚠️ **Important**: The project `.npmrc` only sets the registry. Auth credentials go in your **user-level** `~/.npmrc` so they are not committed to Git.

**1c. Install the package:**

```bash
npm install @cnma/cap-valuehelp
```

---

### Step 2 — CDS Data Model

Import the `ValueHelpList` entity into your CDS service definitions. **Do NOT import it in `db/schema.cds`** — import directly in the service files to avoid namespace issues.

**In your service CDS file** (e.g. `srv/my-service.cds`):

```cds
// Import with alias to avoid naming conflicts
using { ValueHelpList as vh_ValueHelpList } from '@cnma/cap-valuehelp/db/valuehelp';

service MyService @(path: '/odata/v4/myservice') {
    // Read-only for regular users
    @readonly entity ValueHelpList as projection on vh_ValueHelpList;

    // Actions for value help retrieval
    action   getValueHelp(valueHelpID : String, objectType : String,
                          dependsOnValue : String) returns array of String;
    action   getValueHelpSearch(valueHelpID : String, objectType : String,
                                searchTerm : String, filters : String,
                                top : Integer, skip : Integer) returns String;
}
```

**For admin services** (CRUD access):

```cds
using { ValueHelpList as vh_ValueHelpList } from '@cnma/cap-valuehelp/db/valuehelp';

service AdminService @(path: '/odata/v4/admin', requires: 'admin') {
    // Full CRUD for admins
    entity ValueHelpList as projection on vh_ValueHelpList;
}
```

> 💡 **Why alias?** Using `vh_ValueHelpList` avoids CDS circular references when you also have other entities in your model. The projection name `ValueHelpList` is what consumers see in the OData API.

---

### Step 3 — Backend Handlers (TypeScript)

Wire up the package handlers in your CAP service implementation.

**3a. Service handler** (read-only access):

```typescript
// srv/my-service.ts
import { ValueHelpHandler } from '@cnma/cap-valuehelp/srv';
import type { ExternalFetcher } from '@cnma/cap-valuehelp/srv';

module.exports = (srv: any) => {
    // Optional: implement external fetcher for S/4HANA F4 value helps
    const externalFetcher: ExternalFetcher = async (endpoint, options) => {
        // Parse endpoint format: "DESTINATION_NAME:/odata/path/EntitySet"
        const [destName, ...pathParts] = endpoint.split(':');
        const odataPath = pathParts.join(':');

        // Use SAP Cloud SDK, axios, or any HTTP client
        const response = await executeHttpRequest(
            { destinationName: destName },
            { method: 'GET', url: odataPath, params: {
                $format: 'json',
                $top: options.top || 200,
                $skip: options.skip || 0,
                ...(options.filter ? { $filter: `substringof('${options.filter}', LongText)` } : {}),
            }}
        );

        return {
            rows: response.data?.d?.results || [],
            total: response.data?.d?.__count,
        };
    };

    // Configure handler with YOUR namespace's entity names
    const valueHelpHandler = new ValueHelpHandler({
        entityName: 'ValueHelpList',    // Entity name as seen by CDS runtime
        allowedReferenceTables: {
            // Map short names → fully qualified CDS entity names
            'Suppliers':     'your.namespace.Suppliers',
            'CompanyCodes':  'your.namespace.CompanyCodes',
        },
        externalFetcher,  // ← Enable external source type
    });

    // Bind value help action handlers
    srv.on('getValueHelp', valueHelpHandler.getValueHelp.bind(valueHelpHandler));
    srv.on('getValueHelpSearch', valueHelpHandler.getValueHelpSearch.bind(valueHelpHandler));
};
```

**3b. Admin handler** (CRUD access):

```typescript
// srv/admin-service.ts
import { ValueHelpHandler } from '@cnma/cap-valuehelp/srv';

module.exports = (srv: any) => {
    const valueHelpHandler = new ValueHelpHandler({
        entityName: 'ValueHelpList',
        allowedReferenceTables: {
            'Suppliers':    'your.namespace.Suppliers',
            'CompanyCodes': 'your.namespace.CompanyCodes',
        },
    });

    // Validate before save (enforces required fields, JSON format, etc.)
    srv.before(['CREATE', 'UPDATE'], 'ValueHelpList', valueHelpHandler.beforeSave.bind(valueHelpHandler));
};
```

**3c. AI Prompt Injection** (optional — for AI extraction apps):

```typescript
import { ValueHelpPromptInjector } from '@cnma/cap-valuehelp/srv';

const promptInjector = new ValueHelpPromptInjector({
    valueHelpEntity: 'ValueHelpList',
    systemConfigEntity: 'SystemConfiguration',    // Your config entity
    thresholdKey: 'MAX_VALUE_HELP_ENTRIES',        // Optional limit key
});

// Use in your extraction logic
const constraints = await promptInjector.injectConstraints(objectType, promptParts);
```

**3d. Post-Extraction Validation** (optional):

```typescript
import { ValueHelpValidator } from '@cnma/cap-valuehelp/srv';

const validator = new ValueHelpValidator({
    valueHelpEntity: 'ValueHelpList',
});

// Validate extracted values against value help entries
const result = await validator.validate(extractedData, objectType);
```

---

### Step 4 — React Frontend (Optional)

If your app has a React frontend, the package provides ready-to-use widgets and an admin management component.

**4a. Consumer widgets** (for end-user forms):

```tsx
import { ValueHelpSelect, ValueHelpComboBox, ValueHelpMultiSelect } from '@cnma/cap-valuehelp/react';
import '@cnma/cap-valuehelp/react/valuehelp.css';

// Simple dropdown
<ValueHelpSelect
    objectType="INV"
    valueHelpID="companyCodes"
    value={formData.companyCode}
    onChange={(val) => setField('companyCode', val)}
    baseUrl="/odata/v4/myservice"   // Points to YOUR service
/>

// Typeahead combo box
<ValueHelpComboBox
    objectType="INV"
    valueHelpID="supplierCodes"
    value={formData.supplier}
    onChange={(val) => setField('supplier', val)}
    onBatchFieldUpdate={(updates) => applyMultipleFields(updates)}
    baseUrl="/odata/v4/myservice"
/>

// Multi-select with chips
<ValueHelpMultiSelect
    objectType="INV"
    valueHelpID="costCenters"
    value={formData.costCenters}
    onChange={(val) => setField('costCenters', val)}
    baseUrl="/odata/v4/myservice"
/>
```

**4b. Search Help Dialog** (F4 popup):

```tsx
import { ValueHelpSearchInput } from '@cnma/cap-valuehelp/react';

<ValueHelpSearchInput
    objectType="INV"
    valueHelpID="suppliers"
    value={formData.supplier}
    onChange={(val) => setField('supplier', val)}
    onBatchFieldUpdate={(updates) => applyMultipleFields(updates)}
    baseUrl="/odata/v4/myservice"
/>
```

**4c. Admin Management UI** (for admin pages):

```tsx
import { ValueHelpManager } from '@cnma/cap-valuehelp/react';

// With your axios/api client (recommended for CSRF support)
<ValueHelpManager
    objectType="INV"
    serviceUrl="/odata/v4/admin"
    httpClient={api}     // Your axios instance with CSRF interceptor
/>

// Or with built-in fetch (no CSRF)
<ValueHelpManager
    objectType="INV"
    serviceUrl="/odata/v4/admin"
/>
```

**4d. Custom hooks** (for building your own UI):

```tsx
import { useValueHelp, useSearchHelp } from '@cnma/cap-valuehelp/react';

function MyCustomWidget({ objectType, valueHelpID }) {
    const { entries, loading, error, handleSelection } = useValueHelp({
        objectType,
        valueHelpID,
        baseUrl: '/odata/v4/myservice',
    });

    if (loading) return <Spinner />;
    return entries.map(e => <Option key={e.key} value={e.key}>{e.text}</Option>);
}
```

---

### Step 5 — Seed Initial Data (Optional)

Create a CSV file to pre-populate value help definitions:

**`db/data/ValueHelpList.csv`:**

```csv
ID;valueHelpID;objectType;sourceType;staticEntries;referenceTable;keyColumn;textColumn;filterColumn;displayFormat;sortBy;injectIntoPrompt;isActive;description
<uuid>;companyCodes;INV;static;[{"key":"1000","text":"conarum DE"},{"key":"2000","text":"conarum US"}];;;;;;keyAndText;text;true;true;Company code dropdown
<uuid>;suppliers;INV;reference;;Suppliers;supplier;supplierName;objectType;keyAndText;text;true;true;Supplier lookup from reference table
```

> 💡 Use `node -e "console.log(require('crypto').randomUUID())"` to generate UUIDs.

---

## Package Exports Reference

| Import Path | Contents |
|---|---|
| `@cnma/cap-valuehelp/db/valuehelp` | CDS entity `ValueHelpList` |
| `@cnma/cap-valuehelp/srv` | `ValueHelpHandler`, `ValueHelpPromptInjector`, `ValueHelpValidator` |
| `@cnma/cap-valuehelp/react` | All React components, hooks, admin UI, and types |

### React Components

| Component | Widget Type | Description |
|---|---|---|
| `ValueHelpSelect` | `select` / `dropdown` | Standard dropdown |
| `ValueHelpComboBox` | `comboBox` | Typeahead with free text |
| `ValueHelpMultiSelect` | `multiSelect` | Token/chip array input |
| `ValueHelpSearchInput` | `searchHelp` | F4 dialog trigger button |
| `SearchHelpDialog` | — | Full search dialog (internal) |
| `ValueHelpManager` | — | Admin CRUD management panel |

### Hooks

| Hook | Description |
|---|---|
| `useValueHelp` | Fetch entries + returnMapping for a value help ID |
| `useSearchHelp` | Multi-criteria search with server-side pagination |

### Types

All TypeScript interfaces are exported from `@cnma/cap-valuehelp/react`:

```typescript
import type {
    ValueHelpEntry,
    ReturnMapping,
    SearchConfig,
    ValueHelpBaseProps,
    ValueHelpManagerProps,
    HttpClient,
    UseValueHelpOptions,
    UseSearchHelpOptions,
} from '@cnma/cap-valuehelp/react';
```

---

## Common Props

| Prop | Type | Default | Description |
|---|---|---|---|
| `objectType` | `string` | — | Document type (e.g. `'INV'`, `'PO'`) |
| `valueHelpID` | `string` | — | ID of the value help definition |
| `value` | `string` | — | Current field value (key) |
| `onChange` | `(value: string) => void` | — | Single-field change handler |
| `onBatchFieldUpdate` | `(updates: Record) => void` | — | Multi-field updates via returnMapping |
| `dependsOnValue` | `string` | — | Parent field value for cascading |
| `displayFormat` | `'keyOnly' \| 'textOnly' \| 'keyAndText'` | `'keyAndText'` | How entries are displayed |
| `baseUrl` | `string` | `/odata/v4/extraction` | OData service base URL |
| `disabled` | `boolean` | `false` | Disable the widget |

---

## Troubleshooting

### "Cannot find module '@cnma/cap-valuehelp/srv'"
Make sure you ran `npm install` after adding the package. Check that `.npmrc` exists and points to the Azure Artifacts feed.

### CDS compile errors with ValueHelpList
**Do NOT** import `ValueHelpList` in `db/schema.cds`. Import it directly in **service CDS files** using an alias:
```cds
using { ValueHelpList as vh_ValueHelpList } from '@cnma/cap-valuehelp/db/valuehelp';
```

### Dual @sap/cds installation error (local development only)
This only happens with `file:` dependencies during development. When using the published package from npm, this does not occur.

### CSRF 403 errors on save/delete
Pass your app's HTTP client (e.g., axios instance with CSRF interceptor) via the `httpClient` prop to `ValueHelpManager`:
```tsx
<ValueHelpManager objectType="INV" httpClient={api} />
```

---

## Real-World Integration Example

This section shows how the **ai-agent-extraction** app integrates `@cnma/cap-valuehelp` across two screens: an **Admin Schema Editor** and a **User Review Page**.

### Admin Side — Schema Editor

The Schema Editor has two integration points:

**1. ValueHelpManager tab** — Renders the admin CRUD panel for managing value help definitions:

```tsx
import { ValueHelpManager } from '@cnma/cap-valuehelp/react';
import '@cnma/cap-valuehelp/react/valuehelp.css';

// Inside SchemaEditor component — renders when "Value Help" tab is selected
{schemaTypeMode === 'valueHelp' && (
    <ValueHelpManager objectType={formData.objectType} httpClient={api} />
)}
```

**2. ValueHelpID picker per field** — Fetches available definitions so admins can assign value helps to schema fields:

```tsx
// Fetch available value help IDs for the dropdown in each field config
const [valueHelpDefs, setValueHelpDefs] = useState([]);

useEffect(() => {
    const fetchValueHelpDefs = async () => {
        if (!formData.objectType) { setValueHelpDefs([]); return; }
        try {
            const response = await api.get(
                `/odata/v4/admin/ValueHelpList?$filter=objectType eq '${formData.objectType}' and isActive eq true&$select=valueHelpID,description&$orderby=valueHelpID`
            );
            setValueHelpDefs(response.data?.value || []);
        } catch { setValueHelpDefs([]); }
    };
    fetchValueHelpDefs();
}, [formData.objectType]);

// In the field config form — picker dropdown
<select value={field.valueHelpID || ''} onChange={(e) => onSchemaUpdate(path, name, 'valueHelpID', e.target.value || undefined)}>
    <option value="">None</option>
    {availableValueHelps.map(vh => (
        <option key={vh.valueHelpID} value={vh.valueHelpID}>
            {vh.valueHelpID}{vh.description ? ` — ${vh.description}` : ''}
        </option>
    ))}
</select>
```

### User Side — Review Page

The Review page renders extracted document data. Each field checks if it has a `valueHelpID` assigned in the schema, and if so, renders the appropriate widget instead of a plain text input:

```tsx
import { ValueHelpSelect, ValueHelpComboBox, ValueHelpMultiSelect, ValueHelpSearchInput } from '@cnma/cap-valuehelp/react';
import '@cnma/cap-valuehelp/react/valuehelp.css';

const FieldInput = ({ label, fieldData, path, onChange, valueHelpID, objectType, onBatchFieldUpdate, ...rest }) => {
    const value = fieldData?.value || '';
    const widgetType = uiConfig.widget || 'text';

    // If field has a valueHelpID → render the matching widget
    if (valueHelpID && widgetType === 'select') {
        return (
            <ValueHelpSelect
                value={value}
                onChange={(newVal) => onChange(path, newVal)}
                onBatchFieldUpdate={onBatchFieldUpdate}  // ← Multi-field updates
                objectType={objectType}
                valueHelpID={valueHelpID}
                displayFormat={uiConfig.displayFormat}
                disabled={readonly}
            />
        );
    }

    if (valueHelpID && widgetType === 'searchHelp') {
        return (
            <ValueHelpSearchInput
                value={value}
                onChange={(newVal) => onChange(path, newVal)}
                onBatchFieldUpdate={onBatchFieldUpdate}
                objectType={objectType}
                valueHelpID={valueHelpID}
                disabled={readonly}
            />
        );
    }

    // Fallback: plain text input
    return <input value={value} onChange={(e) => onChange(path, e.target.value)} />;
};
```

### How `onBatchFieldUpdate` Works

The key to **multi-field updates** (e.g., selecting company code also fills company name) is the `onBatchFieldUpdate` callback:

```tsx
// Host app provides this callback at the form level:
const handleBatchFieldUpdate = (updates) => {
    // `updates` is a Record<string, string> from the returnMapping
    // e.g. { companyName: "conarum DE", erpSystemId: "KS4500" }
    Object.entries(updates).forEach(([fieldName, value]) => {
        setFieldValue(fieldName, value);
    });
};

// Pass it down to every FieldInput:
<FieldInput
    valueHelpID={schema.properties[key]?.valueHelpID}
    objectType={objectType}
    onBatchFieldUpdate={handleBatchFieldUpdate}
    // ... other props
/>
```

**Flow:**
1. User selects "1000 - conarum DE" in the `companyCodes` dropdown
2. `ValueHelpSelect` reads the `returnMapping` from the value help definition
3. It finds the matching entry and extracts `{ companyName: "conarum DE", systemID: "KS4500" }`
4. It maps `sourceColumn → targetField` and calls `onBatchFieldUpdate({ companyName: "conarum DE", erpSystemId: "KS4500" })`
5. The host app writes those values into the form

---

## Deep Dive: Cascading Dependencies

Cascading dependencies allow a child dropdown to filter its entries based on a parent field's value. This is commonly used for country → plant, company code → tax code, etc.

### How It Works

```mermaid
sequenceDiagram
    participant User as 👤 User
    participant Parent as Company Code<br>(parent dropdown)
    participant Child as Tax Code<br>(child dropdown)
    participant API as OData Service
    participant Handler as ValueHelpHandler

    User->>Parent: Selects "1000" (conarum DE)
    Parent->>Parent: onChange("1000")
    Note over Parent: Host app stores<br>companyCode = "1000"

    User->>Child: Opens dropdown
    Child->>API: getValueHelp(valueHelpID="taxCodes",<br>dependsOnValue="1000")
    API->>Handler: Reads ValueHelpList config<br>filterColumn = "country"
    Handler->>Handler: Parses staticEntries JSON<br>Filters where country matches<br>company "1000" → "DE"
    Handler-->>Child: Returns only DE tax codes:<br>V0, V1, V2, V3, VN
    Child->>Child: Renders 5 items (not all 12)
    User->>Child: Selects "V1" (19% standard)
```

### Data Setup

**Parent value help** (`companyCodes`) — Each entry has extra columns that can be used for filtering:

```json
[
    { "key": "1000", "text": "conarum DE", "country": "DE", "systemID": "KS4500" },
    { "key": "2000", "text": "conarum VN", "country": "VN", "systemID": "PRD400" },
    { "key": "3000", "text": "conarum JP", "country": "JP", "systemID": "PRD300" }
]
```

**Child value help** (`taxCodes`) — Configuration:

| Field | Value | Meaning |
|---|---|---|
| `dependsOn` | `companyCode` | Name of the parent field |
| `filterColumn` | `country` | Column in **this** list to match against the parent's value |

```json
[
    { "key": "V0", "text": "0% Input Tax (tax-exempt)", "country": "DE" },
    { "key": "V1", "text": "19% Input Tax (standard)",  "country": "DE" },
    { "key": "I0", "text": "0% VAT (tax-exempt)",       "country": "VN" },
    { "key": "I1", "text": "5% VAT (reduced)",          "country": "VN" },
    { "key": "J0", "text": "0% Consumption Tax",        "country": "JP" },
    { "key": "J1", "text": "10% Consumption Tax",       "country": "JP" }
]
```

### Frontend Wiring

The host app must pass the parent field's **current value** as the `dependsOnValue` prop:

```tsx
// The host app knows the current companyCode value
const companyCodeValue = extractedData.companyCode?.value;

<ValueHelpSelect
    objectType="INV"
    valueHelpID="taxCodes"
    value={extractedData.taxCode?.value}
    onChange={(val) => setField('taxCode', val)}
    dependsOnValue={companyCodeValue}   // ← This triggers filtering
/>
```

When `dependsOnValue` changes (e.g., user switches company code), the widget automatically re-fetches filtered entries from the backend.

### Backend Logic (inside ValueHelpHandler)

When the handler receives a `getValueHelp` call with `dependsOnValue`, it:

1. **For static entries** — Filters the JSON array by `filterColumn`:
   ```
   entries.filter(e => e[filterColumn] === dependsOnValue)
   ```

2. **For reference entries** — Adds a WHERE clause to the CDS query:
   ```
   SELECT * FROM ReferenceTable WHERE filterColumn = :dependsOnValue
   ```

### Multi-Level Cascading

You can chain multiple levels. For example:

```
Country → Company Code → Plant → Cost Center
```

Each child just sets `dependsOn` to its immediate parent's field name. The package handles each level independently — there's no explicit "chain" to configure.

| Value Help | `dependsOn` | `filterColumn` |
|---|---|---|
| `countryCodes` | *(none)* | — |
| `companyCodes` | `country` | `country` |
| `plants` | `companyCode` | `companyCode` |
| `costCenters` | `plant` | `plant` |


---

## Development (Contributing to this package)

```bash
git clone <repo-url>
cd cap-valuehelp
npm install
npm run build        # Compile TypeScript (srv + react)
npm run build:srv    # Backend only
npm run build:react  # Frontend only
npm test             # Run tests
```

### Publishing a new version

```bash
# 1. Bump version
npm version patch    # or minor / major

# 2. Publish
npm publish
```

---

## License

UNLICENSED — Internal package for Conarum Development Kit.