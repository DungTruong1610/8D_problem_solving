/**
 * ValueHelpPromptInjector.ts
 * Dual-guard AI prompt injection for F4 Value Help.
 *
 * @cnma/cap-valuehelp — Reusable package version
 *
 * Guard 1 (per-list):  ValueHelpList.injectIntoPrompt must be true
 * Guard 2 (global):    SystemConfiguration.AI_VALUE_HELP_PROMPT_THRESHOLD
 *
 * Reads valueHelpID from schemaStructure fields, injects valid keys
 * into the prompt so the AI produces constrained values.
 */

import cds from '@sap/cds';

const LOG = cds.log('valuehelp-prompt');

/**
 * Configuration options for ValueHelpPromptInjector.
 */
export interface PromptInjectorConfig {
    /** Fully qualified CDS entity name for ValueHelpList */
    valueHelpEntity: string;
    /** Fully qualified CDS entity name for SystemConfiguration (for threshold lookup) */
    systemConfigEntity: string;
    /** Config key name for the prompt threshold. Default: 'AI_VALUE_HELP_PROMPT_THRESHOLD' */
    thresholdKey?: string;
}

export class ValueHelpPromptInjector {

    private config: PromptInjectorConfig;

    constructor(config: PromptInjectorConfig) {
        this.config = config;
    }

    /**
     * Inject value help constraints into prompt parts.
     * Called from ExtractionProcessor after few-shot injection.
     */
    async injectConstraints(
        schema: any,
        promptParts: string[]
    ): Promise<void> {
        try {
            const schemaStructure = this.safeParseJSON(schema.schemaStructure, {});
            if (!schemaStructure || Object.keys(schemaStructure).length === 0) return;

            const db = await cds.connect.to('db');

            // Read global threshold (Guard 2)
            const thresholdKey = this.config.thresholdKey || 'AI_VALUE_HELP_PROMPT_THRESHOLD';
            const thresholdConfig = await db.run(
                SELECT.one.from(this.config.systemConfigEntity)
                    .where({ configKey: thresholdKey })
            );
            const maxEntries = parseInt(thresholdConfig?.configValue || '50', 10);

            let injectedCount = 0;

            // Collect all fields with valueHelpID from the nested schema structure.
            // Schema format: { type: "object", properties: { field: { ..., valueHelpID } } }
            // Line items:    properties.items.items.properties.{ field: { ..., valueHelpID } }
            const fieldsToCheck: Array<[string, any]> = [];

            const headerProps = schemaStructure.properties || schemaStructure;
            for (const [fieldName, fieldDef] of Object.entries(headerProps)) {
                fieldsToCheck.push([fieldName, fieldDef]);
            }

            // Also traverse line item fields (items array → items schema → properties)
            const itemsDef = headerProps.items;
            if (itemsDef?.type === 'array' && itemsDef.items?.properties) {
                for (const [fieldName, fieldDef] of Object.entries(itemsDef.items.properties)) {
                    fieldsToCheck.push([`items.${fieldName}`, fieldDef]);
                }
            }

            LOG.info(`Scanning ${fieldsToCheck.length} field(s) for valueHelpID`);

            for (const [fieldName, fieldDef] of fieldsToCheck) {
                const valueHelpID = (fieldDef as any)?.valueHelpID;
                if (!valueHelpID) continue;

                const list = await db.run(
                    SELECT.one.from(this.config.valueHelpEntity)
                        .where({
                            valueHelpID,
                            objectType: schema.objectType,
                            isActive: true
                        })
                );

                // Guard 1: per-list opt-out
                if (!list || !list.injectIntoPrompt) continue;

                // Only inject static entries (reference tables may be too large)
                if (list.sourceType !== 'static' || !list.staticEntries) continue;

                const entries = this.safeParseJSON(list.staticEntries, []);

                // Guard 2: global threshold
                if (entries.length > maxEntries) {
                    LOG.info(`Skipping prompt injection for ${fieldName}: ${entries.length} entries exceeds threshold ${maxEntries}`);
                    continue;
                }

                const isArray = (fieldDef as any)?.type === 'array';
                const mapping = entries
                    .map((e: any) => `- "${e.text || e.key}" → ${e.key}`)
                    .join('\n');

                promptParts.push(
                    isArray
                        ? `For field "${fieldName}", output an ARRAY of keys from the mapping below:\n${mapping}`
                        : `For field "${fieldName}", you MUST use ONLY one of the values below. Match the document content to the correct key. If no match is found, set value to null:\n${mapping}`
                );

                injectedCount++;
            }

            if (injectedCount > 0) {
                LOG.info(`Injected value help constraints for ${injectedCount} field(s)`);
            }

        } catch (err: any) {
            // Non-fatal: extraction continues without value help constraints
            LOG.warn(`ValueHelp prompt injection skipped: ${err.message}`);
        }
    }

    private safeParseJSON(json: string | null | undefined, fallback: any): any {
        if (!json) return fallback;
        try {
            return JSON.parse(json);
        } catch {
            return fallback;
        }
    }
}
