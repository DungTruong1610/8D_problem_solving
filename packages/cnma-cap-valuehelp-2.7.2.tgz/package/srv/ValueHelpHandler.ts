/**
 * ValueHelpHandler.ts
 * Core handler for F4 Value Help — fetches entries, handles search, validates saves.
 *
 * @cnma/cap-valuehelp — Reusable package version
 *
 * Supports 3 source types:
 *   - static:    Inline JSON entries (staticEntries field)
 *   - reference: Dynamic DB table lookup (referenceTable/keyColumn/textColumn)
 *   - external:  S/4HANA OData or REST endpoint (via consumer-provided fetcher)
 */

import cds from '@sap/cds';

const LOG = cds.log('valuehelp');

/**
 * Configuration options for ValueHelpHandler.
 * Consumers pass these when creating a handler instance to customize entity names
 * and allowed reference tables for their specific app.
 */
/**
 * Result shape returned by the externalFetcher callback.
 * Each row is a flat object with at least the key and text columns.
 */
export interface ExternalFetchResult {
    rows: Record<string, unknown>[];
    total?: number;
}

/**
 * Callback signature for fetching data from an external system (e.g., S/4HANA OData).
 * The consuming app implements this using SAP Cloud SDK, axios, or any HTTP client.
 *
 * @param endpoint - The external endpoint string from the ValueHelpList config
 *                   (e.g., "S4_DEST:/sap/opu/odata/CNMA/INV_SRV/F4_GLAccountSet")
 * @param options  - Filter, pagination, and search parameters
 * @returns Promise resolving to rows + optional total count
 */
export type ExternalFetcher = (
    endpoint: string,
    options: {
        filter?: string;
        defaultFilter?: string;
        dependsOnColumn?: string;
        dependsOnValue?: string;
        searchFilters?: Record<string, string>;
        top?: number;
        skip?: number;
        /** BCP-47 locale from req.locale (e.g. 'de', 'en'). Used as sap-language on S/4 calls. */
        language?: string;
        /** HTTP method — 'GET' (default) or 'POST' */
        method?: string;
        /** JSON template body for POST requests (contains {{variable}} placeholders) */
        payloadTemplate?: string;
        /** Dot-notation path to result array in nested response (e.g. "d.toOpenPurchasingDocument.results.0.toOpenPurchasingDocumentItem.results") */
        responsePath?: string;
        /** Context values from the current row for multi-field dependency (e.g. { companyCode: "1000", purchaseOrderNo: "4500005744" }) */
        contextValues?: Record<string, string>;
    }
) => Promise<ExternalFetchResult>;

export interface ValueHelpConfig {
    /** Fully qualified CDS entity name for ValueHelpList, e.g. 'cnma.clair2.ValueHelpList' */
    entityName: string;
    /** Map of short table names to fully qualified CDS entity names */
    allowedReferenceTables: Record<string, string>;
    /**
     * Optional callback for fetching entries from external systems (sourceType = 'external').
     * If not provided, external source type will return an empty array with a warning.
     */
    externalFetcher?: ExternalFetcher;
}

export class ValueHelpHandler {

    private config: ValueHelpConfig;

    constructor(config: ValueHelpConfig) {
        this.config = config;
    }

    // ──────────────────────────────────────────────
    // getValueHelp — Fetch entries + returnMapping
    // ──────────────────────────────────────────────

    async getValueHelp(req: any): Promise<string> {
        const { objectType, valueHelpID, filter, dependsOnValue } = req.data;
        const language: string | undefined = req.locale || undefined;

        if (!objectType || !valueHelpID) {
            return JSON.stringify({ entries: [], returnMapping: [], config: { disableValidation: false } });
        }

        try {
            const db = await cds.connect.to('db');
            const list = await db.run(
                SELECT.one.from(this.config.entityName)
                    .where({ valueHelpID, objectType, isActive: true })
            );

            if (!list) {
                LOG.warn(`ValueHelp not found: ${valueHelpID} for ${objectType}`);
                return JSON.stringify({ entries: [], returnMapping: [], config: { disableValidation: false } });
            }

            const returnMapping = this.safeParseJSON(list.returnMapping, []);

            let entries: any[] = [];

            switch (list.sourceType) {
                case 'static':
                    entries = this.handleStaticSource(list, filter, dependsOnValue);
                    break;
                case 'reference':
                    entries = await this.handleReferenceSource(db, list, returnMapping, filter, dependsOnValue);
                    break;
                case 'external':
                    entries = await this.handleExternalSource(list, filter, dependsOnValue, language);
                    break;
                default:
                    LOG.warn(`Unknown sourceType: ${list.sourceType}`);
            }

            // Apply displayFormat
            entries = this.applyDisplayFormat(entries, list);

            // Apply sortBy
            entries = this.applySortBy(entries, list.sortBy);

            return JSON.stringify({
                entries,
                returnMapping,
                config: { disableValidation: !!list.disableValidation }
            });

        } catch (err: any) {
            LOG.error(`getValueHelp error: ${err.message}`);
            return JSON.stringify({ entries: [], returnMapping: [], config: { disableValidation: false } });
        }
    }

    // ──────────────────────────────────────────────
    // getValueHelpSearch — Multi-criteria + pagination
    // ──────────────────────────────────────────────

    async getValueHelpSearch(req: any): Promise<string> {
        const { objectType, valueHelpID, filters: filtersJson, columns: columnsJson, top, skip } = req.data;
        const language: string | undefined = req.locale || undefined;

        if (!objectType || !valueHelpID) {
            return JSON.stringify({ data: [], total: 0, returnMapping: [] });
        }

        try {
            const db = await cds.connect.to('db');
            const list = await db.run(
                SELECT.one.from(this.config.entityName)
                    .where({ valueHelpID, objectType, isActive: true })
            );

            if (!list) {
                return JSON.stringify({ data: [], total: 0, returnMapping: [] });
            }

            const returnMapping = this.safeParseJSON(list.returnMapping, []);
            const searchFilters = this.safeParseJSON(filtersJson, {});
            const requestedColumns = this.safeParseJSON(columnsJson, []);
            const pageSize = top || 20;
            const offset = skip || 0;

            if (list.sourceType === 'static') {
                // Search within static entries
                let entries = this.safeParseJSON(list.staticEntries, []);
                entries = this.applySearchFilters(entries, searchFilters, list.dependsOn);
                const total = entries.length;
                const data = entries.slice(offset, offset + pageSize);
                return JSON.stringify({ data, total, returnMapping });
            }

            if (list.sourceType === 'reference') {
                const entityName = this.config.allowedReferenceTables[list.referenceTable];
                if (!entityName) {
                    LOG.error(`Reference table not allowed: ${list.referenceTable}`);
                    return JSON.stringify({ data: [], total: 0, returnMapping: [] });
                }

                // Build column list
                const columns = new Set<string>([list.keyColumn, list.textColumn]);
                for (const m of returnMapping) {
                    columns.add(m.sourceColumn);
                }
                if (requestedColumns.length > 0) {
                    for (const c of requestedColumns) columns.add(c);
                }

                // Build WHERE clause from search filters
                const whereConditions: any[] = [];

                // Default: only return active records (soft-delete support)
                // Only filter by isActive when the target entity actually has this column
                const entityDef = cds.model?.definitions?.[entityName] as any;
                const hasIsActive = entityDef?.elements?.['isActive'] !== undefined;
                if (hasIsActive) {
                    whereConditions.push({ isActive: true });
                }

                // filterColumn scoping
                if (list.filterColumn) {
                    whereConditions.push({ [list.filterColumn]: objectType });
                }

                // Apply search filters (LIKE for string matching)
                for (const [col, val] of Object.entries(searchFilters)) {
                    if (!val || typeof val !== 'string' || !val.trim()) continue;

                    // Special handling for _dependsOn: resolve to actual column name from ValueHelp config
                    if (col === '_dependsOn' && list.dependsOn) {
                        whereConditions.push({ [list.dependsOn]: val });
                    } else if (col !== '_dependsOn') {
                        const tokens = this.tokenizeSearchString(val);
                        if (tokens.length > 0) {
                            // Use SAP CAP CQN (Core Query Notation) array format instead of raw SQL strings.
                            // This safely escapes the column name {ref:[col]} and prevents SQL Injection.
                            const cqnOrCondition: any[] = [];
                            tokens.forEach((t, index) => {
                                if (index > 0) cqnOrCondition.push('OR');
                                cqnOrCondition.push('lower(', { ref: [col] }, ')', 'like', { val: `%${t.toLowerCase()}%` });
                            });
                            
                            whereConditions.push(cqnOrCondition);
                        }
                    }
                }

                // Count total
                let countQuery = SELECT.from(entityName).columns('count(*) as count');
                for (const cond of whereConditions) {
                    countQuery = countQuery.where(cond);
                }
                const countResult = await db.run(countQuery);
                const total = countResult[0]?.count || 0;

                // Fetch paginated data
                try {
                    let dataQuery = SELECT.distinct.from(entityName)
                        .columns(...columns)
                        .limit(pageSize, offset);
                    for (const cond of whereConditions) {
                        dataQuery = dataQuery.where(cond);
                    }
                    const rows = await db.run(dataQuery);

                    const data = rows.map((row: any) => ({
                        key: row[list.keyColumn],
                        text: row[list.textColumn],
                        ...row,
                    }));

                    return JSON.stringify({ data, total, returnMapping });
                } catch (queryErr: any) {
                    LOG.error(`Reference query failed for ${entityName} with columns [${[...columns]}]: ${queryErr.message}`);
                    return JSON.stringify({ data: [], total: 0, returnMapping: [] });
                }
            }

            if (list.sourceType === 'external') {
                // External source: delegate to consumer-provided fetcher
                if (!this.config.externalFetcher) {
                    LOG.warn('External source type requires externalFetcher in config');
                    return JSON.stringify({ data: [], total: 0, returnMapping: [] });
                }

                try {
                    // Parse contextValues from _context search filter or fallback to _dependsOn JSON
                    let contextValues: Record<string, string> | undefined;
                    const contextRaw = searchFilters['_context'] || searchFilters['_dependsOn'];
                    if (contextRaw) {
                        try {
                            const parsed = JSON.parse(contextRaw);
                            if (typeof parsed === 'object' && parsed !== null) {
                                contextValues = parsed;
                            }
                        } catch {
                            // ignore
                        }
                    }

                    const result = await this.config.externalFetcher(list.externalEndpoint || '', {
                        searchFilters,
                        defaultFilter: list.defaultFilter || undefined,
                        dependsOnColumn: list.dependsOn || undefined,
                        dependsOnValue: searchFilters['_dependsOn'] || undefined,
                        top: pageSize,
                        skip: offset,
                        language,
                        method: list.externalMethod || 'GET',
                        payloadTemplate: list.externalPayload || undefined,
                        responsePath: list.externalResponsePath || undefined,
                        contextValues,
                    });

                    const data = result.rows.map((row: any) => ({
                        key: row[list.keyColumn] || '',
                        text: row[list.textColumn] || '',
                        ...row,
                    }));

                    return JSON.stringify({
                        data,
                        total: result.total ?? data.length,
                        returnMapping,
                    });
                } catch (extErr: any) {
                    LOG.error(`External search failed for ${list.externalEndpoint}: ${extErr.message}`);
                    return JSON.stringify({ data: [], total: 0, returnMapping: [] });
                }
            }

            return JSON.stringify({ data: [], total: 0, returnMapping: [] });

        } catch (err: any) {
            LOG.error(`getValueHelpSearch error: ${err.message}`);
            return JSON.stringify({ data: [], total: 0, returnMapping: [] });
        }
    }

    // ──────────────────────────────────────────────
    // beforeSave — Validate JSON fields
    // ──────────────────────────────────────────────

    async beforeSave(req: any): Promise<void> {
        const data = req.data;

        // Validate staticEntries JSON
        if (data.staticEntries) {
            const parsed = this.tryParseJSON(data.staticEntries);
            if (parsed === null) {
                req.error(400, 'staticEntries must be valid JSON array');
                return;
            }
            if (!Array.isArray(parsed)) {
                req.error(400, 'staticEntries must be a JSON array');
                return;
            }
            // Each entry must have key and text
            for (const entry of parsed) {
                if (!('key' in entry) || !('text' in entry)) {
                    req.error(400, 'Each static entry must have "key" and "text" properties');
                    return;
                }
            }
        }

        // Validate returnMapping JSON
        if (data.returnMapping) {
            const parsed = this.tryParseJSON(data.returnMapping);
            if (parsed === null) {
                req.error(400, 'returnMapping must be valid JSON');
                return;
            }
            if (!Array.isArray(parsed)) {
                req.error(400, 'returnMapping must be a JSON array');
                return;
            }
            for (const mapping of parsed) {
                if (!mapping.sourceColumn || !mapping.targetField) {
                    req.error(400, 'Each returnMapping entry must have "sourceColumn" and "targetField"');
                    return;
                }
            }
        }

        // Validate searchConfig JSON
        if (data.searchConfig) {
            const parsed = this.tryParseJSON(data.searchConfig);
            if (parsed === null) {
                req.error(400, 'searchConfig must be valid JSON');
                return;
            }
            // Only enforce required fields if searchConfig has actual content
            if (Object.keys(parsed).length > 0) {
                if (!parsed.title || !parsed.searchFields || !parsed.resultColumns || !parsed.returnField) {
                    req.error(400, 'searchConfig must have title, searchFields, resultColumns, and returnField');
                    return;
                }
            }
        }

        // Validate externalPayload JSON template (for POST external sources)
        if (data.externalPayload) {
            // Replace "{{variable}}" (with optional surrounding quotes) → "__PH__" for valid JSON
            const sanitized = data.externalPayload.replace(/"?\{\{[^}]+\}\}"?/g, '"__PH__"');
            const parsed = this.tryParseJSON(sanitized);
            if (parsed === null) {
                req.error(400, 'externalPayload must be valid JSON (with optional {{variable}} placeholders)');
                return;
            }
        }

        // Validate referenceTable for reference source type (security: prevent SQL injection)
        if (data.sourceType === 'reference' && data.referenceTable) {
            if (!this.config.allowedReferenceTables[data.referenceTable]) {
                req.error(400, `Reference table "${data.referenceTable}" is not allowed. Allowed: ${Object.keys(this.config.allowedReferenceTables).join(', ')}`);
                return;
            }
        }
    }
    // ──────────────────────────────────────────────
    // Source Type Handlers
    // ──────────────────────────────────────────────

    private handleStaticSource(list: any, filter?: string, dependsOnValue?: string): any[] {
        let entries = this.safeParseJSON(list.staticEntries, []);

        // Apply dependsOn filter (use loose string comparison to handle number vs string mismatch)
        if (dependsOnValue && list.dependsOn) {
            const depVal = String(dependsOnValue);
            entries = entries.filter((e: any) =>
                String(e[list.dependsOn]) === depVal || String(e.dependsOnValue) === depVal
            );
        }

        // Apply text filter (typeahead)
        if (filter && filter.trim()) {
            const lowerFilter = filter.toLowerCase();
            entries = entries.filter((e: any) =>
                (e.key && e.key.toLowerCase().includes(lowerFilter)) ||
                (e.text && e.text.toLowerCase().includes(lowerFilter))
            );
        }

        return entries;
    }

    private async handleReferenceSource(
        db: any, list: any, returnMapping: any[],
        filter?: string, dependsOnValue?: string
    ): Promise<any[]> {
        const entityName = this.config.allowedReferenceTables[list.referenceTable];
        if (!entityName) {
            LOG.error(`Reference table not allowed: ${list.referenceTable}`);
            return [];
        }

        // Collect all needed columns
        const columns = new Set<string>([list.keyColumn, list.textColumn]);
        for (const m of returnMapping) {
            columns.add(m.sourceColumn);
        }

        try {
            // Check if entity has isActive column (standard SAP tables like Currencies don't)
            const entityDef = cds.model?.definitions?.[entityName] as any;
            const hasIsActive = entityDef?.elements?.['isActive'] !== undefined;

            let query = SELECT.distinct.from(entityName)
                .columns(...columns)
                .limit(200);

            if (hasIsActive) {
                query = query.where({ isActive: true });
            }

            // filterColumn: scope results by objectType
            if (list.filterColumn) {
                query = query.where({ [list.filterColumn]: list.objectType });
            }

            // dependsOn: filter by parent field value
            if (dependsOnValue && list.dependsOn) {
                query = query.where({ [list.dependsOn]: dependsOnValue });
            }

            // Filter (typeahead) — search both key and text columns
            if (filter && filter.trim()) {
                const lowerFilter = filter.toLowerCase().replace(/'/g, "''");
                query = query.where(
                    `(LOWER(${list.keyColumn}) LIKE '%${lowerFilter}%' OR LOWER(${list.textColumn}) LIKE '%${lowerFilter}%')`
                );
            }

            const rows = await db.run(query);

            return rows.map((row: any) => ({
                key: row[list.keyColumn],
                text: row[list.textColumn],
                ...row,
            }));
        } catch (queryErr: any) {
            LOG.error(`Reference query failed for ${entityName} with columns [${[...columns]}]: ${queryErr.message}`);
            return [];
        }
    }

    private async handleExternalSource(
        list: any, filter?: string, dependsOnValue?: string, language?: string
    ): Promise<any[]> {
        if (!this.config.externalFetcher) {
            LOG.warn('External source type requires externalFetcher in ValueHelpConfig. Returning empty.');
            return [];
        }

        const endpoint = list.externalEndpoint;
        if (!endpoint) {
            LOG.warn(`ValueHelp "${list.valueHelpID}": sourceType is 'external' but no externalEndpoint configured`);
            return [];
        }

        try {
            LOG.info(`Fetching external value help: ${endpoint} (method: ${list.externalMethod || 'GET'})`);

            // Parse contextValues from dependsOnValue if it's JSON, otherwise use as single value
            let contextValues: Record<string, string> | undefined;
            if (dependsOnValue) {
                try {
                    const parsed = JSON.parse(dependsOnValue);
                    if (typeof parsed === 'object' && parsed !== null) {
                        contextValues = parsed;
                    }
                } catch {
                    // Not JSON — single value, keep as dependsOnValue
                }
            }

            const result = await this.config.externalFetcher(endpoint, {
                filter,
                defaultFilter: list.defaultFilter || undefined,
                dependsOnColumn: list.dependsOn || undefined,
                dependsOnValue: dependsOnValue || undefined,
                top: 200,
                language,
                method: list.externalMethod || 'GET',
                payloadTemplate: list.externalPayload || undefined,
                responsePath: list.externalResponsePath || undefined,
                contextValues,
            });

            // Map rows to { key, text, ...extra } format using keyColumn/textColumn
            return result.rows.map((row: any) => ({
                key: row[list.keyColumn] || '',
                text: row[list.textColumn] || '',
                ...row,
            }));
        } catch (err: any) {
            LOG.error(`External fetch failed for "${list.valueHelpID}" (${endpoint}): ${err.message}`);
            return [];
        }
    }

    // ──────────────────────────────────────────────
    // Formatting & Sorting
    // ──────────────────────────────────────────────

    private applyDisplayFormat(entries: any[], list: any): any[] {
        const format = list.displayFormat || 'keyAndText';

        return entries.map(entry => {
            const formatted = { ...entry };
            const key = String(entry.key);
            switch (format) {
                case 'keyOnly':
                    formatted.text = key;
                    break;
                case 'textOnly':
                    // Keep text as-is (from textColumn or static text)
                    break;
                case 'keyAndText':
                default:
                    // Only reformat if text doesn't already contain the full "key - " prefix.
                    // Using just startsWith(key) caused false positives (e.g. key "D", text "Discounts").
                    const prefix = `${key} - `;
                    if (entry.text && !entry.text.startsWith(prefix)) {
                        formatted.text = prefix + entry.text;
                    }
                    break;
            }
            return formatted;
        });
    }

    private applySortBy(entries: any[], sortBy?: string): any[] {
        const field = sortBy || 'text';
        return [...entries].sort((a, b) => {
            const aVal = (a[field] || '').toString().toLowerCase();
            const bVal = (b[field] || '').toString().toLowerCase();
            return aVal.localeCompare(bVal);
        });
    }

    // ──────────────────────────────────────────────
    // Search Helpers
    // ──────────────────────────────────────────────

    private applySearchFilters(entries: any[], filters: Record<string, string>, dependsOnColumn?: string): any[] {
        let result = entries;
        for (const [col, val] of Object.entries(filters)) {
            if (!val || typeof val !== 'string' || !val.trim()) continue;

            // Special handling for _dependsOn: resolve to actual column name and use exact match
            if (col === '_dependsOn' && dependsOnColumn) {
                result = result.filter((e: any) =>
                    e[dependsOnColumn] && e[dependsOnColumn].toString() === val
                );
            } else if (col !== '_dependsOn') {
                const tokens = this.tokenizeSearchString(val).map(t => t.toLowerCase());
                if (tokens.length > 0) {
                    result = result.filter((e: any) => {
                        const fieldVal = e[col]?.toString().toLowerCase();
                        return fieldVal && tokens.some(token => fieldVal.includes(token));
                    });
                }
            }
        }
        return result;
    }

    // ──────────────────────────────────────────────
    // ──────────────────────────────────────────────
    // Utilities
    // ──────────────────────────────────────────────

    private tokenizeSearchString(val: string): string[] {
        if (!val || typeof val !== 'string') return [];
        return val.split(/[,\n\t;]+/).map(t => t.trim()).filter(Boolean);
    }

    private safeParseJSON(json: string | null | undefined, fallback: any): any {
        if (!json) return fallback;
        try {
            return JSON.parse(json);
        } catch {
            LOG.warn(`Failed to parse JSON: ${json.substring(0, 100)}`);
            return fallback;
        }
    }

    private tryParseJSON(json: string): any | null {
        try {
            return JSON.parse(json);
        } catch {
            return null;
        }
    }
}
