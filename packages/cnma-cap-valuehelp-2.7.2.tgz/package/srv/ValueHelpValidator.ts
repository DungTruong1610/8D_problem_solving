/**
 * ValueHelpValidator.ts
 * Post-extraction validation — checks extracted values against value help lists.
 * Logs WARNINGS only — never blocks or rejects extraction results.
 *
 * @cnma/cap-valuehelp — Reusable package version
 */

import cds from '@sap/cds';

const LOG = cds.log('valuehelp-validator');

/**
 * Configuration options for ValueHelpValidator.
 */
export interface ValidatorConfig {
    /** Fully qualified CDS entity name for ValueHelpList */
    valueHelpEntity: string;
}

export class ValueHelpValidator {

    private config: ValidatorConfig;

    constructor(config: ValidatorConfig) {
        this.config = config;
    }

    /**
     * Validate extracted data against value help definitions.
     * Returns an array of warning messages for invalid values.
     *
     * @param schema - The ObjectSchema entity
     * @param extractedData - The extracted JSON data
     * @param logCallback - Optional log function for processing logs
     */
    async validate(
        schema: any,
        extractedData: any,
        logCallback?: (msg: string, level?: 'Info' | 'Warning' | 'Error') => Promise<void>
    ): Promise<string[]> {
        const warnings: string[] = [];

        try {
            const schemaStructure = this.safeParseJSON(schema.schemaStructure, {});
            if (!schemaStructure || Object.keys(schemaStructure).length === 0) return warnings;
            if (!extractedData) return warnings;

            const db = await cds.connect.to('db');

            for (const [fieldName, fieldDef] of Object.entries(schemaStructure)) {
                const valueHelpID = (fieldDef as any)?.valueHelpID;
                if (!valueHelpID) continue;

                const extractedValue = extractedData[fieldName];
                if (!extractedValue) continue; // No value to validate

                const list = await db.run(
                    SELECT.one.from(this.config.valueHelpEntity)
                        .where({
                            valueHelpID,
                            objectType: schema.objectType,
                            isActive: true
                        })
                );

                if (!list) continue; // No list to validate against

                // Only validate static entries (reference tables require DB lookup)
                if (list.sourceType !== 'static' || !list.staticEntries) continue;

                const entries = this.safeParseJSON(list.staticEntries, []);
                if (entries.length === 0) continue;

                const validKeys = entries.map((e: any) => e.key);
                const isArray = (fieldDef as any)?.type === 'array';

                if (isArray && Array.isArray(extractedValue)) {
                    // Validate each element in array
                    const invalidValues = extractedValue.filter(
                        (v: any) => !validKeys.includes(v)
                    );
                    if (invalidValues.length > 0) {
                        const msg = `[ValueHelp] Field "${fieldName}": extracted values [${invalidValues.join(', ')}] not in valid list [${validKeys.join(', ')}]`;
                        warnings.push(msg);
                        if (logCallback) await logCallback(msg, 'Warning');
                    }
                } else if (typeof extractedValue === 'string') {
                    // Validate single value
                    if (!validKeys.includes(extractedValue)) {
                        const msg = `[ValueHelp] Field "${fieldName}": extracted value "${extractedValue}" not in valid list [${validKeys.join(', ')}]`;
                        warnings.push(msg);
                        if (logCallback) await logCallback(msg, 'Warning');
                    }
                }
            }

            if (warnings.length > 0) {
                LOG.info(`ValueHelp validation found ${warnings.length} warning(s)`);
            }

        } catch (err: any) {
            // Non-fatal: log error but don't block extraction
            LOG.warn(`ValueHelp validation skipped: ${err.message}`);
        }

        return warnings;
    }

    private safeParseJSON(json: string | null | undefined, fallback: any): any {
        if (!json) return fallback;
        try {
            return JSON.parse(json);
        } catch {
            return fallback;
        }
    }
}
