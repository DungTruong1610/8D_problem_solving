# @cnma/cap-identity

Reusable **Shadow Directory & Identity** module for SAP CAP applications.

Provides JIT (Just-In-Time) user provisioning, group management, SAML group sync, and identity resolution — extracted from the Flexible Request Management (FRM) project.

## Features

- **Shadow Directory** — `ShadowUsers`, `ShadowGroups`, `GroupMembers`, `SupportTypes` entities
- **JIT Provisioning** — Auto-creates user records on first login from IDP (IAS/XSUAA)
- **SAML Group Sync** — Bi-directional sync of SAML group claims to local group memberships
- **Email Change Recovery** — Handles IDP email changes via stable `idpUserId` (user_uuid)
- **Identity Service** — REST endpoints: `me()`, `resolveGroupMembers()`, `getUserGroups()`
- **managedWithUser Aspect** — Optional UUID-based `createdBy`/`modifiedBy` FK to ShadowUsers
- **User Resolver** — Cached IDP user → ShadowUser UUID resolution (single + bulk)

## Installation

```bash
npm install @cnma/cap-identity
```

## Quick Start

### 1. Import CDS Entities

In your `db/schema.cds`:

```cds
using { cnma.identity.ShadowUsers }      from '@cnma/cap-identity/db/identity';
using { cnma.identity.ShadowGroups }      from '@cnma/cap-identity/db/identity';
using { cnma.identity.GroupMembers }       from '@cnma/cap-identity/db/identity';
using { cnma.identity.SupportTypes }       from '@cnma/cap-identity/db/identity';
using { cnma.identity.SamlGroupMappings }  from '@cnma/cap-identity/db/identity';
```

Optional — if you want UUID-based audit fields:

```cds
using { cnma.identity.managedWithUser } from '@cnma/cap-identity/db/common';

entity MyEntity : cuid, managedWithUser {
    title : String;
}
```

### 2. Expose in Your Service

In your `srv/service.cds`:

```cds
using { cnma.identity.ShadowUsers as id_ShadowUsers } from '@cnma/cap-identity/db/identity';

service MyService {
    @readonly entity ShadowUsers as projection on id_ShadowUsers;
}
```

### 3. Register JIT Provisioning

In your `srv/service.ts`:

```typescript
import { IdentityProvisioner } from '@cnma/cap-identity/srv';

export default class MyService extends cds.ApplicationService {
    async init() {
        // Auto-provision users on every request
        this.before('*', async (req) => {
            if (req.user?.id) await IdentityProvisioner.provisionUser(req.user);
        });

        await super.init();
    }
}
```

### 4. (Optional) Identity Service Endpoint

The package ships a CDS service definition at `/identity`. To use it, ensure the consuming app references it:

```cds
// In your app, the IdentityService is auto-discovered from the package
```

Register the handler in your `srv/server.ts`:

```typescript
import cds from '@sap/cds';
import { IdentityServiceHandler } from '@cnma/cap-identity/srv';

cds.on('served', (services) => {
    for (const srv of services) {
        if (srv.name === 'IdentityService') {
            const handler = new IdentityServiceHandler(srv as cds.ApplicationService);
            handler.register();
        }
    }
});
```

### 5. (Optional) ManagedUserHandler

Only if you use the `managedWithUser` aspect:

```typescript
import { ManagedUserHandler } from '@cnma/cap-identity/srv';

export default class MyService extends cds.ApplicationService {
    async init() {
        const managedUserHandler = new ManagedUserHandler(this);
        managedUserHandler.register();
        await super.init();
    }
}
```

## React Admin UI

The package includes a self-contained **Organization Management** admin page for managing the Shadow Directory.

### 6. Add Admin UI to Your App

```tsx
import { OrganizationManager } from '@cnma/cap-identity/react';
import '@cnma/cap-identity/react/identity.css';

// Provide your HTTP client (works with fetch, axios, etc.)
const httpClient = {
    get: (url: string) => fetch(url).then(r => r.json()),
    post: (url: string, data: any) => fetch(url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data)
    }).then(r => r.json()),
    patch: (url: string, data: any) => fetch(url, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data)
    }).then(r => r.json()),
    delete: (url: string) => fetch(url, { method: 'DELETE' }),
};

function AdminPage() {
    return (
        <OrganizationManager
            httpClient={httpClient}
            baseUrl="/odata/v4/admin"
            onError={(msg) => console.error(msg)}
            onSuccess={(msg) => console.log(msg)}
        />
    );
}
```

### React Components

| Component | Description |
|-----------|-------------|
| `OrganizationManager` | Full admin page with 4 tabs (Principal Types, Users, Groups, SAML Mappings) |
| `SupportTypesTab` | Toggle principal types on/off |
| `UsersTab` | Read-only list of JIT-provisioned users with search |
| `GroupsTab` | Full CRUD for groups + member management slide-in panel |
| `SamlMappingsTab` | Map external SAML groups to local groups |
| `GroupMembersPanel` | Slide-in panel for adding/removing group members |

### CSS

Import the stylesheet in your app:
```typescript
import '@cnma/cap-identity/react/identity.css';
```

All CSS classes are prefixed with `ci-` to avoid collisions with your app's styles.

---

## API Reference

### `IdentityProvisioner` (Static Class)

| Method | Description |
|--------|-------------|
| `provisionUser(user)` | JIT-provision or update a ShadowUser from CAP user context |
| `getOrigin(user)` | Extract IDP origin from JWT |
| `getIdpUserId(user)` | Extract stable IDP user UUID from JWT |
| `getShadowUser(userId, origin?)` | Look up a ShadowUser by IDP credentials |
| `getUserGroupIds(shadowUserId)` | Get all group IDs a user belongs to |
| `syncSamlGroups(shadowUser, capUser)` | Sync SAML group memberships |

### `IdentityServiceHandler`

Register on an `ApplicationService` to handle `me()`, `resolveGroupMembers()`, `getUserGroups()`.

### `ManagedUserHandler`

Register on an `ApplicationService` to auto-set `createdBy_ID`/`modifiedBy_ID` to ShadowUser UUIDs.

### `UserResolverHelper`

| Method | Description |
|--------|-------------|
| `resolveUserUUID(userId, origin?)` | Resolve IDP user to ShadowUser UUID (cached) |
| `resolveMultipleUsers(userIds, origin?)` | Bulk resolve (cached) |
| `clearCache()` | Clear in-memory cache |

## CDS Entities

| Entity | Description |
|--------|-------------|
| `ShadowUsers` | IDP-synced user records (JIT-provisioned) |
| `ShadowGroups` | Admin-managed groups (teams, departments, roles) |
| `GroupMembers` | User ↔ Group membership (with source tracking: MANUAL/SAML) |
| `SupportTypes` | Configurable principal types (USER, GROUP, TEAM, etc.) |
| `SamlGroupMappings` | Maps external SAML groups to local ShadowGroups |

## Namespace

All entities use the `cnma.identity` namespace.

## Build

```bash
npm run build          # Compiles both srv and react → dist/
npm run build:srv      # Compiles srv/*.ts → dist/srv/
npm run build:react    # Compiles react/**/*.tsx → dist/react/
```

## Publish

```bash
npm publish      # Publishes to @cnma scope on Azure DevOps feed
```
