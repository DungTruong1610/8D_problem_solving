/**
 * @cnma/cap-identity — Common Aspects
 *
 * Usage in consuming apps:
 *   using { cnma.identity.managedWithUser } from '@cnma/cap-identity/db/common';
 *
 * Provides a custom managed aspect that uses UUID references to ShadowUsers
 * instead of the default string-based user IDs from @sap/cds/common.
 */
namespace cnma.identity;

using { cnma.identity.ShadowUsers } from './identity';

// ----------------------------------------------------------------------------
// Custom Managed Aspect with UUID-Based User References
// ----------------------------------------------------------------------------

/**
 * Custom managed aspect that uses UUID references to ShadowUsers
 * instead of the default string-based user IDs.
 *
 * This provides:
 * - Referential integrity (FK to ShadowUsers)
 * - Easy JOINs for display name resolution
 * - Consistent with ownerId/principalId pattern
 *
 * The ManagedUserHandler automatically resolves the user UUID
 * from req.user.id on CREATE/UPDATE operations.
 *
 * Note: This is opt-in. Consumers who prefer standard `managed` (string-based)
 * can simply not import this aspect.
 */
aspect managedWithUser {
    createdAt  : Timestamp @cds.on.insert: $now;
    createdBy  : Association to ShadowUsers;
    modifiedAt : Timestamp @cds.on.insert: $now @cds.on.update: $now;
    modifiedBy : Association to ShadowUsers;
}
