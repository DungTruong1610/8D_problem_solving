/**
 * @cnma/cap-identity — i18n resource injection
 *
 * Safely injects the `identity` namespace resources into the shared i18next
 * singleton WITHOUT calling .init() again (which would override the consuming
 * app's namespace, fallbackLng, and plugin chain).
 *
 * Usage (consuming app's i18n.ts):
 *   import '@cnma/cap-identity/react/i18n';   // side-effect: adds identity ns
 *
 * Components inside cap-identity use:
 *   const { t } = useTranslation('identity');
 */

import i18n from 'i18next';
import { initReactI18next } from 'react-i18next';
import en from './locales/en.json';
import de from './locales/de.json';
import ja from './locales/ja.json';

const addIdentityResources = () => {
    i18n.addResourceBundle('en', 'identity', en, true, false);
    i18n.addResourceBundle('de', 'identity', de, true, false);
    i18n.addResourceBundle('ja', 'identity', ja, true, false);
};

if (i18n.isInitialized) {
    // App already called .init() — just inject resources into existing instance
    addIdentityResources();
} else {
    // Standalone mode (no consuming app) — initialize minimally
    i18n
        .use(initReactI18next)
        .init({
            fallbackLng: 'en',
            ns: ['identity'],
            defaultNS: 'identity',
            interpolation: { escapeValue: false },
            resources: {
                en: { identity: en },
                de: { identity: de },
                ja: { identity: ja },
            },
        });
}

export default i18n;