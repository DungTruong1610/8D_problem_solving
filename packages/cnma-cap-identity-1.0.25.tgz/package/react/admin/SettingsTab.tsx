import { useState, useEffect } from 'react';
import { useTranslation } from 'react-i18next';
import { Plus, MoreVertical, Pencil, Trash2, Loader2, Palette, Globe, Users } from 'lucide-react';
import type { Theme, Language } from '../types';
import type { IdentityAdminService } from '../services/IdentityAdminService';
import { Button } from '@cnma/react-ui';
import { Input } from '@cnma/react-ui';
import { Label } from '@cnma/react-ui';
import { Badge } from '@cnma/react-ui';
import {
    Select,
    SelectTrigger,
    SelectValue,
    SelectContent,
    SelectItem,
} from '@cnma/react-ui';
import {
    Dialog,
    DialogContent,
    DialogHeader,
    DialogTitle,
    DialogDescription,
    DialogFooter,
} from '@cnma/react-ui';
import { Table, TableHeader, TableBody, TableHead, TableRow, TableCell } from '@cnma/react-ui';
import { cn } from '@cnma/react-ui';

interface SettingsTabProps {
    service: IdentityAdminService;
    onError?: (msg: string) => void;
    onSuccess?: (msg: string) => void;
}

/**
 * SettingsTab — Admin UI for managing Themes, Languages, and User Settings.
 * Organized in two sections: Visual Settings (Themes) and Language Settings (Languages).
 */
export function SettingsTab({ service, onError, onSuccess }: SettingsTabProps) {
    const { t } = useTranslation('identity');
    const [activeSection, setActiveSection] = useState<'themes' | 'languages'>('themes');

    return (
        <div className="space-y-6">
            {/* Section Toggle */}
            <div className="flex gap-1 bg-muted p-1 rounded-lg w-fit" role="tablist">
                <button
                    role="tab"
                    aria-selected={activeSection === 'themes'}
                    className={cn(
                        'flex items-center gap-2 px-4 py-2 text-sm font-medium rounded-md transition-all',
                        activeSection === 'themes'
                            ? 'bg-card text-primary shadow-sm'
                            : 'text-muted-foreground hover:text-foreground'
                    )}
                    onClick={() => setActiveSection('themes')}
                >
                    <Palette className="size-4" />
                    {t('settings.tabs.themes')}
                </button>
                <button
                    role="tab"
                    aria-selected={activeSection === 'languages'}
                    className={cn(
                        'flex items-center gap-2 px-4 py-2 text-sm font-medium rounded-md transition-all',
                        activeSection === 'languages'
                            ? 'bg-card text-primary shadow-sm'
                            : 'text-muted-foreground hover:text-foreground'
                    )}
                    onClick={() => setActiveSection('languages')}
                >
                    <Globe className="size-4" />
                    {t('settings.tabs.languages')}
                </button>
            </div>

            {activeSection === 'themes' && <ThemesSection service={service} onError={onError} onSuccess={onSuccess} />}
            {activeSection === 'languages' && <LanguagesSection service={service} onError={onError} onSuccess={onSuccess} />}
        </div>
    );
}

// ----------------------------------------------------------------------------
// Themes Section
// ----------------------------------------------------------------------------

function ThemesSection({ service, onError, onSuccess }: Omit<SettingsTabProps, 'onError' | 'onSuccess'> & { onError?: SettingsTabProps['onError']; onSuccess?: SettingsTabProps['onSuccess'] }) {
    const { t } = useTranslation('identity');
    const [themes, setThemes] = useState<Theme[]>([]);
    const [isLoading, setIsLoading] = useState(true);

    const [showCreateDialog, setShowCreateDialog] = useState(false);
    const [editingTheme, setEditingTheme] = useState<Theme | null>(null);
    const [deletingTheme, setDeletingTheme] = useState<Theme | null>(null);
    const [isSaving, setIsSaving] = useState(false);

    // Form state
    const [formCode, setFormCode] = useState('');
    const [formName, setFormName] = useState('');
    const [formDesc, setFormDesc] = useState('');
    const [formIcon, setFormIcon] = useState('');
    const [formSortOrder, setFormSortOrder] = useState('0');

    useEffect(() => { loadThemes(); }, []);

    async function loadThemes() {
        try {
            setIsLoading(true);
            const data = await service.getThemes();
            setThemes(data);
        } catch {
            onError?.(t('errors.loadFailed', { item: 'themes' }));
        } finally {
            setIsLoading(false);
        }
    }

    function openCreateDialog() {
        setFormCode('');
        setFormName('');
        setFormDesc('');
        setFormIcon('');
        setFormSortOrder('0');
        setShowCreateDialog(true);
    }

    function openEditDialog(theme: Theme) {
        setEditingTheme(theme);
        setFormCode(theme.code);
        setFormName(theme.name);
        setFormDesc(theme.description || '');
        setFormIcon(theme.icon || '');
        setFormSortOrder(String(theme.sortOrder || 0));
    }

    async function handleSave() {
        if (!formCode.trim() || !formName.trim()) return;
        try {
            setIsSaving(true);
            const payload = {
                code: formCode.trim(),
                name: formName.trim(),
                description: formDesc.trim() || null,
                icon: formIcon.trim() || null,
                sortOrder: parseInt(formSortOrder) || 0,
                isEnabled: true,
            };

            if (editingTheme) {
                await service.updateTheme(editingTheme.ID, payload);
                onSuccess?.(t('settings.themes.updateSuccess', { name: formName }));
                setEditingTheme(null);
            } else {
                await service.createTheme(payload);
                onSuccess?.(t('settings.themes.createSuccess', { name: formName }));
                setShowCreateDialog(false);
            }
            loadThemes();
        } catch (error: any) {
            onError?.(error?.message || t('settings.themes.saveFailed'));
        } finally {
            setIsSaving(false);
        }
    }

    async function handleDelete() {
        if (!deletingTheme) return;
        try {
            await service.deleteTheme(deletingTheme.ID);
            onSuccess?.(t('settings.themes.deleteSuccess', { name: deletingTheme.name }));
            setDeletingTheme(null);
            loadThemes();
        } catch (error: any) {
            onError?.(error?.message || t('settings.themes.deleteFailed'));
        }
    }

    const isDialogOpen = showCreateDialog || !!editingTheme;

    return (
        <div className="space-y-4">
            <div className="rounded-lg border bg-muted/50 p-4">
                <p className="text-sm text-muted-foreground">
                    {t('settings.themes.description')}
                </p>
            </div>

            <div className="flex items-center justify-between">
                <span className="text-sm text-muted-foreground">
                    {t('settings.themes.themeCount', { count: themes.length })}
                </span>
                <Button size="sm" onClick={openCreateDialog}>
                    <Plus className="size-4" /> {t('settings.themes.add')}
                </Button>
            </div>

            <div className="rounded-lg border bg-card overflow-visible">
                <Table>
                    <TableHeader>
                        <TableRow>
                            <TableHead className="w-[50px]">{t('settings.themes.columns.icon')}</TableHead>
                            <TableHead>{t('settings.themes.columns.name')}</TableHead>
                            <TableHead>{t('settings.themes.columns.code')}</TableHead>
                            <TableHead>{t('settings.themes.columns.description')}</TableHead>
                            <TableHead className="w-[80px]">{t('settings.themes.columns.order')}</TableHead>
                            <TableHead className="w-[80px]">{t('settings.themes.columns.status')}</TableHead>
                            <TableHead className="w-[50px]"></TableHead>
                        </TableRow>
                    </TableHeader>
                    <TableBody>
                        {isLoading ? (
                            [1, 2, 3].map(i => (
                                <TableRow key={i}>
                                    <TableCell colSpan={7}><div className="h-10 bg-muted rounded animate-pulse" /></TableCell>
                                </TableRow>
                            ))
                        ) : themes.length === 0 ? (
                            <TableRow>
                                <TableCell colSpan={7} className="text-center py-8 text-muted-foreground">
                                    {t('settings.themes.noThemes')}
                                </TableCell>
                            </TableRow>
                        ) : (
                            themes.map(theme => (
                                <TableRow key={theme.ID}>
                                    <TableCell>
                                        <div className="size-8 rounded-lg bg-primary/10 flex items-center justify-center text-sm">
                                            {theme.icon || '🎨'}
                                        </div>
                                    </TableCell>
                                    <TableCell>
                                        <span className="font-medium text-foreground">{theme.name}</span>
                                    </TableCell>
                                    <TableCell>
                                        <Badge variant="secondary">{theme.code}</Badge>
                                    </TableCell>
                                    <TableCell>
                                        <span className="text-sm text-muted-foreground">{theme.description || '—'}</span>
                                    </TableCell>
                                    <TableCell>
                                        <span className="text-sm text-muted-foreground">{theme.sortOrder}</span>
                                    </TableCell>
                                    <TableCell>
                                        <Badge
                                            className={cn(
                                                'text-xs',
                                                theme.isEnabled
                                                    ? 'bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-400'
                                                    : 'bg-gray-100 text-gray-500'
                                            )}
                                        >
                                            {theme.isEnabled ? t('settings.themes.status.enabled') : t('settings.themes.status.disabled')}
                                        </Badge>
                                    </TableCell>
                                    <TableCell>
                                        <div className="relative">
                                            <Button variant="ghost" size="icon" onClick={() => openEditDialog(theme)}>
                                                <Pencil className="size-4" />
                                            </Button>
                                            <Button variant="ghost" size="icon" onClick={() => setDeletingTheme(theme)}>
                                                <Trash2 className="size-4" />
                                            </Button>
                                        </div>
                                    </TableCell>
                                </TableRow>
                            ))
                        )}
                    </TableBody>
                </Table>
            </div>

            {/* Create/Edit Dialog */}
            <Dialog open={isDialogOpen} onOpenChange={(open) => { if (!open) { setShowCreateDialog(false); setEditingTheme(null); } }}>
                <DialogContent className="sm:max-w-md">
                    <DialogHeader>
                        <DialogTitle>{editingTheme ? t('settings.themes.dialog.editTitle') : t('settings.themes.dialog.createTitle')}</DialogTitle>
                        <DialogDescription>
                            {editingTheme ? t('settings.themes.dialog.editDescription') : t('settings.themes.dialog.createDescription')}
                        </DialogDescription>
                    </DialogHeader>
                    <div className="space-y-4 py-2">
                        <div className="grid grid-cols-2 gap-4">
                            <div>
                                <Label className="text-xs text-muted-foreground mb-1">{t('settings.themes.dialog.codeLabel')}</Label>
                                <Input value={formCode} onChange={e => setFormCode(e.target.value)} placeholder={t('settings.themes.dialog.codePlaceholder')} disabled={!!editingTheme} />
                                <p className="text-xs text-muted-foreground mt-1">{t('settings.themes.dialog.codeNote')}</p>
                            </div>
                            <div>
                                <Label className="text-xs text-muted-foreground mb-1">{t('settings.themes.dialog.displayNameLabel')}</Label>
                                <Input value={formName} onChange={e => setFormName(e.target.value)} placeholder={t('settings.themes.dialog.displayNamePlaceholder')} />
                            </div>
                        </div>
                        <div>
                            <Label className="text-xs text-muted-foreground mb-1">{t('settings.themes.dialog.descriptionLabel')}</Label>
                            <Input value={formDesc} onChange={e => setFormDesc(e.target.value)} placeholder={t('settings.themes.dialog.descriptionPlaceholder')} />
                        </div>
                        <div className="grid grid-cols-2 gap-4">
                            <div>
                                <Label className="text-xs text-muted-foreground mb-1">{t('settings.themes.dialog.iconLabel')}</Label>
                                <Input value={formIcon} onChange={e => setFormIcon(e.target.value)} placeholder={t('settings.themes.dialog.iconPlaceholder')} />
                                <p className="text-xs text-muted-foreground mt-1">{t('settings.themes.dialog.iconNote')}</p>
                            </div>
                            <div>
                                <Label className="text-xs text-muted-foreground mb-1">{t('settings.themes.dialog.sortOrderLabel')}</Label>
                                <Input type="number" value={formSortOrder} onChange={e => setFormSortOrder(e.target.value)} />
                            </div>
                        </div>
                    </div>
                    <DialogFooter>
                        <Button variant="outline" onClick={() => { setShowCreateDialog(false); setEditingTheme(null); }}>{t('common.cancel')}</Button>
                        <Button onClick={handleSave} disabled={isSaving || !formCode.trim() || !formName.trim()}>
                            {isSaving && <Loader2 className="size-4 animate-spin" />}
                            {editingTheme ? t('settings.themes.dialog.saveChanges') : t('settings.themes.dialog.addTheme')}
                        </Button>
                    </DialogFooter>
                </DialogContent>
            </Dialog>

            {/* Delete Confirmation */}
            <Dialog open={!!deletingTheme} onOpenChange={(open) => { if (!open) setDeletingTheme(null); }}>
                <DialogContent className="sm:max-w-md">
                    <DialogHeader>
                        <DialogTitle className="flex items-center gap-2">
                            <span className="size-8 rounded-full bg-destructive/10 flex items-center justify-center">
                                <Trash2 className="size-4 text-destructive" />
                            </span>
                            {t('settings.themes.deleteTitle')}
                        </DialogTitle>
                        <DialogDescription>{t('settings.themes.deleteConfirm')}</DialogDescription>
                    </DialogHeader>
                    <div className="py-2">
                        <p className="text-sm text-foreground">
                            {t('settings.themes.deleteActionConfirm', { name: deletingTheme?.name })}
                        </p>
                        <p className="text-sm text-muted-foreground mt-1">
                            {t('settings.themes.deleteWarning')}
                        </p>
                    </div>
                    <DialogFooter>
                        <Button variant="outline" onClick={() => setDeletingTheme(null)}>{t('common.cancel')}</Button>
                        <Button variant="destructive" onClick={handleDelete}>{t('settings.themes.deleteAction')}</Button>
                    </DialogFooter>
                </DialogContent>
            </Dialog>
        </div>
    );
}

// ----------------------------------------------------------------------------
// Languages Section
// ----------------------------------------------------------------------------

function LanguagesSection({ service, onError, onSuccess }: Omit<SettingsTabProps, 'onError' | 'onSuccess'> & { onError?: SettingsTabProps['onError']; onSuccess?: SettingsTabProps['onSuccess'] }) {
    const { t } = useTranslation('identity');
    const [languages, setLanguages] = useState<Language[]>([]);
    const [isLoading, setIsLoading] = useState(true);

    const [showCreateDialog, setShowCreateDialog] = useState(false);
    const [editingLanguage, setEditingLanguage] = useState<Language | null>(null);
    const [deletingLanguage, setDeletingLanguage] = useState<Language | null>(null);
    const [isSaving, setIsSaving] = useState(false);

    // Form state
    const [formCode, setFormCode] = useState('');
    const [formName, setFormName] = useState('');
    const [formNativeName, setFormNativeName] = useState('');
    const [formSortOrder, setFormSortOrder] = useState('0');

    useEffect(() => { loadLanguages(); }, []);

    async function loadLanguages() {
        try {
            setIsLoading(true);
            const data = await service.getLanguages();
            setLanguages(data);
        } catch {
            onError?.(t('errors.loadFailed', { item: 'languages' }));
        } finally {
            setIsLoading(false);
        }
    }

    function openCreateDialog() {
        setFormCode('');
        setFormName('');
        setFormNativeName('');
        setFormSortOrder('0');
        setShowCreateDialog(true);
    }

    function openEditDialog(language: Language) {
        setEditingLanguage(language);
        setFormCode(language.code);
        setFormName(language.name);
        setFormNativeName(language.nativeName || '');
        setFormSortOrder(String(language.sortOrder || 0));
    }

    async function handleSave() {
        if (!formCode.trim() || !formName.trim()) return;
        try {
            setIsSaving(true);
            const payload = {
                code: formCode.trim(),
                name: formName.trim(),
                nativeName: formNativeName.trim() || null,
                sortOrder: parseInt(formSortOrder) || 0,
                isEnabled: true,
            };

            if (editingLanguage) {
                await service.updateLanguage(editingLanguage.ID, payload);
                onSuccess?.(t('settings.languages.updateSuccess', { name: formName }));
                setEditingLanguage(null);
            } else {
                await service.createLanguage(payload);
                onSuccess?.(t('settings.languages.createSuccess', { name: formName }));
                setShowCreateDialog(false);
            }
            loadLanguages();
        } catch (error: any) {
            onError?.(error?.message || t('settings.languages.saveFailed'));
        } finally {
            setIsSaving(false);
        }
    }

    async function handleDelete() {
        if (!deletingLanguage) return;
        try {
            await service.deleteLanguage(deletingLanguage.ID);
            onSuccess?.(t('settings.languages.deleteSuccess', { name: deletingLanguage.name }));
            setDeletingLanguage(null);
            loadLanguages();
        } catch (error: any) {
            onError?.(error?.message || t('settings.languages.deleteFailed'));
        }
    }

    const isDialogOpen = showCreateDialog || !!editingLanguage;

    return (
        <div className="space-y-4">
            <div className="rounded-lg border bg-muted/50 p-4">
                <p className="text-sm text-muted-foreground">
                    {t('settings.languages.description')}
                </p>
            </div>

            <div className="flex items-center justify-between">
                <span className="text-sm text-muted-foreground">
                    {t('settings.languages.languageCount', { count: languages.length })}
                </span>
                <Button size="sm" onClick={openCreateDialog}>
                    <Plus className="size-4" /> {t('settings.languages.add')}
                </Button>
            </div>

            <div className="rounded-lg border bg-card overflow-visible">
                <Table>
                    <TableHeader>
                        <TableRow>
                            <TableHead>{t('settings.languages.columns.language')}</TableHead>
                            <TableHead>{t('settings.languages.columns.code')}</TableHead>
                            <TableHead>{t('settings.languages.columns.nativeName')}</TableHead>
                            <TableHead className="w-[80px]">{t('settings.languages.columns.order')}</TableHead>
                            <TableHead className="w-[90px]">{t('settings.languages.columns.status')}</TableHead>
                            <TableHead className="w-[50px]"></TableHead>
                        </TableRow>
                    </TableHeader>
                    <TableBody>
                        {isLoading ? (
                            [1, 2, 3].map(i => (
                                <TableRow key={i}>
                                    <TableCell colSpan={6}><div className="h-10 bg-muted rounded animate-pulse" /></TableCell>
                                </TableRow>
                            ))
                        ) : languages.length === 0 ? (
                            <TableRow>
                                <TableCell colSpan={6} className="text-center py-8 text-muted-foreground">
                                    {t('settings.languages.noLanguages')}
                                </TableCell>
                            </TableRow>
                        ) : (
                            languages.map(lang => (
                                <TableRow key={lang.ID}>
                                    <TableCell>
                                        <span className="font-medium text-foreground">{lang.name}</span>
                                    </TableCell>
                                    <TableCell>
                                        <Badge variant="secondary">{lang.code}</Badge>
                                    </TableCell>
                                    <TableCell>
                                        <span className="text-sm text-muted-foreground">{lang.nativeName || '—'}</span>
                                    </TableCell>
                                    <TableCell>
                                        <span className="text-sm text-muted-foreground">{lang.sortOrder}</span>
                                    </TableCell>
                                    <TableCell>
                                        <Badge
                                            className={cn(
                                                'text-xs',
                                                lang.isEnabled
                                                    ? 'bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-400'
                                                    : 'bg-gray-100 text-gray-500'
                                            )}
                                        >
                                            {lang.isEnabled ? t('settings.languages.status.enabled') : t('settings.languages.status.disabled')}
                                        </Badge>
                                    </TableCell>
                                    <TableCell>
                                        <div className="relative flex gap-1">
                                            <Button variant="ghost" size="icon" onClick={() => openEditDialog(lang)}>
                                                <Pencil className="size-4" />
                                            </Button>
                                            <Button variant="ghost" size="icon" onClick={() => setDeletingLanguage(lang)}>
                                                <Trash2 className="size-4" />
                                            </Button>
                                        </div>
                                    </TableCell>
                                </TableRow>
                            ))
                        )}
                    </TableBody>
                </Table>
            </div>

            {/* Create/Edit Dialog */}
            <Dialog open={isDialogOpen} onOpenChange={(open) => { if (!open) { setShowCreateDialog(false); setEditingLanguage(null); } }}>
                <DialogContent className="sm:max-w-md">
                    <DialogHeader>
                        <DialogTitle>{editingLanguage ? t('settings.languages.dialog.editTitle') : t('settings.languages.dialog.createTitle')}</DialogTitle>
                        <DialogDescription>
                            {editingLanguage ? t('settings.languages.dialog.editDescription') : t('settings.languages.dialog.createDescription')}
                        </DialogDescription>
                    </DialogHeader>
                    <div className="space-y-4 py-2">
                        <div className="grid grid-cols-2 gap-4">
                            <div>
                                <Label className="text-xs text-muted-foreground mb-1">{t('settings.languages.dialog.codeLabel')}</Label>
                                <Input value={formCode} onChange={e => setFormCode(e.target.value)} placeholder={t('settings.languages.dialog.codePlaceholder')} disabled={!!editingLanguage} />
                                <p className="text-xs text-muted-foreground mt-1">{t('settings.languages.dialog.codeNote')}</p>
                            </div>
                            <div>
                                <Label className="text-xs text-muted-foreground mb-1">{t('settings.languages.dialog.displayNameLabel')}</Label>
                                <Input value={formName} onChange={e => setFormName(e.target.value)} placeholder={t('settings.languages.dialog.displayNamePlaceholder')} />
                            </div>
                        </div>
                        <div className="grid grid-cols-2 gap-4">
                            <div>
                                <Label className="text-xs text-muted-foreground mb-1">{t('settings.languages.dialog.nativeNameLabel')}</Label>
                                <Input value={formNativeName} onChange={e => setFormNativeName(e.target.value)} placeholder={t('settings.languages.dialog.nativeNamePlaceholder')} />
                                <p className="text-xs text-muted-foreground mt-1">{t('settings.languages.dialog.nativeNameNote')}</p>
                            </div>
                            <div>
                                <Label className="text-xs text-muted-foreground mb-1">{t('settings.languages.dialog.sortOrderLabel')}</Label>
                                <Input type="number" value={formSortOrder} onChange={e => setFormSortOrder(e.target.value)} />
                            </div>
                        </div>
                    </div>
                    <DialogFooter>
                        <Button variant="outline" onClick={() => { setShowCreateDialog(false); setEditingLanguage(null); }}>{t('common.cancel')}</Button>
                        <Button onClick={handleSave} disabled={isSaving || !formCode.trim() || !formName.trim()}>
                            {isSaving && <Loader2 className="size-4 animate-spin" />}
                            {editingLanguage ? t('settings.languages.dialog.saveChanges') : t('settings.languages.dialog.addLanguage')}
                        </Button>
                    </DialogFooter>
                </DialogContent>
            </Dialog>

            {/* Delete Confirmation */}
            <Dialog open={!!deletingLanguage} onOpenChange={(open) => { if (!open) setDeletingLanguage(null); }}>
                <DialogContent className="sm:max-w-md">
                    <DialogHeader>
                        <DialogTitle className="flex items-center gap-2">
                            <span className="size-8 rounded-full bg-destructive/10 flex items-center justify-center">
                                <Trash2 className="size-4 text-destructive" />
                            </span>
                            {t('settings.languages.deleteTitle')}
                        </DialogTitle>
                        <DialogDescription>{t('settings.languages.deleteConfirm')}</DialogDescription>
                    </DialogHeader>
                    <div className="py-2">
                        <p className="text-sm text-foreground">
                            {t('settings.languages.deleteActionConfirm', { name: deletingLanguage?.name })}
                        </p>
                        <p className="text-sm text-muted-foreground mt-1">
                            {t('settings.languages.deleteWarning')}
                        </p>
                    </div>
                    <DialogFooter>
                        <Button variant="outline" onClick={() => setDeletingLanguage(null)}>{t('common.cancel')}</Button>
                        <Button variant="destructive" onClick={handleDelete}>{t('settings.languages.deleteAction')}</Button>
                    </DialogFooter>
                </DialogContent>
            </Dialog>
        </div>
    );
}
