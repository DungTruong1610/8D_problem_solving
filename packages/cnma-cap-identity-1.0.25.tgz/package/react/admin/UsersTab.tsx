import { useState, useEffect, useMemo } from 'react';
import { useTranslation } from 'react-i18next';
import { Search, Clock, User, MoreVertical, UserX, UserCheck, Upload } from 'lucide-react';
import type { ShadowUser } from '../types';
import type { IdentityAdminService } from '../services/IdentityAdminService';
import { Input } from '@cnma/react-ui';
import { Badge } from '@cnma/react-ui';
import { Button } from '@cnma/react-ui';
import { Table, TableHeader, TableBody, TableHead, TableRow, TableCell } from '@cnma/react-ui';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from '@cnma/react-ui';
import { UserImportDialog } from './UserImportDialog';
import { cn } from '@cnma/react-ui';

interface UsersTabProps {
    service: IdentityAdminService;
    onError?: (msg: string) => void;
    onSuccess?: (msg: string) => void;
}

const MAX_VISIBLE_GROUPS = 3;

const GROUP_COLORS = [
    'bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-400',
    'bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-400',
    'bg-purple-100 text-purple-700 dark:bg-purple-900/30 dark:text-purple-400',
    'bg-amber-100 text-amber-700 dark:bg-amber-900/30 dark:text-amber-400',
    'bg-rose-100 text-rose-700 dark:bg-rose-900/30 dark:text-rose-400',
    'bg-cyan-100 text-cyan-700 dark:bg-cyan-900/30 dark:text-cyan-400',
    'bg-indigo-100 text-indigo-700 dark:bg-indigo-900/30 dark:text-indigo-400',
    'bg-teal-100 text-teal-700 dark:bg-teal-900/30 dark:text-teal-400',
];

function getGroupColor(groupId: string): string {
    let hash = 0;
    for (let i = 0; i < groupId.length; i++) {
        hash = (hash * 31 + groupId.charCodeAt(i)) | 0;
    }
    return GROUP_COLORS[Math.abs(hash) % GROUP_COLORS.length];
}

/**
 * UsersTab — Display JIT-provisioned users from the Shadow Directory.
 * Supports deactivating / reactivating users.
 */
export function UsersTab({ service, onError, onSuccess }: UsersTabProps) {
    const { t } = useTranslation('identity');
    const [users, setUsers] = useState<ShadowUser[]>([]);
    const [isLoading, setIsLoading] = useState(true);
    const [searchQuery, setSearchQuery] = useState('');
    const [openMenuId, setOpenMenuId] = useState<string | null>(null);
    const [confirmUser, setConfirmUser] = useState<ShadowUser | null>(null);
    const [isSaving, setIsSaving] = useState(false);
    const [showImport, setShowImport] = useState(false);

    useEffect(() => { loadUsers(); }, []);

    async function loadUsers() {
        try {
            setIsLoading(true);
            const data = await service.getShadowUsers();
            setUsers(data);
        } catch (error) {
            onError?.(t('errors.loadFailed', { item: 'users' }));
        } finally {
            setIsLoading(false);
        }
    }

    async function handleToggleStatus() {
        if (!confirmUser) return;
        try {
            setIsSaving(true);
            const newStatus = !confirmUser.isActive;
            await service.updateShadowUser(confirmUser.ID, { isActive: newStatus });
            const label = confirmUser.displayName || confirmUser.email || confirmUser.userId;
            onSuccess?.(newStatus
                ? t('users.reactivateSuccess', { name: label })
                : t('users.deactivateSuccess', { name: label })
            );
            setConfirmUser(null);
            loadUsers();
        } catch (error: any) {
            onError?.(error?.message || t('errors.updateFailed', { item: 'user' }));
        } finally {
            setIsSaving(false);
        }
    }

    const filteredUsers = useMemo(() => {
        if (!searchQuery.trim()) return users;
        const query = searchQuery.toLowerCase();
        return users.filter(user =>
            user.displayName?.toLowerCase().includes(query) ||
            user.email?.toLowerCase().includes(query) ||
            user.userId?.toLowerCase().includes(query) ||
            user.memberships?.some(m => m.group?.name?.toLowerCase().includes(query))
        );
    }, [users, searchQuery]);

    function formatDate(dateStr?: string): string {
        if (!dateStr) return t('common.never');
        return new Date(dateStr).toLocaleDateString('en-US', {
            month: 'short', day: 'numeric', year: 'numeric',
            hour: '2-digit', minute: '2-digit'
        });
    }

    return (
        <div className="space-y-4">
            <div className="rounded-lg border bg-muted/50 p-4">
                <p className="text-sm text-muted-foreground">
                    {t('users.description')}
                </p>
            </div>

            {/* Toolbar */}
            <div className="flex items-center gap-3">
                <div className="relative max-w-sm flex-1">
                    <Search className="absolute left-3 top-1/2 -translate-y-1/2 size-4 text-muted-foreground" />
                    <Input
                        type="text"
                        placeholder={t('users.searchPlaceholder')}
                        value={searchQuery}
                        onChange={(e) => setSearchQuery(e.target.value)}
                        className="pl-9"
                    />
                </div>
                <span className="text-sm text-muted-foreground whitespace-nowrap">
                    {t('users.userCount', { count: filteredUsers.length })}
                </span>
                <Button size="sm" variant="outline" onClick={() => setShowImport(true)}>
                    <Upload className="size-4" /> {t('users.import')}
                </Button>
            </div>

            {/* Table */}
            <div className="rounded-lg border bg-card overflow-visible">
                {isLoading ? (
                    <div className="p-4 space-y-3">
                        {[1, 2, 3, 4].map(i => (
                            <div key={i} className="h-12 bg-muted rounded animate-pulse" />
                        ))}
                    </div>
                ) : (
                    <Table>
                        <TableHeader>
                            <TableRow>
                                <TableHead>{t('users.columns.user')}</TableHead>
                                <TableHead>{t('users.columns.groups')}</TableHead>
                                <TableHead className="w-[150px]">{t('users.columns.idpOrigin')}</TableHead>
                                <TableHead className="w-[120px]">{t('users.columns.status')}</TableHead>
                                <TableHead className="w-[200px]">{t('users.columns.lastLogin')}</TableHead>
                                <TableHead className="w-[50px]"></TableHead>
                            </TableRow>
                        </TableHeader>
                        <TableBody>
                            {filteredUsers.length === 0 ? (
                                <TableRow>
                                    <TableCell colSpan={6} className="text-center py-8 text-muted-foreground">
                                        {searchQuery ? t('users.noResults') : t('users.noUsersYet')}
                                    </TableCell>
                                </TableRow>
                            ) : (
                                filteredUsers.map(user => {
                                    const groups = user.memberships
                                        ?.filter(m => m.group)
                                        .map(m => m.group!) || [];
                                    const visibleGroups = groups.slice(0, MAX_VISIBLE_GROUPS);
                                    const overflowCount = groups.length - MAX_VISIBLE_GROUPS;

                                    return (
                                        <TableRow key={user.ID} className={cn(!user.isActive && 'opacity-60')}>
                                            <TableCell>
                                                <div className="flex items-center gap-3">
                                                    <div className="size-9 rounded-full bg-muted flex items-center justify-center shrink-0">
                                                        <User className="size-4 text-muted-foreground" />
                                                    </div>
                                                    <div>
                                                        <div className="font-medium text-foreground">
                                                            {user.displayName || `${user.firstName || ''} ${user.lastName || ''}`.trim() || t('common.unknown')}
                                                        </div>
                                                        <div className="text-sm text-muted-foreground">{user.email || user.userId}</div>
                                                    </div>
                                                </div>
                                            </TableCell>
                                            <TableCell>
                                                {groups.length === 0 ? (
                                                    <span className="text-xs text-muted-foreground italic">—</span>
                                                ) : (
                                                    <div className="flex items-center gap-1 flex-wrap">
                                                        {visibleGroups.map(g => (
                                                            <span
                                                                key={g.ID}
                                                                className={cn(
                                                                    'inline-flex items-center px-2 py-0.5 rounded-full text-[11px] font-medium whitespace-nowrap',
                                                                    getGroupColor(g.ID)
                                                                )}
                                                                title={g.name}
                                                            >
                                                                {g.name}
                                                            </span>
                                                        ))}
                                                        {overflowCount > 0 && (
                                                            <span
                                                                className="inline-flex items-center px-1.5 py-0.5 rounded-full text-[10px] font-medium bg-muted text-muted-foreground"
                                                                title={groups.slice(MAX_VISIBLE_GROUPS).map(g => g.name).join(', ')}
                                                            >
                                                                +{overflowCount}
                                                            </span>
                                                        )}
                                                    </div>
                                                )}
                                            </TableCell>
                                            <TableCell>
                                                <Badge variant="secondary">
                                                    {user.origin || 'sap.default'}
                                                </Badge>
                                            </TableCell>
                                            <TableCell>
                                                <Badge
                                                    variant={user.isActive ? 'default' : 'destructive'}
                                                    className="text-[10px]"
                                                >
                                                    {user.isActive ? t('users.status.active') : t('users.status.inactive')}
                                                </Badge>
                                            </TableCell>
                                            <TableCell className="text-muted-foreground">
                                                <div className="flex items-center gap-1.5">
                                                    <Clock className="size-3.5" />
                                                    {formatDate(user.lastLoginAt)}
                                                </div>
                                            </TableCell>
                                            <TableCell>
                                                <div className="relative">
                                                    <Button
                                                        variant="ghost"
                                                        size="icon"
                                                        onClick={() => setOpenMenuId(openMenuId === user.ID ? null : user.ID)}
                                                    >
                                                        <MoreVertical className="size-4" />
                                                    </Button>
                                                    {openMenuId === user.ID && (
                                                        <>
                                                            <div className="fixed inset-0 z-10" onClick={() => setOpenMenuId(null)} />
                                                            <div className="absolute right-0 top-full mt-1 z-20 bg-popover border rounded-md shadow-md min-w-[160px] py-1">
                                                                {user.isActive ? (
                                                                    <button
                                                                        className="flex items-center gap-2 w-full px-3 py-2 text-sm hover:bg-destructive/10 text-destructive text-left"
                                                                        onClick={() => { setConfirmUser(user); setOpenMenuId(null); }}
                                                                    >
                                                                        <UserX className="size-3.5" /> {t('users.deactivate')}
                                                                    </button>
                                                                ) : (
                                                                    <button
                                                                        className="flex items-center gap-2 w-full px-3 py-2 text-sm hover:bg-accent text-left"
                                                                        onClick={() => { setConfirmUser(user); setOpenMenuId(null); }}
                                                                    >
                                                                        <UserCheck className="size-3.5" /> {t('users.reactivate')}
                                                                    </button>
                                                                )}
                                                            </div>
                                                        </>
                                                    )}
                                                </div>
                                            </TableCell>
                                        </TableRow>
                                    );
                                })
                            )}
                        </TableBody>
                    </Table>
                )}
            </div>

            {/* Import Dialog */}
            {showImport && (
                <UserImportDialog
                    service={service}
                    onClose={() => setShowImport(false)}
                    onDone={() => { setShowImport(false); loadUsers(); onSuccess?.(t('import.doneSuccess')); }}
                    onError={onError}
                />
            )}

            {/* Deactivate / Reactivate Confirmation Dialog */}
            <Dialog open={!!confirmUser} onOpenChange={(open) => { if (!open) setConfirmUser(null); }}>
                <DialogContent className="sm:max-w-md">
                    <DialogHeader>
                        <DialogTitle className="flex items-center gap-2">
                            {confirmUser?.isActive ? (
                                <>
                                    <span className="size-8 rounded-full bg-destructive/10 flex items-center justify-center">
                                        <UserX className="size-4 text-destructive" />
                                    </span>
                                    {t('users.deactivateTitle')}
                                </>
                            ) : (
                                <>
                                    <span className="size-8 rounded-full bg-green-100 dark:bg-green-900/30 flex items-center justify-center">
                                        <UserCheck className="size-4 text-green-700 dark:text-green-400" />
                                    </span>
                                    {t('users.reactivateTitle')}
                                </>
                            )}
                        </DialogTitle>
                        <DialogDescription>
                            {confirmUser?.isActive ? t('users.deactivateConfirm') : t('users.reactivateConfirm')}
                        </DialogDescription>
                    </DialogHeader>

                    <div className="py-2 space-y-2">
                        <p className="text-sm text-foreground">
                            {confirmUser?.isActive ? (
                                <>
                                    {t('users.deactivateActionConfirm', { name: confirmUser?.displayName || confirmUser?.email || confirmUser?.userId })}
                                </>
                            ) : (
                                <>
                                    {t('users.reactivateActionConfirm', { name: confirmUser?.displayName || confirmUser?.email || confirmUser?.userId })}
                                </>
                            )}
                        </p>
                        {confirmUser?.isActive && (
                            <p className="text-sm text-muted-foreground">
                                {t('users.deactivateWarning')}
                            </p>
                        )}
                    </div>

                    <DialogFooter>
                        <Button variant="outline" onClick={() => setConfirmUser(null)}>
                            {t('common.cancel')}
                        </Button>
                        {confirmUser?.isActive ? (
                            <Button variant="destructive" onClick={handleToggleStatus} disabled={isSaving}>
                                {t('users.deactivateAction')}
                            </Button>
                        ) : (
                            <Button onClick={handleToggleStatus} disabled={isSaving}>
                                {t('users.reactivateAction')}
                            </Button>
                        )}
                    </DialogFooter>
                </DialogContent>
            </Dialog>
        </div>
    );
}