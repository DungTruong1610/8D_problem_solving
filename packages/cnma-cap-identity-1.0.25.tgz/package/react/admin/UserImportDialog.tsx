import { useState, useRef, useCallback } from 'react';
import { useTranslation } from 'react-i18next';
import { Upload, Download, X, CheckCircle2, AlertCircle, Info, Loader2, FileText } from 'lucide-react';
import type { IdentityAdminService } from '../services/IdentityAdminService';
import { Button } from '@cnma/react-ui';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from '@cnma/react-ui';
import { Table, TableHeader, TableBody, TableHead, TableRow, TableCell } from '@cnma/react-ui';
import { cn } from '@cnma/react-ui';

interface ImportRow {
    email: string;
    firstName: string;
    lastName: string;
    displayName: string;
    groups: string;
    origin: string;
    _error?: string; // client-side validation error
}

interface ImportResult {
    email: string;
    status: 'created' | 'exists' | 'error';
    message: string;
}

interface UserImportDialogProps {
    service: IdentityAdminService;
    onClose: () => void;
    onDone: () => void; // reload parent list
    onError?: (msg: string) => void;
}

type Step = 'upload' | 'preview' | 'importing' | 'results';

const CSV_TEMPLATE = [
    'email,firstName,lastName,displayName,groups,origin',
    'john.doe@company.com,John,Doe,,ACCOUNTANT;PURCHASER,sap.default',
    'jane.smith@company.com,Jane,Smith,Jane S.,ACCOUNTANT,azure-ad',
].join('\n');

const REQUIRED_HEADERS = ['email'];
const KNOWN_HEADERS = ['email', 'firstname', 'lastname', 'displayname', 'groups', 'origin'];

/** Minimal CSV parser — handles quoted fields containing commas. */
function parseCsv(text: string): { headers: string[]; rows: Record<string, string>[] } {
    const lines = text.replace(/\r\n/g, '\n').replace(/\r/g, '\n').trim().split('\n');
    if (lines.length === 0) return { headers: [], rows: [] };

    function splitLine(line: string): string[] {
        const fields: string[] = [];
        let field = '';
        let inQuotes = false;
        for (let i = 0; i < line.length; i++) {
            const ch = line[i];
            if (ch === '"') {
                if (inQuotes && line[i + 1] === '"') { field += '"'; i++; }
                else inQuotes = !inQuotes;
            } else if (ch === ',' && !inQuotes) {
                fields.push(field.trim()); field = '';
            } else {
                field += ch;
            }
        }
        fields.push(field.trim());
        return fields;
    }

    const headers = splitLine(lines[0]).map(h => h.toLowerCase());
    const rows = lines.slice(1).filter(l => l.trim()).map(line => {
        const values = splitLine(line);
        return Object.fromEntries(headers.map((h, i) => [h, values[i] ?? '']));
    });
    return { headers, rows };
}

function downloadTemplate() {
    const blob = new Blob([CSV_TEMPLATE], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'users_import_template.csv';
    a.click();
    URL.revokeObjectURL(url);
}

export function UserImportDialog({ service, onClose, onDone, onError }: UserImportDialogProps) {
    const { t } = useTranslation('identity');
    const [step, setStep] = useState<Step>('upload');
    const [isDragging, setIsDragging] = useState(false);
    const [fileName, setFileName] = useState('');
    const [rows, setRows] = useState<ImportRow[]>([]);
    const [results, setResults] = useState<ImportResult[]>([]);
    const [parseError, setParseError] = useState('');
    const fileInputRef = useRef<HTMLInputElement>(null);

    const processFile = useCallback((file: File) => {
        if (!file.name.endsWith('.csv')) {
            setParseError(t('import.errors.csvOnly'));
            return;
        }
        setParseError('');
        setFileName(file.name);

        const reader = new FileReader();
        reader.onload = (e) => {
            const text = e.target?.result as string;
            const { headers, rows: rawRows } = parseCsv(text);

            // Validate required headers
            const missing = REQUIRED_HEADERS.filter(h => !headers.includes(h));
            if (missing.length > 0) {
                setParseError(t('import.errors.missingColumns', { missing: missing.join(', ') }));
                return;
            }

            const parsed: ImportRow[] = rawRows.map(r => {
                const email = (r['email'] || '').trim().toLowerCase();
                const row: ImportRow = {
                    email,
                    firstName:   (r['firstname']   || r['first_name']   || '').trim(),
                    lastName:    (r['lastname']    || r['last_name']    || '').trim(),
                    displayName: (r['displayname'] || r['display_name'] || '').trim(),
                    groups:      (r['groups'] || '').trim(),
                    origin:      (r['origin'] || '').trim(),
                };
                if (!email) row._error = t('import.errors.emailRequired');
                else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) row._error = t('import.errors.invalidEmail');
                return row;
            });

            if (parsed.length === 0) {
                setParseError(t('import.errors.noDataRows'));
                return;
            }

            setRows(parsed);
            setStep('preview');
        };
        reader.readAsText(file);
    }, []);

    const handleDrop = useCallback((e: React.DragEvent) => {
        e.preventDefault();
        setIsDragging(false);
        const file = e.dataTransfer.files[0];
        if (file) processFile(file);
    }, [processFile]);

    const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const file = e.target.files?.[0];
        if (file) processFile(file);
        e.target.value = '';
    };

    async function handleImport() {
        const validRows = rows.filter(r => !r._error);
        if (validRows.length === 0) return;

        setStep('importing');
        try {
            const res = await service.importUsers(validRows.map(r => ({
                email: r.email,
                firstName:   r.firstName   || undefined,
                lastName:    r.lastName    || undefined,
                displayName: r.displayName || undefined,
                groups:      r.groups      || undefined,
                origin:      r.origin      || undefined,
            })));
            setResults(res);
            setStep('results');
            onDone();
        } catch (err: any) {
            onError?.(err?.message || t('import.errors.importFailed'));
            setStep('preview');
        }
    }

    const validCount   = rows.filter(r => !r._error).length;
    const invalidCount = rows.filter(r => !!r._error).length;

    // ── Results summary ──────────────────────────────────────────────────
    const createdCount = results.filter(r => r.status === 'created').length;
    const existsCount  = results.filter(r => r.status === 'exists').length;
    const errorCount   = results.filter(r => r.status === 'error').length;

    return (
        <Dialog open onOpenChange={(open) => { if (!open) onClose(); }}>
            <DialogContent className="sm:max-w-2xl max-h-[90vh] flex flex-col">
                <DialogHeader>
                    <DialogTitle className="flex items-center gap-2">
                        <Upload className="size-5" />
                        {t('import.title')}
                    </DialogTitle>
                    <DialogDescription>
                        {step === 'upload'    && t('import.steps.upload')}
                        {step === 'preview'   && t('import.steps.preview', { count: rows.length })}
                        {step === 'importing' && t('import.steps.importing')}
                        {step === 'results'   && t('import.steps.results', { created: createdCount, exists: existsCount, errors: errorCount })}
                    </DialogDescription>
                </DialogHeader>

                {/* ── UPLOAD STEP ─────────────────────────────────────────────── */}
                {step === 'upload' && (
                    <div className="space-y-4 py-2 flex-1">
                        {/* Template download */}
                        <div className="flex items-start gap-3 rounded-lg border bg-muted/40 p-3">
                            <Info className="size-4 text-muted-foreground mt-0.5 shrink-0" />
                            <div className="text-sm text-muted-foreground space-y-1">
                                <p>
                                    CSV columns: <code className="text-xs bg-muted px-1 py-0.5 rounded">email</code>{' '}
                                    <span className="text-xs">(required)</span>,{' '}
                                    <code className="text-xs bg-muted px-1 py-0.5 rounded">firstName</code>,{' '}
                                    <code className="text-xs bg-muted px-1 py-0.5 rounded">lastName</code>,{' '}
                                    <code className="text-xs bg-muted px-1 py-0.5 rounded">displayName</code>,{' '}
                                    <code className="text-xs bg-muted px-1 py-0.5 rounded">groups</code>,{' '}
                                    <code className="text-xs bg-muted px-1 py-0.5 rounded">origin</code>
                                </p>
                                <p>For <code className="text-xs bg-muted px-1 py-0.5 rounded">groups</code>, separate multiple group names with a semicolon: <code className="text-xs bg-muted px-1 py-0.5 rounded">ACCOUNTANT;PURCHASER</code>. <code className="text-xs bg-muted px-1 py-0.5 rounded">origin</code> defaults to <code className="text-xs bg-muted px-1 py-0.5 rounded">sap.default</code> if left empty.</p>
                            </div>
                            <Button variant="outline" size="sm" className="shrink-0" onClick={downloadTemplate}>
                                <Download className="size-3.5" /> {t('import.template.download')}
                            </Button>
                        </div>

                        {/* Drop zone */}
                        <div
                            className={cn(
                                'border-2 border-dashed rounded-lg p-10 text-center cursor-pointer transition-colors',
                                isDragging ? 'border-primary bg-primary/5' : 'border-muted-foreground/25 hover:border-primary/50 hover:bg-muted/30'
                            )}
                            onDragOver={(e) => { e.preventDefault(); setIsDragging(true); }}
                            onDragLeave={() => setIsDragging(false)}
                            onDrop={handleDrop}
                            onClick={() => fileInputRef.current?.click()}
                        >
                            <input ref={fileInputRef} type="file" accept=".csv" className="hidden" onChange={handleFileChange} />
                            <FileText className="size-10 mx-auto mb-3 text-muted-foreground/50" />
                            <p className="text-sm font-medium text-foreground">{t('import.dropzone.title')}</p>
                            <p className="text-xs text-muted-foreground mt-1">{t('import.dropzone.subtitle')}</p>
                        </div>

                        {parseError && (
                            <div className="flex items-center gap-2 text-sm text-destructive rounded-lg border border-destructive/30 bg-destructive/5 px-3 py-2">
                                <AlertCircle className="size-4 shrink-0" />
                                {parseError}
                            </div>
                        )}
                    </div>
                )}

                {/* ── PREVIEW STEP ────────────────────────────────────────────── */}
                {step === 'preview' && (
                    <div className="flex-1 min-h-0 flex flex-col space-y-3 py-2">
                        {/* Summary bar */}
                        <div className="flex items-center gap-4 text-sm">
                            <span className="text-muted-foreground">{fileName}</span>
                            <span className="text-green-700 dark:text-green-400 font-medium">{t('import.preview.valid', { count: validCount })}</span>
                            {invalidCount > 0 && (
                                <span className="text-destructive font-medium">{t('import.preview.withErrors', { count: invalidCount })}</span>
                            )}
                        </div>

                        {/* Preview table */}
                        <div className="flex-1 min-h-0 overflow-auto rounded-lg border">
                            <Table>
                                <TableHeader>
                                    <TableRow>
                                        <TableHead className="w-6"></TableHead>
                                        <TableHead>{t('import.columns.email')}</TableHead>
                                        <TableHead>{t('import.columns.firstName')}</TableHead>
                                        <TableHead>{t('import.columns.lastName')}</TableHead>
                                        <TableHead>{t('import.columns.displayName')}</TableHead>
                                        <TableHead>{t('import.columns.groups')}</TableHead>
                                        <TableHead>{t('import.columns.origin')}</TableHead>
                                    </TableRow>
                                </TableHeader>
                                <TableBody>
                                    {rows.map((row, i) => (
                                        <TableRow key={i} className={cn(row._error && 'bg-destructive/5')}>
                                            <TableCell className="pr-0">
                                                {row._error
                                                    ? <span title={row._error}><AlertCircle className="size-3.5 text-destructive" /></span>
                                                    : <CheckCircle2 className="size-3.5 text-green-600 dark:text-green-400" />
                                                }
                                            </TableCell>
                                            <TableCell className="font-mono text-xs">
                                                {row.email || <span className="text-destructive italic">empty</span>}
                                                {row._error && <div className="text-[10px] text-destructive">{row._error}</div>}
                                            </TableCell>
                                            <TableCell className="text-xs">{row.firstName || <span className="text-muted-foreground">—</span>}</TableCell>
                                            <TableCell className="text-xs">{row.lastName  || <span className="text-muted-foreground">—</span>}</TableCell>
                                            <TableCell className="text-xs">{row.displayName || <span className="text-muted-foreground">—</span>}</TableCell>
                                            <TableCell className="text-xs">
                                                {row.groups
                                                    ? row.groups.split(';').map((g, gi) => (
                                                        <span key={gi} className="inline-flex items-center px-1.5 py-0.5 rounded bg-muted text-[10px] font-medium mr-1">{g.trim()}</span>
                                                    ))
                                                    : <span className="text-muted-foreground">—</span>
                                                }
                                            </TableCell>
                                            <TableCell className="font-mono text-xs">
                                                {row.origin || <span className="text-muted-foreground">sap.default</span>}
                                            </TableCell>
                                        </TableRow>
                                    ))}
                                </TableBody>
                            </Table>
                        </div>
                    </div>
                )}

                {/* ── IMPORTING STEP ──────────────────────────────────────────── */}
                {step === 'importing' && (
                    <div className="flex-1 flex flex-col items-center justify-center gap-3 py-10">
                        <Loader2 className="size-10 animate-spin text-primary" />
                        <p className="text-sm text-muted-foreground">{t('import.importing', { count: validCount })}</p>
                    </div>
                )}

                {/* ── RESULTS STEP ────────────────────────────────────────────── */}
                {step === 'results' && (
                    <div className="flex-1 min-h-0 flex flex-col space-y-3 py-2">
                        {/* Summary chips */}
                        <div className="flex gap-3">
                            <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-green-100 dark:bg-green-900/30 text-green-700 dark:text-green-400 text-sm font-medium">
                                <CheckCircle2 className="size-4" /> {t('import.results.created', { count: createdCount })}
                            </div>
                            {existsCount > 0 && (
                                <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-muted text-muted-foreground text-sm font-medium">
                                    <Info className="size-4" /> {t('import.results.alreadyExisted', { count: existsCount })}
                                </div>
                            )}
                            {errorCount > 0 && (
                                <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-destructive/10 text-destructive text-sm font-medium">
                                    <AlertCircle className="size-4" /> {t('import.results.errors', { count: errorCount })}
                                </div>
                            )}
                        </div>

                        {/* Detailed results */}
                        <div className="flex-1 min-h-0 overflow-auto rounded-lg border">
                            <Table>
                                <TableHeader>
                                    <TableRow>
                                        <TableHead className="w-6"></TableHead>
                                        <TableHead>{t('import.results.email')}</TableHead>
                                        <TableHead>{t('import.results.message')}</TableHead>
                                    </TableRow>
                                </TableHeader>
                                <TableBody>
                                    {results.map((r, i) => (
                                        <TableRow key={i}>
                                            <TableCell>
                                                {r.status === 'created' && <CheckCircle2 className="size-3.5 text-green-600 dark:text-green-400" />}
                                                {r.status === 'exists'  && <Info className="size-3.5 text-muted-foreground" />}
                                                {r.status === 'error'   && <AlertCircle className="size-3.5 text-destructive" />}
                                            </TableCell>
                                            <TableCell className="font-mono text-xs">{r.email}</TableCell>
                                            <TableCell className={cn(
                                                'text-xs',
                                                r.status === 'error' && 'text-destructive',
                                                r.status === 'exists' && 'text-muted-foreground',
                                            )}>
                                                {r.message}
                                            </TableCell>
                                        </TableRow>
                                    ))}
                                </TableBody>
                            </Table>
                        </div>
                    </div>
                )}

                <DialogFooter className="shrink-0">
                    {step === 'upload' && (
                        <Button variant="outline" onClick={onClose}>{t('common.cancel')}</Button>
                    )}
                    {step === 'preview' && (
                        <>
                            <Button variant="outline" onClick={() => { setStep('upload'); setRows([]); }}>
                                <X className="size-4" /> {t('import.preview.back')}
                            </Button>
                            <Button onClick={handleImport} disabled={validCount === 0}>
                                <Upload className="size-4" />
                                {t('import.preview.import', { count: validCount })}
                            </Button>
                        </>
                    )}
                    {step === 'results' && (
                        <Button onClick={onClose}>{t('import.results.done')}</Button>
                    )}
                </DialogFooter>
            </DialogContent>
        </Dialog>
    );
}
