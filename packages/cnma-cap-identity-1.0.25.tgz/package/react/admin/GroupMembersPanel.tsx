import { useState, useEffect } from 'react';
import { useTranslation } from 'react-i18next';
import { X, Search, UserPlus, Trash2, Loader2, Users, User, Check } from 'lucide-react';
import type { ShadowUser, ShadowGroup, GroupMember } from '../types';
import type { IdentityAdminService } from '../services/IdentityAdminService';
import { Button } from '@cnma/react-ui';
import { Input } from '@cnma/react-ui';
import { cn } from '@cnma/react-ui';

interface GroupMembersPanelProps {
    group: ShadowGroup;
    service: IdentityAdminService;
    onClose: () => void;
    onError?: (msg: string) => void;
    onSuccess?: (msg: string) => void;
}

/**
 * GroupMembersPanel — Slide-in panel for managing group members.
 * Supports multi-select: search users, toggle selection, then add all at once.
 */
export function GroupMembersPanel({ group, service, onClose, onError, onSuccess }: GroupMembersPanelProps) {
    const { t } = useTranslation('identity');
    const [members, setMembers] = useState<GroupMember[]>([]);
    const [isLoading, setIsLoading] = useState(true);
    const [searchQuery, setSearchQuery] = useState('');
    const [searchResults, setSearchResults] = useState<ShadowUser[]>([]);
    const [isSearching, setIsSearching] = useState(false);
    const [selectedUsers, setSelectedUsers] = useState<Map<string, ShadowUser>>(new Map());
    const [isAdding, setIsAdding] = useState(false);
    const [removingMemberId, setRemovingMemberId] = useState<string | null>(null);

    useEffect(() => { loadMembers(); }, [group.ID]);

    // Debounced search
    useEffect(() => {
        if (!searchQuery.trim()) { setSearchResults([]); return; }
        const timer = setTimeout(searchUsers, 300);
        return () => clearTimeout(timer);
    }, [searchQuery]);

    async function loadMembers() {
        try {
            setIsLoading(true);
            const data = await service.getGroupMembers(group.ID);
            setMembers(data);
        } catch (error) {
            onError?.(t('groups.members.loadFailed', { item: 'members' }));
        } finally {
            setIsLoading(false);
        }
    }

    async function searchUsers() {
        try {
            setIsSearching(true);
            const users = await service.getShadowUsers(searchQuery);
            const memberUserIds = new Set(members.map(m => m.user_ID));
            setSearchResults(users.filter(u => !memberUserIds.has(u.ID)));
        } catch (error) {
            console.error('Search failed:', error);
        } finally {
            setIsSearching(false);
        }
    }

    function toggleUserSelection(user: ShadowUser) {
        setSelectedUsers(prev => {
            const next = new Map(prev);
            if (next.has(user.ID)) {
                next.delete(user.ID);
            } else {
                next.set(user.ID, user);
            }
            return next;
        });
    }

    async function handleAddSelected() {
        if (selectedUsers.size === 0) return;
        try {
            setIsAdding(true);
            const usersToAdd = Array.from(selectedUsers.values());
            const results = await Promise.allSettled(
                usersToAdd.map(user => service.addGroupMember(group.ID, user.ID))
            );
            const succeeded = results.filter(r => r.status === 'fulfilled').length;
            const failed = results.filter(r => r.status === 'rejected').length;

            if (failed > 0) {
                onSuccess?.(t('groups.members.addPartialSuccess', { succeeded, failed, succeeded_plural: succeeded !== 1 ? 's' : '', failed_plural: failed !== 1 ? 's' : '' }));
            } else {
                onSuccess?.(t('groups.members.addSuccess', { count: succeeded }));
            }

            setSelectedUsers(new Map());
            setSearchQuery('');
            setSearchResults([]);
            await loadMembers();
        } catch (error: any) {
            onError?.(error?.message || t('groups.members.addFailed'));
        } finally {
            setIsAdding(false);
        }
    }

    async function handleRemoveMember(member: GroupMember) {
        try {
            setRemovingMemberId(member.ID);
            await service.removeGroupMember(member.ID);
            onSuccess?.(t('groups.members.removeSuccess'));
            await loadMembers();
        } catch (error: any) {
            onError?.(error?.message || 'Failed to remove member');
        } finally {
            setRemovingMemberId(null);
        }
    }

    return (
        <>
            {/* Overlay */}
            <div
                className="fixed inset-0 z-50 bg-black/50 animate-in fade-in-0"
                onClick={onClose}
            />

            {/* Panel */}
            <div
                className="fixed right-0 top-0 h-full w-full max-w-md bg-background shadow-xl z-50 flex flex-col animate-in slide-in-from-right"
                onClick={e => e.stopPropagation()}
            >
                {/* Header */}
                <div className="flex items-center justify-between p-4 border-b">
                    <div className="flex items-center gap-3">
                        <div className="size-10 rounded-lg bg-primary/10 flex items-center justify-center">
                            <Users className="size-5 text-primary" />
                        </div>
                        <div>
                            <h2 className="font-semibold text-foreground">{group.name}</h2>
                            <p className="text-sm text-muted-foreground">
                                {t('groups.members.memberCount', { count: members.length, count_plural: members.length !== 1 ? 's' : '' })}
                            </p>
                        </div>
                    </div>
                    <Button variant="ghost" size="icon" onClick={onClose}>
                        <X className="size-5 text-muted-foreground" />
                    </Button>
                </div>

                {/* Search to Add */}
                <div className="p-4 border-b">
                    <div className="relative">
                        <Search className="absolute left-3 top-1/2 -translate-y-1/2 size-4 text-muted-foreground" />
                        <Input
                            type="text"
                            placeholder={t('groups.members.searchPlaceholder')}
                            value={searchQuery}
                            onChange={(e) => setSearchQuery(e.target.value)}
                            className="pl-9"
                        />
                    </div>

                    {searchQuery && (
                        <div className="mt-2 max-h-48 overflow-y-auto border rounded-lg">
                            {isSearching ? (
                                <div className="p-4 text-center text-sm text-muted-foreground">
                                    <Loader2 className="size-4 animate-spin mx-auto mb-1" />
                                    {t('groups.members.searching')}
                                </div>
                            ) : searchResults.length === 0 ? (
                                <div className="p-4 text-center text-sm text-muted-foreground">
                                    {t('groups.members.noSearchResults')}
                                </div>
                            ) : (
                                searchResults.map(user => {
                                    const isSelected = selectedUsers.has(user.ID);
                                    return (
                                        <div
                                            key={user.ID}
                                            className={cn(
                                                'flex items-center justify-between p-3 border-b last:border-b-0 cursor-pointer transition-colors',
                                                isSelected
                                                    ? 'bg-primary/5 hover:bg-primary/10'
                                                    : 'hover:bg-muted/50'
                                            )}
                                            onClick={() => toggleUserSelection(user)}
                                        >
                                            <div className="flex items-center gap-3">
                                                <div className={cn(
                                                    'size-8 rounded-full flex items-center justify-center transition-colors',
                                                    isSelected
                                                        ? 'bg-primary text-primary-foreground'
                                                        : 'bg-muted'
                                                )}>
                                                    {isSelected ? (
                                                        <Check className="size-4" />
                                                    ) : (
                                                        <User className="size-4 text-muted-foreground" />
                                                    )}
                                                </div>
                                                <div>
                                                    <div className="text-sm font-medium text-foreground">
                                                        {user.displayName || 'Unknown'}
                                                    </div>
                                                    <div className="text-xs text-muted-foreground">{user.email}</div>
                                                </div>
                                            </div>
                                        </div>
                                    );
                                })
                            )}
                        </div>
                    )}

                    {/* Add selected button */}
                    {selectedUsers.size > 0 && (
                        <div className="mt-3 flex items-center justify-between">
                            <span className="text-sm text-muted-foreground">
                                {t('groups.members.selectedCount', { count: selectedUsers.size })}
                            </span>
                            <div className="flex items-center gap-2">
                                <Button
                                    size="sm"
                                    variant="ghost"
                                    onClick={() => setSelectedUsers(new Map())}
                                    className="text-muted-foreground"
                                >
                                    {t('groups.members.clear')}
                                </Button>
                                <Button
                                    size="sm"
                                    onClick={handleAddSelected}
                                    disabled={isAdding}
                                >
                                    {isAdding ? (
                                        <Loader2 className="size-4 animate-spin" />
                                    ) : (
                                        <UserPlus className="size-4" />
                                    )}
                                    {t('groups.members.addMembers', { count: selectedUsers.size })}
                                </Button>
                            </div>
                        </div>
                    )}
                </div>

                {/* Members List */}
                <div className="flex-1 overflow-y-auto p-4">
                    <h3 className="text-sm font-medium text-muted-foreground mb-3">{t('groups.members.title', { name: group.name })}</h3>

                    {isLoading ? (
                        <div className="space-y-3">
                            {[1, 2, 3].map(i => (
                                <div key={i} className="flex items-center gap-3 animate-pulse">
                                    <div className="size-10 rounded-full bg-muted" />
                                    <div className="flex-1">
                                        <div className="h-4 bg-muted rounded w-32 mb-1" />
                                        <div className="h-3 bg-muted rounded w-48" />
                                    </div>
                                </div>
                            ))}
                        </div>
                    ) : members.length === 0 ? (
                        <div className="text-center py-8">
                            <Users className="size-12 text-muted-foreground/30 mx-auto mb-3" />
                            <p className="text-sm text-muted-foreground">{t('groups.members.noMembers')}</p>
                            <p className="text-xs text-muted-foreground/70 mt-1">
                                {t('groups.members.searchToAdd')}
                            </p>
                        </div>
                    ) : (
                        <div className="space-y-2">
                            {members.map(member => (
                                <div
                                    key={member.ID}
                                    className="flex items-center justify-between p-3 bg-muted/50 rounded-lg"
                                >
                                    <div className="flex items-center gap-3">
                                        <div className="size-10 rounded-full bg-gradient-to-br from-muted to-muted-foreground/20 flex items-center justify-center">
                                            <User className="size-5 text-muted-foreground" />
                                        </div>
                                        <div>
                                            <div className="font-medium text-foreground">
                                                {member.user?.displayName || 'Unknown'}
                                            </div>
                                            <div className="text-sm text-muted-foreground">
                                                {member.user?.email}
                                            </div>
                                        </div>
                                    </div>
                                    <Button
                                        variant="ghost"
                                        size="icon"
                                        onClick={() => handleRemoveMember(member)}
                                        disabled={removingMemberId === member.ID}
                                        className="text-muted-foreground hover:text-destructive hover:bg-destructive/10"
                                    >
                                        {removingMemberId === member.ID ? (
                                            <Loader2 className="size-4 animate-spin" />
                                        ) : (
                                            <Trash2 className="size-4" />
                                        )}
                                    </Button>
                                </div>
                            ))}
                        </div>
                    )}
                </div>
            </div>
        </>
    );
}
