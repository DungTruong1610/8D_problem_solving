import { useState, useEffect } from 'react';
import { useTranslation } from 'react-i18next';
import { Plus, MoreVertical, Pencil, Trash2, Users, Loader2, Mail, PowerOff, Power } from 'lucide-react';
import type { ShadowGroup, SupportType } from '../types';
import type { IdentityAdminService } from '../services/IdentityAdminService';
import { GroupMembersPanel } from './GroupMembersPanel';
import { Button } from '@cnma/react-ui';
import { Input } from '@cnma/react-ui';
import { Label } from '@cnma/react-ui';
import { Textarea } from '@cnma/react-ui';
import { Badge } from '@cnma/react-ui';
import { Select, SelectTrigger, SelectValue, SelectContent, SelectItem } from '@cnma/react-ui';
import {
    Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter,
} from '@cnma/react-ui';
import { Table, TableHeader, TableBody, TableHead, TableRow, TableCell } from '@cnma/react-ui';
import { cn } from '@cnma/react-ui';

interface GroupsTabProps {
    service: IdentityAdminService;
    onError?: (msg: string) => void;
    onSuccess?: (msg: string) => void;
}

const TYPE_ICONS: Record<string, string> = {
    GROUP: '👥', TEAM: '👥', DEPARTMENT: '🏢', ROLE: '💼',
};

/**
 * GroupsTab — Full CRUD for Shadow Groups with member management.
 */
export function GroupsTab({ service, onError, onSuccess }: GroupsTabProps) {
    const { t } = useTranslation('identity');
    const [groups, setGroups] = useState<ShadowGroup[]>([]);
    const [isLoading, setIsLoading] = useState(true);
    // Track which menu is open + whether the dropdown should open upward
    const [openMenu, setOpenMenu] = useState<{ id: string; direction: 'up' | 'down' } | null>(null);

    // Dialog states
    const [showCreateDialog, setShowCreateDialog] = useState(false);
    const [editingGroup, setEditingGroup] = useState<ShadowGroup | null>(null);
    const [deletingGroup, setDeletingGroup] = useState<ShadowGroup | null>(null);
    const [togglingGroup, setTogglingGroup] = useState<ShadowGroup | null>(null);
    const [managingMembersGroup, setManagingMembersGroup] = useState<ShadowGroup | null>(null);

    // Form state
    const [formName, setFormName] = useState('');
    const [formDesc, setFormDesc] = useState('');
    const [formTypeId, setFormTypeId] = useState('');
    const [formGroupEmail, setFormGroupEmail] = useState('');
    const [formEmailMode, setFormEmailMode] = useState<'GROUP_ONLY' | 'MEMBERS_ONLY' | 'BOTH'>('GROUP_ONLY');
    const [supportTypes, setSupportTypes] = useState<SupportType[]>([]);
    const [isSaving, setIsSaving] = useState(false);

    useEffect(() => { loadGroups(); }, []);

    async function loadGroups() {
        try {
            setIsLoading(true);
            const data = await service.getShadowGroups();
            setGroups(data);
        } catch (error) {
            onError?.(t('errors.loadFailed', { item: 'groups' }));
        } finally {
            setIsLoading(false);
        }
    }

    async function openCreateDialog() {
        setFormName('');
        setFormDesc('');
        setFormTypeId('');
        setFormGroupEmail('');
        setFormEmailMode('GROUP_ONLY');
        try {
            const types = await service.getSupportTypes();
            const groupTypes = types.filter(t => t.isEnabled && t.code !== 'USER' && t.code !== 'POSITION');
            setSupportTypes(groupTypes);
            if (groupTypes.length > 0) setFormTypeId(groupTypes[0].ID);
        } catch (e) {
            onError?.(t('errors.loadFailed', { item: 'group types' }));
        }
        setShowCreateDialog(true);
    }

    function openEditDialog(group: ShadowGroup) {
        setEditingGroup(group);
        setFormName(group.name);
        setFormDesc(group.description || '');
        setFormTypeId(group.type_ID);
        setFormGroupEmail(group.groupEmail || '');
        setFormEmailMode(group.emailNotificationMode || 'GROUP_ONLY');
        setOpenMenu(null);
    }

    async function handleSave() {
        if (!formName.trim()) return;
        try {
            setIsSaving(true);
            if (editingGroup) {
                await service.updateShadowGroup(editingGroup.ID, {
                    name: formName.trim(),
                    description: formDesc.trim() || null,
                    groupEmail: formGroupEmail.trim() || null,
                    emailNotificationMode: formEmailMode,
                } as Parameters<typeof service.updateShadowGroup>[1]);
                onSuccess?.(t('groups.updateSuccess', { name: formName }));
                setEditingGroup(null);
            } else {
                await service.createShadowGroup({
                    name: formName.trim(),
                    description: formDesc.trim() || undefined,
                    type_ID: formTypeId,
                    groupEmail: formGroupEmail.trim() || undefined,
                    emailNotificationMode: formEmailMode,
                });
                onSuccess?.(t('groups.createSuccess', { name: formName }));
                setShowCreateDialog(false);
            }
            loadGroups();
        } catch (error: any) {
            onError?.(error?.message || t('errors.saveFailed', { item: 'group' }));
        } finally {
            setIsSaving(false);
        }
    }

    async function handleDelete() {
        if (!deletingGroup) return;
        try {
            await service.deleteShadowGroup(deletingGroup.ID);
            onSuccess?.(t('groups.deleteSuccess', { name: deletingGroup.name }));
            setDeletingGroup(null);
            loadGroups();
        } catch (error: any) {
            onError?.(error?.message || t('errors.deleteFailed', { item: 'group' }));
        }
    }

    async function handleToggleStatus() {
        if (!togglingGroup) return;
        try {
            setIsSaving(true);
            const newStatus = !togglingGroup.isActive;
            await service.updateShadowGroup(togglingGroup.ID, { isActive: newStatus });
            onSuccess?.(newStatus ? t('groups.activateSuccess', { name: togglingGroup.name }) : t('groups.deactivateSuccess', { name: togglingGroup.name }));
            setTogglingGroup(null);
            loadGroups();
        } catch (error: any) {
            onError?.(error?.message || t('errors.updateFailed', { item: 'group' }));
        } finally {
            setIsSaving(false);
        }
    }

    /** Open the action menu, auto-detecting whether to render it above or below the trigger. */
    function handleMenuOpen(e: React.MouseEvent, groupId: string) {
        if (openMenu?.id === groupId) {
            setOpenMenu(null);
            return;
        }
        const rect = (e.currentTarget as HTMLElement).getBoundingClientRect();
        const spaceBelow = window.innerHeight - rect.bottom;
        // Approximate height: Edit + Deactivate/Activate + Delete = ~3 items × 36px = ~108px
        const direction = spaceBelow < 130 ? 'up' : 'down';
        setOpenMenu({ id: groupId, direction });
    }

    const isDialogOpen = showCreateDialog || !!editingGroup;

    return (
        <div className="space-y-4">
            <div className="rounded-lg border bg-muted/50 p-4">
                <p className="text-sm text-muted-foreground">
                    {t('groups.description')}
                </p>
            </div>

            <div className="flex items-center justify-between">
                <span className="text-sm text-muted-foreground">
                    {t('groups.groupCount', { count: groups.length })}
                </span>
                <Button size="sm" onClick={openCreateDialog}>
                    <Plus className="size-4" /> {t('groups.create')}
                </Button>
            </div>

            {/* Table */}
            <div className="rounded-lg border bg-card overflow-visible">
                <Table>
                    <TableHeader>
                        <TableRow>
                            <TableHead>{t('groups.columns.group')}</TableHead>
                            <TableHead className="w-[120px]">{t('groups.columns.type')}</TableHead>
                            <TableHead className="w-[200px]">{t('groups.columns.groupEmail')}</TableHead>
                            <TableHead className="w-[150px]">{t('groups.columns.notification')}</TableHead>
                            <TableHead className="w-[100px]">{t('groups.columns.members')}</TableHead>
                            <TableHead className="w-[90px]">{t('groups.columns.status')}</TableHead>
                            <TableHead className="w-[50px]"></TableHead>
                        </TableRow>
                    </TableHeader>
                    <TableBody>
                        {isLoading ? (
                            [1, 2, 3].map(i => (
                                <TableRow key={i}>
                                    <TableCell colSpan={7}>
                                        <div className="h-10 bg-muted rounded animate-pulse" />
                                    </TableCell>
                                </TableRow>
                            ))
                        ) : groups.length === 0 ? (
                            <TableRow>
                                <TableCell colSpan={7} className="text-center py-8 text-muted-foreground">
                                    {t('groups.noGroups')}
                                </TableCell>
                            </TableRow>
                        ) : (
                            groups.map(group => {
                                const memberCount = group.members?.length ?? 0;
                                const emailMode = group.emailNotificationMode || 'GROUP_ONLY';
                                const modeColors: Record<string, string> = {
                                    GROUP_ONLY: 'bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-400',
                                    MEMBERS_ONLY: 'bg-purple-100 text-purple-700 dark:bg-purple-900/30 dark:text-purple-400',
                                    BOTH: 'bg-amber-100 text-amber-700 dark:bg-amber-900/30 dark:text-amber-400',
                                };

                                return (
                                    <TableRow key={group.ID} className={cn(!group.isActive && 'opacity-60')}>
                                        {/* Group name + description */}
                                        <TableCell>
                                            <div className="flex items-center gap-3">
                                                <div className="size-9 rounded-lg bg-primary/10 flex items-center justify-center shrink-0 text-base">
                                                    {TYPE_ICONS[group.type?.code || 'GROUP'] || '👥'}
                                                </div>
                                                <div className="min-w-0">
                                                    <div className="font-medium text-foreground truncate">{group.name}</div>
                                                    {group.description && (
                                                        <div className="text-xs text-muted-foreground truncate max-w-[250px]">{group.description}</div>
                                                    )}
                                                </div>
                                            </div>
                                        </TableCell>

                                        {/* Type */}
                                        <TableCell>
                                            <Badge variant="secondary">
                                                {group.type?.name || group.type?.code || t('common.unknown')}
                                            </Badge>
                                        </TableCell>

                                        {/* Group Email */}
                                        <TableCell>
                                            {group.groupEmail ? (
                                                <div className="flex items-center gap-1.5 text-sm">
                                                    <Mail className="size-3.5 text-muted-foreground shrink-0" />
                                                    <span className="text-foreground truncate max-w-[160px]">{group.groupEmail}</span>
                                                </div>
                                            ) : (
                                                <span className="text-xs text-muted-foreground italic">{t('common.notSet')}</span>
                                            )}
                                        </TableCell>

                                        {/* Notification Mode */}
                                        <TableCell>
                                            <span className={cn(
                                                'inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium',
                                                modeColors[emailMode] || modeColors.GROUP_ONLY
                                            )}>
                                                {emailMode === 'GROUP_ONLY' ? t('groups.notificationModes.groupOnly') : emailMode === 'MEMBERS_ONLY' ? t('groups.notificationModes.membersOnly') : t('groups.notificationModes.both')}
                                            </span>
                                        </TableCell>

                                        {/* Members */}
                                        <TableCell>
                                            <Button
                                                variant="ghost"
                                                size="sm"
                                                className="gap-1.5"
                                                onClick={() => setManagingMembersGroup(group)}
                                            >
                                                <Users className="size-3.5" />
                                                <span>{memberCount}</span>
                                            </Button>
                                        </TableCell>

                                        {/* Status */}
                                        <TableCell>
                                            <Badge
                                                variant={group.isActive ? 'default' : 'secondary'}
                                                className={cn(
                                                    'text-xs',
                                                    group.isActive
                                                        ? 'bg-green-100 text-green-700 hover:bg-green-100 dark:bg-green-900/30 dark:text-green-400'
                                                        : 'bg-gray-100 text-gray-500'
                                                )}
                                            >
                                                {group.isActive ? t('groups.status.active') : t('groups.status.inactive')}
                                            </Badge>
                                        </TableCell>

                                        {/* Actions */}
                                        <TableCell>
                                            <div className="relative">
                                                <Button
                                                    variant="ghost"
                                                    size="icon"
                                                    onClick={(e) => handleMenuOpen(e, group.ID)}
                                                >
                                                    <MoreVertical className="size-4" />
                                                </Button>
                                                {openMenu?.id === group.ID && (
                                                    <>
                                                        <div className="fixed inset-0 z-10" onClick={() => setOpenMenu(null)} />
                                                        <div className={cn(
                                                            'absolute right-0 z-20 bg-popover border rounded-md shadow-md min-w-[160px] py-1',
                                                            openMenu.direction === 'up' ? 'bottom-full mb-1' : 'top-full mt-1'
                                                        )}>
                                                            <button
                                                                className="flex items-center gap-2 w-full px-3 py-2 text-sm hover:bg-accent text-left"
                                                                onClick={() => openEditDialog(group)}
                                                            >
                                                                <Pencil className="size-3.5" /> {t('common.edit')}
                                                            </button>
                                                            {group.isActive ? (
                                                                <button
                                                                    className="flex items-center gap-2 w-full px-3 py-2 text-sm hover:bg-amber-50 text-amber-700 dark:hover:bg-amber-900/20 dark:text-amber-400 text-left"
                                                                    onClick={() => { setTogglingGroup(group); setOpenMenu(null); }}
                                                                >
                                                                    <PowerOff className="size-3.5" /> {t('groups.deactivateAction')}
                                                                </button>
                                                            ) : (
                                                                <button
                                                                    className="flex items-center gap-2 w-full px-3 py-2 text-sm hover:bg-accent text-left"
                                                                    onClick={() => { setTogglingGroup(group); setOpenMenu(null); }}
                                                                >
                                                                    <Power className="size-3.5" /> {t('groups.activateAction')}
                                                                </button>
                                                            )}
                                                            <button
                                                                className="flex items-center gap-2 w-full px-3 py-2 text-sm hover:bg-destructive/10 text-destructive text-left"
                                                                onClick={() => { setDeletingGroup(group); setOpenMenu(null); }}
                                                            >
                                                                <Trash2 className="size-3.5" /> {t('common.delete')}
                                                            </button>
                                                        </div>
                                                    </>
                                                )}
                                            </div>
                                        </TableCell>
                                    </TableRow>
                                );
                            })
                        )}
                    </TableBody>
                </Table>
            </div>

            {/* Create/Edit Dialog */}
            <Dialog open={isDialogOpen} onOpenChange={(open) => { if (!open) { setShowCreateDialog(false); setEditingGroup(null); } }}>
                <DialogContent className="sm:max-w-md">
                    <DialogHeader>
                        <DialogTitle>
                            {editingGroup ? t('groups.dialog.editTitle') : t('groups.dialog.createTitle')}
                        </DialogTitle>
                        <DialogDescription>
                            {editingGroup ? t('groups.dialog.editDescription') : t('groups.dialog.createDescription')}
                        </DialogDescription>
                    </DialogHeader>

                    <div className="space-y-4 py-2">
                        <div>
                            <Label className="text-xs text-muted-foreground mb-1">{t('groups.dialog.nameLabel')}</Label>
                            <Input value={formName} onChange={e => setFormName(e.target.value)} placeholder={t('groups.dialog.namePlaceholder')} autoFocus />
                        </div>
                        {!editingGroup && (
                            <div>
                                <Label className="text-xs text-muted-foreground mb-1">{t('groups.dialog.typeLabel')}</Label>
                                <Select value={formTypeId} onValueChange={setFormTypeId}>
                                    <SelectTrigger>
                                        <SelectValue placeholder={t('groups.dialog.typePlaceholder')} />
                                    </SelectTrigger>
                                    <SelectContent>
                                        {supportTypes.map(t => (
                                            <SelectItem key={t.ID} value={t.ID}>{t.name}</SelectItem>
                                        ))}
                                    </SelectContent>
                                </Select>
                                <p className="text-xs text-muted-foreground mt-1">{t('groups.dialog.typeNote')}</p>
                            </div>
                        )}
                        {editingGroup?.type && (
                            <div>
                                <Label className="text-xs text-muted-foreground mb-1">{t('groups.dialog.typeLabel')}</Label>
                                <Input value={editingGroup.type.name || editingGroup.type.code} readOnly />
                            </div>
                        )}
                        <div>
                            <Label className="text-xs text-muted-foreground mb-1">{t('groups.dialog.descriptionLabel')}</Label>
                            <Textarea value={formDesc} onChange={e => setFormDesc(e.target.value)} placeholder={t('groups.dialog.descriptionPlaceholder')} rows={3} />
                        </div>

                        {/* Email Notification Settings */}
                        <div className="border-t pt-4 mt-2">
                            <div className="flex items-center gap-2 mb-3">
                                <Mail className="size-4 text-muted-foreground" />
                                <span className="text-sm font-medium text-foreground">{t('groups.dialog.emailNotifications')}</span>
                            </div>
                            <div className="space-y-3">
                                <div>
                                    <Label className="text-xs text-muted-foreground mb-1">{t('groups.dialog.groupEmailLabel')}</Label>
                                    <Input
                                        type="email"
                                        value={formGroupEmail}
                                        onChange={e => setFormGroupEmail(e.target.value)}
                                        placeholder={t('groups.dialog.groupEmailPlaceholder')}
                                    />
                                    <p className="text-xs text-muted-foreground mt-1">{t('groups.dialog.groupEmailNote')}</p>
                                </div>
                                <div>
                                    <Label className="text-xs text-muted-foreground mb-1">{t('groups.dialog.notificationModeLabel')}</Label>
                                    <Select value={formEmailMode} onValueChange={(v) => setFormEmailMode(v as any)}>
                                        <SelectTrigger>
                                            <SelectValue />
                                        </SelectTrigger>
                                        <SelectContent>
                                            <SelectItem value="GROUP_ONLY">{t('groups.notificationModes.groupOnly')}</SelectItem>
                                            <SelectItem value="MEMBERS_ONLY">{t('groups.notificationModes.membersOnly')}</SelectItem>
                                            <SelectItem value="BOTH">{t('groups.notificationModes.both')}</SelectItem>
                                        </SelectContent>
                                    </Select>
                                    <p className="text-xs text-muted-foreground mt-1">
                                        {formEmailMode === 'GROUP_ONLY' && t('groups.dialog.notificationModeNotes.groupOnly')}
                                        {formEmailMode === 'MEMBERS_ONLY' && t('groups.dialog.notificationModeNotes.membersOnly')}
                                        {formEmailMode === 'BOTH' && t('groups.dialog.notificationModeNotes.both')}
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>

                    <DialogFooter>
                        <Button variant="outline" onClick={() => { setShowCreateDialog(false); setEditingGroup(null); }}>
                            {t('groups.dialog.cancel')}
                        </Button>
                        <Button onClick={handleSave} disabled={isSaving || !formName.trim()}>
                            {isSaving && <Loader2 className="size-4 animate-spin" />}
                            {editingGroup ? t('groups.dialog.saveChanges') : t('groups.dialog.create')}
                        </Button>
                    </DialogFooter>
                </DialogContent>
            </Dialog>

            {/* Deactivate / Activate Confirmation Dialog */}
            <Dialog open={!!togglingGroup} onOpenChange={(open) => { if (!open) setTogglingGroup(null); }}>
                <DialogContent className="sm:max-w-md">
                    <DialogHeader>
                        <DialogTitle className="flex items-center gap-2">
                            {togglingGroup?.isActive ? (
                                <>
                                    <span className="size-8 rounded-full bg-amber-100 dark:bg-amber-900/30 flex items-center justify-center">
                                        <PowerOff className="size-4 text-amber-700 dark:text-amber-400" />
                                    </span>
                                    {t('groups.deactivateTitle')}
                                </>
                            ) : (
                                <>
                                    <span className="size-8 rounded-full bg-green-100 dark:bg-green-900/30 flex items-center justify-center">
                                        <Power className="size-4 text-green-700 dark:text-green-400" />
                                    </span>
                                    {t('groups.activateTitle')}
                                </>
                            )}
                        </DialogTitle>
                        <DialogDescription>
                            {togglingGroup?.isActive ? t('groups.deactivateConfirm') : t('groups.activateConfirm')}
                        </DialogDescription>
                    </DialogHeader>
                    <div className="py-2 space-y-2">
                        <p className="text-sm text-foreground">
                            {togglingGroup?.isActive ? t('groups.deactivateActionConfirm', { name: togglingGroup?.name }) : t('groups.activateActionConfirm', { name: togglingGroup?.name })}
                        </p>
                        {togglingGroup?.isActive && (
                            <p className="text-sm text-muted-foreground">
                                {t('groups.deactivateWarning')}
                            </p>
                        )}
                    </div>
                    <DialogFooter>
                        <Button variant="outline" onClick={() => setTogglingGroup(null)}>{t('common.cancel')}</Button>
                        {togglingGroup?.isActive ? (
                            <Button
                                className="bg-amber-600 hover:bg-amber-700 text-white"
                                onClick={handleToggleStatus}
                                disabled={isSaving}
                            >
                                {t('groups.deactivateAction')}
                            </Button>
                        ) : (
                            <Button onClick={handleToggleStatus} disabled={isSaving}>
                                {t('groups.activateAction')}
                            </Button>
                        )}
                    </DialogFooter>
                </DialogContent>
            </Dialog>

            {/* Delete Confirmation */}
            <Dialog open={!!deletingGroup} onOpenChange={(open) => { if (!open) setDeletingGroup(null); }}>
                <DialogContent className="sm:max-w-md">
                    <DialogHeader>
                        <DialogTitle className="flex items-center gap-2">
                            <span className="size-8 rounded-full bg-destructive/10 flex items-center justify-center">
                                <Trash2 className="size-4 text-destructive" />
                            </span>
                            {t('groups.deleteTitle')}
                        </DialogTitle>
                        <DialogDescription>
                            {t('groups.deleteConfirm')}
                        </DialogDescription>
                    </DialogHeader>
                    <div className="py-2 space-y-2">
                        <p className="text-sm text-foreground">
                            {t('groups.deleteActionConfirm', { name: deletingGroup?.name })}
                        </p>
                        <p className="text-sm text-muted-foreground">
                            {t('groups.deleteWarning')}
                        </p>
                    </div>
                    <DialogFooter>
                        <Button variant="outline" onClick={() => setDeletingGroup(null)}>{t('common.cancel')}</Button>
                        <Button variant="destructive" onClick={handleDelete}>{t('groups.deleteAction')}</Button>
                    </DialogFooter>
                </DialogContent>
            </Dialog>

            {/* Members Panel */}
            {managingMembersGroup && (
                <GroupMembersPanel
                    group={managingMembersGroup}
                    service={service}
                    onClose={() => setManagingMembersGroup(null)}
                    onError={onError}
                    onSuccess={onSuccess}
                />
            )}
        </div>
    );
}
