import { useState, useEffect } from 'react';
import { useTranslation } from 'react-i18next';
import { Plus, Trash2, Loader2, Link2 } from 'lucide-react';
import type { SamlMapping, ShadowGroup } from '../types';
import type { IdentityAdminService } from '../services/IdentityAdminService';
import { Button } from '@cnma/react-ui';
import { Input } from '@cnma/react-ui';
import { Label } from '@cnma/react-ui';
import { Badge } from '@cnma/react-ui';
import { Switch } from '@cnma/react-ui';
import { Select, SelectTrigger, SelectValue, SelectContent, SelectItem } from '@cnma/react-ui';
import { Table, TableHeader, TableBody, TableHead, TableRow, TableCell } from '@cnma/react-ui';
import { Separator } from '@cnma/react-ui';
import { cn } from '@cnma/react-ui';

interface SamlMappingsTabProps {
    service: IdentityAdminService;
    onError?: (msg: string) => void;
    onSuccess?: (msg: string) => void;
}

/**
 * SamlMappingsTab — Manage SAML-to-Local group mappings.
 */
export function SamlMappingsTab({ service, onError, onSuccess }: SamlMappingsTabProps) {
    const { t } = useTranslation('identity');
    const [mappings, setMappings] = useState<SamlMapping[]>([]);
    const [groups, setGroups] = useState<ShadowGroup[]>([]);
    const [isLoading, setIsLoading] = useState(true);

    // Create form
    const [showCreateForm, setShowCreateForm] = useState(false);
    const [newExternalGroup, setNewExternalGroup] = useState('');
    const [newLocalGroupId, setNewLocalGroupId] = useState('');
    const [newDescription, setNewDescription] = useState('');
    const [isCreating, setIsCreating] = useState(false);

    useEffect(() => { loadData(); }, []);

    async function loadData() {
        try {
            setIsLoading(true);
            const [mappingsData, groupsData] = await Promise.all([
                service.getSamlMappings(),
                service.getShadowGroups()
            ]);
            setMappings(mappingsData);
            setGroups(groupsData);
        } catch (error) {
            onError?.(t('errors.loadFailed', { item: 'SAML mappings' }));
        } finally {
            setIsLoading(false);
        }
    }

    async function handleCreate() {
        if (!newExternalGroup.trim() || !newLocalGroupId) return;
        try {
            setIsCreating(true);
            await service.createSamlMapping({
                externalGroupName: newExternalGroup.trim(),
                localGroup_ID: newLocalGroupId,
                description: newDescription.trim() || undefined
            });
            onSuccess?.(t('samlMappings.createSuccess'));
            setShowCreateForm(false);
            setNewExternalGroup('');
            setNewLocalGroupId('');
            setNewDescription('');
            loadData();
        } catch (error) {
            onError?.(t('samlMappings.createFailed'));
        } finally {
            setIsCreating(false);
        }
    }

    async function handleToggle(mapping: SamlMapping) {
        try {
            await service.updateSamlMapping(mapping.ID, { isEnabled: !mapping.isEnabled });
            setMappings(prev => prev.map(m =>
                m.ID === mapping.ID ? { ...m, isEnabled: !m.isEnabled } : m
            ));
        } catch (error) {
            onError?.(t('samlMappings.toggleFailed'));
        }
    }

    async function handleDelete(mapping: SamlMapping) {
        if (!confirm(t('samlMappings.deleteConfirm', { external: mapping.externalGroupName, local: mapping.localGroup?.name }))) return;
        try {
            await service.deleteSamlMapping(mapping.ID);
            onSuccess?.(t('samlMappings.deleteSuccess'));
            loadData();
        } catch (error) {
            onError?.(t('samlMappings.deleteFailed'));
        }
    }

    return (
        <div className="space-y-4">
            <div className="rounded-lg border bg-muted/50 p-4">
                <p className="text-sm text-muted-foreground">
                    {t('samlMappings.description')}
                </p>
            </div>

            <div className="flex items-center justify-between">
                <span className="text-sm text-muted-foreground">
                    {t('samlMappings.mappingCount', { count: mappings.length })}
                </span>
                <Button size="sm" onClick={() => setShowCreateForm(true)}>
                    <Plus className="size-4" /> {t('samlMappings.add')}
                </Button>
            </div>

            {/* Create Form */}
            {showCreateForm && (
                <div className="rounded-lg border border-primary/30 bg-card p-5 space-y-4 shadow-sm">
                    <h3 className="text-sm font-semibold text-foreground">{t('samlMappings.create.title')}</h3>
                    <div className="grid grid-cols-2 gap-4">
                        <div>
                            <Label className="text-xs text-muted-foreground mb-1">{t('samlMappings.create.samlGroupLabel')}</Label>
                            <Input
                                value={newExternalGroup}
                                onChange={(e) => setNewExternalGroup(e.target.value)}
                                placeholder={t('samlMappings.create.samlGroupPlaceholder')}
                                className="font-mono text-xs"
                            />
                            <p className="text-xs text-muted-foreground mt-1">{t('samlMappings.create.samlGroupNote')}</p>
                        </div>
                        <div>
                            <Label className="text-xs text-muted-foreground mb-1">{t('samlMappings.create.localGroupLabel')}</Label>
                            <Select value={newLocalGroupId} onValueChange={setNewLocalGroupId}>
                                <SelectTrigger>
                                    <SelectValue placeholder={t('samlMappings.create.localGroupPlaceholder')} />
                                </SelectTrigger>
                                <SelectContent>
                                    {groups.map(g => (
                                        <SelectItem key={g.ID} value={g.ID}>{g.name}</SelectItem>
                                    ))}
                                </SelectContent>
                            </Select>
                        </div>
                    </div>
                    <div>
                        <Label className="text-xs text-muted-foreground mb-1">{t('samlMappings.create.descriptionLabel')}</Label>
                        <Input
                            value={newDescription}
                            onChange={(e) => setNewDescription(e.target.value)}
                            placeholder={t('samlMappings.create.descriptionPlaceholder')}
                        />
                    </div>
                    <Separator />
                    <div className="flex justify-end gap-2">
                        <Button variant="outline" onClick={() => {
                            setShowCreateForm(false);
                            setNewExternalGroup('');
                            setNewLocalGroupId('');
                            setNewDescription('');
                        }}>
                            {t('samlMappings.create.cancel')}
                        </Button>
                        <Button
                            onClick={handleCreate}
                            disabled={isCreating || !newExternalGroup.trim() || !newLocalGroupId}
                        >
                            {isCreating && <Loader2 className="size-4 animate-spin" />}
                            {t('samlMappings.create.create')}
                        </Button>
                    </div>
                </div>
            )}

            {/* Table */}
            <div className="rounded-lg border bg-card overflow-hidden">
                <Table>
                    <TableHeader>
                        <TableRow>
                            <TableHead>{t('samlMappings.columns.samlGroup')}</TableHead>
                            <TableHead className="w-[50px]"></TableHead>
                            <TableHead>{t('samlMappings.columns.localGroup')}</TableHead>
                            <TableHead className="w-[100px]">{t('samlMappings.columns.status')}</TableHead>
                            <TableHead className="w-[50px]"></TableHead>
                        </TableRow>
                    </TableHeader>
                    <TableBody>
                        {isLoading ? (
                            [1, 2].map(i => (
                                <TableRow key={i}>
                                    <TableCell colSpan={5}>
                                        <div className="h-10 bg-muted rounded animate-pulse" />
                                    </TableCell>
                                </TableRow>
                            ))
                        ) : mappings.length === 0 ? (
                            <TableRow>
                                <TableCell colSpan={5} className="text-center py-8 text-muted-foreground">
                                    {t('samlMappings.noMappings')}
                                </TableCell>
                            </TableRow>
                        ) : (
                            mappings.map(mapping => (
                                <TableRow key={mapping.ID}>
                                    <TableCell>
                                        <code className="px-2 py-0.5 bg-muted rounded text-xs font-mono">
                                            {mapping.externalGroupName}
                                        </code>
                                    </TableCell>
                                    <TableCell className="text-center">
                                        <Link2 className="size-4 text-muted-foreground mx-auto" />
                                    </TableCell>
                                    <TableCell>
                                        <Badge variant="secondary">
                                            {mapping.localGroup?.name || t('common.unknown')}
                                        </Badge>
                                    </TableCell>
                                    <TableCell>
                                        <Switch
                                            checked={mapping.isEnabled}
                                            onCheckedChange={() => handleToggle(mapping)}
                                        />
                                    </TableCell>
                                    <TableCell>
                                        <Button
                                            variant="ghost"
                                            size="icon"
                                            onClick={() => handleDelete(mapping)}
                                            className="text-muted-foreground hover:text-destructive hover:bg-destructive/10"
                                        >
                                            <Trash2 className="size-4" />
                                        </Button>
                                    </TableCell>
                                </TableRow>
                            ))
                        )}
                    </TableBody>
                </Table>
            </div>
        </div>
    );
}
