import { useState } from 'react';
import { useTranslation } from 'react-i18next';
import type { OrganizationManagerProps } from '../types';
import { IdentityAdminService } from '../services/IdentityAdminService';
import { SupportTypesTab } from './SupportTypesTab';
import { UsersTab } from './UsersTab';
import { GroupsTab } from './GroupsTab';
import { SamlMappingsTab } from './SamlMappingsTab';
import { SettingsTab } from './SettingsTab';
import { cn } from '@cnma/react-ui';
import { Building2, Settings, Users, FolderKey, Link2, Palette } from 'lucide-react';

/**
 * @cnma/cap-identity — Organization Manager
 *
 * Main admin UI for managing the Shadow Directory.
 * Self-contained — includes tabs for Principal Types, Users, Groups, and SAML Mappings.
 *
 * Usage:
 *   import { OrganizationManager } from '@cnma/cap-identity/react';
 *   import '@cnma/cap-identity/react/identity.css';
 *
 *   <OrganizationManager
 *       httpClient={myHttpClient}
 *       baseUrl="/odata/v4/identity-admin"
 *       onError={(msg) => toast.error(msg)}
 *       onSuccess={(msg) => toast.success(msg)}
 *   />
 */

type TabId = 'types' | 'users' | 'groups' | 'saml' | 'settings';

interface TabDef {
    id: TabId;
    labelKey: string;
    icon: React.ReactNode;
}

const TABS: TabDef[] = [
    { id: 'types', labelKey: 'orgManager.tabs.principalTypes', icon: <Settings className="size-4" /> },
    { id: 'users', labelKey: 'orgManager.tabs.users', icon: <Users className="size-4" /> },
    { id: 'groups', labelKey: 'orgManager.tabs.groups', icon: <FolderKey className="size-4" /> },
    { id: 'saml', labelKey: 'orgManager.tabs.samlMappings', icon: <Link2 className="size-4" /> },
    { id: 'settings', labelKey: 'orgManager.tabs.settings', icon: <Palette className="size-4" /> },
];

export function OrganizationManager({
    httpClient,
    baseUrl = '/odata/v4/identity-admin',
    onError,
    onSuccess,
    className = '',
}: OrganizationManagerProps) {
    const { t } = useTranslation('identity');
    const [activeTab, setActiveTab] = useState<TabId>('types');

    const service = new IdentityAdminService(httpClient, baseUrl);

    const tabProps = { service, onError, onSuccess };

    return (
        <div className={cn("ci-org-manager", className)}>
            {/* Header */}
            <header className="border-b bg-background sticky top-0 z-10">
                <div className="max-w-6xl mx-auto px-6 py-4 flex items-center gap-3">
                    <div className="size-10 rounded-xl bg-primary flex items-center justify-center">
                        <Building2 className="size-5 text-primary-foreground" />
                    </div>
                    <div>
                        <h1 className="text-lg font-semibold text-foreground">{t('orgManager.title')}</h1>
                        <p className="text-sm text-muted-foreground">
                            {t('orgManager.description')}
                        </p>
                    </div>
                </div>
            </header>

            {/* Content */}
            <div className="max-w-6xl mx-auto px-6 py-6">
                {/* Tabs */}
                <div className="flex gap-1 bg-muted p-1 rounded-lg w-fit mb-6" role="tablist">
                    {TABS.map(tab => (
                        <button
                            key={tab.id}
                            role="tab"
                            aria-selected={activeTab === tab.id}
                            className={cn(
                                'flex items-center gap-2 px-4 py-2 text-sm font-medium rounded-md transition-all',
                                activeTab === tab.id
                                    ? 'bg-card text-primary shadow-sm'
                                    : 'text-muted-foreground hover:text-foreground'
                            )}
                            onClick={() => setActiveTab(tab.id)}
                        >
                            {tab.icon}
                            {t(tab.labelKey)}
                        </button>
                    ))}
                </div>

                <div role="tabpanel">
                    {activeTab === 'types' && <SupportTypesTab {...tabProps} />}
                    {activeTab === 'users' && <UsersTab {...tabProps} />}
                    {activeTab === 'groups' && <GroupsTab {...tabProps} />}
                    {activeTab === 'saml' && <SamlMappingsTab {...tabProps} />}
                    {activeTab === 'settings' && <SettingsTab {...tabProps} />}
                </div>
            </div>
        </div>
    );
}
