import { useState, useEffect } from 'react';
import { useTranslation } from 'react-i18next';
import { Loader2 } from 'lucide-react';
import type { SupportType } from '../types';
import type { IdentityAdminService } from '../services/IdentityAdminService';
import { Switch } from '@cnma/react-ui';
import { Badge } from '@cnma/react-ui';
import { cn } from '@cnma/react-ui';

interface SupportTypesTabProps {
    service: IdentityAdminService;
    onError?: (msg: string) => void;
    onSuccess?: (msg: string) => void;
}

const TYPE_ICONS: Record<string, string> = {
    USER: '👤',
    GROUP: '👥',
    TEAM: '👥',
    DEPARTMENT: '🏢',
    ROLE: '💼',
    POSITION: '🔗',
};

/**
 * SupportTypesTab — Configure which principal types are enabled.
 */
export function SupportTypesTab({ service, onError, onSuccess }: SupportTypesTabProps) {
    const { t } = useTranslation('identity');
    const [types, setTypes] = useState<SupportType[]>([]);
    const [isLoading, setIsLoading] = useState(true);
    const [updatingId, setUpdatingId] = useState<string | null>(null);

    useEffect(() => { loadTypes(); }, []);

    async function loadTypes() {
        try {
            setIsLoading(true);
            const data = await service.getSupportTypes();
            setTypes(data);
        } catch (error) {
            onError?.(t('errors.loadFailed', { item: 'principal types' }));
        } finally {
            setIsLoading(false);
        }
    }

    async function handleToggle(type: SupportType) {
        try {
            setUpdatingId(type.ID);
            const newValue = !type.isEnabled;
            await service.updateSupportType(type.ID, { isEnabled: newValue });
            setTypes(prev => prev.map(t => t.ID === type.ID ? { ...t, isEnabled: newValue } : t));
            onSuccess?.(t('supportTypes.toggleSuccess', { name: type.name, enabled: newValue }));
        } catch (error: any) {
            const msg = error?.message || t('errors.updateFailed', { item: type.name });
            onError?.(msg);
        } finally {
            setUpdatingId(null);
        }
    }

    if (isLoading) {
        return (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {[1, 2, 3, 4, 5, 6].map(i => (
                    <div key={i} className="rounded-lg border bg-card p-5 animate-pulse">
                        <div className="flex gap-4">
                            <div className="size-12 rounded-xl bg-muted" />
                            <div className="flex-1 space-y-2">
                                <div className="h-4 bg-muted rounded w-24" />
                                <div className="h-3 bg-muted rounded w-40" />
                            </div>
                        </div>
                    </div>
                ))}
            </div>
        );
    }

    return (
        <div className="space-y-4">
            <div className="rounded-lg border bg-muted/50 p-4">
                <p className="text-sm text-muted-foreground">
                    {t('supportTypes.description')}
                </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {types.map(type => {
                    const icon = TYPE_ICONS[type.code] || '👤';
                    const isUpdating = updatingId === type.ID;

                    return (
                        <div
                            key={type.ID}
                            className={cn(
                                "rounded-lg border bg-card p-5 transition-all hover:shadow-md",
                                !type.isEnabled && "opacity-60"
                            )}
                        >
                            <div className="flex items-start justify-between gap-4">
                                <div className="flex items-start gap-4">
                                    <div className={cn(
                                        "size-12 rounded-xl flex items-center justify-center text-xl shrink-0",
                                        type.isEnabled
                                            ? "bg-primary/10"
                                            : "bg-muted"
                                    )}>
                                        {icon}
                                    </div>
                                    <div>
                                        <h3 className="font-semibold text-foreground">{type.name}</h3>
                                        <p className="text-sm text-muted-foreground mt-0.5">
                                            {type.description || `${type.code} principal type`}
                                        </p>
                                        <Badge variant="secondary" className="mt-2 text-[10px]">{type.code}</Badge>
                                    </div>
                                </div>

                                <div className="pt-1">
                                    {isUpdating ? (
                                        <Loader2 className="size-4 animate-spin text-muted-foreground" />
                                    ) : (
                                        <Switch
                                            checked={type.isEnabled}
                                            onCheckedChange={() => handleToggle(type)}
                                            disabled={type.code === 'USER'}
                                        />
                                    )}
                                </div>
                            </div>
                        </div>
                    );
                })}
            </div>
        </div>
    );
}
