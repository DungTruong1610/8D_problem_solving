import { useState, useEffect, useCallback } from 'react';
import { useTranslation } from 'react-i18next';
import { Palette, Globe, Loader2 } from 'lucide-react';
import type { Theme, Language, UserSettings, IdentityHttpClient } from '../../types';
import { createIdentityService } from '../../service';
import {
    Button,
    Badge,
    Select,
    SelectTrigger,
    SelectValue,
    SelectContent,
    SelectItem,
    cn,
} from '@cnma/react-ui';

type PrefTab = 'theme' | 'language';

export interface UserPreferencesPageProps {
    /** HTTP client for API calls */
    httpClient: IdentityHttpClient;
    /** Base URL for the identity API (e.g. '/odata/v4/identity') */
    baseUrl?: string;
    /** Callback when error occurs — typically shows a toast */
    onError?: (message: string) => void;
    /** Callback when preferences are saved — typically shows a toast */
    onSuccess?: (message: string) => void;
}

/**
 * UserPreferencesPage — Reusable full-page user preferences for theme & language settings.
 * Designed to be rendered as a route inside any consuming app.
 *
 * Layout: 2-column — left sidebar nav (Button ghost) + right content.
 * Uses @cnma/react-ui components throughout. No inline styles, no hardcoded strings.
 */
export function UserPreferencesPage({
    httpClient,
    baseUrl = '/odata/v4/identity',
    onError,
    onSuccess,
}: UserPreferencesPageProps) {
    const { t } = useTranslation('identity');

    const [themes, setThemes] = useState<Theme[]>([]);
    const [languages, setLanguages] = useState<Language[]>([]);
    const [userSettings, setUserSettings] = useState<UserSettings | null>(null);

    const [selectedThemeId, setSelectedThemeId] = useState<string>('__system__');
    const [selectedLanguageId, setSelectedLanguageId] = useState<string>('__system__');

    const [isLoading, setIsLoading] = useState(true);
    const [isSaving, setIsSaving] = useState(false);
    const [error, setError] = useState<string | null>(null);

    const [activeTab, setActiveTab] = useState<PrefTab>('theme');

    useEffect(() => {
        void loadData();
    }, []);

    async function loadData() {
        try {
            setIsLoading(true);
            setError(null);
            const svc = createIdentityService(httpClient, baseUrl);
            const [themesData, languagesData, settingsData] = await Promise.all([
                svc.getThemes(),
                svc.getLanguages(),
                svc.getUserSettings(),
            ]);

            setThemes(themesData);
            setLanguages(languagesData);

            const settings = settingsData?.[0] || null;
            setUserSettings(settings);

            if (settings) {
                setSelectedThemeId(settings.theme_ID || '__system__');
                setSelectedLanguageId(settings.language_ID || '__system__');
            }
        } catch (err: unknown) {
            const msg = err instanceof Error ? err.message : t('errors.loadFailed', { item: 'preferences' });
            setError(msg);
            onError?.(msg);
        } finally {
            setIsLoading(false);
        }
    }

    const handleSave = useCallback(async () => {
        try {
            setIsSaving(true);
            const svc = createIdentityService(httpClient, baseUrl);
            const payload = {
                theme_ID: selectedThemeId === '__system__' ? null : selectedThemeId,
                language_ID: selectedLanguageId === '__system__' ? null : selectedLanguageId,
            };

            if (userSettings) {
                await svc.updateUserSettings(userSettings.ID, payload);
            } else {
                await svc.createUserSettings(payload);
            }

            onSuccess?.(t('userPreferences.saveSuccess'));

            window.dispatchEvent(new CustomEvent('cap-identity:settings-changed', {
                detail: {
                    theme_ID: payload.theme_ID,
                    language_ID: payload.language_ID,
                },
            }));

            await loadData();
        } catch (err: unknown) {
            const msg = err instanceof Error ? err.message : t('errors.saveFailed', { item: 'preferences' });
            onError?.(msg);
        } finally {
            setIsSaving(false);
        }
    }, [userSettings, selectedThemeId, selectedLanguageId, httpClient, baseUrl, onError, onSuccess, t]);

    const hasChanges = !userSettings || (
        selectedThemeId !== (userSettings.theme_ID || '__system__') ||
        selectedLanguageId !== (userSettings.language_ID || '__system__')
    );

    const navItems: { id: PrefTab; label: string; icon: React.ReactNode }[] = [
        { id: 'theme', label: t('userPreferences.tabs.theme'), icon: <Palette size={18} className="shrink-0" /> },
        { id: 'language', label: t('userPreferences.tabs.language'), icon: <Globe size={18} className="shrink-0" /> },
    ];

    if (isLoading) {
        return (
            <div className="flex items-center justify-center h-64">
                <Loader2 className="size-8 animate-spin text-muted-foreground" />
            </div>
        );
    }

    if (error) {
        return (
            <div className="p-6 text-center text-muted-foreground">
                {error}
            </div>
        );
    }

    return (
        <div className="flex h-full overflow-hidden">
            {/* Left sidebar nav */}
            <nav className="w-56 shrink-0 flex flex-col bg-muted/30 border-r border-border">
                <div className="p-4 border-b border-border">
                    <p className="text-sm font-semibold text-foreground">Preferences</p>
                </div>
                <div className="flex flex-col p-2 gap-0.5">
                    {navItems.map((item) => (
                        <Button
                            key={item.id}
                            variant="ghost"
                            onClick={() => setActiveTab(item.id)}
                            className={cn(
                                'w-full justify-start gap-2 font-normal',
                                activeTab === item.id && 'bg-primary/10 text-primary font-semibold hover:bg-primary/15 hover:text-primary'
                            )}
                        >
                            {item.icon}
                            {item.label}
                        </Button>
                    ))}
                </div>
            </nav>

            {/* Right content area */}
            <div className="flex-1 overflow-y-auto p-6">
                {activeTab === 'theme' ? (
                    <ThemeContent
                        themes={themes}
                        selectedThemeId={selectedThemeId}
                        onSelectTheme={setSelectedThemeId}
                        isSaving={isSaving}
                        hasChanges={hasChanges}
                        onSave={handleSave}
                    />
                ) : (
                    <LanguageContent
                        languages={languages}
                        selectedLanguageId={selectedLanguageId}
                        onSelectLanguage={setSelectedLanguageId}
                        isSaving={isSaving}
                        hasChanges={hasChanges}
                        onSave={handleSave}
                    />
                )}
            </div>
        </div>
    );
}

// ----------------------------------------------------------------------------
// Theme Tab Content
// ----------------------------------------------------------------------------

interface ThemeContentProps {
    themes: Theme[];
    selectedThemeId: string;
    onSelectTheme: (id: string) => void;
    isSaving: boolean;
    hasChanges: boolean;
    onSave: () => void;
}

function ThemeContent({ themes, selectedThemeId, onSelectTheme, isSaving, hasChanges, onSave }: ThemeContentProps) {
    const { t } = useTranslation('identity');

    return (
        <div className="max-w-xl space-y-6">
            <div>
                <h2 className="text-xl font-semibold text-foreground">{t('userPreferences.theme.title')}</h2>
                <p className="text-sm text-muted-foreground mt-1">
                    {t('userPreferences.theme.description')}
                </p>
            </div>

            <Select value={selectedThemeId} onValueChange={onSelectTheme}>
                <SelectTrigger className="w-full">
                    <SelectValue placeholder={t('userPreferences.systemDefault')} />
                </SelectTrigger>
                <SelectContent>
                    <SelectItem value="__system__">{t('userPreferences.systemDefault')}</SelectItem>
                    {themes.map((theme) => (
                        <SelectItem key={theme.ID} value={theme.ID}>
                            <span className="flex items-center gap-2">
                                <span>{theme.icon || '🎨'}</span>
                                <span>{theme.name}</span>
                                {theme.description && (
                                    <Badge variant="secondary" className="text-xs ml-2">
                                        {theme.description}
                                    </Badge>
                                )}
                            </span>
                        </SelectItem>
                    ))}
                </SelectContent>
            </Select>

            {/* Theme preview chips */}
            <div className="flex flex-wrap gap-2">
                {themes.map((theme) => (
                    <button
                        key={theme.ID}
                        type="button"
                        className={cn(
                            'inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full text-sm border transition-all cursor-pointer',
                            selectedThemeId === theme.ID
                                ? 'border-primary bg-primary/10 text-primary'
                                : 'border-border bg-muted/50 text-muted-foreground hover:border-muted-foreground'
                        )}
                        onClick={() => onSelectTheme(theme.ID)}
                    >
                        <span>{theme.icon || '🎨'}</span>
                        <span>{theme.name}</span>
                    </button>
                ))}
            </div>

            <div className="flex items-center justify-end pt-4 border-t border-border">
                <Button onClick={onSave} disabled={isSaving || !hasChanges}>
                    {isSaving && <Loader2 className="size-4 animate-spin" />}
                    {t('userPreferences.save')}
                </Button>
            </div>
        </div>
    );
}

// ----------------------------------------------------------------------------
// Language Tab Content
// ----------------------------------------------------------------------------

interface LanguageContentProps {
    languages: Language[];
    selectedLanguageId: string;
    onSelectLanguage: (id: string) => void;
    isSaving: boolean;
    hasChanges: boolean;
    onSave: () => void;
}

function LanguageContent({ languages, selectedLanguageId, onSelectLanguage, isSaving, hasChanges, onSave }: LanguageContentProps) {
    const { t } = useTranslation('identity');

    return (
        <div className="max-w-xl space-y-6">
            <div>
                <h2 className="text-xl font-semibold text-foreground">{t('userPreferences.language.title')}</h2>
                <p className="text-sm text-muted-foreground mt-1">
                    {t('userPreferences.language.description')}
                </p>
            </div>

            <Select value={selectedLanguageId} onValueChange={onSelectLanguage}>
                <SelectTrigger className="w-full">
                    <SelectValue placeholder={t('userPreferences.systemDefault')} />
                </SelectTrigger>
                <SelectContent>
                    <SelectItem value="__system__">{t('userPreferences.systemDefault')}</SelectItem>
                    {languages.map((lang) => (
                        <SelectItem key={lang.ID} value={lang.ID}>
                            <span className="flex items-center gap-2">
                                <span>{lang.nativeName || lang.name}</span>
                                <Badge variant="secondary" className="text-xs">
                                    {lang.code.toUpperCase()}
                                </Badge>
                            </span>
                        </SelectItem>
                    ))}
                </SelectContent>
            </Select>

            <div className="flex items-center justify-end pt-4 border-t border-border">
                <Button onClick={onSave} disabled={isSaving || !hasChanges}>
                    {isSaving && <Loader2 className="size-4 animate-spin" />}
                    {t('userPreferences.save')}
                </Button>
            </div>
        </div>
    );
}
