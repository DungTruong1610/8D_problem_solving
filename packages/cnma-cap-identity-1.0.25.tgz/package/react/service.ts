/**
 * Identity Service — Reusable OData client for user preferences.
 * Handles envelope format { value: [...] } automatically.
 *
 * Usage:
 *   import { identityService } from '@cnma/cap-identity/react/service';
 */

import type { IdentityHttpClient, Theme, Language } from './types';


// ---------------------------------------------------------------------------
// Generic OData response extractor
// ---------------------------------------------------------------------------

async function fetchODataArray<T>(client: IdentityHttpClient, url: string): Promise<T[]> {
    const response = await client.get<{ value: T[] }>(url);
    return (response as { value: T[] }).value || [];
}

// ---------------------------------------------------------------------------
// Typed client for User Preferences
// ---------------------------------------------------------------------------

export interface ThemeService {
    getThemes(): Promise<ThemeService.types[]>;
}

export interface LanguageService {
    getLanguages(): Promise<LanguageService.types[]>;
}

export interface UserSettingsService {
    getUserSettings(): Promise<UserSettingsService.types[]>;
    createUserSettings(data: { theme_ID?: string | null; language_ID?: string | null }): Promise<UserSettingsService.types>;
    updateUserSettings(id: string, data: { theme_ID?: string | null; language_ID?: string | null }): Promise<void>;
}

export namespace ThemeService {
    export interface types {
        ID: string;
        code: string;
        name: string;
        description?: string | null;
        icon?: string | null;
        sortOrder: number;
        isEnabled: boolean;
    }
}

export namespace LanguageService {
    export interface types {
        ID: string;
        code: string;
        name: string;
        nativeName?: string | null;
        sortOrder: number;
        isEnabled: boolean;
    }
}

export namespace UserSettingsService {
    export interface types {
        ID: string;
        user_ID: string;
        theme_ID?: string | undefined;
        language_ID?: string | undefined;
        // Expanded navigation properties (only present when fetched with $expand=theme,language)
        theme?: Theme | undefined;
        language?: Language | undefined;
    }
}

// ---------------------------------------------------------------------------
// Factory function — creates a fully configured service per baseUrl
// ---------------------------------------------------------------------------

export function createIdentityService(httpClient: IdentityHttpClient, baseUrl: string) {
    return {
        getThemes() {
            return fetchODataArray<ThemeService.types>(
                httpClient,
                `${baseUrl}/Themes?$filter=isEnabled eq true&$orderby=sortOrder`
            );
        },
        getLanguages() {
            return fetchODataArray<LanguageService.types>(
                httpClient,
                `${baseUrl}/Languages?$filter=isEnabled eq true&$orderby=sortOrder`
            );
        },
        getUserSettings() {
            return fetchODataArray<UserSettingsService.types>(
                httpClient,
                `${baseUrl}/UserSettings`
            );
        },
        /** Fetches UserSettings with theme and language codes expanded inline. */
        getUserSettingsExpanded() {
            return fetchODataArray<UserSettingsService.types>(
                httpClient,
                `${baseUrl}/UserSettings?$expand=theme,language`
            );
        },
        async createUserSettings(
            data: { theme_ID?: string | null; language_ID?: string | null }
        ): Promise<UserSettingsService.types> {
            return httpClient.post(`${baseUrl}/UserSettings`, data);
        },
        updateUserSettings(
            id: string,
            data: { theme_ID?: string | null; language_ID?: string | null }
        ) {
            return httpClient.patch(`${baseUrl}/UserSettings('${id}')`, data);
        },
    };
}
