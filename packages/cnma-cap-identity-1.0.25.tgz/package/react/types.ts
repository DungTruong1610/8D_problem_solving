/**
 * @cnma/cap-identity — Shared TypeScript interfaces for React components.
 * These map to the CDS entities defined in db/identity.cds
 */

/**
 * Principal Types configuration.
 * Controls which types of principals can be assigned.
 */
export interface SupportType {
    ID: string;
    code: string;
    name: string;
    description?: string;
    icon?: string;
    isEnabled: boolean;
    sortOrder: number;
    createdAt?: string;
    modifiedAt?: string;
}

/**
 * Shadow User - Auto-provisioned via JIT on login.
 */
export interface ShadowUser {
    ID: string;
    origin?: string;
    userId: string;
    idpUserId?: string;
    email?: string;
    firstName?: string;
    lastName?: string;
    displayName?: string;
    isActive: boolean;
    lastLoginAt?: string;
    createdAt?: string;
    modifiedAt?: string;
    memberships?: Array<{
        ID: string;
        group?: { ID: string; name: string; type?: { code?: string } };
    }>;
}

/**
 * Shadow Group - Local groups managed by admins.
 */
export interface ShadowGroup {
    ID: string;
    name: string;
    description?: string;
    type_ID: string;
    type?: SupportType;
    externalId?: string;
    isActive: boolean;
    groupEmail?: string;
    emailNotificationMode?: 'GROUP_ONLY' | 'MEMBERS_ONLY' | 'BOTH';
    members?: GroupMember[];
    createdAt?: string;
    modifiedAt?: string;
}

/**
 * Group Member - Links Users to Groups.
 */
export interface GroupMember {
    ID: string;
    user_ID: string;
    user?: ShadowUser;
    group_ID: string;
    group?: ShadowGroup;
    memberRole?: string;
    source?: string;
    addedBy?: string;
    addedAt?: string;
}

/**
 * SAML Group Mapping - Maps external IDP groups to local groups.
 */
export interface SamlMapping {
    ID: string;
    externalGroupName: string;
    localGroup?: { ID: string; name: string };
    localGroup_ID?: string;
    isEnabled: boolean;
    description?: string;
}

/**
 * Theme - Configurable UI themes available in the system.
 */
export interface Theme {
    ID: string;
    code: string;
    name: string;
    description?: string | null;
    icon?: string | null;
    sortOrder: number;
    isEnabled: boolean;
}

/**
 * Language - Configurable UI languages available in the system.
 */
export interface Language {
    ID: string;
    code: string;
    name: string;
    nativeName?: string | null;
    sortOrder: number;
    isEnabled: boolean;
}

/**
 * User Settings - Per-user theme and language preferences.
 */
export interface UserSettings {
    ID: string;
    user_ID: string;
    theme_ID?: string;
    theme?: Theme;
    language_ID?: string;
    language?: Language;
    createdAt?: string;
    modifiedAt?: string;
}

/**
 * HTTP client interface that consuming apps must implement.
 * This decouples the components from any specific HTTP library (axios, fetch, etc.)
 *
 * The consuming app provides this to OrganizationManager:
 * ```typescript
 * const httpClient: IdentityHttpClient = {
 *     get: (url) => fetch(url).then(r => r.json()),
 *     post: (url, data) => fetch(url, { method: 'POST', body: JSON.stringify(data) }).then(r => r.json()),
 *     patch: (url, data) => fetch(url, { method: 'PATCH', body: JSON.stringify(data) }).then(r => r.json()),
 *     delete: (url) => fetch(url, { method: 'DELETE' }),
 * };
 * ```
 */
export interface IdentityHttpClient {
    get: <T = any>(url: string) => Promise<T>;
    post: <T = any>(url: string, data?: any) => Promise<T>;
    patch: <T = any>(url: string, data?: any) => Promise<T>;
    delete: <T = any>(url: string) => Promise<T>;
}

/**
 * Configuration for OrganizationManager component.
 */
export interface OrganizationManagerProps {
    /** HTTP client for API calls */
    httpClient: IdentityHttpClient;
    /** Base URL for the identity admin API (default: '/odata/v4/admin') */
    baseUrl?: string;
    /** Callback when an error occurs */
    onError?: (message: string) => void;
    /** Callback when a success action completes */
    onSuccess?: (message: string) => void;
    /** Additional CSS class for the root container */
    className?: string;
}

/**
 * Configuration for individual tab components.
 */
export interface IdentityTabProps {
    httpClient: IdentityHttpClient;
    baseUrl: string;
    onError?: (message: string) => void;
    onSuccess?: (message: string) => void;
}
