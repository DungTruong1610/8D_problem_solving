import type { IdentityHttpClient, SupportType, ShadowUser, ShadowGroup, GroupMember, SamlMapping, Theme, Language, UserSettings } from '../types';

/**
 * @cnma/cap-identity — Identity Admin Service
 *
 * Internal service layer that wraps the httpClient for all CRUD operations.
 * Used by all admin tab components. Not exported directly — consumed via OrganizationManager.
 */
export class IdentityAdminService {
    private http: IdentityHttpClient;
    private baseUrl: string;

    constructor(httpClient: IdentityHttpClient, baseUrl: string = '/identity-admin') {
        this.http = httpClient;
        this.baseUrl = baseUrl;
    }

    // --- Support Types ---

    async getSupportTypes(): Promise<SupportType[]> {
        const res = await this.http.get<{ value: SupportType[] }>(
            `${this.baseUrl}/SupportTypes?$orderby=sortOrder asc`
        );
        return res.value || res;
    }

    async updateSupportType(id: string, data: Partial<SupportType>): Promise<void> {
        await this.http.patch(`${this.baseUrl}/SupportTypes(${id})`, data);
    }

    // --- Shadow Users ---

    async importUsers(rows: Array<{
        email: string;
        firstName?: string;
        lastName?: string;
        displayName?: string;
        groups?: string;
    }>): Promise<Array<{ email: string; status: 'created' | 'exists' | 'error'; message: string }>> {
        const raw = await this.http.post<string>(`${this.baseUrl}/importUsers`, { users: JSON.stringify(rows) });
        return typeof raw === 'string' ? JSON.parse(raw) : raw;
    }

    async updateShadowUser(id: string, data: { isActive: boolean }): Promise<void> {
        await this.http.patch(`${this.baseUrl}/ShadowUsers(${id})`, data);
    }

    async getShadowUsers(search?: string): Promise<ShadowUser[]> {
        let url = `${this.baseUrl}/ShadowUsers?$expand=memberships($expand=group($select=ID,name;$expand=type($select=code)))&$orderby=displayName asc`;
        if (search?.trim()) {
            const q = encodeURIComponent(search.trim().toLowerCase());
            url += `&$filter=contains(tolower(displayName),'${q}') or contains(tolower(email),'${q}')`;
        }
        const res = await this.http.get<{ value: ShadowUser[] }>(url);
        return res.value || res;
    }

    // --- Shadow Groups ---

    async getShadowGroups(): Promise<ShadowGroup[]> {
        const res = await this.http.get<{ value: ShadowGroup[] }>(
            `${this.baseUrl}/ShadowGroups?$expand=type,members($select=ID)&$orderby=name asc`
        );
        return res.value || res;
    }

    async createShadowGroup(data: {
        name: string; description?: string; type_ID: string;
        groupEmail?: string; emailNotificationMode?: string;
    }): Promise<ShadowGroup> {
        return await this.http.post(`${this.baseUrl}/ShadowGroups`, data);
    }

    async updateShadowGroup(id: string, data: Partial<ShadowGroup> & { groupEmail?: string | null; description?: string | null; isActive?: boolean }): Promise<void> {
        await this.http.patch(`${this.baseUrl}/ShadowGroups(${id})`, data);
    }

    async deleteShadowGroup(id: string): Promise<void> {
        await this.http.delete(`${this.baseUrl}/ShadowGroups(${id})`);
    }

    // --- Group Members ---

    async getGroupMembers(groupId: string): Promise<GroupMember[]> {
        const res = await this.http.get<{ value: GroupMember[] }>(
            `${this.baseUrl}/GroupMembers?$filter=group_ID eq ${groupId}&$expand=user`
        );
        return res.value || res;
    }

    async addGroupMember(groupId: string, userId: string): Promise<GroupMember> {
        return await this.http.post(`${this.baseUrl}/GroupMembers`, {
            group_ID: groupId,
            user_ID: userId,
            source: 'MANUAL',
            addedAt: new Date().toISOString()
        });
    }

    async removeGroupMember(memberId: string): Promise<void> {
        await this.http.delete(`${this.baseUrl}/GroupMembers(${memberId})`);
    }

    // --- SAML Mappings ---

    async getSamlMappings(): Promise<SamlMapping[]> {
        const res = await this.http.get<{ value: SamlMapping[] }>(
            `${this.baseUrl}/SamlGroupMappings?$expand=localGroup`
        );
        return res.value || res;
    }

    async createSamlMapping(data: { externalGroupName: string; localGroup_ID: string; description?: string }): Promise<SamlMapping> {
        return await this.http.post(`${this.baseUrl}/SamlGroupMappings`, {
            ...data,
            isEnabled: true
        });
    }

    async updateSamlMapping(id: string, data: Partial<SamlMapping>): Promise<void> {
        await this.http.patch(`${this.baseUrl}/SamlGroupMappings(${id})`, data);
    }

    async deleteSamlMapping(id: string): Promise<void> {
        await this.http.delete(`${this.baseUrl}/SamlGroupMappings(${id})`);
    }

    // --- Themes ---

    async getThemes(): Promise<Theme[]> {
        const res = await this.http.get<{ value: Theme[] }>(
            `${this.baseUrl}/Themes?$orderby=sortOrder asc`
        );
        return res.value || res;
    }

    async createTheme(data: Omit<Theme, 'ID'>): Promise<Theme> {
        return await this.http.post(`${this.baseUrl}/Themes`, data);
    }

    async updateTheme(id: string, data: Partial<Theme>): Promise<void> {
        await this.http.patch(`${this.baseUrl}/Themes(${id})`, data);
    }

    async deleteTheme(id: string): Promise<void> {
        await this.http.delete(`${this.baseUrl}/Themes(${id})`);
    }

    // --- Languages ---

    async getLanguages(): Promise<Language[]> {
        const res = await this.http.get<{ value: Language[] }>(
            `${this.baseUrl}/Languages?$orderby=sortOrder asc`
        );
        return res.value || res;
    }

    async createLanguage(data: Omit<Language, 'ID'>): Promise<Language> {
        return await this.http.post(`${this.baseUrl}/Languages`, data);
    }

    async updateLanguage(id: string, data: Partial<Language>): Promise<void> {
        await this.http.patch(`${this.baseUrl}/Languages(${id})`, data);
    }

    async deleteLanguage(id: string): Promise<void> {
        await this.http.delete(`${this.baseUrl}/Languages(${id})`);
    }

    // --- User Settings ---

    async getUserSettings(userId?: string): Promise<UserSettings[]> {
        let url = `${this.baseUrl}/UserSettings`;
        if (userId) {
            url += `?$filter=user_ID eq ${userId}`;
        } else {
            url += '?$expand=theme,language';
        }
        const res = await this.http.get<{ value: UserSettings[] }>(url);
        return res.value || res;
    }

    async updateUserSettings(id: string, data: { theme_ID?: string | null; language_ID?: string | null }): Promise<void> {
        await this.http.patch(`${this.baseUrl}/UserSettings(${id})`, data);
    }
}
