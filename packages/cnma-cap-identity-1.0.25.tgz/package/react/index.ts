/**
 * @cnma/cap-identity — React barrel export
 *
 * Usage:
 *   import { OrganizationManager } from '@cnma/cap-identity/react';
 *   import '@cnma/cap-identity/react/identity.css';
 *
 *   import { UserPreferencesDialog } from '@cnma/cap-identity/react/user/preferences';
 */

// Admin Components
export { OrganizationManager } from './admin/OrganizationManager';
export { SupportTypesTab } from './admin/SupportTypesTab';
export { UsersTab } from './admin/UsersTab';
export { GroupsTab } from './admin/GroupsTab';
export { SamlMappingsTab } from './admin/SamlMappingsTab';
export { GroupMembersPanel } from './admin/GroupMembersPanel';

// User-facing Components
export { UserPreferencesDialog } from './user/preferences';
export { UserPreferencesPage } from './user/preferences';
export type { UserPreferencesPageProps } from './user/preferences';

// i18n (optional — only import if using standalone)
export { default as i18n } from './i18n';

// Reusable service (handles OData envelope automatically)
export { createIdentityService } from './service';

// Types (re-export for consumers)
export type {
    SupportType,
    ShadowUser,
    ShadowGroup,
    GroupMember,
    SamlMapping,
    Theme,
    Language,
    UserSettings,
    IdentityHttpClient,
    OrganizationManagerProps,
    IdentityTabProps,
} from './types';