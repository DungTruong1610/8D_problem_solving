import cds from '@sap/cds';

interface UserSettingsRow {
    ID: string;
    user_ID: string;
    theme_ID?: string | null;
    language_ID?: string | null;
}

/**
 * @cnma/cap-identity — User Settings Processor
 *
 * Business logic for user settings operations:
 * - Lazy provisioning of UserSettings on first access
 * - Validation of theme/language assignments
 *
 * Uses cds.db.run(cds.ql.*) instead of named SELECT/INSERT imports
 * to avoid the undefined-at-load-time issue with CDS named exports.
 */
export class UserSettingsProcessor {

    private log = cds.log('user-settings-processor');

    /**
     * Get or create UserSettings for a given ShadowUser.
     * If no settings exist, creates default (null theme/language → system defaults).
     */
    async getOrCreateSettings(shadowUserId: string): Promise<UserSettingsRow> {
        const { UserSettings } = cds.entities('cnma.identity');

        const existing = await cds.db.run(
            cds.ql.SELECT.one.from(UserSettings).where({ user_ID: shadowUserId })
        );
        if (existing) {
            return existing as UserSettingsRow;
        }

        // Lazily provision with nulls (system defaults)
        await cds.db.run(
            cds.ql.INSERT.into(UserSettings).entries({
                user_ID: shadowUserId,
                theme_ID: null,
                language_ID: null,
            })
        );

        const created = await cds.db.run(
            cds.ql.SELECT.one.from(UserSettings).where({ user_ID: shadowUserId })
        );
        this.log.debug(`UserSettings provisioned for user ${shadowUserId}`);
        return created as UserSettingsRow;
    }

    /**
     * Validate that a theme is enabled and can be assigned.
     */
    async isThemeEnabled(themeCode: string): Promise<boolean> {
        const { Themes } = cds.entities('cnma.identity');
        const theme = await cds.db.run(
            cds.ql.SELECT.one.from(Themes).where({ code: themeCode, isEnabled: true })
        );
        return !!theme;
    }

    /**
     * Validate that a language is enabled and can be assigned.
     */
    async isLanguageEnabled(languageCode: string): Promise<boolean> {
        const { Languages } = cds.entities('cnma.identity');
        const lang = await cds.db.run(
            cds.ql.SELECT.one.from(Languages).where({ code: languageCode, isEnabled: true })
        );
        return !!lang;
    }
}
