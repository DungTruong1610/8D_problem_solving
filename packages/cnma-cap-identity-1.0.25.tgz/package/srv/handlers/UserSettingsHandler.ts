import cds from '@sap/cds';
import { IdentityProvisioner } from '../IdentityProvisioner';
import { UserSettingsProcessor } from '../lib/processors/UserSettingsProcessor';

/**
 * @cnma/cap-identity — User Settings Handler
 *
 * Handles UserSettings authorization:
 * - Users can only read/update/create their own settings
 * - Admins can view/update any user's settings
 *
 * Usage:
 *   const handler = new UserSettingsHandler(this);
 *   handler.register();
 */
export class UserSettingsHandler {

    private srv: cds.ApplicationService;
    private processor: UserSettingsProcessor;
    private log = cds.log('user-settings-handler');

    constructor(srv: cds.ApplicationService) {
        this.srv = srv;
        this.processor = new UserSettingsProcessor();
    }

    register() {
        this.srv.before(['READ', 'UPDATE', 'PATCH'], 'UserSettings', this.authorizeUserSettings.bind(this));
        // Intercept POST: upsert via processor (get-or-create + patch) instead of raw INSERT
        this.srv.on('CREATE', 'UserSettings', this.onCreateUserSettings.bind(this));
        this.srv.on('getUserSettings', this.onGetUserSettings.bind(this));

        this.log.info('[cap-identity] UserSettingsHandler registered');
    }

    /**
     * On CREATE: upsert — get or provision the settings row, then apply theme/language.
     * Uses cds.db directly to avoid module-level SELECT import issues.
     */
    private async onCreateUserSettings(req: cds.Request) {
        if (!req.user?.id) {
            req.error(401, 'Not authenticated');
            return;
        }

        try {
            const origin = IdentityProvisioner.getOrigin(req.user);
            const { ShadowUsers, UserSettings } = cds.entities('cnma.identity');

            const shadowUser = await cds.db.run(
                cds.ql.SELECT.one.from(ShadowUsers).where({ origin, userId: req.user.id })
            );
            if (!shadowUser) {
                req.error(404, 'User not found. Please log in again.');
                return;
            }

            const settings = await this.processor.getOrCreateSettings(shadowUser.ID);

            const patch: Record<string, string | null> = {};
            if ('theme_ID' in req.data) patch.theme_ID = req.data.theme_ID ?? null;
            if ('language_ID' in req.data) patch.language_ID = req.data.language_ID ?? null;

            if (Object.keys(patch).length > 0) {
                await cds.db.run(cds.update(UserSettings, settings.ID).with(patch));
            }

            return cds.db.run(cds.ql.SELECT.one.from(UserSettings).where({ ID: settings.ID }));
        } catch (err: unknown) {
            this.log.error('[cap-identity] UserSettings DB error in onCreateUserSettings:', err instanceof Error ? err.message : err);
            req.error(503, 'Service temporarily unavailable. Please try again.');
        }
    }

    /**
     * Before READ/UPDATE/PATCH: Enforce that users can only access their own settings.
     * Admins are allowed to access any settings.
     * For non-admin READ: auto-provision settings if missing.
     */
    private async authorizeUserSettings(req: cds.Request) {
        if (!req.user?.id) {
            req.error(401, 'Not authenticated');
            return;
        }

        if (req.user.is('admin')) return;

        try {
            const origin = IdentityProvisioner.getOrigin(req.user);
            const { ShadowUsers } = cds.entities('cnma.identity');

            const shadowUser = await cds.db.run(
                cds.ql.SELECT.one.from(ShadowUsers).where({ origin, userId: req.user.id })
            );
            if (!shadowUser) {
                req.error(404, 'User not found');
                return;
            }

            if (req.event === 'READ') {
                await this.processor.getOrCreateSettings(shadowUser.ID);
            } else if (req.event === 'UPDATE' || req.event === 'PATCH') {
                const targetUserId = req.data?.user_ID || req.data?.user?.ID;
                if (targetUserId && targetUserId !== shadowUser.ID) {
                    req.error(403, 'You can only modify your own settings');
                    return;
                }
                req.data.user_ID = shadowUser.ID;
            }
        } catch (err: unknown) {
            this.log.error('[cap-identity] UserSettings DB error in authorizeUserSettings:', err instanceof Error ? err.message : err);
            req.error(503, 'Service temporarily unavailable. Please try again.');
        }
    }

    /**
     * Function: Get user settings for a given userId (or current user if not specified).
     * Creates settings lazily if they don't exist.
     */
    private async onGetUserSettings(req: cds.Request) {
        if (!req.user?.id) {
            req.error(401, 'Not authenticated');
            return;
        }

        const { userId } = req.data || {};
        const origin = IdentityProvisioner.getOrigin(req.user);
        const { ShadowUsers } = cds.entities('cnma.identity');

        if (userId && !req.user.is('admin')) {
            req.error(403, 'Non-admins cannot query other users settings');
            return;
        }

        const whereClause = userId
            ? { ID: userId }
            : { origin, userId: req.user.id };

        const targetShadowUser = await cds.db.run(
            cds.ql.SELECT.one.from(ShadowUsers).where(whereClause)
        );

        if (!targetShadowUser) {
            req.error(404, 'User not found');
            return;
        }

        return this.processor.getOrCreateSettings(targetShadowUser.ID);
    }
}
