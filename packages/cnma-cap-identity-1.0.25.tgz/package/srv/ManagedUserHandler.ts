import cds from '@sap/cds';
import { IdentityProvisioner } from './IdentityProvisioner';

/**
 * @cnma/cap-identity — Managed User Handler
 *
 * Automatically resolves the current user's ShadowUser UUID
 * and sets createdBy_ID / modifiedBy_ID on create/update operations.
 *
 * This handler works with the custom managedWithUser aspect that uses
 * Association to ShadowUsers instead of string user IDs.
 *
 * Usage:
 *   import { ManagedUserHandler } from '@cnma/cap-identity/srv';
 *
 *   // In your service init():
 *   const managedUserHandler = new ManagedUserHandler(this);
 *   managedUserHandler.register();
 *
 * Note: Only needed if your entities use the managedWithUser aspect.
 * If using standard `managed` from @sap/cds/common, this is not needed.
 */
export class ManagedUserHandler {

    private srv: cds.ApplicationService;
    private userCache: Map<string, string> = new Map();
    private static readonly MAX_CACHE_SIZE = 1000;
    private log = cds.log('managed-user-handler');

    constructor(srv: cds.ApplicationService) {
        this.srv = srv;
    }

    /**
     * Register the handler for all CREATE/UPDATE operations.
     */
    register() {
        // Register for all entity operations
        this.srv.before(['CREATE', 'UPDATE'], '*', this.resolveManagedUser.bind(this));
        this.log.debug('[cap-identity] ManagedUserHandler registered for CREATE/UPDATE operations');
    }

    /**
     * Before CREATE/UPDATE: Resolve user UUID from ShadowUsers
     */
    private async resolveManagedUser(req: cds.Request) {
        // Skip if no user context (system operations)
        if (!req.user?.id) return;

        const userId = req.user.id;

        // Skip for identity entities to avoid recursion
        const entityName = req.target?.name || '';
        if (entityName.includes('ShadowUsers') ||
            entityName.includes('ShadowGroups') ||
            entityName.includes('GroupMembers') ||
            entityName.includes('SupportTypes')) {
            return;
        }

        // Skip if data is not an object
        if (!req.data || typeof req.data !== 'object') return;

        // Get or resolve UUID using composite key (origin + userId)
        const origin = IdentityProvisioner.getOrigin(req.user);
        const cacheKey = `${origin}:${userId}`;
        let userUUID: string | undefined = this.userCache.get(cacheKey);

        if (!userUUID) {
            userUUID = await this.lookupUserUUID(userId, origin) ?? undefined;
            if (userUUID) {
                this.evictIfNeeded();
                this.userCache.set(cacheKey, userUUID);
            }
        }

        // If no UUID found, user doesn't exist in ShadowUsers yet (JIT not done)
        // In this case, we leave the fields null and let JIT create the user
        if (!userUUID) {
            this.log.warn(`User ${userId} not found in ShadowUsers`);
            return;
        }

        // Handle array of data (batch operations)
        const items = Array.isArray(req.data) ? req.data : [req.data];

        for (const data of items) {
            // Set createdBy_ID on CREATE
            if (req.event === 'CREATE') {
                data.createdBy_ID = userUUID;
                data.modifiedBy_ID = userUUID;
            }
            // Set modifiedBy_ID on UPDATE
            else if (req.event === 'UPDATE') {
                data.modifiedBy_ID = userUUID;
            }
        }
    }

    /**
     * Lookup ShadowUser UUID by origin and userId
     */
    private async lookupUserUUID(userId: string, origin: string): Promise<string | null> {
        try {
            const { ShadowUsers } = cds.entities('cnma.identity');
            const user = await cds.db.run(
                cds.ql.SELECT.one.from(ShadowUsers).where({ origin, userId }).columns('ID')
            );
            return user?.ID || null;
        } catch (e) {
            this.log.error(`Error looking up user ${origin}:${userId}:`, e);
            return null;
        }
    }

    /**
     * Evict oldest entries if cache exceeds max size.
     * Uses Array for FIFO ordering.
     */
    private evictIfNeeded(): void {
        if (this.userCache.size >= ManagedUserHandler.MAX_CACHE_SIZE) {
            const keysToDelete = Array.from(this.userCache.keys()).slice(0, 100);
            for (const key of keysToDelete) {
                this.userCache.delete(key);
            }
        }
    }
}
