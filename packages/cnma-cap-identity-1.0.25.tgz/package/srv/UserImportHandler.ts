import cds, { SELECT, INSERT } from '@sap/cds';

export interface ImportUserRow {
    email: string;
    firstName?: string;
    lastName?: string;
    displayName?: string;
    groups?: string; // semicolon-separated group names
    origin?: string; // IDP origin, defaults to 'sap.default'
}

export interface ImportUserResult {
    email: string;
    status: 'created' | 'exists' | 'error';
    message: string;
}

/**
 * UserImportHandler — Bulk user provisioning for initial deployment.
 *
 * Creates ShadowUser records from uploaded CSV data without requiring
 * users to log in first. Actual IDP fields (idpUserId, origin, etc.)
 * are synced the first time each user authenticates via JIT provisioning.
 *
 * Rules:
 * - origin defaults to 'sap.default' for all imported users
 * - Duplicate emails are skipped (reported as 'exists') but group
 *   assignments are still applied
 * - Unknown group names are noted in the result message but do not
 *   cause the row to fail
 */
export class UserImportHandler {

    private srv: cds.ApplicationService;
    private log = cds.log('identity.import');

    constructor(srv: cds.ApplicationService) {
        this.srv = srv;
    }

    register() {
        this.srv.on('importUsers', this.onImportUsers.bind(this));
        this.log.info('[cap-identity] UserImportHandler registered');
    }

    private async onImportUsers(req: cds.Request): Promise<string> {
        const { users: usersJson } = req.data as { users: string };

        let rows: ImportUserRow[];
        try {
            rows = JSON.parse(usersJson);
            if (!Array.isArray(rows)) throw new Error('Expected array');
        } catch {
            req.error(400, 'Invalid users payload — expected a JSON array');
            return '';
        }

        const { ShadowUsers, ShadowGroups, GroupMembers } = this.srv.entities;
        const results: ImportUserResult[] = [];

        for (const row of rows) {
            const email = row.email?.trim().toLowerCase();

            if (!email) {
                results.push({ email: row.email || '', status: 'error', message: 'Email is required' });
                continue;
            }

            const origin = row.origin?.trim() || 'sap.default';
            const firstName = row.firstName?.trim() || '';
            const lastName  = row.lastName?.trim()  || '';
            const displayName = row.displayName?.trim()
                || (firstName || lastName ? `${firstName} ${lastName}`.trim() : email);

            let shadowUserId: string;

            try {
                // Check for existing user (composite key: origin + userId = email)
                const existing = await SELECT.one.from(ShadowUsers)
                    .where({ origin, userId: email }) as any;

                if (existing) {
                    // Backfill any missing profile fields without overwriting populated ones
                    const patch: Record<string, string> = {};
                    if (!existing.firstName && firstName) patch.firstName = firstName;
                    if (!existing.lastName  && lastName)  patch.lastName  = lastName;
                    if (!existing.displayName && displayName) patch.displayName = displayName;
                    if (!existing.email && email) patch.email = email;

                    if (Object.keys(patch).length > 0) {
                        await cds.run(UPDATE(ShadowUsers).where({ ID: existing.ID }).set(patch));
                    }

                    shadowUserId = existing.ID;
                    results.push({ email, status: 'exists', message: 'User already exists — profile backfilled' });
                } else {
                    // Create new pre-provisioned user
                    await INSERT.into(ShadowUsers).entries({
                        origin,
                        userId: email,
                        email,
                        firstName,
                        lastName,
                        displayName,
                        isActive: true,
                    });

                    const created = await SELECT.one.from(ShadowUsers)
                        .where({ origin, userId: email }) as any;

                    shadowUserId = created.ID;
                    results.push({ email, status: 'created', message: 'User created successfully' });
                }

                // Assign groups (regardless of create vs exists)
                if (row.groups) {
                    const groupNames = row.groups
                        .split(';')
                        .map((g: string) => g.trim())
                        .filter(Boolean);

                    const unknownGroups: string[] = [];

                    for (const groupName of groupNames) {
                        const group = await SELECT.one.from(ShadowGroups)
                            .where({ name: groupName }) as any;

                        if (!group) {
                            unknownGroups.push(groupName);
                            continue;
                        }

                        // Idempotent — skip if already a member
                        const alreadyMember = await SELECT.one.from(GroupMembers)
                            .where({ user_ID: shadowUserId, group_ID: group.ID });

                        if (!alreadyMember) {
                            await INSERT.into(GroupMembers).entries({
                                user_ID:  shadowUserId,
                                group_ID: group.ID,
                                source:   'MANUAL',
                                addedAt:  new Date(),
                            });
                        }
                    }

                    if (unknownGroups.length > 0) {
                        // Append warning to the result without changing status
                        const last = results[results.length - 1];
                        last.message += ` (unknown groups skipped: ${unknownGroups.join(', ')})`;
                    }
                }
            } catch (err: any) {
                this.log.error(`Failed to import user ${email}:`, err);
                results.push({ email, status: 'error', message: err.message || 'Unexpected error' });
            }
        }

        const created = results.filter(r => r.status === 'created').length;
        const skipped = results.filter(r => r.status === 'exists').length;
        const errors  = results.filter(r => r.status === 'error').length;
        this.log.info(`Import complete — created: ${created}, exists: ${skipped}, errors: ${errors}`);

        return JSON.stringify(results);
    }
}
