import cds from '@sap/cds';

/**
 * @cnma/cap-identity — User Resolver Helper
 *
 * Utility class to resolve IDP user identifiers (email, subject ID)
 * to ShadowUser UUIDs. Includes in-memory caching for performance.
 *
 * Usage:
 *   import { UserResolverHelper } from '@cnma/cap-identity/srv';
 *
 *   const resolver = new UserResolverHelper(srv);
 *   const uuid = await resolver.resolveUserUUID('alice@example.com');
 *   const bulk = await resolver.resolveMultipleUsers(['alice@example.com', 'bob@example.com']);
 */
export class UserResolverHelper {

    private srv: cds.Service;
    private cache: Map<string, string> = new Map();
    private static readonly MAX_CACHE_SIZE = 1000;
    private log = cds.log('user-resolver-helper');

    constructor(srv: cds.Service) {
        this.srv = srv;
    }

    /**
     * Resolve an IDP user identifier to its ShadowUser UUID.
     * Returns null if user is not found in ShadowUsers table.
     *
     * @param userId - The IDP user identifier (email or subject ID)
     * @param origin - The IDP origin (e.g., 'sap.default', 'azure-ad'). Defaults to 'sap.default'
     * @returns The ShadowUser UUID or null if not found
     */
    async resolveUserUUID(userId: string, origin: string = 'sap.default'): Promise<string | null> {
        if (!userId) return null;

        // Create composite cache key
        const cacheKey = `${origin}:${userId}`;

        // Check cache first
        const cached = this.cache.get(cacheKey);
        if (cached) {
            return cached;
        }

        try {
            const { ShadowUsers } = this.srv.entities;
            const user = await cds.db.run(
                cds.ql.SELECT.one.from(ShadowUsers).where({ origin: origin, userId: userId }).columns('ID')
            ) as { ID: string } | null;

            if (user?.ID) {
                this.evictIfNeeded();
                this.cache.set(cacheKey, user.ID);
                return user.ID;
            }

            this.log.warn(`ShadowUser not found for IDP user: ${origin}:${userId}`);
            return null;
        } catch (e) {
            this.log.error(`Error resolving ShadowUser for ${origin}:${userId}:`, e);
            return null;
        }
    }

    /**
     * Bulk resolve multiple user IDs to UUIDs.
     * Useful for batch operations.
     *
     * @param userIds - Array of IDP user identifiers
     * @param origin - The IDP origin (e.g., 'sap.default', 'azure-ad'). Defaults to 'sap.default'
     * @returns Map of userId -> UUID (only includes found users)
     */
    async resolveMultipleUsers(userIds: string[], origin: string = 'sap.default'): Promise<Map<string, string>> {
        const resultMap = new Map<string, string>();
        const toFetch: string[] = [];

        // Check cache first (using composite key)
        for (const userId of userIds) {
            const cacheKey = `${origin}:${userId}`;
            const cached = this.cache.get(cacheKey);
            if (cached) {
                resultMap.set(userId, cached);
            } else {
                toFetch.push(userId);
            }
        }

        // Fetch remaining from DB using composite key (origin + userId)
        if (toFetch.length > 0) {
            try {
                const { ShadowUsers } = this.srv.entities;
                const users = await cds.db.run(
                    cds.ql.SELECT.from(ShadowUsers).where({ origin, userId: { in: toFetch } }).columns('ID', 'userId')
                ) as { ID: string; userId: string }[];

                for (const user of users) {
                    const cacheKey = `${origin}:${user.userId}`;
                    this.evictIfNeeded();
                    this.cache.set(cacheKey, user.ID);
                    resultMap.set(user.userId, user.ID);
                }
            } catch (e) {
                this.log.error(`Error bulk resolving ShadowUsers for origin ${origin}:`, e);
            }
        }

        return resultMap;
    }

    /**
     * Clear the cache (useful for testing or memory management).
     */
    clearCache(): void {
        this.cache.clear();
    }

    /**
     * Evict oldest entries if cache exceeds max size.
     * Uses Array for FIFO ordering.
     */
    private evictIfNeeded(): void {
        if (this.cache.size >= UserResolverHelper.MAX_CACHE_SIZE) {
            const keysToDelete = Array.from(this.cache.keys()).slice(0, 100);
            for (const key of keysToDelete) {
                this.cache.delete(key);
            }
        }
    }
}
