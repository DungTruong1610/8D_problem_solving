import cds from '@sap/cds';
import { IdentityServiceHandler } from './IdentityServiceHandler';
import { UserSettingsHandler } from './handlers/UserSettingsHandler';

/**
 * IdentityService — CAP service handler
 *
 * Discovered by CAP convention (filename matches CDS file).
 * Delegates custom function handlers to IdentityServiceHandler.
 */
export default class IdentityService extends cds.ApplicationService {
    async init() {
        const handler = new IdentityServiceHandler(this);
        handler.register();

        const settingsHandler = new UserSettingsHandler(this);
        settingsHandler.register();

        await super.init();
    }
}
