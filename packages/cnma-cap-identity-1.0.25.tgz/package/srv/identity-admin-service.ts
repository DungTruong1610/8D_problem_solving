import cds from '@sap/cds';
import { IdentityServiceHandler } from './IdentityServiceHandler';
import { UserImportHandler } from './UserImportHandler';
import { UserSettingsHandler } from './handlers/UserSettingsHandler';

/**
 * IdentityAdminService — CAP service handler
 *
 * Discovered by CAP convention (filename matches CDS file).
 * Delegates custom function handlers to IdentityServiceHandler.
 */
export default class IdentityAdminServiceHandler extends cds.ApplicationService {
    async init() {
        const handler = new IdentityServiceHandler(this);
        handler.register();

        const importHandler = new UserImportHandler(this);
        importHandler.register();

        const settingsHandler = new UserSettingsHandler(this);
        settingsHandler.register();

        await super.init();
    }
}
