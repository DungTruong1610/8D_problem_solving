/**
 * @cnma/cap-identity — Public Identity Service
 *
 * Read-only identity resolution for all authenticated users.
 * Any logged-in user can call me(), search users/groups, and resolve memberships.
 *
 * Authorization: @requires 'authenticated-user'
 */
using { cnma.identity as db } from '../db/identity';

@requires: 'authenticated-user'
service IdentityService @(path: '/identity') {

    // Principal Types (read-only, filtered to enabled types)
    @readonly
    entity SupportTypes as projection on db.SupportTypes
        where isEnabled = true
        order by sortOrder asc;

    // Users (read-only, everyone can search)
    @readonly
    entity ShadowUsers as projection on db.ShadowUsers
        where isActive = true;

    // Groups (read-only, everyone can search)
    @readonly
    entity ShadowGroups as projection on db.ShadowGroups
        where isActive = true;

    // Group Members (read-only)
    @readonly
    entity GroupMembers as projection on db.GroupMembers;

    // Themes (read-only, filtered to enabled)
    @readonly
    entity Themes as projection on db.Themes
        where isEnabled = true
        order by sortOrder asc;

    // Languages (read-only, filtered to enabled)
    @readonly
    entity Languages as projection on db.Languages
        where isEnabled = true
        order by sortOrder asc;

    // User Settings (each user can only PATCH their own; READ auto-provisions on first call)
    entity UserSettings as projection on db.UserSettings;

    // Get current user's ShadowUser record (JIT provisioning trigger)
    function me() returns ShadowUsers;

    // Resolve all users in a group (for approval resolution)
    function resolveGroupMembers(groupId: UUID) returns array of ShadowUsers;

    // Get groups that a user belongs to
    function getUserGroups(userId: UUID) returns array of ShadowGroups;
}
