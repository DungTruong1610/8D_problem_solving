/**
 * @cnma/cap-identity — Admin Identity Service
 *
 * Full CRUD for managing the Shadow Directory.
 * Only users with 'admin' scope can access this service.
 *
 * Authorization: @requires 'admin'
 * Path: /identity-admin
 *
 * Host app maps 'admin' scope in xs-security.json:
 *   { "name": "$XSAPPNAME.admin", "description": "Admin scope" }
 */
using { cnma.identity as db } from '../db/identity';

@requires: 'admin'
service IdentityAdminService @(path: '/identity-admin') {

    // Support Types — admin can toggle enabled/disabled
    entity SupportTypes as projection on db.SupportTypes
        order by sortOrder asc;

    // Shadow Users — admin can view and update (e.g., deactivate/reactivate)
    entity ShadowUsers as projection on db.ShadowUsers;

    // Groups — full CRUD
    entity ShadowGroups as projection on db.ShadowGroups;

    // Group Members — full CRUD (add/remove members)
    entity GroupMembers as projection on db.GroupMembers;

    // SAML Group Mappings — full CRUD
    entity SamlGroupMappings as projection on db.SamlGroupMappings;

    // Themes — full CRUD
    entity Themes as projection on db.Themes
        order by sortOrder asc;

    // Languages — full CRUD
    entity Languages as projection on db.Languages
        order by sortOrder asc;

    // User Settings — full CRUD (view/update any user's settings)
    entity UserSettings as projection on db.UserSettings;

    /**
     * Bulk import users from CSV/upload data.
     * Creates ShadowUser records and assigns group memberships.
     * Actual IDP fields (idpUserId, etc.) are filled in on first login via JIT.
     *
     * Input:  JSON array of { email, firstName?, lastName?, displayName?, groups? }
     *         groups = semicolon-separated group names (e.g. "ACCOUNTANT;PURCHASER")
     * Output: JSON array of { email, status, message }
     *         status = 'created' | 'exists' | 'error'
     */
    action importUsers(users: LargeString) returns LargeString;
}
