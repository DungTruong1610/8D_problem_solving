import cds from '@sap/cds';
import { IdentityProvisioner } from './IdentityProvisioner';

/**
 * @cnma/cap-identity — Identity Service Handler
 *
 * Handles the IdentityService CDS service endpoints:
 * - me()                  : Get current user's ShadowUser record + admin status + group memberships
 * - resolveGroupMembers() : Get all active users in a group
 * - getUserGroups()        : Get all active groups a user belongs to
 *
 * Usage:
 *   import { IdentityServiceHandler } from '@cnma/cap-identity/srv';
 *
 *   // Option 1: As a standalone CDS service (register in server.ts)
 *   cds.on('serving', 'IdentityService', (srv) => {
 *       const handler = new IdentityServiceHandler(srv);
 *       handler.register();
 *   });
 *
 *   // Option 2: Register in an existing ApplicationService
 *   const handler = new IdentityServiceHandler(this);
 *   handler.register();
 */
export class IdentityServiceHandler {

    private srv: cds.ApplicationService;
    private log = cds.log('identity');

    constructor(srv: cds.ApplicationService) {
        this.srv = srv;
    }

    /**
     * Register all identity service handlers.
     */
    register() {
        this.srv.on('me', this.onMe.bind(this));
        this.srv.on('resolveGroupMembers', this.onResolveGroupMembers.bind(this));
        this.srv.on('getUserGroups', this.onGetUserGroups.bind(this));

        this.log.info('[cap-identity] IdentityServiceHandler registered');
    }

    /**
     * Get current authenticated user's ShadowUser record.
     * Triggers JIT provisioning if user doesn't exist.
     * Returns ShadowUser record + isAdmin flag + group memberships.
     */
    private async onMe(req: cds.Request) {
        if (!req.user?.id) {
            req.error(401, 'Not authenticated');
            return;
        }

        // Debug: Log origin for troubleshooting (only at debug level)
        const origin = IdentityProvisioner.getOrigin(req.user);
        this.log.debug(`Resolving user: ${origin}:${req.user.id}`);

        // Ensure user is provisioned
        await IdentityProvisioner.provisionUser(req.user);

        const { ShadowUsers, GroupMembers } = this.srv.entities;

        const shadowUser = await cds.db.run(
            cds.ql.SELECT.one.from(ShadowUsers).where({ origin, userId: req.user.id })
        );

        if (!shadowUser) {
            req.error(404, 'User not found after provisioning');
            return;
        }

        // Fetch user's group memberships for frontend authorization checks
        const memberships = await cds.db.run(
            cds.ql.SELECT.from(GroupMembers).columns('group_ID').where({ user_ID: shadowUser.ID })
        );

        const groupIds = memberships.map((m: { group_ID: string }) => m.group_ID);
        this.log.debug(`User ${shadowUser.ID} belongs to ${groupIds.length} groups: ${groupIds.join(', ')}`);

        // Add admin status based on XSUAA scope + group memberships
        return {
            ...shadowUser,
            isAdmin: req.user.is('admin'),  // Check if user has admin scope
            groupIds  // Array of group IDs the user belongs to
        };
    }

    /**
     * Resolve all users who are members of a group.
     * Used by ApproverResolver to expand group assignments.
     */
    private async onResolveGroupMembers(req: cds.Request) {
        const { groupId } = req.data;

        if (!groupId) {
            req.error(400, 'groupId is required');
            return;
        }

        const { ShadowUsers, GroupMembers } = this.srv.entities;

        const members = await cds.db.run(
            cds.ql.SELECT.from(GroupMembers).columns('user_ID').where({ group_ID: groupId })
        );

        const userIds = members.map((m: { user_ID: string }) => m.user_ID);

        if (userIds.length === 0) {
            return [];
        }

        const users = await cds.db.run(
            cds.ql.SELECT.from(ShadowUsers).where({ ID: { in: userIds }, isActive: true })
        );

        return users;
    }

    /**
     * Get all groups that a user belongs to.
     * Used for inbox filtering and RLS.
     */
    private async onGetUserGroups(req: cds.Request) {
        const { userId } = req.data;

        if (!userId) {
            req.error(400, 'userId is required');
            return;
        }

        const { ShadowGroups, GroupMembers } = this.srv.entities;

        const memberships = await cds.db.run(
            cds.ql.SELECT.from(GroupMembers).columns('group_ID').where({ user_ID: userId })
        );

        const groupIds = memberships.map((m: { group_ID: string }) => m.group_ID);

        if (groupIds.length === 0) {
            return [];
        }

        const groups = await cds.db.run(
            cds.ql.SELECT.from(ShadowGroups).where({ ID: { in: groupIds }, isActive: true })
        );

        return groups;
    }
}
