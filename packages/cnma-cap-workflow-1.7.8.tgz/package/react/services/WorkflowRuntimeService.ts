import type { WorkflowHttpClient, ProcessFlowStep, WorkflowInstance, WorkflowHistory } from '../types';

/**
 * @cnma/cap-workflow — Runtime Service Client
 *
 * Wraps httpClient for all runtime workflow operations.
 * Used by ProcessFlow, ApprovalPanel, WorkflowTimeline components.
 */
export class WorkflowRuntimeService {
    private http: WorkflowHttpClient;
    private baseUrl: string;

    constructor(httpClient: WorkflowHttpClient, baseUrl: string = './workflow') {
        this.http = httpClient;
        this.baseUrl = baseUrl;
    }

    // --- Read ---

    async getWorkflowInstance(id: string): Promise<WorkflowInstance> {
        return await this.http.get(`${this.baseUrl}/WorkflowInstances(${id})`);
    }

    async getProcessFlow(workflowId: string): Promise<ProcessFlowStep[]> {
        const res = await this.http.get<{ value: ProcessFlowStep[] }>(
            `${this.baseUrl}/getProcessFlow(workflowId=${workflowId})`
        );
        return res.value || res;
    }

    async getWorkflowHistory(workflowId: string): Promise<WorkflowHistory[]> {
        const res = await this.http.get<{ value: WorkflowHistory[] }>(
            `${this.baseUrl}/WorkflowHistories?$filter=workflowInstance_ID eq ${workflowId}&$orderby=performedAt desc`
        );
        return res.value || res;
    }

    /**
     * Fetch history across ALL workflow runs for the same reference (document).
     * Tags each event with its runNumber so the timeline can group/separate them.
     */
    async getWorkflowHistoryByReference(
        referenceId: string,
        referenceType: string,
    ): Promise<WorkflowHistory[]> {
        // 1. Find all workflow instances for this reference
        const instanceRes = await this.http.get<{ value: WorkflowInstance[] }>(
            `${this.baseUrl}/WorkflowInstances?$filter=referenceId eq ${referenceId} and referenceType eq '${referenceType}'&$select=ID,runNumber&$orderby=runNumber asc`
        );
        const instances = instanceRes.value || instanceRes;
        if (!instances || instances.length === 0) return [];

        // 2. Build filter for all workflow instance IDs
        const idFilter = instances
            .map((w: WorkflowInstance) => `workflowInstance_ID eq ${w.ID}`)
            .join(' or ');

        const historyRes = await this.http.get<{ value: WorkflowHistory[] }>(
            `${this.baseUrl}/WorkflowHistories?$filter=${idFilter}&$orderby=performedAt desc`
        );
        const events = historyRes.value || historyRes;

        // 3. Tag each event with its runNumber
        const runMap = new Map(instances.map((w: WorkflowInstance) => [w.ID, w.runNumber]));
        return events.map((e: WorkflowHistory) => ({
            ...e,
            runNumber: runMap.get(e.workflowInstance_ID || '') || 1,
        }));
    }

    // --- Actions ---

    async startWorkflow(referenceId: string, referenceType: string, definitionId: string, opts?: {
        responsibleType?: string;
        responsibleId?: string;
    }): Promise<{ workflowId: string; status: string }> {
        return await this.http.post(`${this.baseUrl}/startWorkflow`, {
            referenceId, referenceType, definitionId, ...opts,
        });
    }

    async approveTask(taskId: string, comment?: string): Promise<{ taskId: string; status: string }> {
        return await this.http.post(`${this.baseUrl}/approveStep`, { taskId, comment });
    }

    async rejectTask(taskId: string, comment: string): Promise<{ taskId: string; status: string }> {
        return await this.http.post(`${this.baseUrl}/rejectStep`, { taskId, comment });
    }

    async reassignTask(taskId: string, newAssigneeType: string, newAssigneeId: string, reason: string): Promise<{ taskId: string; status: string }> {
        return await this.http.post(`${this.baseUrl}/reassignApprover`, {
            taskId, newAssigneeType, newAssigneeId, reason,
        });
    }

    async cancelWorkflow(workflowId: string, reason?: string): Promise<{ workflowId: string; status: string }> {
        return await this.http.post(`${this.baseUrl}/cancelWorkflow`, { workflowId, reason });
    }

    async rerunWorkflow(workflowId: string): Promise<{ newWorkflowId: string; status: string }> {
        return await this.http.post(`${this.baseUrl}/rerunWorkflow`, { workflowId });
    }

    async remindApprovers(workflowId: string): Promise<{ reminded: number }> {
        return await this.http.post(`${this.baseUrl}/remindApprovers`, { workflowId });
    }

    // --- Functions ---

    async getAvailableWorkflows(objectType: string, orgKeyValue?: string): Promise<Array<{
        definitionId: string;
        workflowType: string;
        description: string;
    }>> {
        const params = orgKeyValue
            ? `objectType='${objectType}',orgKeyValue='${orgKeyValue}'`
            : `objectType='${objectType}'`;
        const res = await this.http.get<{ value: Array<{ definitionId: string; workflowType: string; description: string }> }>(
            `${this.baseUrl}/getAvailableWorkflows(${params})`
        );
        return res.value || res;
    }

    /**
     * Get the active step's field settings for the current user.
     * Used by the form renderer to enable per-field editability during approval.
     *
     * @returns isCurrentApprover=true if calling user has a pending task,
     *          along with parsed fieldSettings for form-level override.
     */
    async getActiveStepFieldSettings(workflowId: string): Promise<{
        isCurrentApprover: boolean;
        isResponsiblePerson: boolean;
        stepName: string | null;
        pendingTaskCount: number;
        fieldSettings: Record<string, 'readonly' | 'editable' | 'mandatory' | 'hidden'> | null;
    }> {
        const res = await this.http.get<any>(
            `${this.baseUrl}/getActiveStepFieldSettings(workflowId=${workflowId})`
        );

        const data = res.value ?? res;

        // Normalize fieldSettings: convert both array format (new) and object format (legacy) → Record<fieldName, mode>
        let fieldSettings: Record<string, 'readonly' | 'editable' | 'mandatory' | 'hidden'> | null = null;
        if (data.fieldSettings) {
            const parsed = JSON.parse(data.fieldSettings);
            if (Array.isArray(parsed)) {
                // New format saved by FieldSettingsEditor: [{ fieldName, mode, label? }]
                fieldSettings = {};
                for (const item of parsed) {
                    if (item.fieldName && item.mode) {
                        const key = item.fieldName.endsWith('.value') && !item.fieldName.includes('[]')
                            ? item.fieldName.slice(0, -6)
                            : item.fieldName;
                        fieldSettings[key] = item.mode;
                    }
                }
            } else if (typeof parsed === 'object' && parsed !== null) {
                // Legacy format: { fieldName: mode }
                fieldSettings = parsed;
            }
        }

        return {
            isCurrentApprover: data.isCurrentApprover,
            isResponsiblePerson: data.isResponsiblePerson ?? false,
            stepName: data.stepName,
            pendingTaskCount: data.pendingTaskCount ?? 1,
            fieldSettings,
        };
    }
}
