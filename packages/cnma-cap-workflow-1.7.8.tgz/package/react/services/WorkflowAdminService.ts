import type {
    WorkflowHttpClient,
    WorkflowDefinition,
    WorkflowStepDefinition,
    DefaultStepApprover,
    WorkflowObjectType,
    StepDependency,
} from '../types';

/**
 * @cnma/cap-workflow — Admin Service Client
 *
 * Wraps httpClient for workflow definition CRUD operations.
 * Used by WorkflowManager admin components.
 */
export class WorkflowAdminService {
    private http: WorkflowHttpClient;
    private baseUrl: string;

    constructor(httpClient: WorkflowHttpClient, baseUrl: string = './workflow-admin') {
        this.http = httpClient;
        this.baseUrl = baseUrl;
    }

    // --- Object Types ---

    async getObjectTypes(): Promise<WorkflowObjectType[]> {
        const res = await this.http.get<{ value: WorkflowObjectType[] }>(
            `${this.baseUrl}/WorkflowObjectType?$orderby=objectType asc`
        );
        return res.value || res;
    }

    async updateObjectType(id: string, data: Partial<WorkflowObjectType>): Promise<void> {
        await this.http.patch(`${this.baseUrl}/WorkflowObjectType(${id})`, data);
    }

    // --- Workflow Definitions ---

    async getDefinitions(): Promise<WorkflowDefinition[]> {
        const res = await this.http.get<{ value: WorkflowDefinition[] }>(
            `${this.baseUrl}/WorkflowDefinitions?$orderby=objectType asc,priority desc`
        );
        return res.value || res;
    }

    async getDefinition(id: string): Promise<WorkflowDefinition> {
        return await this.http.get(
            `${this.baseUrl}/WorkflowDefinitions(${id})?$expand=steps($expand=defaultApprovers;$orderby=displayOrder asc),stepDependencies`
        );
    }

    async createDefinition(data: Partial<WorkflowDefinition>): Promise<WorkflowDefinition> {
        return await this.http.post(`${this.baseUrl}/WorkflowDefinitions`, data);
    }

    async updateDefinition(id: string, data: Partial<WorkflowDefinition>): Promise<void> {
        await this.http.patch(`${this.baseUrl}/WorkflowDefinitions(${id})`, data);
    }

    async deleteDefinition(id: string): Promise<void> {
        await this.http.delete(`${this.baseUrl}/WorkflowDefinitions(${id})`);
    }

    // --- Steps ---

    async createStep(data: Partial<WorkflowStepDefinition>): Promise<WorkflowStepDefinition> {
        return await this.http.post(`${this.baseUrl}/WorkflowStepDefinitions`, data);
    }

    async updateStep(id: string, data: Partial<WorkflowStepDefinition>): Promise<void> {
        await this.http.patch(`${this.baseUrl}/WorkflowStepDefinitions(${id})`, data);
    }

    async deleteStep(id: string): Promise<void> {
        await this.http.delete(`${this.baseUrl}/WorkflowStepDefinitions(${id})`);
    }

    // --- Default Approvers ---

    async createApprover(data: Partial<DefaultStepApprover>): Promise<DefaultStepApprover> {
        return await this.http.post(`${this.baseUrl}/DefaultStepApprovers`, data);
    }

    async updateApprover(id: string, data: Partial<DefaultStepApprover>): Promise<void> {
        await this.http.patch(`${this.baseUrl}/DefaultStepApprovers(${id})`, data);
    }

    async deleteApprover(id: string): Promise<void> {
        await this.http.delete(`${this.baseUrl}/DefaultStepApprovers(${id})`);
    }

    // --- Dependencies ---

    async getDependencies(definitionId: string): Promise<StepDependency[]> {
        const res = await this.http.get<{ value: StepDependency[] }>(
            `${this.baseUrl}/StepDependencies?$filter=definition_ID eq ${definitionId}`
        );
        return res.value || res;
    }

    async createDependency(data: { definition_ID: string; predecessor_ID: string; successor_ID: string }): Promise<void> {
        await this.http.post(`${this.baseUrl}/StepDependencies`, data);
    }

    async deleteDependency(id: string): Promise<void> {
        await this.http.delete(`${this.baseUrl}/StepDependencies(${id})`);
    }

    // --- Test Email ---

    async sendTestEmail(eventType: string, recipientEmail: string, notificationSettings?: string | null): Promise<void> {
        await this.http.post(`${this.baseUrl}/sendTestEmail`, {
            eventType,
            recipientEmail,
            notificationSettings: notificationSettings || null,
        });
    }
}
