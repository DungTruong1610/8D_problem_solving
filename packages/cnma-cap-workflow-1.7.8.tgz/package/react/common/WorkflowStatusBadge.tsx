/**
 * WorkflowStatusBadge — Domain-specific badge for workflow statuses.
 *
 * Extends the design system `Badge` component by mapping workflow
 * domain status codes (ACTIVE, COMPLETED, REJECTED, etc.) to the
 * correct marketing palette variant automatically.
 *
 * Pattern mirrors DocumentStatusBadge / PostingStatusBadge from @cnma/react-ui.
 *
 * Usage:
 *   <WorkflowStatusBadge status="ACTIVE" />       → "In Progress" (blue)
 *   <WorkflowStatusBadge status="COMPLETED" />    → "Approved" (green)
 *   <WorkflowStatusBadge status="REJECTED" />     → "Rejected" (red)
 *   <WorkflowStatusBadge status="CANCELLED" />    → "Cancelled" (gray)
 *   <WorkflowStatusBadge status="DRAFT" />        → "Draft" (amber)
 *   <WorkflowStatusBadge status="PENDING" />      → "Pending" (orange)
 *
 * ── Design Token Mapping ──────────────────────────────────────────────────
 * | Workflow Status | Badge Variant | Colour (light)      |
 * |-----------------|---------------|---------------------|
 * | ACTIVE          | informative   | Blue                |
 * | COMPLETED       | positive      | Green               |
 * | APPROVED        | positive      | Green               |
 * | REJECTED        | negative      | Red                 |
 * | CANCELLED       | obsoleted     | Gray                |
 * | DRAFT           | risk          | Amber / Gold        |
 * | PENDING         | attention     | Orange              |
 */

import React from 'react';
import { Badge, badgeVariants } from '@cnma/react-ui';
import type { VariantProps } from 'class-variance-authority';
import { cn } from '@cnma/react-ui';
import { useTranslation } from 'react-i18next';

// ── Canonical workflow status codes ──────────────────────────────────────────

export type WorkflowStatus =
    | 'ACTIVE'
    | 'COMPLETED'
    | 'APPROVED'
    | 'REJECTED'
    | 'CANCELLED'
    | 'DRAFT'
    | 'PENDING'
    | (string & {}); // allow unknown status codes without losing type safety

// ── Status → Badge variant map ───────────────────────────────────────────────

const STATUS_VARIANT_MAP: Record<string, VariantProps<typeof badgeVariants>['variant']> = {
    ACTIVE: 'informativeBlue',       // Blue  — in-flight
    COMPLETED: 'positive',      // Green — all done
    APPROVED: 'positive',      // Green — synonym for COMPLETED
    REJECTED: 'negative',      // Red   — hard stop
    CANCELLED: 'obsoleted',     // Gray  — abandoned
    DRAFT: 'risk',          // Amber — not yet submitted
    PENDING: 'attention',     // Orange — waiting to start
};

// ── Status → Human-readable label map ───────────────────────────────────────

const STATUS_I18N_MAP: Record<string, string> = {
    ACTIVE: 'inProgress',
    COMPLETED: 'approved',
    APPROVED: 'approved',
    REJECTED: 'rejected',
    CANCELLED: 'cancelled',
    DRAFT: 'draft',
    PENDING: 'pending',
};

// ── Component ────────────────────────────────────────────────────────────────

export interface WorkflowStatusBadgeProps {
    /** The workflow status code (case-insensitive) */
    status: WorkflowStatus | string | null | undefined;
    /** Optional class overrides */
    className?: string;
}

export function WorkflowStatusBadge({ status, className }: WorkflowStatusBadgeProps) {
    const { t } = useTranslation('workflow');
    const key = (status ?? 'PENDING').toUpperCase();
    const variant = STATUS_VARIANT_MAP[key] ?? 'outline';
    const i18nKey = STATUS_I18N_MAP[key];
    const label = i18nKey ? t(`common.status.${i18nKey}`) : (status ?? 'Unknown');

    return (
        <Badge variant={variant} className={cn('font-semibold', className)}>
            {label}
        </Badge>
    );
}
