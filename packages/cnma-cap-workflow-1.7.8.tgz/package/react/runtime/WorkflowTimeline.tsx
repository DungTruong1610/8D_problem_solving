import React, { useEffect, useState, useCallback } from 'react';
import { useTranslation } from 'react-i18next';
import {
    CheckCircle2, XCircle, PlayCircle, StopCircle, RotateCw,
    UserPlus, Clock, Loader2, AlertCircle, History, User, ChevronDown, ChevronUp
} from 'lucide-react';
import { Badge, cn, Card, CardContent, CardHeader, CardTitle } from '@cnma/react-ui';
import { WorkflowRuntimeService } from '../services/WorkflowRuntimeService';
import type { WorkflowTimelineProps, WorkflowHistory } from '../types';

/**
 * WorkflowTimeline — Grouped audit log for workflow events.
 *
 * Events are grouped by step name (like the SAP Flexible Request Management
 * audit log), with collapsible sections, event counts, status transition
 * badges, performer names, and quoted comments.
 *
 * When referenceId + referenceType are provided, shows history across
 * ALL workflow runs with visual "Round N" separators.
 */
export function WorkflowTimeline({
    httpClient,
    workflowId,
    referenceId,
    referenceType,
    baseUrl = '/workflow',
    maxItems = 50,
    className,
}: WorkflowTimelineProps) {
    const { t } = useTranslation('workflow');
    const [events, setEvents] = useState<WorkflowHistory[]>([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState<string | null>(null);

    const service = React.useMemo(
        () => new WorkflowRuntimeService(httpClient, baseUrl),
        [httpClient, baseUrl]
    );

    const loadHistory = useCallback(async () => {
        try {
            setLoading(true);
            setError(null);

            let data: WorkflowHistory[];
            if (referenceId && referenceType) {
                data = await service.getWorkflowHistoryByReference(referenceId, referenceType);
            } else {
                data = await service.getWorkflowHistory(workflowId);
            }

            setEvents(data.slice(0, maxItems));
        } catch (err: any) {
            setError(err.message || t('runtime.timeline.loadFailed'));
        } finally {
            setLoading(false);
        }
    }, [service, workflowId, referenceId, referenceType, maxItems]);

    useEffect(() => { loadHistory(); }, [loadHistory]);

    if (loading) {
        return (
            <div className={cn("flex items-center justify-center py-6", className)}>
                <Loader2 className="animate-spin text-primary" />
                <span className="ml-2 text-sm text-muted-foreground">{t('runtime.timeline.loading')}</span>
            </div>
        );
    }

    if (error) {
        return (
            <div className={cn("flex items-center gap-2 rounded-lg border border-destructive/50 bg-destructive/10 p-3", className)}>
                <div className="flex items-center justify-center rounded-full bg-destructive/20 w-8 h-8">
                    <AlertCircle className="h-4 w-4 text-destructive" />
                </div>
                <span className="text-sm text-destructive">{error}</span>
            </div>
        );
    }

    if (events.length === 0) {
        return (
            <div className={cn("flex flex-col items-center py-6 text-muted-foreground", className)}>
                <History className="h-8 w-8 mb-2 opacity-50" />
                <span className="text-sm">{t('runtime.timeline.noEvents')}</span>
            </div>
        );
    }

    // Group events by step (or 'Workflow' for step-less events)
    const groups = groupEventsByStep(events, t);

    // Determine if we have multiple runs
    const hasMultipleRuns = events.some(e => e.runNumber && e.runNumber > 1);

    return (
        <Card className={cn("w-full overflow-hidden", className)}>
            <CardContent className="px-4 pb-4 pt-3">
                {/* {hasMultipleRuns && (
                    <div className="flex items-center gap-2 pb-3">
                        <RotateCw className="h-3.5 w-3.5 text-muted-foreground" />
                        <span className="text-xs text-muted-foreground">
                            Showing history across all submission rounds
                        </span>
                    </div>
                )} */}
                <div className="space-y-4">
                    {groups.map((group, groupIdx) => (
                        <React.Fragment key={group.key}>
                            {/* Round separator */}
                            {hasMultipleRuns && groupIdx > 0 && group.runNumber !== groups[groupIdx - 1].runNumber && (
                                <div className="flex items-center gap-3 py-2">
                                    <div className="flex-1 border-t border-dashed border-primary/30" />
                                    <Badge variant="secondary" hasBorder={true}>
                                        <RotateCw className="h-3 w-3 mr-1 inline" />
                                        {t('runtime.timeline.round', { number: group.runNumber })}
                                    </Badge>
                                    <div className="flex-1 border-t border-dashed border-primary/30" />
                                </div>
                            )}
                            <StepGroup group={group} t={t} />
                        </React.Fragment>
                    ))}
                </div>
            </CardContent>
        </Card>
    );
}

// ─── Step Group ─────────────────────────────────────────────────────────────

interface EventGroup {
    key: string;
    stepName: string;
    events: WorkflowHistory[];
    runNumber: number;
}

function StepGroup({ group, t }: { group: EventGroup, t: any }) {
    const [expanded, setExpanded] = useState(false);
    const stepIcon = getStepIcon(group.events);

    return (
        <div className="rounded-lg border bg-card">
            {/* Section Header */}
            <button
                onClick={() => setExpanded(!expanded)}
                className={cn(
                    "flex items-center justify-between w-full rounded-t-lg px-3 py-2.5 transition-colors",
                    "hover:bg-muted/50 group"
                )}
            >
                <div className="flex items-center gap-2.5">
                    <div className={cn(
                        "flex items-center justify-center rounded-full p-1.5",
                        stepIcon.bgColor
                    )}>
                        <stepIcon.icon className={cn("h-3.5 w-3.5", stepIcon.color)} />
                    </div>
                    <span className="text-sm font-semibold text-foreground">{group.stepName}</span>
                </div>
                <div className="flex items-center gap-2">
                    <Badge variant="secondary" hasBorder={true}>
                        {t('runtime.timeline.eventsCount', { count: group.events.length })}
                    </Badge>
                    {expanded
                        ? <ChevronUp className="h-3.5 w-3.5 text-muted-foreground" />
                        : <ChevronDown className="h-3.5 w-3.5 text-muted-foreground" />
                    }
                </div>
            </button>

            {/* Events */}
            {expanded && (
                <div className="border-t border-border/50 px-3 py-3 space-y-3">
                    {group.events.map(event => (
                        <EventCard key={event.ID} event={event} t={t} />
                    ))}
                </div>
            )}
        </div>
    );
}

// ─── Event Card ─────────────────────────────────────────────────────────────

function EventCard({ event, t }: { event: WorkflowHistory, t: any }) {
    const config = EVENT_CONFIG[event.eventType] || EVENT_CONFIG.DEFAULT;
    const performerName = event.performedByName || (event.isSystemAction ? t('runtime.timeline.system') : undefined);
    const label = t(`runtime.timeline.events.${event.eventType}`, config.label || t('runtime.timeline.events.DEFAULT'));

    return (
        <div className="relative pl-5">
            {/* Dot on the timeline */}
            <div className={cn(
                "absolute left-0 top-1.5 w-2.5 h-2.5 rounded-full border-2 border-background shadow-sm",
                config.dotColor,
            )} />

            {/* Vertical connector line */}
            <div className="absolute left-[4px] top-6 bottom-0 w-0.5 bg-border/50" />

            {/* Event card */}
            <div className={cn(
                "rounded-md border bg-card p-3 space-y-2 shadow-sm",
                "transition-shadow hover:shadow-md"
            )}>
                {/* Title row + timestamp */}
                <div className="flex items-baseline justify-between gap-2">
                    <span className="text-sm font-semibold text-foreground">{label}</span>
                    {event.performedAt && (
                        <time className="text-[11px] text-muted-foreground whitespace-nowrap shrink-0">
                            {formatTimestamp(event.performedAt)}
                        </time>
                    )}
                </div>

                {/* Performer */}
                {performerName && (
                    <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
                        <User className="h-3 w-3" />
                        <span>{performerName}</span>
                    </div>
                )}

                {/* Status transition badges */}
                {(event.previousValue || event.newValue) && (
                    <div className="flex items-center gap-1.5 flex-wrap">
                        {event.previousValue && (
                            <Badge
                                variant={getTransitionBadgeVariant(event.previousValue) as any}
                            >
                                {formatStatusValue(event.previousValue, t)}
                            </Badge>
                        )}
                        {event.previousValue && event.newValue && (
                            <span className="text-[10px] text-muted-foreground">→</span>
                        )}
                        {event.newValue && (
                            <Badge
                                variant={getTransitionBadgeVariant(event.newValue) as any}
                            >
                                {formatStatusValue(event.newValue, t)}
                            </Badge>
                        )}
                    </div>
                )}

                {/* Comment */}
                {event.comment && (
                    <div className="border-l-2 border-blue-300 dark:border-blue-700 pl-2.5 py-0.5 mt-1">
                        <p className="text-xs text-muted-foreground italic">
                            &ldquo;{event.comment}&rdquo;
                        </p>
                    </div>
                )}
            </div>
        </div>
    );
}

// ─── Grouping Logic ─────────────────────────────────────────────────────────

function groupEventsByStep(events: WorkflowHistory[], t: any): EventGroup[] {
    const groupMap = new Map<string, EventGroup>();
    const groupOrder: string[] = [];

    for (const event of events) {
        const stepName = event.stepName || t('runtime.timeline.workflow');
        const runNumber = event.runNumber || 1;
        const key = `${runNumber}-${stepName}`;

        if (!groupMap.has(key)) {
            groupMap.set(key, { key, stepName, events: [], runNumber });
            groupOrder.push(key);
        }
        groupMap.get(key)!.events.push(event);
    }

    return groupOrder.map(key => groupMap.get(key)!);
}

// ─── Step Icon Helper ───────────────────────────────────────────────────────

function getStepIcon(events: WorkflowHistory[]): { icon: any; color: string; bgColor: string } {
    const hasApproved = events.some(e => e.eventType === 'STEP_COMPLETED' || e.eventType === 'TASK_APPROVED');
    const hasRejected = events.some(e => e.eventType === 'STEP_REJECTED' || e.eventType === 'TASK_REJECTED');

    if (hasRejected) return { icon: XCircle, color: 'text-status-negative-text', bgColor: 'bg-status-negative/10' };
    if (hasApproved) return { icon: CheckCircle2, color: 'text-status-positive-text', bgColor: 'bg-status-positive/10' };
    return { icon: Clock, color: 'text-status-informative-text', bgColor: 'bg-status-informative/10' };
}

// ─── Event Config ───────────────────────────────────────────────────────────

const EVENT_CONFIG: Record<string, { label: string; dotColor: string }> = {
    WORKFLOW_CREATED: { label: 'Created', dotColor: 'bg-status-informative' },
    WORKFLOW_STARTED: { label: 'Started', dotColor: 'bg-status-informative' },
    WORKFLOW_COMPLETED: { label: 'Completed', dotColor: 'bg-status-positive' },
    WORKFLOW_CANCELLED: { label: 'Cancelled', dotColor: 'bg-status-neutral' },
    WORKFLOW_REJECTED: { label: 'Rejected', dotColor: 'bg-status-negative' },
    WORKFLOW_RERUN: { label: 'Rerun Initiated', dotColor: 'bg-status-informative' },
    STEP_ACTIVATED: { label: 'Step Activated', dotColor: 'bg-status-informative' },
    STEP_COMPLETED: { label: 'Completed', dotColor: 'bg-status-positive' },
    STEP_REJECTED: { label: 'Rejected', dotColor: 'bg-status-negative' },
    STEP_RESET: { label: 'Step Reset', dotColor: 'bg-status-risk' },
    TASK_APPROVED: { label: 'Approved', dotColor: 'bg-status-positive' },
    TASK_REJECTED: { label: 'Rejected', dotColor: 'bg-status-negative' },
    TASK_REASSIGNED: { label: 'Reassigned', dotColor: 'bg-status-informative' },
    DEFAULT: { label: 'Event', dotColor: 'bg-status-neutral' },
};

function getTransitionBadgeVariant(value: string): string {
    const v = value.toUpperCase();
    if (v === 'COMPLETED' || v === 'APPROVED' || v === 'ACTIVE') return 'success';
    if (v === 'REJECTED' || v === 'CANCELLED') return 'destructive';
    if (v === 'PENDING' || v === 'IN_PROGRESS') return 'warning';
    return 'outline';
}

/** Convert "COMPLETED" → "Completed", "IN_PROGRESS" → "In Progress" */
function formatStatusValue(value: string, t: any): string {
    const camelValue = value.toLowerCase().replace(/_([a-z])/g, (g) => g[1].toUpperCase());
    const translated = t(`common.status.${camelValue}`, value);
    if (translated !== value) return translated;

    return value
        .toLowerCase()
        .replace(/_/g, ' ')
        .replace(/\b\w/g, c => c.toUpperCase());
}

function formatTimestamp(iso: string): string {
    const d = new Date(iso);
    const time = d.toLocaleTimeString(undefined, { hour: '2-digit', minute: '2-digit' });
    const date = d.toLocaleDateString(undefined, { month: 'numeric', day: 'numeric', year: 'numeric' });
    return `${time} ${date}`;
}
