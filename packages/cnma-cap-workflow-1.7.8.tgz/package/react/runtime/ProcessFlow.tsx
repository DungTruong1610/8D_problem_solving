import React, { useEffect, useState, useCallback } from 'react';
import {
    Check, X, Clock, ArrowRight, User, Users,
    Loader2, AlertCircle, ChevronDown, ChevronUp, UserPlus
} from 'lucide-react';
import { toast } from '@cnma/react-ui';
import {
    Badge, Button, cn, Card, CardContent, CardHeader, CardTitle, Textarea,
    Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogTrigger
} from '@cnma/react-ui';
import {
    Select, SelectTrigger, SelectValue, SelectContent, SelectItem, SelectGroup,
} from '@cnma/react-ui';
import { WorkflowRuntimeService } from '../services/WorkflowRuntimeService';
import { PrincipalPicker } from '../admin/PrincipalPicker';
import { WorkflowStatusBadge } from '../common/WorkflowStatusBadge';
import { useTranslation } from 'react-i18next';
import type {
    ProcessFlowProps, ProcessFlowStep, ProcessFlowTask, StepStatus, TaskStatus,
    PrincipalTypeOption, PrincipalSearchResult
} from '../types';

/**
 * ProcessFlow — Vertical timeline visualization for a running workflow.
 *
 * Inspired by SAP Flexible Workflow Request Management:
 * - Large circle indicators on left edge (green=completed, blue=active, gray=pending)
 * - Continuous vertical connector line
 * - Expandable approver detail cards with decidedBy info + comments
 *
 * Supports DAG parallel rendering: steps with the same displayOrder
 * are grouped into a single row and rendered side-by-side.
 *
 * Usage:
 * ```tsx
 * <ProcessFlow
 *     httpClient={httpClient}
 *     workflowId="..."
 *     onApprove={(taskId) => openApprovalPanel(taskId)}
 * />
 * ```
 */
export function ProcessFlow({
    httpClient,
    workflowId,
    baseUrl = '/workflow',
    principalTypes,
    onSearchPrincipals,
    onResolvePrincipal,
    onActionComplete,
    onBeforeApprove,
    canUserActOnTask,
    onFieldSettingsLoaded,
    className,
}: ProcessFlowProps) {
    const { t } = useTranslation('workflow');
    const [steps, setSteps] = useState<ProcessFlowStep[]>([]);
    const [activeStepSettings, setActiveStepSettings] = useState<{
        isCurrentApprover: boolean;
        isResponsiblePerson: boolean;
        stepName: string | null;
        pendingTaskCount: number;
        fieldSettings: Record<string, 'readonly' | 'editable' | 'mandatory' | 'hidden'> | null;
    } | null>(null);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState<string | null>(null);
    const [expandedSteps, setExpandedSteps] = useState<Set<string>>(new Set());

    const service = React.useMemo(
        () => new WorkflowRuntimeService(httpClient, baseUrl),
        [httpClient, baseUrl]
    );

    const loadFlow = useCallback(async () => {
        try {
            setLoading(true);
            setError(null);
            const [data, settings] = await Promise.all([
                service.getProcessFlow(workflowId),
                service.getActiveStepFieldSettings(workflowId).catch(() => null)
            ]);
            setSteps(data);
            setActiveStepSettings(settings);
            // Notify host app of field settings so it can apply per-field editability
            if (settings && onFieldSettingsLoaded) {
                onFieldSettingsLoaded({
                    isCurrentApprover: settings.isCurrentApprover,
                    stepName: settings.stepName,
                    fieldSettings: settings.fieldSettings,
                });
            }
            // Default: Expand all steps
            setExpandedSteps(new Set(data.map(s => s.stepId)));
        } catch (err: any) {
            setError(err.message || t('runtime.processFlow.loadFailed', 'Failed to load process flow'));
        } finally {
            setLoading(false);
        }
    }, [service, workflowId, onFieldSettingsLoaded]);

    useEffect(() => { loadFlow(); }, [loadFlow]);

    const toggleStep = useCallback((stepId: string) => {
        setExpandedSteps(prev => {
            const next = new Set(prev);
            if (next.has(stepId)) next.delete(stepId);
            else next.add(stepId);
            return next;
        });
    }, []);

    const resolvedCanUserAct = useCallback((_step: ProcessFlowStep, task: ProcessFlowTask) => {
        // 1. Server-resolved per-task authorization (preferred — most accurate)
        if (task.isActionable !== undefined) {
            return task.isActionable;
        }
        // 2. Fallback: host app callback
        if (canUserActOnTask) {
            return canUserActOnTask(task);
        }
        // 3. Fallback: step-level check (legacy — less precise)
        if (activeStepSettings?.isCurrentApprover && activeStepSettings.stepName === _step.stepName) {
            return true;
        }
        return false;
    }, [activeStepSettings, canUserActOnTask]);

    if (loading) {
        return (
            <div className={cn("flex items-center justify-center py-8", className)}>
                <Loader2 className="animate-spin text-primary" />
                <span className="ml-2 text-sm text-muted-foreground">{t('runtime.processFlow.loading', 'Loading workflow...')}</span>
            </div>
        );
    }

    if (error) {
        return (
            <div className={cn("flex items-center gap-2 rounded-lg border border-destructive/50 bg-destructive/10 p-4", className)}>
                <div className="flex items-center justify-center rounded-full bg-destructive/20 w-9 h-9">
                    <AlertCircle className="h-5 w-5 text-destructive" />
                </div>
                <span className="text-sm text-destructive">{error}</span>
            </div>
        );
    }

    const visibleSteps = steps.filter(step => step.status !== 'SKIPPED');

    if (visibleSteps.length === 0) {
        return (
            <div className={cn("text-center py-8 text-muted-foreground text-sm", className)}>
                {t('runtime.processFlow.noSteps', 'No workflow steps found.')}
            </div>
        );
    }

    // Group steps by displayOrder for parallel rendering
    const lanes = groupByDisplayOrder(visibleSteps);

    return (
        <Card className={cn("w-full overflow-hidden", className)}>
            <CardHeader className="px-4 pt-4 pb-0">
                <CardTitle className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">
                    {t('runtime.processFlow.approvalSteps', 'Approval Steps')}
                </CardTitle>
            </CardHeader>
            <CardContent className="px-4 pb-4 pt-3">
                <div className="relative">
                    {lanes.map((lane, laneIdx) => (
                        <React.Fragment key={laneIdx}>
                            {lane.length === 1 ? (
                                <TimelineStep
                                    step={lane[0]}
                                    isExpanded={expandedSteps.has(lane[0].stepId)}
                                    isLast={laneIdx === lanes.length - 1}
                                    onToggle={() => toggleStep(lane[0].stepId)}
                                    service={service}
                                    principalTypes={principalTypes}
                                    onSearchPrincipals={onSearchPrincipals}
                                    onResolvePrincipal={onResolvePrincipal}
                                    onActionComplete={onActionComplete}
                                    onBeforeApprove={onBeforeApprove}
                                    canUserActOnTask={(task) => resolvedCanUserAct(lane[0], task)}
                                />
                            ) : (
                                // Parallel steps
                                <div className="relative pl-14 pb-4">
                                    {/* Parallel left bar */}
                                    <div className="absolute left-4 top-0 bottom-0 w-0.5 bg-primary/30" />
                                    <div className="text-xs text-primary font-medium mb-2 flex items-center gap-1">
                                        <ArrowRight className="h-3 w-3" />
                                        {t('runtime.processFlow.parallelSteps', 'Parallel ({{count}} steps)', { count: lane.length })}
                                    </div>
                                    <div className="space-y-2">
                                        {lane.map(step => (
                                            <TimelineStep
                                                key={step.stepId}
                                                step={step}
                                                isExpanded={expandedSteps.has(step.stepId)}
                                                isLast={false}
                                                compact
                                                onToggle={() => toggleStep(step.stepId)}
                                                service={service}
                                                principalTypes={principalTypes}
                                                onSearchPrincipals={onSearchPrincipals}
                                                onResolvePrincipal={onResolvePrincipal}
                                                onActionComplete={onActionComplete}
                                                onBeforeApprove={onBeforeApprove}
                                                canUserActOnTask={(task) => resolvedCanUserAct(step, task)}
                                            />
                                        ))}
                                    </div>
                                </div>
                            )}
                        </React.Fragment>
                    ))}
                </div>
            </CardContent>
        </Card>
    );
}

// ─── Step approval strategy label ──────────────────────────────────────────

function ApprovalStrategyBadge({ approvalMode, approverSeqMode }: { approvalMode: string; approverSeqMode?: string }) {
    const { t } = useTranslation('workflow');
    let label: string;
    let colorClass: string;

    const seq = approverSeqMode || 'PARALLEL';

    if (approvalMode === 'ANY_ONE') {
        label = t('runtime.processFlow.anyOneApprover', 'Any one approver');
        colorClass = 'bg-blue-50 text-blue-700 border-blue-200 dark:bg-blue-900/30 dark:text-blue-300 dark:border-blue-800';
    } else {
        // ALL
        label = seq === 'SEQUENTIAL' ? t('runtime.processFlow.allApproversSequential', 'All approvers · Sequential') : t('runtime.processFlow.allApproversParallel', 'All approvers · Parallel');
        colorClass = seq === 'SEQUENTIAL'
            ? 'bg-amber-50 text-amber-700 border-amber-200 dark:bg-amber-900/30 dark:text-amber-300 dark:border-amber-800'
            : 'bg-violet-50 text-violet-700 border-violet-200 dark:bg-violet-900/30 dark:text-violet-300 dark:border-violet-800';
    }

    return (
        <span className={cn(
            'inline-flex items-center gap-1 px-1.5 py-0.5 text-[10px] font-medium rounded border leading-none',
            colorClass,
        )}>
            {label}
        </span>
    );
}

// ─── Timeline Step ──────────────────────────────────────────────────────────

function TimelineStep({
    step, isExpanded, isLast, compact, onToggle, service, principalTypes, onSearchPrincipals, onResolvePrincipal, onActionComplete, onBeforeApprove, canUserActOnTask
}: {
    step: ProcessFlowStep;
    isExpanded: boolean;
    isLast: boolean;
    compact?: boolean;
    onToggle: () => void;
    service: WorkflowRuntimeService;
    principalTypes?: PrincipalTypeOption[];
    onSearchPrincipals?: (principalType: string, query: string) => Promise<PrincipalSearchResult[]>;
    onResolvePrincipal?: (principalType: string, id: string) => Promise<PrincipalSearchResult | null>;
    onActionComplete?: () => void;
    onBeforeApprove?: (taskId: string) => Promise<boolean> | boolean;
    canUserActOnTask?: (task: ProcessFlowTask) => boolean;
}) {
    const config = STEP_CONFIG[step.status];
    const isPending = step.status === 'PENDING' || step.status === 'SKIPPED';

    return (
        <div className="relative flex gap-4">
            {/* ─── Left: Circle + Connector Line ─── */}
            <div className="flex flex-col items-center shrink-0 w-9">
                {/* Circle */}
                <div
                    className={cn(
                        "relative flex items-center justify-center rounded-full border-2 transition-all duration-300",
                        compact ? "w-7 h-7" : "w-9 h-9",
                        config.circleBg,
                        config.circleBorder,
                        step.status === 'ACTIVE' && "shadow-md shadow-btn-action/30",
                    )}
                >
                    <config.icon className={cn(
                        "transition-all",
                        compact ? "h-3.5 w-3.5" : "h-4.5 w-4.5",
                        config.iconColor,
                        step.status === 'ACTIVE' && "animate-spin",
                    )} />

                    {/* Active pulse ring */}
                    {step.status === 'ACTIVE' && (
                        <span className="absolute inset-0 rounded-full border-2 border-btn-action animate-ping opacity-30" />
                    )}
                </div>

                {/* Connector line */}
                {!isLast && (
                    <div
                        className={cn(
                            "w-0.5 flex-1 mt-1 min-h-4 transition-all duration-300",
                            step.status === 'APPROVED'
                                ? "bg-status-positive"
                                : step.status === 'REJECTED'
                                    ? "bg-status-negative"
                                    : step.status === 'ACTIVE'
                                        ? "bg-gradient-to-b from-btn-action to-muted-foreground/30"
                                        : "bg-muted border-l border-dashed border-muted-foreground/30 w-0",
                        )}
                    />
                )}
            </div>

            {/* ─── Right: Step Content ─── */}
            <div className={cn("flex-1 min-w-0", !isLast && "pb-6")}>
                {/* Step Header (clickable to expand) */}
                <button
                    onClick={onToggle}
                    className="flex items-center justify-between w-full text-left group gap-2"
                >
                    {/* Left: Step Name + strategy badge */}
                    <div className={cn(
                        "flex items-center gap-2 font-semibold transition-colors min-w-0 flex-wrap",
                        compact ? "text-sm" : "text-base",
                        isPending && "text-muted-foreground",
                    )}>
                        <span className="truncate">{step.stepName}</span>
                        <ApprovalStrategyBadge
                            approvalMode={step.approvalMode}
                            approverSeqMode={step.approverSeqMode}
                        />
                        {step.tasks.length > 0 && (
                            <span className="inline-flex shrink-0">
                                {isExpanded
                                    ? <ChevronUp className="h-4 w-4 text-muted-foreground" />
                                    : <ChevronDown className="h-4 w-4 text-muted-foreground" />
                                }
                            </span>
                        )}
                    </div>

                    {/* Right: completion time + status badge */}
                    <div className="flex items-center gap-1.5 shrink-0">
                        {step.completedAt && step.status === 'APPROVED' && (
                            <span className="text-xs text-muted-foreground">
                                {formatDateTime(step.completedAt)}
                            </span>
                        )}
                        <WorkflowStatusBadge status={step.status} className="px-1.5 py-0 h-5" />
                    </div>
                </button>

                {/* ─── Expanded: Task Details ─── */}
                {isExpanded && step.tasks.length > 0 && (
                    <div className="mt-2 space-y-2">
                        {step.tasks.map(task => (
                            <TaskCard
                                key={task.taskId}
                                task={task}
                                stepStatus={step.status}
                                service={service}
                                principalTypes={principalTypes}
                                onSearchPrincipals={onSearchPrincipals}
                                onResolvePrincipal={onResolvePrincipal}
                                onActionComplete={onActionComplete}
                                onBeforeApprove={onBeforeApprove}
                                canUserActOnTask={canUserActOnTask}
                            />
                        ))}
                    </div>
                )}
            </div>
        </div>
    );
}

// ─── Task Card ──────────────────────────────────────────────────────────────

type TaskAction = 'none' | 'approving' | 'rejecting' | 'reassigning';

function TaskCard({
    task, stepStatus, service, principalTypes, onSearchPrincipals, onResolvePrincipal, onActionComplete, onBeforeApprove, canUserActOnTask
}: {
    task: ProcessFlowTask;
    stepStatus?: StepStatus;
    service: WorkflowRuntimeService;
    principalTypes?: PrincipalTypeOption[];
    onSearchPrincipals?: (principalType: string, query: string) => Promise<PrincipalSearchResult[]>;
    onResolvePrincipal?: (principalType: string, id: string) => Promise<PrincipalSearchResult | null>;
    onActionComplete?: () => void;
    onBeforeApprove?: (taskId: string) => Promise<boolean> | boolean;
    canUserActOnTask?: (task: ProcessFlowTask) => boolean;
}) {
    const { t } = useTranslation('workflow');
    const [action, setAction] = useState<TaskAction>('none');
    const [comment, setComment] = useState('');
    const [loading, setLoading] = useState(false);
    const [actionError, setActionError] = useState<string | null>(null);

    // Reassign state
    const [reassignType, setReassignType] = useState(task.assigneeType);
    const [reassignId, setReassignId] = useState('');
    const [reassignName, setReassignName] = useState('');
    const [reassignReason, setReassignReason] = useState('');

    const isDisabled = canUserActOnTask ? !canUserActOnTask(task) : false;

    const types = principalTypes && principalTypes.length > 0
        ? principalTypes
        : [
            { code: 'USER', label: t('common.user', 'User') },
            { code: 'GROUP', label: t('common.group', 'Group') }
          ];

    /** Open the approve dialog — runs host validation first if provided */
    const handleOpenApprove = async () => {
        if (onBeforeApprove) {
            const canProceed = await onBeforeApprove(task.taskId);
            if (!canProceed) return; // Host blocked — it handles its own error display
        }
        setAction('approving');
    };

    const handleApprove = async () => {
        try {
            setLoading(true);
            setActionError(null);
            await service.approveTask(task.taskId, comment || undefined);
            toast.success(t('common.messages.taskApproved', 'Task approved successfully'), { position: 'bottom-right' });
            setAction('none');
            setComment('');
            onActionComplete?.();
        } catch (err: any) {
            setActionError(err.message || t('common.messages.approveFailed', 'Failed to approve'));
        } finally {
            setLoading(false);
        }
    };

    const handleReject = async () => {
        if (!comment.trim()) {
            setActionError(t('runtime.approval.commentRequiredRejectError', 'A comment is required when rejecting'));
            return;
        }
        try {
            setLoading(true);
            setActionError(null);
            await service.rejectTask(task.taskId, comment);
            toast.success(t('common.messages.taskRejected', 'Task rejected successfully'), { position: 'bottom-right' });
            setAction('none');
            setComment('');
            onActionComplete?.();
        } catch (err: any) {
            setActionError(err.message || t('common.messages.rejectFailed', 'Failed to reject'));
        } finally {
            setLoading(false);
        }
    };

    const handleReassign = async () => {
        if (!reassignId.trim() || !reassignReason.trim()) {
            setActionError(t('runtime.approval.reassignRequiredError', 'Assignee and reason are required'));
            return;
        }
        try {
            setLoading(true);
            setActionError(null);
            await service.reassignTask(task.taskId, reassignType, reassignId, reassignReason);
            toast.success(t('common.messages.taskReassigned', 'Task reassigned successfully'), { position: 'bottom-right' });
            setAction('none');
            setReassignId('');
            setReassignName('');
            setReassignReason('');
            onActionComplete?.();
        } catch (err: any) {
            setActionError(err.message || t('common.messages.reassignFailed', 'Failed to reassign'));
        } finally {
            setLoading(false);
        }
    };

    const cancelAction = () => {
        setAction('none');
        setComment('');
        setActionError(null);
        setReassignId('');
        setReassignName('');
        setReassignReason('');
    };

    const isGroupTask = task.assigneeType !== 'USER';
    const isDecided = task.status !== 'PENDING';

    return (
        <Card className="w-full overflow-hidden gap-0 shadow-sm border-border transition-shadow bg-card hover:shadow-md">
            {/* ── Card Header: assignee identity + type badge + status ── */}
            <div className="px-3 py-2 bg-muted/60 border-b border-border flex flex-col gap-2">
                {/* Row 1: icon · name · type badge · status */}
                <div className="flex items-center gap-2 min-w-0 flex-wrap">
                    {isGroupTask
                        ? <Users className="h-3.5 w-3.5 text-muted-foreground/70 shrink-0" />
                        : <User className="h-3.5 w-3.5 text-muted-foreground/70 shrink-0" />
                    }
                    <span className="text-sm font-semibold text-foreground">{task.assigneeName}</span>
                    <AssigneeTypeBadge type={task.assigneeType} t={t} />
                    <WorkflowStatusBadge status={task.status} />
                </div>

                {/* Row 2: action buttons — always on own row when PENDING+ACTIVE */}
                {task.status === 'PENDING' && stepStatus === 'ACTIVE' && (
                    <div className="flex items-center gap-1.5">
                        {/* Full action row: only when the user is the assigned approver */}
                        {!isDisabled && (
                            <>
                        {/* Approve */}
                        <Dialog open={action === 'approving'} onOpenChange={(o) => o ? handleOpenApprove() : cancelAction()}>
                            <DialogTrigger asChild>
                                <Button variant="success" size="sm" className="h-7 px-3 text-xs" disabled={isDisabled} onClick={(e) => { e.preventDefault(); handleOpenApprove(); }}>
                                    <Check className="h-3 w-3 mr-1" />{t('runtime.approval.approve', 'Approve')}
                                </Button>
                            </DialogTrigger>
                            <DialogContent className="sm:max-w-lg">
                                <DialogHeader><DialogTitle>{t('runtime.approval.approveTask', 'Approve Task')}</DialogTitle></DialogHeader>
                                <div className="py-4 space-y-3">
                                    {actionError && (
                                        <div className="flex items-start gap-2 rounded-md border border-destructive/40 bg-destructive/10 px-3 py-2 text-sm text-destructive">
                                            <AlertCircle className="h-4 w-4 mt-0.5 shrink-0" />
                                            <span>{actionError}</span>
                                        </div>
                                    )}
                                    <Textarea value={comment} onChange={(e) => setComment(e.target.value)}
                                        placeholder={t('runtime.approval.commentPlaceholder', 'Optional comment...')} className="min-h-[100px] resize-none" autoFocus />
                                </div>
                                <DialogFooter>
                                    <Button variant="ghost" onClick={cancelAction} disabled={loading}>{t('common.cancel', 'Cancel')}</Button>
                                    <Button variant="success" onClick={handleApprove} disabled={loading}>
                                        {loading ? <Loader2 className="h-4 w-4 animate-spin mr-2" /> : <Check className="h-4 w-4 mr-2" />}
                                        {t('runtime.approval.confirmApprove', 'Confirm Approve')}
                                    </Button>
                                </DialogFooter>
                            </DialogContent>
                        </Dialog>

                        {/* Reject */}
                        <Dialog open={action === 'rejecting'} onOpenChange={(o) => o ? setAction('rejecting') : cancelAction()}>
                            <DialogTrigger asChild>
                                <Button variant="destructive" size="sm" className="h-7 px-3 text-xs" disabled={isDisabled}>
                                    <X className="h-3 w-3 mr-1" />{t('runtime.approval.reject', 'Reject')}
                                </Button>
                            </DialogTrigger>
                            <DialogContent className="sm:max-w-lg">
                                <DialogHeader><DialogTitle>{t('runtime.approval.rejectTask', 'Reject Task')}</DialogTitle></DialogHeader>
                                <div className="py-4 space-y-3">
                                    {actionError && (
                                        <div className="flex items-start gap-2 rounded-md border border-destructive/40 bg-destructive/10 px-3 py-2 text-sm text-destructive">
                                            <AlertCircle className="h-4 w-4 mt-0.5 shrink-0" />
                                            <span>{actionError}</span>
                                        </div>
                                    )}
                                    <Textarea value={comment} onChange={(e) => setComment(e.target.value)}
                                        placeholder={t('runtime.approval.rejectReasonPlaceholder', 'Rejection reason (required)...')} className="min-h-[100px] resize-none" autoFocus />
                                </div>
                                <DialogFooter>
                                    <Button variant="ghost" onClick={cancelAction} disabled={loading}>{t('common.cancel', 'Cancel')}</Button>
                                    <Button variant="destructive" onClick={handleReject} disabled={loading || !comment.trim()}>
                                        {loading ? <Loader2 className="h-4 w-4 animate-spin mr-2" /> : <X className="h-4 w-4 mr-2" />}
                                        {t('runtime.approval.confirmReject', 'Confirm Reject')}
                                    </Button>
                                </DialogFooter>
                            </DialogContent>
                        </Dialog>
                            </>
                        )}

                        {/* Reassign — visible to both the assigned approver AND the responsible person */}
                        {(!isDisabled || task.isReassignable) && (
                        <Dialog open={action === 'reassigning'} onOpenChange={(o) => o ? setAction('reassigning') : cancelAction()}>
                            <DialogTrigger asChild>
                                <Button variant="outline" size="sm" className="h-7 px-3 text-xs">
                                    <UserPlus className="h-3 w-3 mr-1" />{t('runtime.approval.reassign', 'Reassign')}
                                </Button>
                            </DialogTrigger>
                            <DialogContent className="sm:max-w-lg">
                                <DialogHeader><DialogTitle>{t('runtime.approval.reassignTask', 'Reassign Task')}</DialogTitle></DialogHeader>
                                {actionError && (
                                    <div className="flex items-start gap-2 rounded-md border border-destructive/40 bg-destructive/10 px-3 py-2 text-sm text-destructive">
                                        <AlertCircle className="h-4 w-4 mt-0.5 shrink-0" />
                                        <span>{actionError}</span>
                                    </div>
                                )}
                                <div className="py-2 space-y-4">
                                    <div className="space-y-1.5">
                                        <label className="text-sm font-medium">{t('runtime.approval.assigneeType', 'Assignee Type')}</label>
                                        <Select value={reassignType} onValueChange={setReassignType}>
                                            <SelectTrigger><SelectValue /></SelectTrigger>
                                            <SelectContent>
                                                <SelectGroup>
                                                    {types.map(t => <SelectItem key={t.code} value={t.code}>{t.label}</SelectItem>)}
                                                </SelectGroup>
                                            </SelectContent>
                                        </Select>
                                    </div>
                                    <div className="space-y-1.5">
                                        <label className="text-sm font-medium">{t('runtime.approval.assigneeLabel', 'Assignee')}</label>
                                        {onSearchPrincipals ? (
                                            <PrincipalPicker value={reassignId} displayName={reassignName}
                                                principalType={reassignType} onSearch={onSearchPrincipals}
                                                onResolve={onResolvePrincipal} onSelect={(id) => setReassignId(id)} />
                                        ) : (
                                            <input type="text" value={reassignId} onChange={(e) => setReassignId(e.target.value)}
                                                placeholder={t('runtime.approval.uuidPlaceholder', 'Enter assignee ID')}
                                                className="w-full rounded-md border bg-background px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-ring" />
                                        )}
                                    </div>
                                    <div className="space-y-1.5">
                                        <label className="text-sm font-medium">{t('runtime.approval.reasonLabel', 'Reason')} <span className="text-destructive">*</span></label>
                                        <Textarea value={reassignReason} onChange={(e) => setReassignReason(e.target.value)}
                                            placeholder={t('runtime.approval.reassignReasonPlaceholder', 'Reason for reassignment (required)...')} className="min-h-[80px] resize-none" />
                                    </div>
                                </div>
                                <DialogFooter>
                                    <Button variant="ghost" onClick={cancelAction} disabled={loading}>{t('common.cancel', 'Cancel')}</Button>
                                    <Button variant="default" onClick={handleReassign} disabled={loading || !reassignId.trim() || !reassignReason.trim()}>
                                        {loading ? <Loader2 className="h-4 w-4 animate-spin mr-2" /> : <UserPlus className="h-4 w-4 mr-2" />}
                                        {t('runtime.approval.confirmReassign', 'Confirm Reassign')}
                                    </Button>
                                </DialogFooter>
                            </DialogContent>
                        </Dialog>
                        )}
                    </div>
                )}
            </div>

            {/* ── Card Body: decision detail + comment ── */}
            {isDecided && (
                <CardContent className="px-3 py-2 space-y-1.5 bg-card">
                    {/* For group tasks: show who in the group actually decided */}
                    {isGroupTask && task.decidedByName ? (
                        <div className="flex flex-wrap gap-x-4 gap-y-0.5 text-xs text-muted-foreground">
                            <span>
                                {task.status === 'APPROVED' ? t('runtime.processFlow.approvedByMember', 'Approved by member:') : t('runtime.processFlow.rejectedByMember', 'Rejected by member:')}{' '}
                                <span className="font-semibold text-foreground">{task.decidedByName}</span>
                            </span>
                            {task.decidedAt && (
                                <span>
                                    {t('runtime.processFlow.at', 'at:')} <span className="font-semibold text-foreground">{formatDateTime(task.decidedAt)}</span>
                                </span>
                            )}
                        </div>
                    ) : (
                        /* Individual user: just show the decided timestamp */
                        task.decidedAt && (
                            <p className="text-xs text-muted-foreground">
                                {task.status === 'APPROVED' ? t('runtime.processFlow.approvedAt', 'Approved at:') : t('runtime.processFlow.rejectedAt', 'Rejected at:')}{' '}
                                <span className="font-semibold text-foreground">{formatDateTime(task.decidedAt)}</span>
                            </p>
                        )
                    )}

                    {/* Comment */}
                    {task.comment && (
                        <div className="relative pl-3 py-1 before:absolute before:left-0 before:top-0 before:bottom-0 before:w-0.5 before:bg-btn-action/40 before:rounded-full">
                            <p className="text-sm text-muted-foreground italic">&ldquo;{task.comment}&rdquo;</p>
                        </div>
                    )}
                </CardContent>
            )}
        </Card>
    );
}

// ─── Group by displayOrder ──────────────────────────────────────────────────

function groupByDisplayOrder(steps: ProcessFlowStep[]): ProcessFlowStep[][] {
    const sorted = [...steps].sort((a, b) => a.displayOrder - b.displayOrder);
    const lanes: ProcessFlowStep[][] = [];
    let currentOrder = -1;
    let currentLane: ProcessFlowStep[] = [];

    for (const step of sorted) {
        if (step.displayOrder !== currentOrder) {
            if (currentLane.length > 0) lanes.push(currentLane);
            currentLane = [step];
            currentOrder = step.displayOrder;
        } else {
            currentLane.push(step);
        }
    }
    if (currentLane.length > 0) lanes.push(currentLane);

    return lanes;
}

// ─── Helpers ────────────────────────────────────────────────────────────────

function AssigneeTypeBadge({ type, t }: { type: string, t: any }) {
    const label = type === 'USER' ? t('common.user', 'User').toUpperCase() : type === 'GROUP' ? t('common.group', 'Group').toUpperCase() : type;
    return (
        <Badge
            variant="outline"
            className={cn(
                type === 'USER'
                    ? "border-blue-200 bg-blue-50 text-blue-700 dark:bg-blue-900/40 dark:text-blue-300 dark:border-blue-900"
                    : "border-purple-200 bg-purple-50 text-purple-700 dark:bg-purple-900/40 dark:text-purple-300 dark:border-purple-900"
            )}
        >
            {label}
        </Badge>
    );
}

function formatDateTime(iso: string): string {
    const d = new Date(iso);
    return d.toLocaleDateString(undefined, {
        month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit',
    });
}

// ─── Status Configs ─────────────────────────────────────────────────────────

const STEP_CONFIG: Record<StepStatus, {
    icon: any;
    iconColor: string;
    circleBg: string;
    circleBorder: string;
    statusColor: string;
    statusLabel: string;
}> = {
    APPROVED: {
        icon: Check,
        iconColor: 'text-white',
        circleBg: 'bg-status-positive',
        circleBorder: 'border-status-positive',
        statusColor: 'text-status-positive-text',
        statusLabel: 'Completed',
    },
    ACTIVE: {
        icon: Loader2,
        iconColor: 'text-btn-action-foreground',
        circleBg: 'bg-btn-action',
        circleBorder: 'border-btn-action',
        statusColor: 'text-btn-action',
        statusLabel: 'In Progress',
    },
    REJECTED: {
        icon: X,
        iconColor: 'text-white',
        circleBg: 'bg-status-negative',
        circleBorder: 'border-status-negative',
        statusColor: 'text-status-negative-text',
        statusLabel: 'Rejected',
    },
    PENDING: {
        icon: Clock,
        iconColor: 'text-muted-foreground',
        circleBg: 'bg-muted',
        circleBorder: 'border-muted-foreground/50',
        statusColor: 'text-muted-foreground',
        statusLabel: 'Upcoming',
    },
    SKIPPED: {
        icon: ArrowRight,
        iconColor: 'text-muted-foreground',
        circleBg: 'bg-muted',
        circleBorder: 'border-muted-foreground/50',
        statusColor: 'text-muted-foreground',
        statusLabel: 'Skipped',
    },
};
