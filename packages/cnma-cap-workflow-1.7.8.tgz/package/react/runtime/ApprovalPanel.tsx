import React, { useState } from 'react';
import { CheckCircle2, XCircle, UserPlus, Loader2 } from 'lucide-react';
import { Button, Textarea, cn, Card, CardContent, CardHeader, CardTitle } from '@cnma/react-ui';
import { WorkflowRuntimeService } from '../services/WorkflowRuntimeService';
import { PrincipalPicker } from '../admin/PrincipalPicker';
import { useTranslation } from 'react-i18next';
import type { ApprovalPanelProps, PrincipalTypeOption } from '../types';


/**
 * ApprovalPanel — Action panel for approving/rejecting/reassigning a task.
 *
 * Can be embedded in a dialog, side panel, or inline.
 * Handles the full action lifecycle: validate → submit → callback.
 *
 * When `onSearchPrincipals` is provided, the reassign form uses a searchable
 * people picker (PrincipalPicker). Otherwise falls back to a raw text input.
 *
 * Usage:
 * ```tsx
 * <ApprovalPanel
 *     httpClient={httpClient}
 *     taskId="..."
 *     principalTypes={types}
 *     onSearchPrincipals={searchFn}
 *     onComplete={(action) => refetchWorkflow()}
 * />
 * ```
 */
export function ApprovalPanel({
    httpClient,
    taskId,
    baseUrl = '/workflow',
    onComplete,
    onError,
    principalTypes,
    onSearchPrincipals,
    className,
}: ApprovalPanelProps) {
    const { t } = useTranslation('workflow');
    const [activeAction, setActiveAction] = useState<'approve' | 'reject' | 'reassign' | null>(null);
    const [comment, setComment] = useState('');
    const [reassignType, setReassignType] = useState('USER');
    const [reassignId, setReassignId] = useState('');
    const [reassignName, setReassignName] = useState('');
    const [reassignReason, setReassignReason] = useState('');
    const [loading, setLoading] = useState(false);

    const types = principalTypes && principalTypes.length > 0
        ? principalTypes
        : [
            { code: 'USER', label: t('common.user', 'User') },
            { code: 'GROUP', label: t('common.group', 'Group') },
        ];

    const service = React.useMemo(
        () => new WorkflowRuntimeService(httpClient, baseUrl),
        [httpClient, baseUrl]
    );

    const handleApprove = async () => {
        if (!comment.trim()) {
            onError?.(t('runtime.approval.commentRequiredError', 'A comment is required when approving'));
            return;
        }
        try {
            setLoading(true);
            await service.approveTask(taskId, comment);
            onComplete?.('APPROVED');
        } catch (err: any) {
            onError?.(err.message || t('runtime.approval.approveFailed', 'Failed to approve'));
        } finally {
            setLoading(false);
        }
    };

    const handleReject = async () => {
        if (!comment.trim()) {
            onError?.(t('runtime.approval.commentRequiredRejectError', 'A comment is required when rejecting'));
            return;
        }
        try {
            setLoading(true);
            await service.rejectTask(taskId, comment);
            onComplete?.('REJECTED');
        } catch (err: any) {
            onError?.(err.message || t('runtime.approval.rejectFailed', 'Failed to reject'));
        } finally {
            setLoading(false);
        }
    };

    const handleReassign = async () => {
        if (!reassignId.trim() || !reassignReason.trim()) {
            onError?.(t('runtime.approval.reassignRequiredError', 'Assignee and reason are required'));
            return;
        }
        try {
            setLoading(true);
            await service.reassignTask(taskId, reassignType, reassignId, reassignReason);
            onComplete?.('REASSIGNED');
        } catch (err: any) {
            onError?.(err.message || t('runtime.approval.reassignFailed', 'Failed to reassign'));
        } finally {
            setLoading(false);
        }
    };

    const resetReassign = () => {
        setActiveAction(null);
        setReassignId('');
        setReassignName('');
        setReassignReason('');
    };

    return (
        <div className={cn("space-y-4", className)}>
            {/* Action Buttons */}
            {!activeAction && (
                <div className="flex gap-2">
                    <Button
                        variant="success"
                        size="sm"
                        onClick={() => setActiveAction('approve')}
                        className="flex-1"
                    >
                        <CheckCircle2 className="h-4 w-4 mr-1.5" />
                        {t('runtime.approval.approve', 'Approve')}
                    </Button>
                    <Button
                        variant="destructive"
                        size="sm"
                        onClick={() => setActiveAction('reject')}
                        className="flex-1"
                    >
                        <XCircle className="h-4 w-4 mr-1.5" />
                        {t('runtime.approval.reject', 'Reject')}
                    </Button>
                    <Button
                        variant="outline"
                        size="sm"
                        onClick={() => setActiveAction('reassign')}
                        className="flex-1"
                    >
                        <UserPlus className="h-4 w-4 mr-1.5" />
                        {t('runtime.approval.reassign', 'Reassign')}
                    </Button>
                </div>
            )}

            {/* Approve Form */}
            {activeAction === 'approve' && (
                <Card className="border-border">
                    <CardHeader className="pb-2 pt-3 px-3">
                        <CardTitle className="text-sm font-medium flex items-center gap-2">
                            <CheckCircle2 className="h-4 w-4 text-status-completed-text" />
                            {t('runtime.approval.approveTask', 'Approve this task')}
                        </CardTitle>
                    </CardHeader>
                    <CardContent className="px-3 pb-3 space-y-3">
                        <div>
                            <label className="text-xs text-muted-foreground mb-1 block">
                                {t('runtime.approval.commentLabel', 'Comment')} <span className="text-destructive">*</span>
                            </label>
                            <Textarea
                                value={comment}
                                onChange={(e) => setComment(e.target.value)}
                                placeholder={t('runtime.approval.commentPlaceholder', 'Add a comment...')}
                                className="min-h-[60px] resize-none"
                                required
                            />
                        </div>
                        <div className="flex gap-2 justify-end">
                            <Button variant="ghost" size="sm" onClick={() => { setActiveAction(null); setComment(''); }} disabled={loading}>
                                {t('common.cancel', 'Cancel')}
                            </Button>
                            <Button variant="success" size="sm" onClick={handleApprove} disabled={loading || !comment.trim()}>
                                {loading ? <Loader2 className="h-4 w-4 animate-spin mr-1" /> : <CheckCircle2 className="h-4 w-4 mr-1" />}
                                {t('runtime.approval.confirmApprove', 'Confirm Approve')}
                            </Button>
                        </div>
                    </CardContent>
                </Card>
            )}

            {/* Reject Form */}
            {activeAction === 'reject' && (
                <Card className="border-destructive/40">
                    <CardHeader className="pb-2 pt-3 px-3">
                        <CardTitle className="text-sm font-medium text-destructive flex items-center gap-2">
                            <XCircle className="h-4 w-4" />
                            {t('runtime.approval.rejectTask', 'Reject this task')}
                        </CardTitle>
                    </CardHeader>
                    <CardContent className="px-3 pb-3 space-y-3">
                        <div>
                            <label className="text-xs text-muted-foreground mb-1 block">
                                {t('runtime.approval.commentLabel', 'Comment')} <span className="text-destructive">*</span>
                            </label>
                            <Textarea
                                value={comment}
                                onChange={(e) => setComment(e.target.value)}
                                placeholder={t('runtime.approval.rejectReasonPlaceholder', 'Rejection reason...')}
                                className="min-h-[80px] resize-none border-destructive/40 focus-visible:ring-destructive/30"
                                required
                            />
                        </div>
                        <div className="flex gap-2 justify-end">
                            <Button variant="ghost" size="sm" onClick={() => { setActiveAction(null); setComment(''); }} disabled={loading}>
                                {t('common.cancel', 'Cancel')}
                            </Button>
                            <Button variant="destructive" size="sm" onClick={handleReject} disabled={loading || !comment.trim()}>
                                {loading ? <Loader2 className="h-4 w-4 animate-spin mr-1" /> : <XCircle className="h-4 w-4 mr-1" />}
                                {t('runtime.approval.confirmReject', 'Confirm Reject')}
                            </Button>
                        </div>
                    </CardContent>
                </Card>
            )}

            {/* Reassign Form */}
            {activeAction === 'reassign' && (
                <Card className="border-border">
                    <CardHeader className="pb-2 pt-3 px-3">
                        <CardTitle className="text-sm font-medium flex items-center gap-2">
                            <UserPlus className="h-4 w-4 text-primary" />
                            {t('runtime.approval.reassignTask', 'Reassign this task')}
                        </CardTitle>
                    </CardHeader>
                    <CardContent className="px-3 pb-3 space-y-3">
                        {/* Assignee Type */}
                        <div>
                            <label className="text-xs text-muted-foreground mb-1 block">{t('runtime.approval.assigneeType', 'Assignee Type')}</label>
                            <select
                                value={reassignType}
                                onChange={(e) => {
                                    setReassignType(e.target.value);
                                    setReassignId('');
                                    setReassignName('');
                                }}
                                className="w-full rounded-md border bg-background px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-ring"
                            >
                                {types.map(t => (
                                    <option key={t.code} value={t.code}>{t.label}</option>
                                ))}
                            </select>
                        </div>

                        {/* Assignee Picker */}
                        <div>
                            <label className="text-xs text-muted-foreground mb-1 block">
                                {t('runtime.approval.assigneeLabel', 'Assignee')} <span className="text-destructive">*</span>
                            </label>
                            {onSearchPrincipals ? (
                                <PrincipalPicker
                                    value={reassignId}
                                    displayName={reassignName}
                                    principalType={reassignType}
                                    onSearch={onSearchPrincipals}
                                    onSelect={(id) => setReassignId(id)}
                                />
                            ) : (
                                <input
                                    type="text"
                                    value={reassignId}
                                    onChange={(e) => setReassignId(e.target.value)}
                                    placeholder={t('runtime.approval.uuidPlaceholder', 'UUID or identifier')}
                                    className="w-full rounded-md border bg-background px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-ring"
                                />
                            )}
                        </div>

                        {/* Reason */}
                        <div>
                            <label className="text-xs text-muted-foreground mb-1 block">
                                {t('runtime.approval.reasonLabel', 'Reason')} <span className="text-destructive">*</span>
                            </label>
                            <Textarea
                                value={reassignReason}
                                onChange={(e) => setReassignReason(e.target.value)}
                                placeholder={t('runtime.approval.reassignReasonPlaceholder', 'Reason for reassignment...')}
                                className="min-h-[60px] resize-none"
                                required
                            />
                        </div>
                        <div className="flex gap-2 justify-end">
                            <Button variant="ghost" size="sm" onClick={resetReassign} disabled={loading}>
                                {t('common.cancel', 'Cancel')}
                            </Button>
                            <Button variant="default" size="sm" onClick={handleReassign} disabled={loading || !reassignId.trim() || !reassignReason.trim()}>
                                {loading ? <Loader2 className="h-4 w-4 animate-spin mr-1" /> : <UserPlus className="h-4 w-4 mr-1" />}
                                {t('runtime.approval.confirmReassign', 'Confirm Reassign')}
                            </Button>
                        </div>
                    </CardContent>
                </Card>
            )}
        </div>
    );
}
