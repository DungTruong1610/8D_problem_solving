/**
 * @cnma/cap-workflow — i18n resource injection
 *
 * Safely injects the `workflow` namespace resources into the shared i18next
 * singleton WITHOUT calling .init() again.
 *
 * Usage (consuming app's i18n.ts):
 *   import '@cnma/cap-workflow/react/i18n';   // side-effect: adds workflow ns
 *
 * Components inside cap-workflow use:
 *   const { t } = useTranslation('workflow');
 */

import i18n from 'i18next';
import { initReactI18next } from 'react-i18next';
import en from './locales/en.json';
import de from './locales/de.json';
import ja from './locales/ja.json';

const addWorkflowResources = () => {
    i18n.addResourceBundle('en', 'workflow', en, true, false);
    i18n.addResourceBundle('de', 'workflow', de, true, false);
    i18n.addResourceBundle('ja', 'workflow', ja, true, false);
};

if (i18n.isInitialized) {
    // App already called .init() — just inject resources into existing instance
    addWorkflowResources();
} else {
    // Standalone mode (no consuming app) — initialize minimally
    i18n
        .use(initReactI18next)
        .init({
            fallbackLng: 'en',
            ns: ['workflow'],
            defaultNS: 'workflow',
            interpolation: { escapeValue: false },
            resources: {
                en: { workflow: en },
                de: { workflow: de },
                ja: { workflow: ja },
            },
        });
}

export default i18n;
