/**
 * @cnma/cap-workflow — React Types
 *
 * TypeScript interfaces for React components.
 * Maps to CDS entities + engine types for frontend consumption.
 */

// ─── Status Types ───────────────────────────────────────────────────────────

export type WorkflowStatus = 'DRAFT' | 'ACTIVE' | 'COMPLETED' | 'REJECTED' | 'CANCELLED';
export type StepStatus = 'PENDING' | 'ACTIVE' | 'APPROVED' | 'REJECTED' | 'SKIPPED';
export type TaskStatus = 'PENDING' | 'APPROVED' | 'REJECTED';

// ─── Runtime View Types ─────────────────────────────────────────────────────

export interface WorkflowInstance {
    ID: string;
    referenceId: string;
    referenceType: string;
    definition_ID?: string;
    workflowType?: string;
    runNumber: number;
    status: WorkflowStatus;
    responsibleType?: string;
    responsibleId?: string;
    responsibleName?: string;
    startedAt?: string;
    completedAt?: string;
    createdAt?: string;
}

export interface StepInstance {
    ID: string;
    stepName?: string;
    displayOrder?: number;
    status: StepStatus;
    approvalMode?: string;
    approverSeqMode?: string;
    activatedAt?: string;
    completedAt?: string;
    tasks?: ApprovalTask[];
}

export interface ApprovalTask {
    ID: string;
    assigneeType: string;
    assigneeId: string;
    assigneeName?: string;
    taskOrder: number;
    status: TaskStatus;
    decidedByType?: string;
    decidedById?: string;
    decidedByName?: string;
    decidedAt?: string;
    comment?: string;
}

export interface WorkflowHistory {
    ID: string;
    workflowInstance_ID?: string;
    eventType: string;
    performedById?: string;
    performedByName?: string;
    isSystemAction: boolean;
    performedAt?: string;
    stepName?: string;
    previousValue?: string;
    newValue?: string;
    comment?: string;
    /** Populated by getWorkflowHistoryByReference for cross-run display */
    runNumber?: number;
}

// ─── Process Flow (from getProcessFlow function) ────────────────────────────

export interface ProcessFlowStep {
    stepId: string;
    stepName: string;
    displayOrder: number;
    status: StepStatus;
    approvalMode: string;
    approverSeqMode?: string;
    activatedAt?: string;
    completedAt?: string;
    tasks: ProcessFlowTask[];
}

export interface ProcessFlowTask {
    taskId: string;
    assigneeName: string;
    assigneeType: string;
    status: TaskStatus;
    decidedAt?: string;
    decidedByName?: string;
    decidedByType?: string;
    comment?: string;
    /** Server-resolved: true if the current user can act on this specific task */
    isActionable?: boolean;
    /** Server-resolved: true if the current user can reassign (but NOT approve/reject) this task.
     *  Applies to the workflow's responsible person for OOO delegation. */
    isReassignable?: boolean;
}

// ─── Admin Types ────────────────────────────────────────────────────────────

export interface WorkflowDefinition {
    ID: string;
    objectType: string;
    orgKeyValue?: string;
    triggerAction?: string;
    workflowType: string;
    description?: string;
    responsibleType?: string;
    responsibleId?: string;
    responsibleName?: string;
    rejectionMode: string;
    completionPolicy: string;
    definitionVersion: number;
    priority: number;
    isActive: boolean;
    enforceFourEyes: boolean;
    notificationSettings?: string; // JSON: INotificationSettings
    steps?: WorkflowStepDefinition[];
    stepDependencies?: StepDependency[];
}

export interface WorkflowStepDefinition {
    ID: string;
    definition_ID?: string;
    displayOrder: number;
    stepName: string;
    stepDescription?: string;
    approvalMode: string;
    approverSeqMode: string;
    fieldSettings?: string;
    conditionExpr?: string;
    defaultApprovers?: DefaultStepApprover[];
}

export interface DefaultStepApprover {
    ID: string;
    step_ID?: string;
    principalType: string;
    principalId: string;
    principalName?: string;
    approverOrder: number;
}

export interface StepDependency {
    ID: string;
    definition_ID: string;
    predecessor_ID: string;
    successor_ID: string;
}

/** Field-level setting for a workflow step */
export type FieldSettingMode = 'mandatory' | 'editable' | 'readonly' | 'hidden';

export interface FieldSetting {
    fieldName: string;
    label?: string;
    mode: FieldSettingMode;
}

export interface FlatConditionRow {
    id: string;
    isActive: boolean;
    leftBracket: string;
    field: string;
    operator: string;
    isSchema: boolean;
    value: string;
    rightBracket: string;
    logicalOperator: string;
}

// ─── Notification Configuration Types ───────────────────────────────────────

/** Email events that can be configured per workflow definition */
export type NotificationEventType =
    | 'TASK_ASSIGNED'
    | 'TASK_APPROVED'
    | 'TASK_REJECTED'
    | 'TASK_REASSIGNED'
    | 'TASK_REMINDER'
    | 'WORKFLOW_COMPLETED'
    | 'WORKFLOW_REJECTED';

/** All known notification event types */
export const NOTIFICATION_EVENT_TYPES: NotificationEventType[] = [
    'TASK_ASSIGNED',
    'TASK_APPROVED',
    'TASK_REJECTED',
    'TASK_REASSIGNED',
    'TASK_REMINDER',
    'WORKFLOW_COMPLETED',
    'WORKFLOW_REJECTED',
];

/** Human-readable labels and descriptions for notification events */
export const NOTIFICATION_EVENT_META: Record<NotificationEventType, { label: string; description: string; icon: string }> = {
    TASK_ASSIGNED:      { label: 'Task Assigned',      description: 'When an approver receives a new task',         icon: '🔔' },
    TASK_APPROVED:      { label: 'Task Approved',      description: 'When a task is approved by an approver',       icon: '✅' },
    TASK_REJECTED:      { label: 'Task Rejected',      description: 'When a task is rejected by an approver',       icon: '❌' },
    TASK_REASSIGNED:    { label: 'Task Reassigned',    description: 'When a task is reassigned to a new approver',  icon: '🔄' },
    TASK_REMINDER:      { label: 'Task Reminder',      description: 'When responsible person reminds approver',     icon: '⏰' },
    WORKFLOW_COMPLETED: { label: 'Workflow Completed', description: 'When all approval steps are finished',         icon: '🎉' },
    WORKFLOW_REJECTED:  { label: 'Workflow Rejected',  description: 'When the workflow is rejected',                icon: '⚠️' },
};

/** Available placeholders for email templates */
export const TEMPLATE_PLACEHOLDERS = [
    { key: 'assigneeName',       label: 'Assignee Name' },
    { key: 'stepName',           label: 'Step Name' },
    { key: 'workflowType',       label: 'Workflow Type' },
    { key: 'documentReference',  label: 'Document Reference' },
    { key: 'documentLink',       label: 'Document Link' },
    { key: 'objectType',         label: 'Object Type' },
    { key: 'approverName',       label: 'Approver Name' },
    { key: 'comment',            label: 'Comment' },
    { key: 'responsibleName',    label: 'Responsible Person' },
    { key: 'reassignerName',     label: 'Reassigned By' },
] as const;

/** Available info table field keys */
export const INFO_FIELD_OPTIONS = [
    { key: 'workflow',    label: 'Workflow Type' },
    { key: 'step',        label: 'Step Name' },
    { key: 'document',    label: 'Document Reference' },
    { key: 'objectType',  label: 'Object Type' },
    { key: 'approver',    label: 'Approved By' },
    { key: 'rejector',    label: 'Rejected By' },
    { key: 'responsible', label: 'Responsible Person' },
    { key: 'comment',     label: 'Comment' },
    { key: 'reassigner',  label: 'Reassigned By' },
] as const;

/** Structured template for custom email content */
export interface IStructuredTemplate {
    subject: string;
    greeting: string;
    bodyText: string;
    infoFields: string[];
    buttonLabel?: string;
    buttonColor?: string;
}

/** Per-event notification configuration */
export interface INotificationEventConfig {
    enabled: boolean;
    template?: IStructuredTemplate;
}

/** Top-level notification settings stored as JSON on WorkflowDefinition */
export interface INotificationBusinessField {
    fieldKey: string;
    label: string;
}

export interface INotificationSettings {
    events: Partial<Record<NotificationEventType, INotificationEventConfig>>;
    businessFields?: INotificationBusinessField[];
}

export interface WorkflowObjectType {
    ID: string;
    objectType: string;
    displayName?: string;
    orgKeyField?: string;
    isActive: boolean;
}

// ─── Component Props ────────────────────────────────────────────────────────

/**
 * HTTP client interface — consuming apps must implement.
 * Decouples workflow components from any specific HTTP library.
 */
export interface WorkflowHttpClient {
    get: <T = any>(url: string) => Promise<T>;
    post: <T = any>(url: string, data?: any) => Promise<T>;
    patch: <T = any>(url: string, data?: any) => Promise<T>;
    delete: <T = any>(url: string) => Promise<T>;
}

/**
 * Principal type option for approver dropdowns.
 * Populated from the host app's identity service (e.g., SupportTypes entity).
 */
export interface PrincipalTypeOption {
    /** Internal code, e.g. 'USER', 'GROUP', 'TEAM' */
    code: string;
    /** Human-readable label, e.g. 'Individual User', 'User Group' */
    label: string;
}

/**
 * Search result returned by the onSearchPrincipals callback.
 * Represents a user, group, or other principal that can be assigned as an approver.
 */
export interface PrincipalSearchResult {
    /** UUID of the principal (ShadowUsers.ID or ShadowGroups.ID) */
    id: string;
    /** Display name */
    name: string;
    /** Optional secondary info (email, description, etc.) */
    detail?: string;
}

export interface ProcessFlowProps {
    httpClient: WorkflowHttpClient;
    workflowId: string;
    baseUrl?: string;
    /** Dynamic principal types from the host app. Falls back to [User, Group]. */
    principalTypes?: PrincipalTypeOption[];
    /** Search principals by type and query. Enables autocomplete picker. */
    onSearchPrincipals?: (principalType: string, query: string) => Promise<PrincipalSearchResult[]>;
    /** Resolve a principal by type and ID. Used to display name when value is set but displayName is unavailable. */
    onResolvePrincipal?: (principalType: string, id: string) => Promise<PrincipalSearchResult | null>;
    /** Called after any action (approve/reject/reassign) completes */
    onActionComplete?: () => void;
    /**
     * Called before approval is executed. Return `true` to proceed or `false` to block.
     * Use this to run host-app validation (e.g., mandatory field checks) before approve.
     * The host app is responsible for displaying any validation errors (e.g., via toast/dialog).
     */
    onBeforeApprove?: (taskId: string) => Promise<boolean> | boolean;
    /** If provided, evaluates whether the action buttons for a pending task should be enabled for the current user. */
    canUserActOnTask?: (task: ProcessFlowTask) => boolean;
    /**
     * Called when active step field settings are loaded from the server.
     * Host app uses this to apply per-field editability (editable/readonly/hidden/mandatory)
     * to the review/approval form.
     *
     * @example
     * ```tsx
     * <ProcessFlow
     *     onFieldSettingsLoaded={({ fieldSettings }) => {
     *         if (fieldSettings) setFormFieldModes(fieldSettings);
     *     }}
     * />
     * ```
     */
    onFieldSettingsLoaded?: (settings: {
        isCurrentApprover: boolean;
        stepName: string | null;
        fieldSettings: Record<string, FieldSettingMode> | null;
    }) => void;
    className?: string;
}

export interface ApprovalPanelProps {
    httpClient: WorkflowHttpClient;
    taskId: string;
    baseUrl?: string;
    onComplete?: (action: 'APPROVED' | 'REJECTED' | 'REASSIGNED') => void;
    onError?: (message: string) => void;
    /** Dynamic principal types from the host app's identity service.
     *  If not provided, falls back to hardcoded [User, Group]. */
    principalTypes?: PrincipalTypeOption[];
    /** Search for principals by type and query string.
     *  If provided, enables autocomplete picker instead of raw UUID input. */
    onSearchPrincipals?: (principalType: string, query: string) => Promise<PrincipalSearchResult[]>;
    className?: string;
}

export interface WorkflowTimelineProps {
    httpClient: WorkflowHttpClient;
    workflowId: string;
    /** When set with referenceType, shows history across ALL runs for this document */
    referenceId?: string;
    referenceType?: string;
    baseUrl?: string;
    maxItems?: number;
    className?: string;
}

export interface WorkflowManagerProps {
    httpClient: WorkflowHttpClient;
    adminBaseUrl?: string;
    runtimeBaseUrl?: string;
    /** Dynamic principal types from the host app's identity service.
     *  If not provided, falls back to hardcoded [User, Group, Team, Role]. */
    principalTypes?: PrincipalTypeOption[];
    /** Search for principals by type and query string.
     *  If provided, enables autocomplete picker instead of raw UUID input. */
    onSearchPrincipals?: (principalType: string, query: string) => Promise<PrincipalSearchResult[]>;
    /** Resolve a single principal by type and ID.
     *  Used to display the name after page reload when principalName is unavailable. */
    onResolvePrincipal?: (principalType: string, id: string) => Promise<PrincipalSearchResult | null>;
    /** Resolve the field list for a given objectType.
     *  Returns field names + labels from the host app's schema (e.g. ObjectSchema).
     *  Used by FieldSettingsEditor to show per-step field editability config. */
    onResolveFieldList?: (objectType: string) => Promise<Array<{ name: string; label?: string }>>;
    onError?: (message: string) => void;
    onSuccess?: (message: string) => void;
    className?: string;
}
