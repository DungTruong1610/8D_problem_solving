import React, { useState } from 'react';
import { FileText, Layers } from 'lucide-react';
import { cn, Tabs, TabsList, TabsTrigger } from '@cnma/react-ui';
import { useTranslation } from 'react-i18next';
import { DefinitionsTab } from './DefinitionsTab';
import { ObjectTypesTab } from './ObjectTypesTab';
import type { WorkflowManagerProps } from '../types';

type MainTab = 'definitions' | 'objectTypes';

/**
 * WorkflowManager — Admin orchestrator for workflow configuration.
 *
 * Provides pill-tab navigation between:
 * - Definitions: Workflow definition management (create/edit/delete)
 * - Object Types: Registered business object types
 *
 * Layout fills the full available height so the editor pane can scroll
 * independently without the outer page scrolling.
 *
 * Usage (in host app admin page):
 * ```tsx
 * <WorkflowManager
 *     httpClient={httpClient}
 *     adminBaseUrl="/workflow-admin"
 *     onError={(msg) => toast.error(msg)}
 *     onSuccess={(msg) => toast.success(msg)}
 * />
 * ```
 */
export function WorkflowManager({
    httpClient,
    adminBaseUrl = '/workflow-admin',
    principalTypes,
    onSearchPrincipals,
    onResolvePrincipal,
    onResolveFieldList,
    onError,
    onSuccess,
    className,
}: WorkflowManagerProps) {
    const { t } = useTranslation('workflow');
    const [activeTab, setActiveTab] = useState<MainTab>('definitions');
    const [isEditingDefinition, setIsEditingDefinition] = useState(false);

    return (
        <div className={cn('flex flex-col h-full bg-card/50', className)}>
            {/* Pill tab bar */}
            {!isEditingDefinition && (
                <div className="px-8 pt-8 pb-0 shrink-0">
                    <Tabs
                        value={activeTab}
                        onValueChange={(v) => setActiveTab(v as MainTab)}
                    >
                        <TabsList className="bg-background p-1 rounded-2xl border border-border w-fit shadow-sm">
                            <TabsTrigger
                                value="definitions"
                                className="flex items-center gap-2.5 px-6 py-2.5 rounded-xl text-sm font-bold data-[state=active]:bg-muted"
                            >
                                <FileText className="w-4 h-4" />
                                {t('admin.tabs.definitions', 'Workflow Definitions')}
                            </TabsTrigger>
                            <TabsTrigger
                                value="objectTypes"
                                className="flex items-center gap-2.5 px-6 py-2.5 rounded-xl text-sm font-bold data-[state=active]:bg-muted"
                            >
                                <Layers className="w-4 h-4" />
                                {t('admin.tabs.objectTypes', 'Object Types')}
                            </TabsTrigger>
                        </TabsList>
                    </Tabs>
                </div>
            )}

            {/* Tab content — fills remaining height */}
            <div className={cn("flex-1 min-h-0", !isEditingDefinition && "mt-6")}>
                {activeTab === 'definitions' && (
                    <DefinitionsTab
                        httpClient={httpClient}
                        baseUrl={adminBaseUrl}
                        principalTypes={principalTypes}
                        onSearchPrincipals={onSearchPrincipals}
                        onResolvePrincipal={onResolvePrincipal}
                        onResolveFieldList={onResolveFieldList}
                        onError={onError}
                        onSuccess={onSuccess}
                        onEditingChange={setIsEditingDefinition}
                    />
                )}
                {activeTab === 'objectTypes' && (
                    <ObjectTypesTab
                        httpClient={httpClient}
                        baseUrl={adminBaseUrl}
                        onError={onError}
                        onSuccess={onSuccess}
                    />
                )}
            </div>
        </div>
    );
}
