import React, { useState, useEffect, useCallback } from 'react';
import { Settings2, Eye, EyeOff, Lock, Asterisk } from 'lucide-react';
import {
    cn,
    Button,
    Toggle,
    Select, SelectTrigger, SelectValue, SelectContent, SelectItem,
    Input,
} from '@cnma/react-ui';
import { useTranslation } from 'react-i18next';
import type { FieldSetting, FieldSettingMode } from '../types';

interface FieldSettingsEditorProps {
    /** Current JSON-encoded field settings from the step */
    value?: string;
    /** Available field names from the host app's object schema */
    fieldList?: Array<{ name: string; label?: string }>;
    /** Called when field settings change */
    onChange: (json: string) => void;
    className?: string;
}

const getModeOptions = (t: any): Array<{ value: FieldSettingMode; label: string; icon: typeof Eye }> => [
    { value: 'editable', label: t('admin.fieldSettings.mode.editable', 'Editable'), icon: Eye },
    { value: 'mandatory', label: t('admin.fieldSettings.mode.mandatory', 'Mandatory'), icon: Asterisk },
    { value: 'readonly', label: t('admin.fieldSettings.mode.readonly', 'Read-only'), icon: Lock },
    { value: 'hidden', label: t('admin.fieldSettings.mode.hidden', 'Hidden'), icon: EyeOff },
];

/**
 * FieldSettingsEditor — Configure per-field editability settings for a workflow step.
 * Each field can be: mandatory, editable, readonly, or hidden.
 */
export function FieldSettingsEditor({
    value, fieldList, onChange, className,
}: FieldSettingsEditorProps) {
    const { t } = useTranslation('workflow');
    const [settings, setSettings] = useState<FieldSetting[]>([]);
    const [searchTerm, setSearchTerm] = useState('');
    const [activeFilters, setActiveFilters] = useState<FieldSettingMode[]>(['hidden', 'readonly', 'editable', 'mandatory']);

    const toggleFilter = (mode: FieldSettingMode) => {
        setActiveFilters(prev => 
            prev.includes(mode) ? prev.filter(m => m !== mode) : [...prev, mode]
        );
    };

    const modeOptions = getModeOptions(t);

    // Parse existing settings from JSON
    useEffect(() => {
        if (value) {
            try {
                const parsed = JSON.parse(value);
                if (Array.isArray(parsed)) {
                    setSettings(parsed);
                } else if (typeof parsed === 'object') {
                    // Legacy format: { fieldName: mode }
                    const converted = Object.entries(parsed).map(([fieldName, mode]) => ({
                        fieldName,
                        mode: mode as FieldSettingMode,
                    }));
                    setSettings(converted);
                }
            } catch {
                setSettings([]);
            }
        } else {
            setSettings([]);
        }
    }, [value]);

    // Merge with fieldList — ensure all known fields appear
    const mergedFields = useCallback((): FieldSetting[] => {
        if (!fieldList?.length) return settings;

        const existingMap = new Map(settings.map(s => [s.fieldName, s]));
        return fieldList.map(f => ({
            fieldName: f.name,
            label: f.label || f.name,
            mode: existingMap.get(f.name)?.mode || 'readonly',
        }));
    }, [fieldList, settings]);

    const handleChange = (fieldName: string, mode: FieldSettingMode) => {
        const updated = mergedFields().map(f =>
            f.fieldName === fieldName ? { ...f, mode } : f
        );
        setSettings(updated);
        onChange(JSON.stringify(updated));
    };

    const fields = mergedFields();

    if (!fieldList?.length && settings.length === 0) {
        return (
            <div className={cn("text-xs text-muted-foreground italic py-2", className)}>
                {t('admin.fieldSettings.noFields', 'No field list available. Configure fields in ObjectSchema first.')}
            </div>
        );
    }

    const displayFields = fields.length > 0 ? fields : settings;
    const filteredFields = displayFields.filter(f => 
        activeFilters.includes(f.mode) &&
        ((f.label && f.label.toLowerCase().includes(searchTerm.toLowerCase())) || 
         f.fieldName.toLowerCase().includes(searchTerm.toLowerCase()))
    );

    return (
        <div className={cn("space-y-4", className)}>
            <div className="flex items-center justify-between">
                <div className="flex items-center gap-2 text-sm font-bold text-foreground">
                    <Settings2 className="h-4 w-4 text-primary" />
                    {t('admin.fieldSettings.title', 'Field Settings')}
                </div>
                <div className="flex items-center gap-4">
                    <div className="flex flex-wrap items-center gap-1.5">
                        {modeOptions.map(opt => {
                            const count = displayFields.filter(f => f.mode === opt.value).length;
                            const isActive = activeFilters.includes(opt.value);

                            let colorClasses = 'data-[state=on]:bg-blue-100 data-[state=on]:text-blue-700 data-[state=on]:border-blue-200';
                            if (opt.value === 'hidden') colorClasses = 'data-[state=on]:bg-red-100 data-[state=on]:text-red-700 data-[state=on]:border-red-200';
                            if (opt.value === 'readonly') colorClasses = 'data-[state=on]:bg-teal-100 data-[state=on]:text-teal-700 data-[state=on]:border-teal-200';
                            if (opt.value === 'mandatory') colorClasses = 'data-[state=on]:bg-orange-100 data-[state=on]:text-orange-700 data-[state=on]:border-orange-200';

                            return (
                                <Toggle
                                    key={opt.value}
                                    pressed={isActive}
                                    onPressedChange={() => toggleFilter(opt.value)}
                                    className={cn(
                                        "flex items-center gap-1.5 px-3 py-1.5 rounded-md text-xs font-medium transition-all border",
                                        colorClasses,
                                        !isActive && "bg-background text-muted-foreground border-border opacity-50 hover:opacity-100 hover:bg-muted/50"
                                    )}
                                >
                                    <opt.icon className="w-3.5 h-3.5" />
                                    {opt.label}
                                    <span className={cn("ml-1 px-1.5 py-0.5 rounded text-[10px]", isActive ? "bg-white/50" : "bg-muted")}>
                                        {count}
                                    </span>
                                </Toggle>
                            );
                        })}
                    </div>
                    <div className="w-56">
                        <Input
                            placeholder={t('admin.fieldSettings.search', 'Search fields...')}
                            value={searchTerm}
                            onChange={(e) => setSearchTerm(e.target.value)}
                            className="h-9"
                        />
                    </div>
                </div>
            </div>

            <div className="border border-border rounded-xl overflow-y-auto max-h-[600px] bg-card shadow-sm">
                <table className="w-full text-sm relative">
                    <thead className="sticky top-0 z-10 shadow-sm">
                        <tr className="bg-muted/95 backdrop-blur supports-[backdrop-filter]:bg-muted/80 border-b border-border">
                            <th className="text-left px-5 py-3 font-bold text-foreground">{t('admin.fieldSettings.columnField', 'Field')}</th>
                            <th className="text-center px-3 py-3 font-bold text-foreground w-24">{t('admin.fieldSettings.mode.hidden', 'Hidden')}</th>
                            <th className="text-center px-3 py-3 font-bold text-foreground w-24">{t('admin.fieldSettings.mode.readonly', 'Read-only')}</th>
                            <th className="text-center px-3 py-3 font-bold text-foreground w-24">{t('admin.fieldSettings.mode.editable', 'Editable')}</th>
                            <th className="text-center px-3 py-3 font-bold text-foreground w-24">{t('admin.fieldSettings.mode.mandatory', 'Mandatory')}</th>
                        </tr>
                    </thead>
                    <tbody>
                        {filteredFields.map((field, idx) => (
                            <tr key={field.fieldName} className={cn(
                                "border-b border-border last:border-b-0 hover:bg-muted/50 transition-colors",
                                idx % 2 === 0 ? 'bg-background' : 'bg-muted/10'
                            )}>
                                <td className="px-5 py-3">
                                    <span className="font-bold text-foreground">{field.label || field.fieldName}</span>
                                    {field.label && field.label !== field.fieldName && (
                                        <span className="text-muted-foreground ml-1">({field.fieldName})</span>
                                    )}
                                </td>
                                <td className="px-3 py-3 align-middle text-center">
                                    <Toggle
                                        pressed={field.mode === 'hidden'}
                                        onPressedChange={() => handleChange(field.fieldName, 'hidden')}
                                        className={cn(
                                            "w-6 h-6 min-w-0 p-0 rounded-md mx-auto transition-all",
                                            field.mode === 'hidden' 
                                                ? "border-[6px] border-red-500 data-[state=on]:border-red-500 data-[state=on]:bg-card bg-card" 
                                                : "border border-input bg-card hover:bg-muted/50"
                                        )}
                                        aria-label={t('admin.fieldSettings.mode.hidden', 'Hidden')}
                                    />
                                </td>
                                <td className="px-3 py-3 align-middle text-center">
                                    <Toggle
                                        pressed={field.mode === 'readonly'}
                                        onPressedChange={() => handleChange(field.fieldName, 'readonly')}
                                        className={cn(
                                            "w-6 h-6 min-w-0 p-0 rounded-md mx-auto transition-all",
                                            field.mode === 'readonly' 
                                                ? "border-[6px] border-teal-500 data-[state=on]:border-teal-500 data-[state=on]:bg-card bg-card" 
                                                : "border border-input bg-card hover:bg-muted/50"
                                        )}
                                        aria-label={t('admin.fieldSettings.mode.readonly', 'Read-only')}
                                    />
                                </td>
                                <td className="px-3 py-3 align-middle text-center">
                                    <Toggle
                                        pressed={field.mode === 'editable'}
                                        onPressedChange={() => handleChange(field.fieldName, 'editable')}
                                        className={cn(
                                            "w-6 h-6 min-w-0 p-0 rounded-md mx-auto transition-all",
                                            field.mode === 'editable' 
                                                ? "border-[6px] border-blue-500 data-[state=on]:border-blue-500 data-[state=on]:bg-card bg-card" 
                                                : "border border-input bg-card hover:bg-muted/50"
                                        )}
                                        aria-label={t('admin.fieldSettings.mode.editable', 'Editable')}
                                    />
                                </td>
                                <td className="px-3 py-3 align-middle text-center">
                                    <Toggle
                                        pressed={field.mode === 'mandatory'}
                                        onPressedChange={() => handleChange(field.fieldName, 'mandatory')}
                                        className={cn(
                                            "w-6 h-6 min-w-0 p-0 rounded-md mx-auto transition-all",
                                            field.mode === 'mandatory' 
                                                ? "border-[6px] border-orange-500 data-[state=on]:border-orange-500 data-[state=on]:bg-card bg-card" 
                                                : "border border-input bg-card hover:bg-muted/50"
                                        )}
                                        aria-label={t('admin.fieldSettings.mode.mandatory', 'Mandatory')}
                                    />
                                </td>
                            </tr>
                        ))}
                        {filteredFields.length === 0 && (
                            <tr>
                                <td colSpan={5} className="px-5 py-8 text-center text-muted-foreground text-sm">
                                    {t('admin.fieldSettings.noResults', 'No fields matched your search.')}
                                </td>
                            </tr>
                        )}
                    </tbody>
                </table>
            </div>

        </div>
    );
}
