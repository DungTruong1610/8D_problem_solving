import { useState, useEffect, useRef, useCallback } from 'react';
import { Search, X, Loader2 } from 'lucide-react';
import { cn, Input, Button } from '@cnma/react-ui';
import { useTranslation } from 'react-i18next';
import type { PrincipalSearchResult } from '../types';

interface PrincipalPickerProps {
    /** Currently selected principal ID */
    value: string;
    /** Currently resolved principal name (from server READ handler) */
    displayName?: string;
    /** Principal type code (USER, GROUP, etc.) */
    principalType: string;
    /** Search callback provided by host app */
    onSearch: (principalType: string, query: string) => Promise<PrincipalSearchResult[]>;
    /** Resolve a single principal by ID. Used to display the name after page reload.
     *  If not provided, falls back to showing the truncated UUID. */
    onResolve?: (principalType: string, id: string) => Promise<PrincipalSearchResult | null>;
    /** Called when a principal is selected */
    onSelect: (id: string, name?: string) => void;
    className?: string;
}

/**
 * PrincipalPicker — Searchable autocomplete for selecting users/groups.
 * Replaces raw UUID text input with a type-to-search experience.
 *
 * When a value is set but no displayName is provided (e.g. after reload,
 * because principalName is a virtual field that doesn't survive $expand),
 * it auto-resolves the name via onResolve or shows truncated UUID.
 */
export function PrincipalPicker({
    value, displayName, principalType, onSearch, onResolve, onSelect, className,
}: PrincipalPickerProps) {
    const { t } = useTranslation('workflow');
    const [query, setQuery] = useState('');
    const [results, setResults] = useState<PrincipalSearchResult[]>([]);
    const [isOpen, setIsOpen] = useState(false);
    const [loading, setLoading] = useState(false);
    const [resolving, setResolving] = useState(false);
    const [selectedName, setSelectedName] = useState(displayName || '');
    const wrapperRef = useRef<HTMLDivElement>(null);
    const debounceRef = useRef<ReturnType<typeof setTimeout>>();

    // Update selected name when displayName changes (from server)
    useEffect(() => {
        if (displayName) setSelectedName(displayName);
    }, [displayName]);

    // Auto-resolve name when value exists but displayName is missing
    useEffect(() => {
        if (value && !displayName && !selectedName && onResolve) {
            setResolving(true);
            onResolve(principalType, value)
                .then(result => {
                    if (result) {
                        setSelectedName(result.name);
                    } else {
                        setSelectedName(value.slice(0, 12) + '…');
                    }
                })
                .catch(() => {
                    setSelectedName(value.slice(0, 12) + '…');
                })
                .finally(() => setResolving(false));
        } else if (value && !displayName && !selectedName) {
            // No onResolve — fallback to truncated UUID
            setSelectedName(value.slice(0, 12) + '…');
        }
    }, [value, principalType]); // eslint-disable-line react-hooks/exhaustive-deps

    // Close on outside click
    useEffect(() => {
        function handleClick(e: MouseEvent) {
            if (wrapperRef.current && !wrapperRef.current.contains(e.target as Node)) {
                setIsOpen(false);
            }
        }
        document.addEventListener('mousedown', handleClick);
        return () => document.removeEventListener('mousedown', handleClick);
    }, []);

    // Debounced search
    const handleInputChange = useCallback((val: string) => {
        setQuery(val);
        if (debounceRef.current) clearTimeout(debounceRef.current);

        if (val.length < 2) {
            setResults([]);
            setIsOpen(false);
            return;
        }

        debounceRef.current = setTimeout(async () => {
            setLoading(true);
            try {
                const data = await onSearch(principalType, val);
                setResults(data);
                setIsOpen(true);
            } catch {
                setResults([]);
            } finally {
                setLoading(false);
            }
        }, 300);
    }, [onSearch, principalType]);

    const handleSelect = (result: PrincipalSearchResult) => {
        setSelectedName(result.name);
        setQuery('');
        setIsOpen(false);
        setResults([]);
        onSelect(result.id, result.name);
    };

    const handleClear = () => {
        setSelectedName('');
        setQuery('');
        onSelect('', '');
    };

    // If we have a selected value (resolving or resolved), show chip
    if (value && (selectedName || resolving)) {
        return (
            <div className={cn("flex items-center gap-1.5 flex-1 min-w-0 overflow-hidden", className)}>
                <div className="flex items-center gap-2 bg-accent/50 rounded-md px-3 py-2 h-8 flex-1 min-w-0 overflow-hidden">
                    {resolving ? (
                        <Loader2 className="h-3.5 w-3.5 animate-spin text-muted-foreground shrink-0" />
                    ) : (
                        <span className="text-sm font-medium truncate block">{selectedName}</span>
                    )}
                </div>
                <Button
                    type="button"
                    variant="ghost"
                    size="icon"
                    onClick={handleClear}
                    className="h-8 w-8 p-0 shrink-0"
                >
                    <X className="h-4 w-4" />
                </Button>
            </div>
        );
    }

    // Search input with dropdown
    return (
        <div ref={wrapperRef} className={cn("relative flex-1 min-w-0", className)}>
            <div className="relative flex items-center min-w-0">
                <Search className="absolute left-2.5 h-3 w-3 text-muted-foreground pointer-events-none" />
                <Input
                    className="pl-7 pr-7 h-8 text-xs min-w-0"
                    placeholder={t('admin.principalPicker.searchPlaceholder', 'Search by name…')}
                    value={query}
                    onChange={(e) => handleInputChange(e.target.value)}
                    onFocus={() => { if (results.length > 0) setIsOpen(true); }}
                />
                {loading && <Loader2 className="absolute right-2 h-3 w-3 animate-spin text-muted-foreground" />}
            </div>

            {/* Dropdown results */}
            {isOpen && results.length > 0 && (
                <div className="absolute z-50 top-full left-0 right-0 mt-1 bg-popover border rounded-md shadow-md max-h-40 overflow-y-auto">
                    {results.map(r => (
                        <Button
                            key={r.id}
                            type="button"
                            variant="ghost"
                            className="w-full justify-start px-3 py-1.5 text-xs h-auto font-normal"
                            onClick={() => handleSelect(r)}
                        >
                            <div className="flex-1 min-w-0 text-left">
                                <div className="font-medium truncate">{r.name}</div>
                                {r.detail && (
                                    <div className="text-muted-foreground text-xs truncate">{r.detail}</div>
                                )}
                            </div>
                        </Button>
                    ))}
                </div>
            )}

            {/* No results message */}
            {isOpen && results.length === 0 && query.length >= 2 && !loading && (
                <div className="absolute z-50 top-full left-0 right-0 mt-1 bg-popover border rounded-md shadow-md px-3 py-2 text-xs text-muted-foreground">
                    {t('admin.principalPicker.noResults', 'No results found')}
                </div>
            )}
        </div>
    );
}
