import React from 'react';
import { Loader2, Layers } from 'lucide-react';
import { Button, Switch, cn } from '@cnma/react-ui';
import type { WorkflowHttpClient } from '../../types';
import { useTranslation } from 'react-i18next';
import { useObjectTypesState } from './hooks/useObjectTypesState';

interface ObjectTypesTabProps {
    httpClient: WorkflowHttpClient;
    baseUrl: string;
    onError?: (message: string) => void;
    onSuccess?: (message: string) => void;
}

export function ObjectTypesTab({
    httpClient, baseUrl, onError, onSuccess,
}: ObjectTypesTabProps) {
    const { t } = useTranslation('workflow');
    const {
        objectTypes,
        loading,
        togglingIds,
        handleToggle,
    } = useObjectTypesState(httpClient, baseUrl, t, onError, onSuccess);

    if (loading) {
        return (
            <div className="flex items-center justify-center py-8">
                <Loader2 className="h-5 w-5 animate-spin text-muted-foreground" />
            </div>
        );
    }

    return (
        <div className="px-8">
            <div className="bg-background rounded-3xl border border-border shadow-sm overflow-hidden">
                {/* Header */}
                <div className="p-8 border-b border-border bg-muted/30">
                    <h3 className="font-bold text-foreground text-lg">
                        {t('admin.objectTypes.registeredCount', '{{count}} registered types', { count: objectTypes.length })}
                    </h3>
                </div>

                {/* List */}
                <div className="divide-y divide-border">
                    {objectTypes.map(ot => {
                        const isToggling = togglingIds.has(ot.ID);
                        return (
                            <div
                                key={ot.ID}
                                className="p-6 flex items-center justify-between hover:bg-muted/50 transition-colors group"
                            >
                                <div className="flex items-center gap-5">
                                    <div className="w-12 h-12 bg-muted text-muted-foreground rounded-2xl flex items-center justify-center border border-border group-hover:scale-105 transition-transform shadow-sm">
                                        <Layers className="w-6 h-6" />
                                    </div>
                                    <div>
                                        <div className="flex items-center gap-2">
                                            <span className="font-bold text-foreground text-base">{ot.objectType}</span>
                                            {ot.displayName && (
                                                <span className="text-muted-foreground text-base">{ot.displayName}</span>
                                            )}
                                            {ot.orgKeyField && (
                                                <span className="text-muted-foreground text-xs font-mono ml-2">({ot.orgKeyField})</span>
                                            )}
                                        </div>
                                    </div>
                                </div>

                                <div 
                                    className="flex items-center gap-3 cursor-pointer p-2 rounded-lg hover:bg-background transition-colors"
                                    onClick={(e) => { e.stopPropagation(); handleToggle(ot); }}
                                    title={ot.isActive ? t('admin.definitions.clickToDeactivate', 'Click to deactivate') : t('admin.definitions.clickToActivate', 'Click to activate')}
                                >
                                    <span className={cn(
                                        "text-xs font-bold uppercase tracking-wider",
                                        ot.isActive ? "text-destructive" : "text-muted-foreground"
                                    )}>
                                        {ot.isActive ? t('common.status.active', 'Active') : t('common.status.inactive', 'Inactive')}
                                    </span>
                                    <Switch
                                        checked={ot.isActive}
                                        onCheckedChange={() => handleToggle(ot)}
                                        disabled={isToggling}
                                        aria-label={ot.isActive ? t('admin.definitions.clickToDeactivate', 'Click to deactivate') : t('admin.definitions.clickToActivate', 'Click to activate')}
                                    />
                                    {isToggling && <Loader2 className="w-3 h-3 animate-spin text-muted-foreground" />}
                                </div>
                            </div>
                        );
                    })}
                </div>
            </div>
        </div>
    );
}
