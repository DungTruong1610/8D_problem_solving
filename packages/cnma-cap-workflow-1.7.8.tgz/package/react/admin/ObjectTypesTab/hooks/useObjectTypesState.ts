import { useState, useCallback, useEffect, useMemo } from 'react';
import { WorkflowAdminService } from '../../../services/WorkflowAdminService';
import type { WorkflowHttpClient, WorkflowObjectType } from '../../../types';

export function useObjectTypesState(
    httpClient: WorkflowHttpClient,
    baseUrl: string,
    t: any,
    onError?: (message: string) => void,
    onSuccess?: (message: string) => void
) {
    const [objectTypes, setObjectTypes] = useState<WorkflowObjectType[]>([]);
    const [loading, setLoading] = useState(true);
    const [togglingIds, setTogglingIds] = useState<Set<string>>(new Set());

    const service = useMemo(
        () => new WorkflowAdminService(httpClient, baseUrl),
        [httpClient, baseUrl],
    );

    const loadTypes = useCallback(async (showLoader = true) => {
        try {
            if (showLoader) setLoading(true);
            const data = await service.getObjectTypes();
            setObjectTypes(data);
        } catch (err: any) {
            onError?.(err.message || t('admin.objectTypes.loadFailed', 'Failed to load object types'));
        } finally {
            if (showLoader) setLoading(false);
        }
    }, [service, onError, t]);

    useEffect(() => { loadTypes(); }, [loadTypes]);

    const handleToggle = async (ot: WorkflowObjectType) => {
        setTogglingIds(prev => new Set(prev).add(ot.ID));
        try {
            await service.updateObjectType(ot.ID, { isActive: !ot.isActive });
            onSuccess?.(t('admin.objectTypes.toggleSuccess', '{{type}} {{action}}', {
                type: ot.objectType,
                action: ot.isActive
                    ? t('common.status.deactivated', 'deactivated')
                    : t('common.status.activated', 'activated'),
            }));
            await loadTypes(false);
        } catch (err: any) {
            onError?.(err.message || t('admin.objectTypes.toggleFailed', 'Failed to toggle'));
        } finally {
            setTogglingIds(prev => {
                const next = new Set(prev);
                next.delete(ot.ID);
                return next;
            });
        }
    };

    return {
        objectTypes,
        loading,
        togglingIds,
        handleToggle,
    };
}
