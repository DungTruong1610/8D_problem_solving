import React from 'react';
import { ChevronRight, Trash2, Save, Loader2, AlertCircle } from 'lucide-react';
import { Button, Switch, Tabs, TabsList, TabsTrigger, cn, useConfirm } from '@cnma/react-ui';
import { useTranslation } from 'react-i18next';
import { DefinitionGeneralForm } from './DefinitionGeneralForm';
import { NotificationSettingsEditor } from '../../NotificationSettingsEditor';
import { StepEditor } from '../../StepEditor';
import { useDefinitionForm } from '../hooks/useDefinitionForm';
import type { WorkflowAdminService } from '../../../services/WorkflowAdminService';
import type { WorkflowDefinition, WorkflowObjectType, PrincipalTypeOption, PrincipalSearchResult, WorkflowHttpClient } from '../../../types';

interface DefinitionFormPanelProps {
    service: WorkflowAdminService;
    objectTypes: WorkflowObjectType[];
    editDef: WorkflowDefinition | null;
    fieldList: Array<{ name: string; label?: string }>;
    principalTypes?: PrincipalTypeOption[];
    onSearchPrincipals?: (principalType: string, query: string) => Promise<PrincipalSearchResult[]>;
    onResolvePrincipal?: (principalType: string, id: string) => Promise<PrincipalSearchResult | null>;
    httpClient: WorkflowHttpClient;
    baseUrl: string;
    onClose: () => void;
    onError?: (message: string) => void;
    onSuccess?: (message: string) => void;
}

export function DefinitionFormPanel({
    service,
    objectTypes,
    editDef,
    fieldList,
    principalTypes,
    onSearchPrincipals,
    onResolvePrincipal,
    httpClient,
    baseUrl,
    onClose,
    onError,
    onSuccess,
}: DefinitionFormPanelProps) {
    const { t } = useTranslation('workflow');
    const { confirm, ConfirmDialog } = useConfirm();
    const {
        form,
        f,
        isEdit,
        saving,
        activeTab,
        setActiveTab,
        createdId,
        stepEditorRef,
        handleSave,
        handleDelete,
    } = useDefinitionForm(service, editDef, onClose, confirm, onError, onSuccess);

    return (
        <div className="flex flex-col h-full bg-card/50">
            {/* Top Editor Header */}
            <header className="h-20 border-b border-border flex items-center justify-between px-8 shrink-0 z-10">
                <div className="flex items-center gap-6">
                    <Button variant="ghost" size="icon" onClick={onClose} disabled={saving} className="rounded-full text-muted-foreground hover:bg-muted transition-colors">
                        <ChevronRight className="w-5 h-5 rotate-180" />
                    </Button>
                    <div>
                        <h1 className="text-xl font-bold text-foreground leading-tight">
                            {isEdit ? form.workflowType || t('admin.definitions.editDefinition', 'Edit Definition') : t('admin.definitions.newDefinition', 'New Workflow Definition')}
                        </h1>
                        <p className="text-muted-foreground text-sm font-medium">
                            {isEdit ? `${form.objectType} · v${editDef?.definitionVersion}` : t('admin.definitions.createHint', 'Fill in the details below, then save')}
                        </p>
                    </div>
                </div>
                <div className="flex items-center gap-6">
                    <div className="flex items-center gap-2">
                        <Switch
                            checked={form.isActive}
                            onCheckedChange={(checked) => f('isActive', checked)}
                            aria-label={form.isActive ? t('common.status.active', 'Active') : t('common.status.inactive', 'Inactive')}
                        />
                        <span className="text-sm font-bold text-foreground">
                            {form.isActive ? t('common.status.active', 'Active') : t('common.status.inactive', 'Inactive')}
                        </span>
                    </div>
                    {isEdit && editDef && (
                        <Button variant="ghost" size="icon" onClick={() => handleDelete(editDef.ID)} className="text-muted-foreground hover:text-destructive hover:bg-destructive/10 rounded-full transition-all">
                            <Trash2 className="w-5 h-5" />
                        </Button>
                    )}
                    <Button
                        onClick={handleSave}
                        disabled={saving}
                        className="px-8 h-10 text-sm font-bold rounded-xl transition-all active:scale-95 flex items-center gap-2.5 shadow-md"
                    >
                        {saving ? <Loader2 className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />}
                        {t('common.actions.saveChanges', 'Save changes')}
                    </Button>
                </div>
            </header>

            {/* Top Level Tabs */}
            <div className="bg-primary-foreground border-b border-border sticky top-0 z-10 px-6 py-1.5 shrink-0">
                <div className="flex items-center gap-0 overflow-x-auto no-scrollbar">
                    {[
                        { id: 'general', label: t('admin.definitions.tabs.general', 'General') },
                        { id: 'workflow', label: t('admin.definitions.tabs.workflowSteps', 'Workflow Steps') },
                        { id: 'logic', label: t('admin.definitions.tabs.logic', 'Workflow Logic') },
                        { id: 'notifications', label: t('admin.definitions.tabs.notifications', 'Workflow Notifications') },
                    ].map(tab => {
                        const isActive = activeTab === tab.id;
                        const isDisabled = (tab.id === 'workflow' || tab.id === 'logic') && !createdId;
                        return (
                            <button
                                key={tab.id}
                                onClick={() => !isDisabled && setActiveTab(tab.id as any)}
                                disabled={isDisabled}
                                className={cn(
                                    "relative flex items-center gap-1.5 px-4 py-2 text-sm font-bold transition-all whitespace-nowrap rounded-lg cursor-pointer",
                                    !isDisabled && "hover:bg-muted/60",
                                    isDisabled && "opacity-50 cursor-not-allowed",
                                    isActive ? "text-primary" : "text-muted-foreground"
                                )}
                                role="tab"
                                aria-selected={isActive}
                            >
                                <span>{tab.label}</span>
                                {isDisabled && <span className="ml-1 font-normal text-xs">({t('admin.definitions.saveFirst', 'save first')})</span>}
                                
                                {/* Active indicator line */}
                                {isActive && (
                                    <span className="absolute bottom-0 left-2 right-2 h-0.5 rounded-full bg-primary" />
                                )}
                            </button>
                        );
                    })}
                </div>
            </div>

            <div className="flex flex-1 min-h-0 overflow-hidden">
                {activeTab === 'general' && (
                    <DefinitionGeneralForm
                        form={form}
                        f={f}
                        isEdit={isEdit}
                        objectTypes={objectTypes}
                        principalTypes={principalTypes}
                        onSearchPrincipals={onSearchPrincipals}
                        onResolvePrincipal={onResolvePrincipal}
                    />
                )}

                {activeTab === 'notifications' && (
                    <div className="flex-1 bg-card/50">
                        <NotificationSettingsEditor
                            value={form.notificationSettings}
                            onChange={(val) => f('notificationSettings', val)}
                            schemaFields={fieldList}
                            onSendTestEmail={async (eventType, recipientEmail, notifSettings) => {
                                await service.sendTestEmail(eventType, recipientEmail, notifSettings);
                            }}
                            className="h-full border-0"
                        />
                    </div>
                )}

                {(activeTab === 'workflow' || activeTab === 'logic') && (
                    <div className="flex-1 bg-card/50 overflow-hidden flex flex-col">
                        {createdId ? (
                            <StepEditor
                                activeMode={activeTab as 'workflow' | 'logic'}
                                ref={stepEditorRef}
                                httpClient={httpClient}
                                baseUrl={baseUrl}
                                definitionId={createdId}
                                definitionName={form.workflowType}
                                principalTypes={principalTypes}
                                onSearchPrincipals={onSearchPrincipals}
                                onResolvePrincipal={onResolvePrincipal}
                                fieldList={fieldList}
                                onError={onError}
                                onSuccess={onSuccess}
                            />
                        ) : (
                            <div className="p-10">
                                <div className="text-center py-12 text-muted-foreground text-sm border border-border border-dashed rounded-xl bg-background">
                                    <AlertCircle className="h-6 w-6 mx-auto mb-2 opacity-50" />
                                    {t('admin.definitions.saveFirstConfigHint', 'Save the General settings first to enable step configuration.')}
                                </div>
                            </div>
                        )}
                    </div>
                )}
            </div>
            {ConfirmDialog}
        </div>
    );
}
