import React from 'react';
import { Pencil, Trash2, GitBranch, Loader2 } from 'lucide-react';
import { Button, Badge, cn, Switch } from '@cnma/react-ui';
import type { WorkflowDefinition } from '../../../types';
import { friendlyLabel } from '../utils';

interface DefinitionListItemProps {
    def: WorkflowDefinition;
    objectTypes: any[];
    handleToggleActive: (def: WorkflowDefinition) => void;
    handleOpenEdit: (def: WorkflowDefinition) => void;
    handleDelete: (id: string) => void;
    isToggling?: boolean;
    t: any;
}

export function DefinitionListItem({
    def,
    objectTypes,
    handleToggleActive,
    handleOpenEdit,
    handleDelete,
    isToggling,
    t,
}: DefinitionListItemProps) {
    const getOrgKeyLabel = (objectType: string): string | null => {
        const ot = objectTypes.find(t => t.objectType === objectType);
        if (!ot?.orgKeyField) return null;
        return friendlyLabel(ot.orgKeyField);
    };

    const orgLabel = getOrgKeyLabel(def.objectType);

    return (
        <div
            className="p-6 flex items-center justify-between hover:bg-muted/30 transition-colors group cursor-pointer bg-card"
            onClick={() => handleOpenEdit(def)}
        >
            <div className="flex items-center gap-5">
                <div className="w-12 h-12 bg-primary/10 text-primary rounded-2xl flex items-center justify-center border border-primary/20 group-hover:scale-105 transition-transform shadow-sm">
                    <GitBranch className="w-6 h-6" />
                </div>
                <div>
                    <h4 className="font-bold text-foreground text-base">{def.workflowType}</h4>
                    <p className="text-xs text-muted-foreground mt-1 font-medium">
                        {def.objectType}
                        {orgLabel && def.orgKeyValue && ` · ${orgLabel}: ${def.orgKeyValue}`}
                        {orgLabel && !def.orgKeyValue && ` · All ${orgLabel}s`}
                        {` · v${def.definitionVersion} · ${def.rejectionMode.replace(/_/g, ' ').toLowerCase()}`}
                        {def.responsibleName && ` · Resp: ${def.responsibleName}`}
                    </p>
                </div>
            </div>

            <div className="flex items-center gap-6">
                <div 
                    className="flex items-center gap-3 cursor-pointer p-2 rounded-lg hover:bg-background transition-colors"
                    onClick={(e) => { e.stopPropagation(); handleToggleActive(def); }}
                    title={def.isActive ? t('admin.definitions.clickToDeactivate', 'Click to deactivate') : t('admin.definitions.clickToActivate', 'Click to activate')}
                >
                    <span className={cn(
                        "text-xs font-bold uppercase tracking-wider",
                        def.isActive ? "text-destructive" : "text-muted-foreground"
                    )}>
                        {def.isActive ? t('common.status.active', 'Active') : t('common.status.inactive', 'Inactive')}
                    </span>
                    <Switch
                            checked={def.isActive}
                            onCheckedChange={() => handleToggleActive(def)}
                            disabled={isToggling}
                            aria-label={def.isActive ? t('admin.definitions.clickToDeactivate', 'Click to deactivate') : t('admin.definitions.clickToActivate', 'Click to activate')}
                        />
                    {isToggling && <Loader2 className="w-3 h-3 animate-spin text-muted-foreground" />}
                </div>
                <div className="flex items-center gap-2">
                    <Button
                        variant="ghost"
                        size="icon"
                        title={t('admin.definitions.editDefinition', 'Edit definition')}
                        onClick={(e) => { e.stopPropagation(); handleOpenEdit(def); }}
                        className="text-muted-foreground hover:text-primary hover:bg-primary/10"
                    >
                        <Pencil className="w-5 h-5" />
                    </Button>
                    <Button
                        variant="ghost"
                        size="icon"
                        title={t('admin.definitions.deleteDefinition', 'Delete definition')}
                        onClick={(e) => { e.stopPropagation(); handleDelete(def.ID); }}
                        className="text-muted-foreground hover:text-destructive hover:bg-destructive/10"
                    >
                        <Trash2 className="w-5 h-5" />
                    </Button>
                </div>
            </div>
        </div>
    );
}
