import React from 'react';
import { useTranslation } from 'react-i18next';
import { Target, FileText, Settings, Shield } from 'lucide-react';
import { Select, SelectTrigger, SelectValue, SelectContent, SelectItem, Input, Textarea, Switch } from '@cnma/react-ui';
import { PrincipalPicker } from '../../PrincipalPicker';
import { friendlyLabel } from '../utils';
import type { DefinitionFormState } from '../hooks/useDefinitionForm';
import type { WorkflowObjectType, PrincipalTypeOption, PrincipalSearchResult } from '../../../types';

interface DefinitionGeneralFormProps {
    form: DefinitionFormState;
    f: <K extends keyof DefinitionFormState>(key: K, value: DefinitionFormState[K]) => void;
    isEdit: boolean;
    objectTypes: WorkflowObjectType[];
    principalTypes?: PrincipalTypeOption[];
    onSearchPrincipals?: (principalType: string, query: string) => Promise<PrincipalSearchResult[]>;
    onResolvePrincipal?: (principalType: string, id: string) => Promise<PrincipalSearchResult | null>;
}

export function DefinitionGeneralForm({
    form,
    f,
    isEdit,
    objectTypes,
    principalTypes,
    onSearchPrincipals,
    onResolvePrincipal,
}: DefinitionGeneralFormProps) {
    const { t } = useTranslation('workflow');

    const selectedOT = objectTypes.find(ot => ot.objectType === form.objectType);
    const orgKeyField = selectedOT?.orgKeyField;

    const resolvedTypes = principalTypes && principalTypes.length > 0
        ? principalTypes
        : [{ code: 'USER', label: 'User' }, { code: 'GROUP', label: 'Group' }];

    return (
        <main className="flex-1 bg-background p-10 overflow-y-auto">
            <div className="max-w-4xl mx-auto space-y-6">

                {/* Card 1: Workflow Scope */}
                <div className="bg-card border rounded-2xl p-6 shadow-sm">
                    <div className="flex items-center gap-3 mb-6">
                        <div className="w-8 h-8 rounded-full bg-primary/10 text-primary flex items-center justify-center">
                            <Target className="w-4 h-4" />
                        </div>
                        <div>
                            <h3 className="font-semibold text-sm">{t('admin.definitions.sections.scopeTitle', 'Workflow Scope')}</h3>
                            <p className="text-xs text-muted-foreground">{t('admin.definitions.sections.scopeDesc', 'Define the object type and organizational context')}</p>
                        </div>
                    </div>
                    <div className="space-y-6">
                        <div className="space-y-2">
                            <label className="text-sm font-medium flex items-center gap-1">
                                {t('admin.definitions.fields.objectType', 'Object Type')} <span className="text-destructive">*</span>
                            </label>
                            <Select
                                value={form.objectType}
                                onValueChange={v => f('objectType', v)}
                                disabled={isEdit}
                            >
                                <SelectTrigger className="w-full data-[disabled]:bg-muted data-[disabled]:opacity-70">
                                    <SelectValue placeholder={t('admin.definitions.fields.selectObjectType', 'Select object type…')} />
                                </SelectTrigger>
                                <SelectContent>
                                    {objectTypes.filter(ot => ot.isActive || ot.objectType === form.objectType).map(ot => (
                                        <SelectItem key={ot.ID} value={ot.objectType}>
                                            {ot.objectType}{ot.displayName ? ` — ${ot.displayName}` : ''}
                                        </SelectItem>
                                    ))}
                                </SelectContent>
                            </Select>
                            {isEdit && (
                                <p className="text-xs text-muted-foreground italic">
                                    {t('admin.definitions.fields.objectTypeHint', 'Object type cannot be changed after creation.')}
                                </p>
                            )}
                        </div>

                        {orgKeyField && (
                            <div className="space-y-2">
                                <label className="text-sm font-medium">
                                    {friendlyLabel(orgKeyField)}
                                    <span className="ml-1 text-muted-foreground font-normal lowercase">({orgKeyField})</span>
                                </label>
                                <Input
                                    className="w-full"
                                    placeholder={t('admin.definitions.fields.orgKeyPlaceholder', 'Leave empty for all (global default)')}
                                    value={form.orgKeyValue}
                                    onChange={e => f('orgKeyValue', e.target.value)}
                                />
                                <p className="text-xs text-muted-foreground italic">
                                    {t('admin.definitions.fields.orgKeyHint', 'Scope this workflow to a specific {{label}}. Leave empty to apply globally.', { label: friendlyLabel(orgKeyField).toLowerCase() })}
                                </p>
                            </div>
                        )}
                    </div>
                </div>

                {/* Card 2: Workflow Details */}
                <div className="bg-card border rounded-2xl p-6 shadow-sm">
                    <div className="flex items-center gap-3 mb-6">
                        <div className="w-8 h-8 rounded-full bg-primary/10 text-primary flex items-center justify-center">
                            <FileText className="w-4 h-4" />
                        </div>
                        <div>
                            <h3 className="font-semibold text-sm">{t('admin.definitions.sections.detailsTitle', 'Workflow Details')}</h3>
                            <p className="text-xs text-muted-foreground">{t('admin.definitions.sections.detailsDesc', 'Basic information about this workflow')}</p>
                        </div>
                    </div>
                    <div className="space-y-6">
                        <div className="space-y-2">
                            <label className="text-sm font-medium flex items-center gap-1">
                                {t('admin.definitions.fields.workflowType', 'Workflow Type')} <span className="text-destructive">*</span>
                            </label>
                            <Input
                                className="w-full"
                                placeholder={t('admin.definitions.fields.workflowTypePlaceholder', 'e.g. Cost Center Approval')}
                                value={form.workflowType}
                                onChange={e => f('workflowType', e.target.value)}
                            />
                        </div>

                        <div className="space-y-2">
                            <label className="text-sm font-medium flex items-center gap-1">
                                {t('admin.definitions.fields.triggerAction', 'Trigger Action')} <span className="text-destructive">*</span>
                            </label>
                            <Input
                                className="w-full"
                                placeholder={t('admin.definitions.fields.triggerActionPlaceholder', 'e.g. submitForApproval or requestForGR')}
                                value={form.triggerAction}
                                onChange={e => f('triggerAction', e.target.value)}
                            />
                        </div>

                        <div className="space-y-2">
                            <label className="text-sm font-medium">{t('admin.definitions.fields.description', 'Description')}</label>
                            <Textarea
                                className="w-full min-h-[72px]"
                                placeholder={t('admin.definitions.fields.descriptionPlaceholder', 'Optional description…')}
                                value={form.description}
                                onChange={e => f('description', e.target.value)}
                            />
                        </div>
                    </div>
                </div>

                {/* Card 3: Execution Settings */}
                <div className="bg-card border rounded-2xl p-6 shadow-sm">
                    <div className="flex items-center gap-3 mb-6">
                        <div className="w-8 h-8 rounded-full bg-primary/10 text-primary flex items-center justify-center">
                            <Settings className="w-4 h-4" />
                        </div>
                        <div>
                            <h3 className="font-semibold text-sm">{t('admin.definitions.sections.executionTitle', 'Execution Settings')}</h3>
                            <p className="text-xs text-muted-foreground">{t('admin.definitions.sections.executionDesc', 'Configure how this workflow behaves during runtime')}</p>
                        </div>
                    </div>
                    <div className="space-y-6">
                        <div className="grid grid-cols-2 gap-8">
                            <div className="space-y-2">
                                <label className="text-sm font-medium">{t('admin.definitions.fields.rejectionMode', 'Rejection Mode')}</label>
                                <Select value={form.rejectionMode} onValueChange={v => f('rejectionMode', v)}>
                                    <SelectTrigger className="w-full">
                                        <SelectValue />
                                    </SelectTrigger>
                                    <SelectContent>
                                        <SelectItem value="BACK_TO_RESPONSIBLE">{t('admin.definitions.rejectionMode.backToResponsible', 'Back to Responsible')}</SelectItem>
                                        <SelectItem value="RESTART_STEP">{t('admin.definitions.rejectionMode.restartStep', 'Restart Step')}</SelectItem>
                                        <SelectItem value="NEW_RUN">{t('admin.definitions.rejectionMode.newRun', 'New Run')}</SelectItem>
                                    </SelectContent>
                                </Select>
                            </div>
                            <div className="space-y-2">
                                <label className="text-sm font-medium">{t('admin.definitions.fields.completionPolicy', 'Completion Policy')}</label>
                                <Select value={form.completionPolicy} onValueChange={v => f('completionPolicy', v)}>
                                    <SelectTrigger className="w-full">
                                        <SelectValue />
                                    </SelectTrigger>
                                    <SelectContent>
                                        <SelectItem value="RESPONSIBLE_ONLY">{t('admin.definitions.completionPolicy.responsibleOnly', 'Responsible Only')}</SelectItem>
                                        <SelectItem value="RESPONSIBLE_MEMBERS">{t('admin.definitions.completionPolicy.responsibleMembers', 'Responsible Members')}</SelectItem>
                                        <SelectItem value="ANY_AUTHORIZED">{t('admin.definitions.completionPolicy.anyAuthorized', 'Any Authorized User')}</SelectItem>
                                        <SelectItem value="AUTO_COMPLETE">{t('admin.definitions.completionPolicy.autoComplete', 'Auto-Post on Completion')}</SelectItem>
                                    </SelectContent>
                                </Select>
                            </div>
                        </div>

                        <div className="grid grid-cols-2 gap-8">
                            <div className="space-y-2">
                                <label className="text-sm font-medium">{t('admin.definitions.fields.priority', 'Priority')}</label>
                                <Input
                                    type="number"
                                    className="w-full"
                                    value={form.priority}
                                    min={1}
                                    max={9999}
                                    onChange={e => f('priority', Number(e.target.value))}
                                />
                                <p className="text-xs text-muted-foreground italic">{t('admin.definitions.fields.priorityHint', 'Higher number = higher priority when matching.')}</p>
                            </div>
                        </div>
                    </div>
                </div>

                {/* Card 4: Permissions */}
                <div className="bg-card border rounded-2xl p-6 shadow-sm">
                    <div className="flex items-center gap-3 mb-6">
                        <div className="w-8 h-8 rounded-full bg-primary/10 text-primary flex items-center justify-center">
                            <Shield className="w-4 h-4" />
                        </div>
                        <div>
                            <h3 className="font-semibold text-sm">{t('admin.definitions.sections.permissionsTitle', 'Permissions')}</h3>
                            <p className="text-xs text-muted-foreground">{t('admin.definitions.sections.permissionsDesc', 'Define who is authorized to start this workflow')}</p>
                        </div>
                    </div>
                    <div className="space-y-2">
                        <label className="text-sm font-medium">{t('admin.definitions.fields.responsiblePerson', 'Responsible Person')}</label>
                        {onSearchPrincipals ? (
                            <div className="flex gap-2">
                                <Select
                                    value={form.responsibleType}
                                    onValueChange={v => { f('responsibleType', v); f('responsibleId', ''); f('responsibleName', ''); }}
                                >
                                    <SelectTrigger className="w-36 shrink-0">
                                        <SelectValue />
                                    </SelectTrigger>
                                    <SelectContent>
                                        {resolvedTypes.map(pt => (
                                            <SelectItem key={pt.code} value={pt.code}>{pt.label}</SelectItem>
                                        ))}
                                    </SelectContent>
                                </Select>
                                <div className="flex-1">
                                    <PrincipalPicker
                                        value={form.responsibleId}
                                        displayName={form.responsibleName}
                                        principalType={form.responsibleType}
                                        onSearch={onSearchPrincipals}
                                        onResolve={onResolvePrincipal}
                                        onSelect={(id, name) => { f('responsibleId', id); if (name) f('responsibleName', name); }}
                                    />
                                </div>
                            </div>
                        ) : (
                            <Input
                                className="w-full"
                                placeholder={t('admin.definitions.fields.responsibleIdPlaceholder', 'UUID of responsible user/group')}
                                value={form.responsibleId}
                                onChange={e => f('responsibleId', e.target.value)}
                            />
                        )}
                        <p className="text-xs text-muted-foreground italic">
                            {t('admin.definitions.fields.responsibleHint', 'Only this person (or group member) can submit workflows and post documents.')}
                        </p>
                    </div>

                    {/* 4-Eyes Principle Toggle */}
                    <div className="border-t pt-5 mt-5">
                        <div className="flex items-center justify-between">
                            <div className="space-y-1">
                                <label className="text-sm font-medium">{t('admin.definitions.fields.enforceFourEyes', '4-Eyes Principle')}</label>
                                <p className="text-xs text-muted-foreground">
                                    {t('admin.definitions.fields.enforceFourEyesDesc', 'When enabled, the person who submits cannot approve their own submission.')}
                                </p>
                            </div>
                            <Switch
                                checked={form.enforceFourEyes}
                                onCheckedChange={v => f('enforceFourEyes', v)}
                            />
                        </div>
                    </div>
                </div>

            </div>
        </main>
    );
}
