import { useState, useRef } from 'react';
import { useTranslation } from 'react-i18next';
import type { WorkflowAdminService } from '../../../services/WorkflowAdminService';
import type { WorkflowDefinition } from '../../../types';

export interface DefinitionFormState {
    objectType: string;
    orgKeyValue: string;
    triggerAction: string;
    workflowType: string;
    description: string;
    rejectionMode: string;
    completionPolicy: string;
    responsibleType: string;
    responsibleId: string;
    responsibleName?: string;
    priority: number;
    isActive: boolean;
    enforceFourEyes: boolean;
    notificationSettings?: string | null;
}

export const EMPTY_FORM: DefinitionFormState = {
    objectType: '',
    orgKeyValue: '',
    triggerAction: 'submitForApproval',
    workflowType: '',
    description: '',
    rejectionMode: 'BACK_TO_RESPONSIBLE',
    completionPolicy: 'RESPONSIBLE_ONLY',
    responsibleType: 'USER',
    responsibleId: '',
    responsibleName: '',
    priority: 10,
    isActive: true,
    enforceFourEyes: true,
    notificationSettings: undefined,
};

export function defToForm(def: WorkflowDefinition): DefinitionFormState {
    return {
        objectType: def.objectType,
        orgKeyValue: def.orgKeyValue || '',
        triggerAction: def.triggerAction || 'submitForApproval',
        workflowType: def.workflowType,
        description: def.description || '',
        rejectionMode: def.rejectionMode,
        completionPolicy: def.completionPolicy,
        responsibleType: def.responsibleType || 'USER',
        responsibleId: def.responsibleId || '',
        responsibleName: def.responsibleName || '',
        priority: def.priority,
        isActive: def.isActive,
        enforceFourEyes: def.enforceFourEyes ?? true,
        notificationSettings: def.notificationSettings,
    };
}

export function useDefinitionForm(
    service: WorkflowAdminService,
    editDef: WorkflowDefinition | null,
    onClose: () => void,
    confirmFn: (options: any) => Promise<boolean>,
    onError?: (message: string) => void,
    onSuccess?: (message: string) => void
) {
    const { t } = useTranslation('workflow');
    const isEdit = editDef !== null;

    const [form, setForm] = useState<DefinitionFormState>(
        editDef ? defToForm(editDef) : EMPTY_FORM
    );
    const [saving, setSaving] = useState(false);
    const [activeTab, setActiveTab] = useState<'general' | 'workflow' | 'logic' | 'notifications'>('general');
    const [createdId, setCreatedId] = useState<string | null>(editDef?.ID ?? null);

    const stepEditorRef = useRef<{ save: () => Promise<void>; isDirty: boolean }>(null);

    const f = <K extends keyof DefinitionFormState>(key: K, value: DefinitionFormState[K]) =>
        setForm(prev => ({ ...prev, [key]: value }));

    const handleSave = async () => {
        if (!form.objectType || !form.workflowType) {
            onError?.(t('admin.definitions.requiredFields', 'Object Type and Workflow Type are required'));
            return;
        }
        try {
            setSaving(true);
            const payload = {
                objectType: form.objectType,
                orgKeyValue: form.orgKeyValue || null,
                triggerAction: form.triggerAction || 'submitForApproval',
                workflowType: form.workflowType,
                description: form.description || null,
                rejectionMode: form.rejectionMode,
                completionPolicy: form.completionPolicy,
                responsibleType: form.responsibleType || null,
                responsibleId: form.responsibleId || null,
                priority: form.priority,
                isActive: form.isActive,
                enforceFourEyes: form.enforceFourEyes,
                notificationSettings: form.notificationSettings || null,
            };

            if (createdId) {
                await service.updateDefinition(createdId, payload as any);
                if (stepEditorRef.current?.isDirty) {
                    await stepEditorRef.current.save();
                }
                onSuccess?.(t('admin.definitions.saveSuccess', 'Definition saved'));
            } else {
                const created = await service.createDefinition({
                    ...payload,
                    definitionVersion: 1,
                    isActive: true,
                } as any);
                setCreatedId(created.ID);
                onSuccess?.(t('admin.definitions.createSuccess', 'Definition created — you can now add steps in the Workflow tab'));
                setActiveTab('workflow');
            }
        } catch (err: any) {
            onError?.(err.message || t('admin.definitions.saveFailed', 'Failed to save'));
        } finally {
            setSaving(false);
        }
    };

    const handleDelete = async (id: string) => {
        const ok = await confirmFn({
            title: t('admin.definitions.deleteDefinitionTitle', 'Delete Definition'),
            description: t('admin.definitions.confirmDelete', 'Are you sure you want to delete this workflow definition?'),
            destructive: true,
        });
        if (!ok) return;
        try {
            await service.deleteDefinition(id);
            onSuccess?.(t('admin.definitions.deleteSuccess', 'Definition deleted'));
            onClose();
        } catch (err: any) {
            onError?.(err.message || t('admin.definitions.deleteFailed', 'Failed to delete'));
        }
    };

    return {
        form,
        f,
        isEdit,
        saving,
        activeTab,
        setActiveTab,
        createdId,
        stepEditorRef,
        handleSave,
        handleDelete,
    };
}
