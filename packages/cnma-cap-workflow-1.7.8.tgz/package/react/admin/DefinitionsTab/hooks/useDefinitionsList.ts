import { useState, useCallback, useMemo, useEffect } from 'react';
import { WorkflowAdminService } from '../../../services/WorkflowAdminService';
import type { WorkflowDefinition, WorkflowObjectType, WorkflowHttpClient } from '../../../types';
import { useTranslation } from 'react-i18next';

export function useDefinitionsList(
    httpClient: WorkflowHttpClient,
    baseUrl: string,
    confirmFn: (options: any) => Promise<boolean>,
    onError?: (message: string) => void,
    onSuccess?: (message: string) => void
) {
    const { t } = useTranslation('workflow');
    const [definitions, setDefinitions] = useState<WorkflowDefinition[]>([]);
    const [objectTypes, setObjectTypes] = useState<WorkflowObjectType[]>([]);
    const [loading, setLoading] = useState(true);
    const [togglingIds, setTogglingIds] = useState<Set<string>>(new Set());

    const service = useMemo(
        () => new WorkflowAdminService(httpClient, baseUrl),
        [httpClient, baseUrl]
    );

    const loadDefinitions = useCallback(async () => {
        try {
            setLoading(true);
            const [defs, types] = await Promise.all([
                service.getDefinitions(),
                service.getObjectTypes(),
            ]);
            setDefinitions(defs);
            setObjectTypes(types);
        } catch (err: any) {
            onError?.(err.message || t('admin.definitions.loadFailed', 'Failed to load definitions'));
        } finally {
            setLoading(false);
        }
    }, [service, onError, t]);

    useEffect(() => {
        loadDefinitions();
    }, [loadDefinitions]);

    const handleDelete = async (id: string) => {
        const ok = await confirmFn({
            title: t('admin.definitions.deleteDefinitionTitle', 'Delete Definition'),
            description: t('admin.definitions.confirmDelete', 'Are you sure you want to delete this workflow definition?'),
            destructive: true,
        });
        if (!ok) return;
        try {
            await service.deleteDefinition(id);
            onSuccess?.(t('admin.definitions.deleteSuccess', 'Definition deleted'));
            loadDefinitions();
        } catch (err: any) {
            onError?.(err.message || t('admin.definitions.deleteFailed', 'Failed to delete'));
        }
    };

    const handleToggleActive = async (def: WorkflowDefinition) => {
        try {
            setTogglingIds(prev => new Set(prev).add(def.ID));
            await service.updateDefinition(def.ID, { isActive: !def.isActive });
            setDefinitions(prev => prev.map(d => d.ID === def.ID ? { ...d, isActive: !def.isActive } : d));
            onSuccess?.(
                t('admin.definitions.toggleSuccess', 'Definition {{action}}', {
                    action: def.isActive ? t('common.status.deactivated', 'deactivated') : t('common.status.activated', 'activated'),
                })
            );
        } catch (err: any) {
            onError?.(err.message || t('admin.definitions.toggleFailed', 'Failed to toggle'));
        } finally {
            setTogglingIds(prev => {
                const next = new Set(prev);
                next.delete(def.ID);
                return next;
            });
        }
    };

    return {
        service,
        definitions,
        objectTypes,
        loading,
        togglingIds,
        loadDefinitions,
        handleDelete,
        handleToggleActive,
    };
}
