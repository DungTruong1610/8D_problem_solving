import React, { useState } from 'react';
import { Plus, Loader2 } from 'lucide-react';
import { Button, useConfirm } from '@cnma/react-ui';
import { useTranslation } from 'react-i18next';

import { useDefinitionsList } from './hooks/useDefinitionsList';
import { DefinitionFormPanel } from './components/DefinitionFormPanel';
import { DefinitionListItem } from './components/DefinitionListItem';
import type { WorkflowHttpClient, WorkflowDefinition, PrincipalTypeOption, PrincipalSearchResult } from '../../types';

interface DefinitionsTabProps {
    httpClient: WorkflowHttpClient;
    baseUrl: string;
    principalTypes?: PrincipalTypeOption[];
    onSearchPrincipals?: (principalType: string, query: string) => Promise<PrincipalSearchResult[]>;
    onResolvePrincipal?: (principalType: string, id: string) => Promise<PrincipalSearchResult | null>;
    onResolveFieldList?: (objectType: string) => Promise<Array<{ name: string; label?: string }>>;
    onError?: (message: string) => void;
    onSuccess?: (message: string) => void;
    onEditingChange?: (isEditing: boolean) => void;
}

export function DefinitionsTab({
    httpClient,
    baseUrl,
    principalTypes,
    onSearchPrincipals,
    onResolvePrincipal,
    onResolveFieldList,
    onError,
    onSuccess,
    onEditingChange,
}: DefinitionsTabProps) {
    const { t } = useTranslation('workflow');
    const { confirm, ConfirmDialog } = useConfirm();

    const {
        service,
        definitions,
        objectTypes,
        loading,
        togglingIds,
        loadDefinitions,
        handleDelete,
        handleToggleActive,
    } = useDefinitionsList(httpClient, baseUrl, confirm, onError, onSuccess);

    // Panel state
    const [panelDef, setPanelDef] = useState<WorkflowDefinition | null>(null);
    const [panelOpen, setPanelOpen] = useState(false);
    const [fieldList, setFieldList] = useState<Array<{ name: string; label?: string }>>([]);

    const handleOpenCreate = () => {
        setPanelDef(null);
        setFieldList([]);
        setPanelOpen(true);
        onEditingChange?.(true);
    };

    const handleOpenEdit = async (def: WorkflowDefinition) => {
        setPanelDef(def);
        setPanelOpen(true);
        onEditingChange?.(true);
        if (onResolveFieldList && def.objectType) {
            try {
                const fields = await onResolveFieldList(def.objectType);
                setFieldList(fields);
            } catch { /* optional */ }
        }
    };

    const handleClosePanel = () => {
        setPanelOpen(false);
        setPanelDef(null);
        setFieldList([]);
        loadDefinitions();
        onEditingChange?.(false);
    };

    if (panelOpen) {
        return (
            <DefinitionFormPanel
                service={service}
                objectTypes={objectTypes}
                editDef={panelDef}
                fieldList={fieldList}
                principalTypes={principalTypes}
                onSearchPrincipals={onSearchPrincipals}
                onResolvePrincipal={onResolvePrincipal}
                httpClient={httpClient}
                baseUrl={baseUrl}
                onClose={handleClosePanel}
                onError={onError}
                onSuccess={onSuccess}
            />
        );
    }

    if (loading) {
        return (
            <div className="flex items-center justify-center py-8">
                <Loader2 className="h-5 w-5 animate-spin text-muted-foreground" />
            </div>
        );
    }

    return (
        <div className="bg-background min-h-full p-8 rounded-tr-3xl">
            <div className="max-w-6xl mx-auto">
                <div className="bg-section rounded-3xl border border-border shadow-sm overflow-hidden">
                    <div className="p-4 border-b border-border flex items-center justify-between bg-muted/10">
                        <h3 className="font-bold text-foreground text-lg">
                            {t('admin.definitions.definitionCount', '{{count}} registered definitions', { count: definitions.length })}
                        </h3>
                        <Button onClick={handleOpenCreate} className="flex items-center gap-2 px-6 h-12 text-sm font-bold rounded-xl shadow-md transition-all active:scale-95">
                            <Plus className="w-4 h-4" />
                            {t('admin.definitions.newDefinition', 'New Definition')}
                        </Button>
                    </div>

                    {definitions.length === 0 ? (
                        <div className="text-center py-12 text-muted-foreground text-sm">
                            {t('admin.definitions.noDefinitions', 'No workflow definitions yet. Click "New Definition" to get started.')}
                        </div>
                    ) : (
                        <div className="divide-y divide-border">
                            {definitions.map(def => (
                                <DefinitionListItem
                                    key={def.ID}
                                    def={def}
                                    objectTypes={objectTypes}
                                    isToggling={togglingIds.has(def.ID)}
                                    handleToggleActive={handleToggleActive}
                                    handleOpenEdit={handleOpenEdit}
                                    handleDelete={handleDelete}
                                    t={t}
                                />
                            ))}
                        </div>
                    )}
                </div>
            </div>
            {ConfirmDialog}
        </div>
    );
}
