/** Get friendly label from a camelCase field path, e.g. "header.companyCode" → "Company Code" */
export function friendlyLabel(field: string): string {
    const last = field.split('.').pop() || field;
    return last.replace(/([A-Z])/g, ' $1').replace(/^./, s => s.toUpperCase()).trim();
}
