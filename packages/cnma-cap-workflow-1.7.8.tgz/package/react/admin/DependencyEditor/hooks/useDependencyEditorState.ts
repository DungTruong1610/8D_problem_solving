import { useState } from 'react';
import type { WorkflowStepDefinition, StepDependency } from '../../../types';

export function useDependencyEditorState(
    steps: WorkflowStepDefinition[],
    dependencies: StepDependency[],
    definitionId: string,
    onAdd: (predecessorId: string, successorId: string) => Promise<void>,
    onDelete: (dependencyId: string) => Promise<void>,
    t: any
) {
    const [predecessorId, setPredecessorId] = useState('');
    const [successorId, setSuccessorId] = useState('');
    const [adding, setAdding] = useState(false);
    const [error, setError] = useState<string | null>(null);

    const stepMap = new Map(steps.map(s => [s.ID, s]));

    const handleAdd = async () => {
        if (!predecessorId || !successorId) return;
        if (predecessorId === successorId) {
            setError(t('admin.dependency.errorSelfDep', 'A step cannot depend on itself'));
            return;
        }
        const exists = dependencies.some(
            d => d.predecessor_ID === predecessorId && d.successor_ID === successorId
        );
        if (exists) {
            setError(t('admin.dependency.errorDuplicate', 'This dependency already exists'));
            return;
        }
        
        const cycleError = detectCycle(steps, [
            ...dependencies,
            { ID: 'temp', definition_ID: definitionId, predecessor_ID: predecessorId, successor_ID: successorId },
        ], t);
        
        if (cycleError) {
            setError(cycleError);
            return;
        }

        setError(null);
        setAdding(true);
        try {
            await onAdd(predecessorId, successorId);
            setPredecessorId('');
            setSuccessorId('');
        } catch (err: any) {
            setError(err.message || t('admin.dependency.addFailed', 'Failed to add dependency'));
        } finally {
            setAdding(false);
        }
    };

    const handleDelete = async (depId: string) => {
        try {
            await onDelete(depId);
        } catch (err: any) {
            setError(err.message || t('admin.dependency.removeFailed', 'Failed to remove dependency'));
        }
    };

    return {
        predecessorId,
        setPredecessorId,
        successorId,
        setSuccessorId,
        adding,
        error,
        setError,
        stepMap,
        handleAdd,
        handleDelete,
    };
}

export function detectCycle(
    steps: WorkflowStepDefinition[],
    deps: StepDependency[],
    t: any
): string | null {
    const inDegree = new Map<string, number>();
    const adj = new Map<string, string[]>();

    for (const s of steps) {
        inDegree.set(s.ID, 0);
        adj.set(s.ID, []);
    }

    for (const d of deps) {
        adj.get(d.predecessor_ID)?.push(d.successor_ID);
        inDegree.set(d.successor_ID, (inDegree.get(d.successor_ID) || 0) + 1);
    }

    const queue: string[] = [];
    for (const [id, deg] of inDegree) {
        if (deg === 0) queue.push(id);
    }

    let processed = 0;
    while (queue.length > 0) {
        const node = queue.shift()!;
        processed++;
        for (const succ of adj.get(node) || []) {
            const newDeg = (inDegree.get(succ) || 0) - 1;
            inDegree.set(succ, newDeg);
            if (newDeg === 0) queue.push(succ);
        }
    }

    if (processed < steps.length) {
        return t('admin.dependency.errorCycle', 'Cycle detected! This dependency would create a circular loop.');
    }
    return null;
}

export function computeLanes(
    steps: WorkflowStepDefinition[],
    deps: StepDependency[],
): WorkflowStepDefinition[][] {
    if (deps.length === 0) {
        return [...steps].sort((a, b) => a.displayOrder - b.displayOrder).map(s => [s]);
    }

    const adj = new Map<string, string[]>();
    const inDegree = new Map<string, number>();

    for (const s of steps) {
        adj.set(s.ID, []);
        inDegree.set(s.ID, 0);
    }

    for (const d of deps) {
        adj.get(d.predecessor_ID)?.push(d.successor_ID);
        inDegree.set(d.successor_ID, (inDegree.get(d.successor_ID) || 0) + 1);
    }

    const level = new Map<string, number>();
    const queue: string[] = [];

    for (const [id, deg] of inDegree) {
        if (deg === 0) {
            queue.push(id);
            level.set(id, 0);
        }
    }

    while (queue.length > 0) {
        const node = queue.shift()!;
        const nodeLevel = level.get(node) || 0;
        for (const succ of adj.get(node) || []) {
            level.set(succ, Math.max(level.get(succ) || 0, nodeLevel + 1));
            const newDeg = (inDegree.get(succ) || 0) - 1;
            inDegree.set(succ, newDeg);
            if (newDeg === 0) queue.push(succ);
        }
    }

    const maxLevel = Math.max(...Array.from(level.values()), 0);
    const lanes: WorkflowStepDefinition[][] = [];
    for (let l = 0; l <= maxLevel; l++) {
        const lane = steps
            .filter(s => (level.get(s.ID) || 0) === l)
            .sort((a, b) => a.displayOrder - b.displayOrder);
        if (lane.length > 0) lanes.push(lane);
    }

    const deppedIds = new Set([
        ...deps.map(d => d.predecessor_ID),
        ...deps.map(d => d.successor_ID),
    ]);
    const orphans = steps.filter(s => !deppedIds.has(s.ID) && (level.get(s.ID) ?? 0) === 0);
    if (orphans.length > 0) {
        const lane0 = lanes[0] || [];
        const merged = [...lane0, ...orphans].sort((a, b) => a.displayOrder - b.displayOrder);
        lanes[0] = merged;
    }

    return lanes;
}
