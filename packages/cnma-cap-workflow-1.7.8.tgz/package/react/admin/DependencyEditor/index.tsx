import React from 'react';
import { Plus, Trash2, AlertTriangle, GitBranch } from 'lucide-react';
import { Button, Badge, cn, Select, SelectTrigger, SelectValue, SelectContent, SelectItem } from '@cnma/react-ui';
import { useTranslation } from 'react-i18next';
import type { WorkflowStepDefinition, StepDependency } from '../../types';
import { useDependencyEditorState, computeLanes } from './hooks/useDependencyEditorState';

interface DependencyEditorProps {
    steps: WorkflowStepDefinition[];
    dependencies: StepDependency[];
    definitionId: string;
    onAdd: (predecessorId: string, successorId: string) => Promise<void>;
    onDelete: (dependencyId: string) => Promise<void>;
    className?: string;
}

export function DependencyEditor({
    steps, dependencies, definitionId, onAdd, onDelete, className,
}: DependencyEditorProps) {
    const { t } = useTranslation('workflow');
    const {
        predecessorId,
        setPredecessorId,
        successorId,
        setSuccessorId,
        adding,
        error,
        setError,
        stepMap,
        handleAdd,
        handleDelete,
    } = useDependencyEditorState(steps, dependencies, definitionId, onAdd, onDelete, t);

    if (steps.length < 2) {
        return (
            <div className={cn("text-xs text-muted-foreground italic py-2", className)}>
                {t('admin.dependency.minSteps', 'Add at least 2 steps to configure dependencies.')}
            </div>
        );
    }

    return (
        <div className={cn("space-y-3", className)}>
            <div className="flex items-center gap-2 text-sm font-medium text-muted-foreground">
                <GitBranch className="h-3.5 w-3.5" />
                {t('admin.dependency.title', 'Step Dependencies (DAG)')}
            </div>

            {/* Existing dependencies */}
            {dependencies.length > 0 ? (
                <div className="space-y-1">
                    {dependencies.map(dep => {
                        const pred = stepMap.get(dep.predecessor_ID);
                        const succ = stepMap.get(dep.successor_ID);
                        return (
                            <div key={dep.ID} className="flex items-center gap-2 bg-background rounded-md px-2 py-1.5 text-xs border border-border">
                                <Badge variant="secondary" className="text-xs font-normal">
                                    #{pred?.displayOrder}
                                </Badge>
                                <span className="font-medium truncate text-foreground">{pred?.stepName || '?'}</span>
                                <span className="text-muted-foreground">→</span>
                                <Badge variant="secondary" className="text-xs font-normal">
                                    #{succ?.displayOrder}
                                </Badge>
                                <span className="font-medium truncate text-foreground">{succ?.stepName || '?'}</span>
                                <div className="flex-1" />
                                <Button
                                    variant="ghost" size="icon" className="h-5 w-5 text-muted-foreground hover:text-destructive hover:bg-destructive/10"
                                    onClick={() => handleDelete(dep.ID)}
                                >
                                    <Trash2 className="h-3 w-3" />
                                </Button>
                            </div>
                        );
                    })}
                </div>
            ) : (
                <div className="text-xs text-muted-foreground italic">
                    {t('admin.dependency.noDependencies', 'No dependencies — steps will execute sequentially by display order.')}
                </div>
            )}

            {/* Add new dependency */}
            <div className="flex items-end gap-2">
                <div className="flex-1">
                    <label className="text-xs text-muted-foreground mb-1 block">{t('admin.dependency.afterStep', 'After step')}</label>
                    <Select
                        value={predecessorId}
                        onValueChange={(v) => { setPredecessorId(v); setError(null); }}
                    >
                        <SelectTrigger className="w-full">
                            <SelectValue placeholder={t('admin.dependency.selectPredecessor', 'Select predecessor…')} />
                        </SelectTrigger>
                        <SelectContent>
                            {steps.map(s => (
                                <SelectItem key={s.ID} value={s.ID}>
                                    #{s.displayOrder} {s.stepName}
                                </SelectItem>
                            ))}
                        </SelectContent>
                    </Select>
                </div>
                <span className="text-xs text-muted-foreground pb-1.5">→</span>
                <div className="flex-1">
                    <label className="text-xs text-muted-foreground mb-1 block">{t('admin.dependency.activateStep', 'Activate step')}</label>
                    <Select
                        value={successorId}
                        onValueChange={(v) => { setSuccessorId(v); setError(null); }}
                    >
                        <SelectTrigger className="w-full">
                            <SelectValue placeholder={t('admin.dependency.selectSuccessor', 'Select successor…')} />
                        </SelectTrigger>
                        <SelectContent>
                            {steps.filter(s => s.ID !== predecessorId).map(s => (
                                <SelectItem key={s.ID} value={s.ID}>
                                    #{s.displayOrder} {s.stepName}
                                </SelectItem>
                            ))}
                        </SelectContent>
                    </Select>
                </div>
                <Button
                    variant="default" size="sm"
                    onClick={handleAdd}
                    disabled={!predecessorId || !successorId || adding}
                    className="text-xs"
                >
                    <Plus className="h-3 w-3 mr-1" />
                    {t('common.actions.add', 'Add')}
                </Button>
            </div>

            {/* Error banner */}
            {error && (
                <div className="flex items-center gap-2 text-xs text-destructive bg-destructive/10 border border-destructive/30 rounded-md px-3 py-2">
                    <AlertTriangle className="h-3.5 w-3.5 shrink-0" />
                    {error}
                </div>
            )}

            {/* DAG Preview */}
            {dependencies.length > 0 && (
                <DAGMiniPreview steps={steps} dependencies={dependencies} />
            )}
        </div>
    );
}

function DAGMiniPreview({
    steps, dependencies,
}: {
    steps: WorkflowStepDefinition[];
    dependencies: StepDependency[];
}) {
    const { t } = useTranslation('workflow');
    const lanes = computeLanes(steps, dependencies);

    return (
        <div className="border border-border rounded-md p-3 bg-muted/30">
            <div className="text-xs text-muted-foreground font-medium mb-2">{t('admin.dependency.dagPreview', 'DAG Preview')}</div>
            <div className="space-y-2">
                {lanes.map((lane, laneIdx) => (
                    <React.Fragment key={laneIdx}>
                        <div className="flex items-center gap-2 justify-center flex-wrap">
                            {lane.map(step => (
                                <div
                                    key={step.ID}
                                    className="text-xs px-2 py-1 rounded border border-border bg-background font-medium text-foreground"
                                >
                                    #{step.displayOrder} {step.stepName}
                                </div>
                            ))}
                        </div>
                        {laneIdx < lanes.length - 1 && (
                            <div className="flex justify-center">
                                <span className="text-muted-foreground text-xs">↓</span>
                            </div>
                        )}
                    </React.Fragment>
                ))}
            </div>
        </div>
    );
}
