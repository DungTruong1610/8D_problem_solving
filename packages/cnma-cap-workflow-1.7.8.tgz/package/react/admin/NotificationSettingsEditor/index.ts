/**
 * NotificationSettingsEditor — Feature folder barrel export
 */

export { NotificationSettingsEditor } from './NotificationSettingsEditor';
export type { NotificationSettingsEditorProps } from './NotificationSettingsEditor';
export { useNotificationSettings } from './hooks/useNotificationSettings';
export type { UseNotificationSettingsProps, UseNotificationSettingsReturn } from './hooks/useNotificationSettings';

// Re-export types for convenience
export {
    DEFAULT_TEMPLATES,
    T_KEYS,
    parseSettings,
    serializeSettings,
    previewReplace,
    NOTIFICATION_EVENT_TYPES,
    NOTIFICATION_EVENT_META,
    TEMPLATE_PLACEHOLDERS,
    INFO_FIELD_OPTIONS,
} from './types/notificationSettings.types';
