/**
 * NotificationSettingsEditor — Main orchestrator
 *
 * 2-column layout:
 * - LEFT: Event list with toggle switches and selection
 * - RIGHT: Inline template editor for the selected event with live preview
 */

import { Card } from '@cnma/react-ui';
import { Button } from '@cnma/react-ui';
import { cn } from '@cnma/react-ui';
import { RotateCcw, Send, Loader2 } from 'lucide-react';
import { useTranslation } from 'react-i18next';

import { useNotificationSettings } from './hooks/useNotificationSettings';
import {
    EventListPanel,
    TemplateEditorPanel,
    TemplatePreview,
    PlaceholderBar,
    TestEmailDialog,
    BusinessFieldsPanel,
} from './components';

export interface NotificationSettingsEditorProps {
    /** Current notification settings JSON string (from WorkflowDefinition) */
    value?: string | null;
    /** Callback when settings change — returns JSON string or null/undefined (for null/defaults) */
    onChange: (value: string | null | undefined) => void;
    /** Send a test email — if provided, the "Send Test" button appears */
    onSendTestEmail?: (eventType: string, recipientEmail: string, notificationSettings?: string | null) => Promise<void>;
    /** Available schema fields for the current object type */
    schemaFields?: Array<{ name: string; label?: string }>;
    /** Optional class name */
    className?: string;
}

export function NotificationSettingsEditor({
    value,
    onChange,
    onSendTestEmail,
    schemaFields,
    className,
}: NotificationSettingsEditorProps) {
    const {
        // State
        settings,
        selectedEvent,
        testSending,
        testEmailDialogOpen,
        testEmailInput,
        activeRef,

        // Computed
        currentTemplate,
        isCustom,
        enabled,
        selectedMeta,

        // Actions
        setSelectedEvent,
        isEnabled,
        hasCustomTemplate,
        toggleEvent,
        updateTemplate,
        updateBusinessFields,
        resetTemplate,
        insertPlaceholder,
        openTestEmailDialog,
        closeTestEmailDialog,
        setTestEmailInput,
        handleSendTest,
    } = useNotificationSettings({ value, onChange, onSendTestEmail });

    return (
        <Card className={cn('overflow-hidden', className)}>
            <div className="grid grid-cols-[320px_1fr] min-h-[520px]">
                {/* LEFT: Event List & Business Fields */}
                <div className="flex flex-col border-r border-border">
                    <BusinessFieldsPanel
                        fields={settings.businessFields}
                        schemaFields={schemaFields}
                        onChange={updateBusinessFields}
                    />
                    <EventListPanel
                        selectedEvent={selectedEvent}
                        isEnabled={isEnabled}
                        hasCustomTemplate={hasCustomTemplate}
                        onSelectEvent={setSelectedEvent}
                        onToggleEvent={toggleEvent}
                    />
                </div>

                {/* RIGHT: Template Editor */}
                <div className="flex flex-col overflow-hidden">
                    {/* Editor Header */}
                    <EditorHeader
                        meta={selectedMeta}
                        isCustom={isCustom}
                        enabled={enabled}
                        testSending={testSending}
                        hasSendTestEmail={!!onSendTestEmail}
                        onReset={resetTemplate}
                        onOpenTestEmail={openTestEmailDialog}
                    />

                    {enabled ? (
                        <>
                            {/* Placeholder Bar */}
                            <PlaceholderBar onInsertPlaceholder={insertPlaceholder} />

                            {/* Form + Preview Grid */}
                            <div className="grid grid-cols-2 flex-1 min-h-0 overflow-hidden">
                                <TemplateEditorPanel
                                    template={currentTemplate}
                                    activeRef={activeRef}
                                    onUpdateTemplate={updateTemplate}
                                    businessFields={settings.businessFields}
                                />
                                <TemplatePreview
                                    template={currentTemplate}
                                    isCustom={isCustom}
                                    businessFields={settings.businessFields}
                                />
                            </div>
                        </>
                    ) : (
                        <DisabledState />
                    )}
                </div>
            </div>

            {/* Test Email Dialog */}
            <TestEmailDialog
                open={testEmailDialogOpen}
                email={testEmailInput}
                sending={testSending}
                onEmailChange={setTestEmailInput}
                onSend={handleSendTest}
                onCancel={closeTestEmailDialog}
            />
        </Card>
    );
}

// ─── Sub-components ──────────────────────────────────────────────────────────

function EditorHeader({
    meta,
    isCustom,
    enabled,
    testSending,
    hasSendTestEmail,
    onReset,
    onOpenTestEmail,
}: {
    meta: { icon: string; label: string; description: string };
    isCustom: boolean;
    enabled: boolean;
    testSending: boolean;
    hasSendTestEmail: boolean;
    onReset: () => void;
    onOpenTestEmail: () => void;
}) {
    const { t } = useTranslation('workflow');
    return (
        <div className="flex items-center justify-between p-3 border-b border-border bg-card">
            <div>
                <h3 className="text-sm font-semibold flex items-center gap-2">
                    <span>{meta.icon}</span>
                    {meta.label}
                </h3>
                <p className="text-xs text-muted-foreground">{meta.description}</p>
            </div>
            <div className="flex gap-2 items-center">
                {isCustom && (
                    <Button
                        variant="ghost"
                        size="sm"
                        onClick={onReset}
                        className="text-xs text-muted-foreground hover:text-foreground h-7 px-2"
                    >
                        <RotateCcw className="h-3 w-3 mr-1" />
                        {t('admin.notification.resetToDefault', 'Reset to Default')}
                    </Button>
                )}
                {hasSendTestEmail && (
                    <Button
                        variant="outline"
                        size="sm"
                        onClick={onOpenTestEmail}
                        disabled={testSending || !enabled}
                        className="h-7 px-2 text-xs border-success/50 text-success hover:bg-success/10"
                    >
                        {testSending ? <Loader2 className="h-3 w-3 mr-1 animate-spin" /> : <Send className="h-3 w-3 mr-1" />}
                        {testSending ? t('admin.notification.sending', 'Sending...') : t('admin.notification.sendTest', 'Send Test')}
                    </Button>
                )}
            </div>
        </div>
    );
}

function DisabledState() {
    const { t } = useTranslation('workflow');
    return (
        <div className="flex-1 flex flex-col items-center justify-center p-10 text-muted-foreground">
            <div className="text-center">
                <div className="text-4xl mb-2">🔕</div>
                <div className="text-sm font-medium">{t('admin.notification.disabled', 'This notification is disabled')}</div>
                <div className="text-xs mt-1">{t('admin.notification.disabledDescription', 'Toggle it on in the left panel to configure the template')}</div>
            </div>
        </div>
    );
}
