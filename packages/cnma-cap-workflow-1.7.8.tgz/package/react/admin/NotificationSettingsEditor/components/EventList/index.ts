/**
 * EventList group barrel export
 */

export { EventListPanel } from './EventListPanel';
