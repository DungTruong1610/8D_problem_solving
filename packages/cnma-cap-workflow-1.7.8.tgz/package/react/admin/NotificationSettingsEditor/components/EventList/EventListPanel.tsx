/**
 * EventListPanel — Left panel with notification event list and toggles
 */

import React from 'react';
import { CardHeader, CardTitle, CardDescription } from '@cnma/react-ui';
import { Switch } from '@cnma/react-ui';
import { cn } from '@cnma/react-ui';
import { Mail } from 'lucide-react';
import { NOTIFICATION_EVENT_TYPES, NOTIFICATION_EVENT_META } from '../../../../types';
import type { NotificationEventType } from '../../../../types';
import { T_KEYS } from '../../types/notificationSettings.types';
import { useTranslation } from 'react-i18next';

interface EventListPanelProps {
    selectedEvent: NotificationEventType;
    isEnabled: (eventType: NotificationEventType) => boolean;
    hasCustomTemplate: (eventType: NotificationEventType) => boolean;
    onSelectEvent: (event: NotificationEventType) => void;
    onToggleEvent: (eventType: NotificationEventType) => void;
}

export function EventListPanel({
    selectedEvent,
    isEnabled,
    hasCustomTemplate,
    onSelectEvent,
    onToggleEvent,
}: EventListPanelProps) {
    const { t } = useTranslation('workflow');
    return (
        <div className="border-r border-border bg-muted/30 flex flex-col">
            <CardHeader className="p-4 pb-3 border-b border-border">
                <CardTitle className="text-sm flex items-center gap-2">
                    <Mail className="h-4 w-4 text-primary" />
                    {t('admin.notification.title', 'Notification Events')}
                </CardTitle>
                <CardDescription className="text-xs">{t('admin.notification.subtitle', 'Click to configure · toggle to enable/disable')}</CardDescription>
            </CardHeader>

            <div className="flex-1 overflow-auto">
                {NOTIFICATION_EVENT_TYPES.map(eventType => {
                    const meta = NOTIFICATION_EVENT_META[eventType];
                    const evtEnabled = isEnabled(eventType);
                    const hasCustom = hasCustomTemplate(eventType);
                    const isSelected = selectedEvent === eventType;

                    return (
                        <div
                            key={eventType}
                            onClick={() => onSelectEvent(eventType)}
                            className={cn(
                                'flex items-center justify-between p-3 border-b border-border cursor-pointer transition-all',
                                isSelected ? 'bg-card border-l-[3px] border-l-primary' : 'border-l-[3px] border-l-transparent hover:bg-accent/50',
                                !evtEnabled && 'opacity-50'
                            )}
                        >
                            <div className="flex items-center gap-3 flex-1 min-w-0">
                                <span className="text-base w-6 text-center">{meta.icon}</span>
                                <div className="min-w-0 flex-1">
                                    <div className="flex items-center gap-1.5">
                                        <span className={cn(
                                            'text-xs font-medium',
                                            isSelected ? 'text-foreground font-semibold' : 'text-muted-foreground'
                                        )}>
                                            {t(`admin.notification.event.${eventType}.label`, meta.label)}
                                        </span>
                                        {hasCustom && (
                                            <span className="text-xs px-1 py-0.5 rounded bg-success-bg text-success font-medium">
                                                {t('admin.notification.customBadge', 'Custom')}
                                            </span>
                                        )}
                                    </div>
                                    <p className="text-xs text-muted-foreground truncate">{t(`admin.notification.event.${eventType}.description`, meta.description)}</p>
                                </div>
                            </div>

                            <Switch
                                checked={evtEnabled}
                                onCheckedChange={() => onToggleEvent(eventType)}
                                onClick={(e) => e.stopPropagation()}
                                className="shrink-0"
                            />
                        </div>
                    );
                })}
            </div>
        </div>
    );
}
