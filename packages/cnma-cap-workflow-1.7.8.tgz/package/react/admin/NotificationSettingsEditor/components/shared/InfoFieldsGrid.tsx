/**
 * InfoFieldsGrid — Checkbox grid for selecting info table fields
 */

import { Label, Checkbox } from '@cnma/react-ui';
import { INFO_FIELD_OPTIONS } from '../../../../types';
import type { INotificationBusinessField } from '../../../../types';
import { useTranslation } from 'react-i18next';

interface InfoFieldsGridProps {
    selectedFields?: string[];
    businessFields?: INotificationBusinessField[];
    onToggleField: (key: string) => void;
}

export function InfoFieldsGrid({ selectedFields = [], businessFields = [], onToggleField }: InfoFieldsGridProps) {
    const { t } = useTranslation('workflow');
    
    // Combine standard fields and business fields into a single list
    const allFields = [
        ...INFO_FIELD_OPTIONS.map(f => ({ key: f.key, label: t(`admin.notification.infoFields.${f.key}`, f.label) })),
        ...businessFields.map(bf => ({ key: bf.fieldKey, label: bf.label || bf.fieldKey }))
    ].filter(f => f.key); // Ensure valid keys

    return (
        <div className="space-y-1">
            <Label className="text-xs font-medium text-muted-foreground">
                {t('admin.notification.infoFieldsLabel', 'Info Table Fields')}
            </Label>
            <div className="grid grid-cols-2 gap-1">
                {allFields.map(f => (
                    <label
                        key={f.key}
                        className="flex items-center gap-1.5 text-xs text-foreground cursor-pointer hover:bg-accent/50 rounded px-1 py-0.5"
                    >
                        <Checkbox
                            checked={selectedFields.includes(f.key)}
                            onCheckedChange={() => onToggleField(f.key)}
                        />
                        {f.label}
                    </label>
                ))}
            </div>
        </div>
    );
}
