/**
 * TestEmailDialog — Dialog for sending test email
 */

import React from 'react';
import { Input } from '@cnma/react-ui';
import { Label } from '@cnma/react-ui';
import { Button } from '@cnma/react-ui';
import { AlertCircle, Send, Loader2 } from 'lucide-react';
import { useTranslation } from 'react-i18next';
import { T_KEYS } from '../../types/notificationSettings.types';

interface TestEmailDialogProps {
    open: boolean;
    email: string;
    sending: boolean;
    onEmailChange: (email: string) => void;
    onSend: () => void;
    onCancel: () => void;
}

export function TestEmailDialog({
    open,
    email,
    sending,
    onEmailChange,
    onSend,
    onCancel,
}: TestEmailDialogProps) {
    const { t } = useTranslation('workflow');
    if (!open) return null;

    const isValidEmail = email.includes('@') && email.includes('.');

    return (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50">
            <div className="bg-card rounded-lg shadow-xl p-4 w-[360px]">
                <div className="flex items-center gap-2 mb-3">
                    <AlertCircle className="h-4 w-4 text-primary" />
                    <h3 className="text-sm font-semibold">{t('admin.notification.sendTestTitle', 'Send Test Email')}</h3>
                </div>
                <div className="space-y-3">
                    <div className="space-y-1">
                        <Label htmlFor="test-email" className="text-xs font-medium">
                            {t('admin.notification.recipientEmail', 'Recipient Email')}
                        </Label>
                        <Input
                            id="test-email"
                            type="email"
                            value={email}
                            onChange={e => onEmailChange(e.target.value)}
                            placeholder="your@email.com"
                            className="text-xs h-8"
                            autoFocus
                        />
                    </div>
                    <div className="flex gap-2 justify-end">
                        <Button
                            variant="ghost"
                            size="sm"
                            onClick={onCancel}
                            disabled={sending}
                            className="h-8"
                        >
                            {t('common.cancel', 'Cancel')}
                        </Button>
                        <Button
                            variant="default"
                            size="sm"
                            onClick={onSend}
                            disabled={sending || !isValidEmail}
                            className="h-8"
                        >
                            {sending ? <Loader2 className="h-3 w-3 mr-1 animate-spin" /> : <Send className="h-3 w-3 mr-1" />}
                            {sending ? t('admin.notification.sending', 'Sending...') : t('admin.notification.sendTest', 'Send Test')}
                        </Button>
                    </div>
                </div>
            </div>
        </div>
    );
}
