/**
 * PlaceholderBar — Row of placeholder buttons for inserting template variables
 */

import { Button } from '@cnma/react-ui';
import { TEMPLATE_PLACEHOLDERS } from '../../../../types';
import { T_KEYS } from '../../types/notificationSettings.types';
import { useTranslation } from 'react-i18next';

interface PlaceholderBarProps {
    onInsertPlaceholder: (key: string) => void;
}

export function PlaceholderBar({ onInsertPlaceholder }: PlaceholderBarProps) {
    const { t } = useTranslation('workflow');
    return (
        <div className="flex flex-wrap gap-1 items-center p-2 bg-muted/50 border-b border-border">
            <span className="text-xs text-muted-foreground mr-1">{t('admin.notification.placeholders', 'Placeholders:')}</span>
            {TEMPLATE_PLACEHOLDERS.map(p => (
                <Button
                    key={p.key}
                    variant="ghost"
                    size="sm"
                    onClick={() => onInsertPlaceholder(p.key)}
                    title={p.label}
                    className="h-auto px-1.5 py-0.5 text-xs font-mono text-primary hover:text-primary bg-primary/10 hover:bg-primary/20"
                >
                    {'{{' + p.key + '}}'}
                </Button>
            ))}
        </div>
    );
}
