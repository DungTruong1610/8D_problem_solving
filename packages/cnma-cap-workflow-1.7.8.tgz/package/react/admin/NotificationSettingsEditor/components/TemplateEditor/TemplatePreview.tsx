/**
 * TemplatePreview — Live email preview panel
 */

import React, { useMemo } from 'react';
import { Eye } from 'lucide-react';
import type { IStructuredTemplate, INotificationBusinessField } from '../../../../types';
import { previewReplace } from '../../types/notificationSettings.types';
import { useTranslation } from 'react-i18next';

interface TemplatePreviewProps {
    template: IStructuredTemplate;
    isCustom: boolean;
    businessFields?: INotificationBusinessField[];
}

export function TemplatePreview({ template, isCustom, businessFields = [] }: TemplatePreviewProps) {
    const { t } = useTranslation('workflow');
    const previewHtml = useMemo(() => {
        const tmpl = template;
        const greeting = tmpl.greeting
            ? `<p style="margin:0 0 12px;color:#374151;font-size:13px;">${previewReplace(tmpl.greeting)}</p>`
            : '';
        const body = tmpl.bodyText
            ? `<p style="margin:0 0 12px;color:#374151;font-size:13px;">${previewReplace(tmpl.bodyText).replace(/\n/g, '<br>')}</p>`
            : '';

        const infoFieldMap: Record<string, { label: string; sample: string }> = {
            workflow: { label: t('admin.notification.infoFields.workflow', 'Workflow'), sample: 'Invoice Approval' },
            step: { label: t('admin.notification.infoFields.step', 'Step'), sample: 'Cost Center Approval' },
            document: { label: t('admin.notification.infoFields.document', 'Document'), sample: 'DOC-2024-001' },
            objectType: { label: t('admin.notification.infoFields.objectType', 'Object Type'), sample: 'INV' },
            approver: { label: t('admin.notification.infoFields.approver', 'Approved by'), sample: 'Jane Doe' },
            rejector: { label: t('admin.notification.infoFields.rejector', 'Rejected by'), sample: 'Jane Doe' },
            responsible: { label: t('admin.notification.infoFields.responsible', 'Responsible'), sample: 'Alex Johnson' },
            comment: { label: t('admin.notification.infoFields.comment', 'Comment'), sample: 'Looks good, approved.' },
            reassigner: { label: t('admin.notification.infoFields.reassigner', 'Reassigned by'), sample: 'Maria Garcia' },
        };

        // Add custom business fields to the map with dummy sample data
        businessFields.forEach(bf => {
            if (bf.fieldKey) {
                infoFieldMap[bf.fieldKey] = { label: bf.label || bf.fieldKey, sample: t('admin.notification.businessFields.sampleValue', 'Sample Value') };
            }
        });

        let infoTable = '';
        if (tmpl.infoFields?.length) {
            const rows = tmpl.infoFields
                .map(k => infoFieldMap[k])
                .filter(Boolean)
                .map(f => `<tr><td style="padding:5px 10px;color:#6b7280;font-size:12px;white-space:nowrap">${f!.label}</td><td style="padding:5px 10px;font-size:12px;font-weight:500">${f!.sample}</td></tr>`)
                .join('');
            infoTable = `<table cellpadding="0" cellspacing="0" style="width:100%;border:1px solid #e5e7eb;border-radius:6px;margin:12px 0">${rows}</table>`;
        }

        const button = tmpl.buttonLabel
            ? `<table cellpadding="0" cellspacing="0" style="margin:16px 0"><tr><td style="background:${tmpl.buttonColor || '#1a56db'};border-radius:6px;padding:8px 18px"><span style="color:#fff;font-size:12px;font-weight:600">${previewReplace(tmpl.buttonLabel)}</span></td></tr></table>`
            : '';

        return `
            <div style="background:linear-gradient(135deg,#1e3a5f,#2563eb);padding:16px;text-align:center">
                <h2 style="color:#fff;margin:0;font-size:16px">${t('admin.notification.workflowNotification', 'Workflow Notification')}</h2>
            </div>
            <div style="padding:20px">
                ${greeting}${body}${infoTable}${button}
            </div>
            <div style="padding:12px 20px;background:#f9fafb;text-align:center;border-top:1px solid #e5e7eb">
                <p style="margin:0;font-size:10px;color:#9ca3af">${t('admin.notification.doNotReply', 'This is an automated notification. Do not reply.')}</p>
            </div>
        `;
    }, [template, t, businessFields]);

    return (
        <div className="p-4 bg-muted/30 overflow-auto">
            <div className="flex items-center gap-1.5 mb-2">
                <Eye className="h-3 w-3 text-muted-foreground" />
                <span className="text-xs font-medium text-muted-foreground">{t('admin.notification.livePreview', 'Live Preview')}</span>
            </div>
            <div className="border border-border rounded-lg overflow-hidden bg-card">
                <div className="px-3 py-2 bg-muted/50 border-b border-border">
                    <span className="text-xs text-muted-foreground">
                        <span className="font-semibold">{t('admin.notification.previewSubject', 'Subject:')}</span> {previewReplace(template.subject)}
                    </span>
                </div>
                <div
                    dangerouslySetInnerHTML={{ __html: previewHtml }}
                    className="text-xs"
                />
            </div>
            {isCustom && (
                <p className="text-xs text-success text-center mt-2">
                    ✨ {t('admin.notification.customTemplate', 'Using custom template · changes auto-save')}
                </p>
            )}
        </div>
    );
}
