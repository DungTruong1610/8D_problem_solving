/**
 * TemplateEditorPanel — Form fields for editing notification template
 */

import { Input } from '@cnma/react-ui';
import { Textarea } from '@cnma/react-ui';
import { Label } from '@cnma/react-ui';
import type { IStructuredTemplate, INotificationBusinessField } from '../../../../types';
import { InfoFieldsGrid } from '../shared/InfoFieldsGrid';
import { useTranslation } from 'react-i18next';

interface TemplateEditorPanelProps {
    template: IStructuredTemplate;
    activeRef: React.MutableRefObject<HTMLInputElement | HTMLTextAreaElement | null>;
    onUpdateTemplate: <K extends keyof IStructuredTemplate>(key: K, val: IStructuredTemplate[K]) => void;
    businessFields?: INotificationBusinessField[];
}

export function TemplateEditorPanel({
    template,
    activeRef,
    onUpdateTemplate,
    businessFields,
}: TemplateEditorPanelProps) {
    const { t } = useTranslation('workflow');
    return (
        <div className="p-4 border-r border-border overflow-auto space-y-3">
            {/* Subject */}
            <div className="space-y-1">
                <Label htmlFor="notif-subject" className="text-xs font-medium text-muted-foreground">
                    {t('admin.notification.subject', 'Subject')}
                </Label>
                <Input
                    id="notif-subject"
                    value={template.subject}
                    data-field-key="subject"
                    onChange={e => onUpdateTemplate('subject', e.target.value)}
                    onFocus={e => { activeRef.current = e.target; }}
                    className="text-xs h-8"
                />
            </div>

            {/* Greeting */}
            <div className="space-y-1">
                <Label htmlFor="notif-greeting" className="text-xs font-medium text-muted-foreground">
                    {t('admin.notification.greeting', 'Greeting')}
                </Label>
                <Input
                    id="notif-greeting"
                    value={template.greeting}
                    data-field-key="greeting"
                    onChange={e => onUpdateTemplate('greeting', e.target.value)}
                    onFocus={e => { activeRef.current = e.target; }}
                    className="text-xs h-8"
                />
            </div>

            {/* Body Text */}
            <div className="space-y-1">
                <Label htmlFor="notif-body" className="text-xs font-medium text-muted-foreground">
                    {t('admin.notification.bodyText', 'Body Text')}
                </Label>
                <Textarea
                    id="notif-body"
                    value={template.bodyText}
                    data-field-key="bodyText"
                    onChange={e => onUpdateTemplate('bodyText', e.target.value)}
                    onFocus={e => { activeRef.current = e.target; }}
                    rows={3}
                    className="text-xs resize-none"
                />
            </div>

            <InfoFieldsGrid
                selectedFields={template.infoFields}
                businessFields={businessFields}
                onToggleField={(key) => {
                    const fields = template.infoFields || [];
                    const newFields = fields.includes(key)
                        ? fields.filter((f: string) => f !== key)
                        : [...fields, key];
                    onUpdateTemplate('infoFields', newFields);
                }}
            />

            {/* Button */}
            <div className="flex gap-2 items-end">
                <div className="flex-1 space-y-1">
                    <Label htmlFor="notif-btn-label" className="text-xs font-medium text-muted-foreground">
                        {t('admin.notification.buttonLabel', 'Button Label')}
                    </Label>
                    <Input
                        id="notif-btn-label"
                        value={template.buttonLabel || ''}
                        data-field-key="buttonLabel"
                        onChange={e => onUpdateTemplate('buttonLabel', e.target.value)}
                        onFocus={e => { activeRef.current = e.target; }}
                        placeholder={t('admin.notification.buttonPlaceholder', 'Leave empty for no button')}
                        className="text-xs h-8"
                    />
                </div>
                <div className="space-y-1">
                    <Label className="text-xs font-medium text-muted-foreground block">
                        {t('admin.notification.buttonColor', 'Color')}
                    </Label>
                    <input
                        type="color"
                        value={template.buttonColor || '#1a56db'}
                        onChange={e => onUpdateTemplate('buttonColor', e.target.value)}
                        className="w-8 h-8 rounded cursor-pointer border-0 p-0"
                    />
                </div>
            </div>
        </div>
    );
}
