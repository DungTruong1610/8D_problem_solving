import React from 'react';
import { CardHeader, CardTitle, CardDescription, Button, Input, DropdownMenu, DropdownMenuTrigger, DropdownMenuContent, DropdownMenuCheckboxItem } from '@cnma/react-ui';
import { Database, Plus, Trash2, ChevronDown } from 'lucide-react';
import { useTranslation } from 'react-i18next';
import type { INotificationBusinessField } from '../../../types';

interface BusinessFieldsPanelProps {
    fields?: INotificationBusinessField[];
    schemaFields?: Array<{ name: string; label?: string }>;
    onChange: (fields: INotificationBusinessField[]) => void;
}

export function BusinessFieldsPanel({ fields = [], schemaFields, onChange }: BusinessFieldsPanelProps) {
    const { t } = useTranslation('workflow');

    const handleAdd = () => {
        onChange([...fields, { fieldKey: '', label: '' }]);
    };

    const handleAddFromSchema = (name: string, label?: string) => {
        if (fields.some(f => f.fieldKey === name)) return;
        onChange([...fields, { fieldKey: name, label: label || name }]);
    };

    const handleUpdate = (index: number, key: keyof INotificationBusinessField, value: string) => {
        const newFields = [...fields];
        newFields[index] = { ...newFields[index], [key]: value };
        onChange(newFields);
    };

    const handleRemove = (index: number) => {
        const newFields = [...fields];
        newFields.splice(index, 1);
        onChange(newFields);
    };

    return (
        <div className="border-b border-border bg-card flex flex-col max-h-[300px]">
            <CardHeader className="p-4 pb-3 border-b border-border bg-muted/20">
                <div className="flex flex-col gap-3">
                    <div>
                        <CardTitle className="text-sm flex items-center gap-2">
                            <Database className="h-4 w-4 text-primary" />
                            {t('admin.notification.businessFields.title', 'Business Context Fields')}
                        </CardTitle>
                        <CardDescription className="text-xs mt-1">
                            {t('admin.notification.businessFields.description', 'Additional fields to extract from the business object and display in the notification Info Table.')}
                        </CardDescription>
                    </div>
                    <div className="flex flex-wrap items-center gap-2">
                        {schemaFields && schemaFields.length > 0 && (
                            <DropdownMenu>
                                <DropdownMenuTrigger asChild>
                                    <Button variant="outline" size="sm" className="h-7 text-xs px-2">
                                        <Plus className="h-3 w-3 mr-1" />
                                        {t('admin.notification.businessFields.addFromSchema', 'Add from Schema')}
                                        <ChevronDown className="h-3 w-3 ml-1 opacity-50" />
                                    </Button>
                                </DropdownMenuTrigger>
                                <DropdownMenuContent align="start" className="w-[250px] max-h-[300px] overflow-y-auto">
                                    {schemaFields.map(sf => {
                                        const isChecked = fields.some(f => f.fieldKey === sf.name);
                                        return (
                                            <DropdownMenuCheckboxItem 
                                                key={sf.name} 
                                                checked={isChecked}
                                                onCheckedChange={(checked) => {
                                                    if (checked) {
                                                        handleAddFromSchema(sf.name, sf.label);
                                                    } else {
                                                        const idx = fields.findIndex(f => f.fieldKey === sf.name);
                                                        if (idx > -1) handleRemove(idx);
                                                    }
                                                }}
                                                onSelect={(e) => e.preventDefault()}
                                            >
                                                <span>{sf.label || sf.name}</span>
                                                <span className="text-muted-foreground ml-auto text-[10px] pl-4">{sf.name}</span>
                                            </DropdownMenuCheckboxItem>
                                        );
                                    })}
                                    {schemaFields.length === 0 && (
                                        <div className="text-xs text-muted-foreground p-2 text-center">
                                            {t('admin.notification.businessFields.noSchemaFields', 'No schema fields available')}
                                        </div>
                                    )}
                                </DropdownMenuContent>
                            </DropdownMenu>
                        )}
                    </div>
                </div>
            </CardHeader>
            <div className="p-4 overflow-y-auto space-y-3">
                {fields.length === 0 ? (
                    <div className="text-sm text-muted-foreground italic text-center py-4">
                        {t('admin.notification.businessFields.noFields', 'No business fields configured.')}
                    </div>
                ) : (
                    fields.map((field, index) => (
                        <div key={`${field.fieldKey || ''}-${index}`} className="flex items-center gap-2">
                            <Input
                                placeholder={t('admin.notification.businessFields.keyPlaceholder', 'Key (e.g. amount)')}
                                value={field.fieldKey}
                                onChange={(e) => handleUpdate(index, 'fieldKey', e.target.value)}
                                className="h-8 text-sm"
                            />
                            <Input
                                placeholder={t('admin.notification.businessFields.labelPlaceholder', 'Label (e.g. Total Amount)')}
                                value={field.label}
                                onChange={(e) => handleUpdate(index, 'label', e.target.value)}
                                className="h-8 text-sm"
                            />
                            <Button
                                variant="ghost"
                                size="icon"
                                className="h-8 w-8 text-destructive hover:bg-destructive/10 shrink-0"
                                onClick={() => handleRemove(index)}
                                title={t('admin.notification.businessFields.removeField', 'Remove Field')}
                            >
                                <Trash2 className="h-4 w-4" />
                            </Button>
                        </div>
                    ))
                )}
            </div>
        </div>
    );
}
