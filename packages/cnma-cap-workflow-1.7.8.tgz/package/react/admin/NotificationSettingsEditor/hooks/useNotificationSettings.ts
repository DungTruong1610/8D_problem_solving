/**
 * useNotificationSettings — State and business logic for NotificationSettingsEditor
 */

import { useState, useCallback, useMemo, useRef } from 'react';
import type {
    INotificationSettings,
    INotificationEventConfig,
    IStructuredTemplate,
    NotificationEventType,
} from '../../../types';
import { NOTIFICATION_EVENT_META } from '../../../types';
import {
    DEFAULT_TEMPLATES,
    parseSettings,
    serializeSettings,
} from '../types/notificationSettings.types';

export interface UseNotificationSettingsProps {
    value?: string | null;
    onChange: (value: string | null | undefined) => void;
    onSendTestEmail?: (eventType: string, recipientEmail: string, notificationSettings?: string | null) => Promise<void>;
}

export interface UseNotificationSettingsReturn {
    // State
    settings: INotificationSettings;
    selectedEvent: NotificationEventType;
    testSending: boolean;
    testEmailDialogOpen: boolean;
    testEmailInput: string;
    activeRef: React.MutableRefObject<HTMLInputElement | HTMLTextAreaElement | null>;

    // Computed
    currentTemplate: IStructuredTemplate;
    isCustom: boolean;
    enabled: boolean;
    selectedMeta: typeof import('../../../types').NOTIFICATION_EVENT_META[NotificationEventType];

    // Actions
    setSelectedEvent: (event: NotificationEventType) => void;
    isEnabled: (eventType: NotificationEventType) => boolean;
    hasCustomTemplate: (eventType: NotificationEventType) => boolean;
    toggleEvent: (eventType: NotificationEventType) => void;
    updateTemplate: <K extends keyof IStructuredTemplate>(key: K, val: IStructuredTemplate[K]) => void;
    updateBusinessFields: (fields: import('../../../types').INotificationBusinessField[]) => void;
    resetTemplate: () => void;
    insertPlaceholder: (key: string) => void;
    toggleInfoField: (key: string) => void;
    openTestEmailDialog: () => void;
    closeTestEmailDialog: () => void;
    setTestEmailInput: (email: string) => void;
    handleSendTest: () => Promise<void>;
}

export function useNotificationSettings({
    value,
    onChange,
    onSendTestEmail,
}: UseNotificationSettingsProps): UseNotificationSettingsReturn {
    // ─── State ───────────────────────────────────────────────────────────
    const [selectedEvent, setSelectedEvent] = useState<NotificationEventType>('TASK_ASSIGNED');
    const [testSending, setTestSending] = useState(false);
    const [testEmailDialogOpen, setTestEmailDialogOpen] = useState(false);
    const [testEmailInput, setTestEmailInput] = useState('');
    const activeRef = useRef<HTMLInputElement | HTMLTextAreaElement | null>(null);

    // ─── Settings ───────────────────────────────────────────────────────
    // Parse value purely for rendering
    const settings = useMemo(() => {
        const parsed = parseSettings(value);
        return {
            events: parsed?.events || {},
            businessFields: parsed?.businessFields || []
        };
    }, [value]);

    // Update settings using a functional approach to prevent race conditions
    const updateSettings = useCallback((updater: (prev: INotificationSettings) => INotificationSettings) => {
        const newSettings = updater(settings);
        onChange(serializeSettings(newSettings));
    }, [onChange, settings]);

    const isEnabled = useCallback((eventType: NotificationEventType): boolean => {
        const cfg = settings.events[eventType];
        if (!cfg) return true;
        return cfg.enabled !== false;
    }, [settings]);

    const hasCustomTemplate = useCallback((eventType: NotificationEventType): boolean => {
        return !!settings.events[eventType]?.template;
    }, [settings]);

    const toggleEvent = useCallback((eventType: NotificationEventType) => {
        updateSettings((prev) => {
            const current = prev.events[eventType];
            return {
                ...prev,
                events: {
                    ...(prev.events || {}),
                    [eventType]: { ...current, enabled: !(current?.enabled !== false) },
                },
            };
        });
    }, [updateSettings]);

    // ─── Template Editing ───────────────────────────────────────────────

    const currentTemplate = useMemo((): IStructuredTemplate => {
        return settings.events[selectedEvent]?.template || { ...DEFAULT_TEMPLATES[selectedEvent] };
    }, [settings, selectedEvent]);

    const isCustom = hasCustomTemplate(selectedEvent);

    const updateTemplate = useCallback(<K extends keyof IStructuredTemplate>(key: K, val: IStructuredTemplate[K]) => {
        updateSettings((prev) => {
            const current = prev.events[selectedEvent];
            const tpl = current?.template || { ...DEFAULT_TEMPLATES[selectedEvent] };
            const draft = { ...tpl, [key]: val };
            
            return {
                ...prev,
                events: {
                    ...(prev.events || {}),
                    [selectedEvent]: {
                        ...current,
                        enabled: current?.enabled !== false,
                        template: draft,
                    },
                },
            };
        });
    }, [selectedEvent, updateSettings]);

    const updateBusinessFields = useCallback((fields: import('../../../types').INotificationBusinessField[]) => {
        updateSettings((prev) => ({
            ...prev,
            businessFields: fields.length > 0 ? fields : undefined,
        }));
    }, [updateSettings]);



    const resetTemplate = useCallback(() => {
        updateSettings((prev) => {
            const current = prev.events[selectedEvent];
            if (!current) return prev;
            const { template, ...rest } = current;
            return {
                ...prev,
                events: {
                    ...prev.events,
                    [selectedEvent]: rest as INotificationEventConfig,
                },
            };
        });
    }, [selectedEvent, updateSettings]);

    const insertPlaceholder = useCallback((key: string) => {
        const el = activeRef.current;
        const token = `{{${key}}}`;
        if (el) {
            const start = el.selectionStart ?? el.value.length;
            const end = el.selectionEnd ?? el.value.length;
            const fieldKey = el.dataset.fieldKey as keyof IStructuredTemplate;
            const newVal = el.value.substring(0, start) + token + el.value.substring(end);
            updateTemplate(fieldKey, newVal as any);
            requestAnimationFrame(() => {
                el.selectionStart = el.selectionEnd = start + token.length;
                el.focus();
            });
        }
    }, [updateTemplate]);

    const toggleInfoField = useCallback((key: string) => {
        const fields = currentTemplate.infoFields || [];
        const newFields = fields.includes(key)
            ? fields.filter(f => f !== key)
            : [...fields, key];
        updateTemplate('infoFields', newFields);
    }, [currentTemplate, updateTemplate]);

    // ─── Test Email ─────────────────────────────────────────────────────

    const openTestEmailDialog = useCallback(() => {
        setTestEmailDialogOpen(true);
    }, []);

    const closeTestEmailDialog = useCallback(() => {
        setTestEmailDialogOpen(false);
        setTestEmailInput('');
    }, []);

    const handleSendTest = useCallback(async () => {
        if (!onSendTestEmail) return;
        const email = testEmailInput.trim();
        if (!email || !email.includes('@')) return;
        setTestSending(true);
        try {
            await onSendTestEmail(selectedEvent, email, value);
            setTestEmailDialogOpen(false);
            setTestEmailInput('');
        } catch (err) {
            console.error('Test email failed:', err);
        } finally {
            setTestSending(false);
        }
    }, [onSendTestEmail, selectedEvent, value, testEmailInput]);

    // ─── Derived ────────────────────────────────────────────────────────
    const enabled = isEnabled(selectedEvent);
    const selectedMeta = NOTIFICATION_EVENT_META[selectedEvent];

    return {
        // State
        settings,
        selectedEvent,
        testSending,
        testEmailDialogOpen,
        testEmailInput,
        activeRef,

        // Computed
        currentTemplate,
        isCustom,
        enabled,
        selectedMeta,

        // Actions
        setSelectedEvent,
        isEnabled,
        hasCustomTemplate,
        toggleEvent,
        updateTemplate,
        updateBusinessFields,
        resetTemplate,
        insertPlaceholder,
        toggleInfoField,
        openTestEmailDialog,
        closeTestEmailDialog,
        setTestEmailInput,
        handleSendTest,
    };
}
