/**
 * Types, constants, and default templates for NotificationSettingsEditor
 */

import type {
    INotificationSettings,
    INotificationEventConfig,
    IStructuredTemplate,
    NotificationEventType,
} from '../../../types';
import { NOTIFICATION_EVENT_TYPES, NOTIFICATION_EVENT_META, TEMPLATE_PLACEHOLDERS, INFO_FIELD_OPTIONS } from '../../../types';

// ─── Default Templates ────────────────────────────────────────────────────────

export const DEFAULT_TEMPLATES: Record<NotificationEventType, IStructuredTemplate> = {
    TASK_ASSIGNED: {
        subject: '🔔 Approval Required: {{workflowType}} — {{stepName}}',
        greeting: 'Dear {{assigneeName}},',
        bodyText: 'You have been assigned a new approval task for step "{{stepName}}" in workflow "{{workflowType}}".\n\nPlease review the document and take action.',
        infoFields: ['workflow', 'step', 'document', 'objectType'],
        buttonLabel: 'Review & Approve',
        buttonColor: '#1a56db',
    },
    TASK_APPROVED: {
        subject: '✅ Approved: {{workflowType}} — {{stepName}}',
        greeting: 'Hello,',
        bodyText: 'A task has been approved by {{approverName}} for step "{{stepName}}" in workflow "{{workflowType}}".',
        infoFields: ['workflow', 'step', 'document', 'approver'],
        buttonLabel: 'View Document',
        buttonColor: '#059669',
    },
    TASK_REJECTED: {
        subject: '❌ Rejected: {{workflowType}} — {{stepName}}',
        greeting: 'Hello,',
        bodyText: 'A task has been rejected by {{approverName}} for step "{{stepName}}" in workflow "{{workflowType}}".',
        infoFields: ['workflow', 'step', 'document', 'rejector', 'comment'],
        buttonLabel: 'View Document',
        buttonColor: '#dc2626',
    },
    WORKFLOW_COMPLETED: {
        subject: '🎉 Workflow Completed: {{workflowType}}',
        greeting: 'Hello {{responsibleName}},',
        bodyText: 'The workflow "{{workflowType}}" has been completed. All approval steps have passed successfully.',
        infoFields: ['workflow', 'document', 'responsible'],
        buttonLabel: 'View Document',
        buttonColor: '#059669',
    },
    WORKFLOW_REJECTED: {
        subject: '⚠️ Workflow Rejected: {{workflowType}}',
        greeting: 'Hello,',
        bodyText: 'The workflow "{{workflowType}}" has been rejected.',
        infoFields: ['workflow', 'document', 'rejector', 'comment'],
        buttonLabel: 'View Document',
        buttonColor: '#dc2626',
    },
    TASK_REASSIGNED: {
        subject: '🔄 Task Reassigned: {{workflowType}} — {{stepName}}',
        greeting: 'Dear {{assigneeName}},',
        bodyText: 'A task has been reassigned to you for step "{{stepName}}" in workflow "{{workflowType}}".\n\nPlease review the document and take action.',
        infoFields: ['workflow', 'step', 'document', 'reassigner', 'comment'],
        buttonLabel: 'Review Document',
        buttonColor: '#7c3aed',
    },
    TASK_REMINDER: {
        subject: '⏰ Reminder: {{workflowType}} — {{stepName}}',
        greeting: 'Dear {{assigneeName}},',
        bodyText: 'This is a friendly reminder that you have a pending approval task for step "{{stepName}}" in workflow "{{workflowType}}".\n\nThe responsible person has requested your timely review.',
        infoFields: ['workflow', 'step', 'document', 'objectType', 'responsible'],
        buttonLabel: 'Review & Approve',
        buttonColor: '#d97706',
    },
};

// ─── Translation Keys ──────────────────────────────────────────────────────────

export const T_KEYS = {
    title: 'Notification Events',
    subtitle: 'Click to configure · toggle to enable/disable',
    disabled: 'This notification is disabled',
    disabledDescription: 'Toggle it on in the left panel to configure the template',
    placeholders: 'Placeholders:',
    subject: 'Subject',
    greeting: 'Greeting',
    bodyText: 'Body Text',
    infoFields: 'Info Table Fields',
    buttonLabel: 'Button Label',
    buttonColor: 'Color',
    livePreview: 'Live Preview',
    previewSubject: 'Subject:',
    customTemplate: 'Using custom template · changes auto-save',
    resetToDefault: 'Reset to Default',
    sendTest: 'Send Test',
    sending: 'Sending...',
    sendTestTitle: 'Send Test Email',
    recipientEmail: 'Recipient Email',
} as const;

// ─── Settings Helpers ─────────────────────────────────────────────────────────

export function parseSettings(json?: string | null): INotificationSettings | null {
    if (!json) return null;
    try {
        const parsed = JSON.parse(json) as Partial<INotificationSettings>;
        return {
            events: parsed?.events || {},
            businessFields: parsed?.businessFields
        };
    } catch {
        return null;
    }
}

export function serializeSettings(settings: INotificationSettings): string | null {
    const hasEventOverrides = settings.events && Object.values(settings.events).some(
        cfg => cfg && (cfg.enabled === false || cfg.template)
    );
    
    // Filter out business fields with empty keys
    const validBusinessFields = (settings.businessFields || []).filter(f => f && f.fieldKey && f.fieldKey.trim() !== '');
    const hasBusinessFields = validBusinessFields.length > 0;
    
    if (!hasEventOverrides && !hasBusinessFields) return null;
    
    const safeSettings = {
        events: settings.events || {},
        ...(hasBusinessFields ? { businessFields: validBusinessFields } : {})
    };
    
    return JSON.stringify(safeSettings);
}

// ─── Preview Helpers ───────────────────────────────────────────────────────────

const PREVIEW_SAMPLES: Record<string, string> = {
    assigneeName: 'John Smith',
    stepName: 'Cost Center Approval',
    workflowType: 'Invoice Approval',
    documentReference: 'DOC-2024-001',
    documentLink: '#',
    objectType: 'INV',
    approverName: 'Jane Doe',
    comment: 'Looks good, approved.',
    responsibleName: 'Alex Johnson',
    reassignerName: 'Maria Garcia',
};

export function previewReplace(text: string): string {
    return text.replace(/\{\{(\w+)\}\}/g, (_, key) => PREVIEW_SAMPLES[key] || `{{${key}}}`);
}

// Re-export types and constants for convenience
export { NOTIFICATION_EVENT_TYPES, NOTIFICATION_EVENT_META, TEMPLATE_PLACEHOLDERS, INFO_FIELD_OPTIONS };
