import React from 'react';
import { ChevronDown, ChevronUp, Trash2, User, Users } from 'lucide-react';
import { cn, Badge, Button } from '@cnma/react-ui';
import { useSortable } from '@dnd-kit/sortable';
import { CSS } from '@dnd-kit/utilities';
import type { DraftStep, DraftApprover } from '../types';
import type { PrincipalSearchResult } from '../../../types';

interface SortableStepItemProps {
    step: DraftStep;
    stepIdx: number;
    visibleStepsLength: number;
    expandedStep: string | null;
    setExpandedStep: (key: string) => void;
    moveStep: (key: string, dir: 'up' | 'down') => void;
    deleteStep: (key: string) => void;
    onResolvePrincipal?: (type: string, id: string) => Promise<PrincipalSearchResult | null>;
    t: any;
}

function ApproverNamePreview({ a, i, onResolvePrincipal, t }: { a: DraftApprover, i: number, onResolvePrincipal?: (type: string, id: string) => Promise<PrincipalSearchResult | null>, t: any }) {
    const [name, setName] = React.useState(a.principalName || '');

    React.useEffect(() => {
        if (a.principalName) {
            setName(a.principalName);
            return;
        }
        if (!onResolvePrincipal || !a.principalId) {
            setName(`${t('admin.stepEditor.approverFallback', 'Approver')} ${i + 1}`);
            return;
        }
        onResolvePrincipal(a.principalType, a.principalId)
            .then(res => {
                if (res?.name) setName(res.name);
                else setName(`${t('admin.stepEditor.approverFallback', 'Approver')} ${i + 1}`);
            })
            .catch(() => {
                setName(`${t('admin.stepEditor.approverFallback', 'Approver')} ${i + 1}`);
            });
    }, [a.principalId, a.principalName, a.principalType, onResolvePrincipal, i, t]);

    return (
        <span className="truncate" title={name}>
            {name}
        </span>
    );
}

export function SortableStepItem({
    step, stepIdx, visibleStepsLength, expandedStep, setExpandedStep, moveStep, deleteStep, onResolvePrincipal, t
}: SortableStepItemProps) {
    const {
        attributes,
        listeners,
        setNodeRef,
        transform,
        transition,
        isDragging
    } = useSortable({ id: step._key });

    const style = {
        transform: CSS.Transform.toString(transform),
        transition,
        zIndex: isDragging ? 50 : 'auto',
    };

    return (
        <div
            ref={setNodeRef}
            style={style}
            onClick={() => setExpandedStep(step._key)}
            className={cn(
                'p-4 rounded-2xl border bg-card  cursor-pointer transition-all relative flex flex-col gap-4 group',
                expandedStep === step._key
                    ? 'border-primary shadow-md ring-4 ring-primary/10'
                    : 'border-border hover:border-primary/30 hover:shadow-sm',
                isDragging && 'opacity-50 border-dashed shadow-lg ring-2 ring-primary/20 z-50'
            )}
            {...attributes}
            {...listeners}
        >
            {expandedStep === step._key && (
                <div className="absolute top-1/2 -translate-y-1/2 -right-[1px] w-1.5 h-10 bg-primary rounded-l-full" />
            )}

            <div className="flex items-start justify-between">
                <div className="flex items-center gap-3">
                    <div className="flex flex-col gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                        <Button
                            variant="ghost"
                            size="icon"
                            onClick={(e) => { e.stopPropagation(); moveStep(step._key, 'up'); }}
                            disabled={stepIdx === 0}
                            className="h-6 w-6 p-0.5 text-muted-foreground hover:text-foreground disabled:opacity-30"
                        >
                            <ChevronUp className="w-4 h-4" />
                        </Button>
                        <Button
                            variant="ghost"
                            size="icon"
                            onClick={(e) => { e.stopPropagation(); moveStep(step._key, 'down'); }}
                            disabled={stepIdx === visibleStepsLength - 1}
                            className="h-6 w-6 p-0.5 text-muted-foreground hover:text-foreground disabled:opacity-30"
                        >
                            <ChevronDown className="w-4 h-4" />
                        </Button>
                    </div>
                    <div className="flex items-center gap-2">
                        <Badge variant="outline" className="text-xs font-bold border-primary/30 text-primary">
                            #{step.displayOrder}
                        </Badge>
                        <h4 className={cn(
                            "font-bold text-sm line-clamp-1",
                            expandedStep === step._key ? "text-primary" : "text-foreground"
                        )}>
                            {step.stepName || 'Unnamed Step'}
                        </h4>
                    </div>
                </div>
                <Button
                    variant="ghost"
                    size="sm"
                    onClick={(e) => { e.stopPropagation(); deleteStep(step._key); }}
                    className="p-1.5 h-auto text-muted-foreground hover:text-destructive hover:bg-destructive/10 rounded-lg opacity-0 group-hover:opacity-100 transition-all"
                >
                    <Trash2 className="w-4 h-4" />
                </Button>
            </div>

            <div className="flex items-center gap-2">
                <Badge variant={step.approverSeqMode === 'SEQUENTIAL' ? 'secondary' : 'outline'} className="text-xs font-bold">
                    {step.approverSeqMode === 'SEQUENTIAL' ? t('admin.stepEditor.sequential', 'Sequential') : t('admin.stepEditor.parallel', 'Parallel')}
                </Badge>
                <Badge variant="warning" className="text-xs font-bold">
                    {step.approvalMode === 'ALL' ? t('admin.stepEditor.allApprove', 'All Approve') : t('admin.stepEditor.anyOne', 'Any One')}
                </Badge>
            </div>

            {/* Approvers names preview */}
            {step.defaultApprovers.filter(a => !a._isDeleted).length > 0 && (
                <div className="flex items-center flex-wrap gap-x-3 gap-y-1 mt-1">
                    {step.defaultApprovers.filter(a => !a._isDeleted).map((a, i) => {
                        const dotColors = [
                            'text-blue-500',
                            'text-orange-500',
                            'text-emerald-500',
                            'text-purple-500',
                            'text-pink-500',
                            'text-cyan-500',
                            'text-rose-500',
                            'text-indigo-500'
                        ];
                        return (
                            <div key={i} className="flex items-center gap-1.5 text-xs font-medium text-muted-foreground whitespace-nowrap">
                                <span className={cn("text-lg leading-none -mt-0.5", dotColors[i % dotColors.length])}>•</span>
                                <ApproverNamePreview a={a} i={i} onResolvePrincipal={onResolvePrincipal} t={t} />
                            </div>
                        );
                    })}
                </div>
            )}
        </div>
    );
}
