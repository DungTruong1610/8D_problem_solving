import React, { useMemo, useState, useEffect } from 'react';
import { useTranslation } from 'react-i18next';
import { v4 as uuidv4 } from 'uuid';
import { Button, Checkbox, Input, Select, SelectContent, SelectItem, SelectTrigger, SelectValue, Tabs, TabsList, TabsTrigger, TabsContent } from '@cnma/react-ui';
import { Plus, Trash2, AlertCircle } from 'lucide-react';
import Editor from '@monaco-editor/react';
import { FlatConditionRow } from '../../../types';
import builderSchema from './builder-schema.json';

interface ConditionBuilderProps {
    value: string; // The JSON string of FlatConditionRow[] or AST Object
    onChange: (json: string) => void;
    fieldList?: Array<{ name: string; label?: string }>;
}

export const ConditionBuilder: React.FC<ConditionBuilderProps> = ({ value, onChange, fieldList }) => {
    const { t } = useTranslation('workflow');
    const [mode, setMode] = useState<'basic' | 'advanced'>('basic');
    const [jsonError, setJsonError] = useState<string | null>(null);

    // Initial parsing
    const { initialRows, isAdvancedJson } = useMemo(() => {
        if (!value) return { initialRows: [], isAdvancedJson: false };
        try {
            const parsed = JSON.parse(value);
            if (Array.isArray(parsed)) {
                // Inject internal id for React rendering since it's not saved in DB
                const rowsWithId = parsed.map(r => ({ ...r, id: r.id || uuidv4() }));
                return { initialRows: rowsWithId, isAdvancedJson: false };
            }
            return { initialRows: [], isAdvancedJson: true };
        } catch {
            return { initialRows: [], isAdvancedJson: false };
        }
    }, [value]);

    const [rows, setRows] = useState<FlatConditionRow[]>(initialRows);

    // Switch to advanced mode automatically if it's an AST
    useEffect(() => {
        if (isAdvancedJson) {
            setMode('advanced');
        }
    }, [isAdvancedJson]);

    // Validate Basic Mode logic
    const validationError = useMemo(() => {
        let openCount = 0;
        let closeCount = 0;
        let hasEmptyFields = false;

        rows.filter(r => r.isActive).forEach(r => {
            if (r.leftBracket && r.leftBracket !== '-') openCount += r.leftBracket.length;
            if (r.rightBracket && r.rightBracket !== '-') closeCount += r.rightBracket.length;
            if (!r.field || r.field.trim() === '') hasEmptyFields = true;
        });

        if (hasEmptyFields) return t('admin.stepEditor.conditionBuilder.errEmptyField', 'One or more condition fields are empty.');
        if (openCount !== closeCount) return t('admin.stepEditor.conditionBuilder.errUnbalanced', 'Unbalanced parentheses. Open ({{open}}) != Close ({{close}})', { open: openCount, close: closeCount });
        return null;
    }, [rows, t]);

    const updateRows = (newRows: FlatConditionRow[]) => {
        setRows(newRows);
        // Strip out the internal 'id' before saving to DB
        const payloadToSave = newRows.map(r => {
            const { id, ...rest } = r;
            return rest;
        });
        onChange(JSON.stringify(payloadToSave, null, 2));
    };

    const handleAddCondition = () => {
        const newRow: FlatConditionRow = {
            id: uuidv4(),
            isActive: true,
            leftBracket: '-',
            field: '',
            operator: 'eq',
            isSchema: false,
            value: '',
            rightBracket: '-',
            logicalOperator: 'and',
        };
        updateRows([...rows, newRow]);
    };

    const handleRemoveCondition = (id: string) => {
        updateRows(rows.filter((r) => r.id !== id));
    };

    const handleChange = (id: string, field: keyof FlatConditionRow, val: any) => {
        const newRows = rows.map((r) => {
            if (r.id === id) {
                const updated = { ...r, [field]: val };
                // Reset value if user switches schema mode
                if (field === 'isSchema') updated.value = '';
                return updated;
            }
            return r;
        });
        updateRows(newRows);
    };

    const dataFields = useMemo(() => {
        if (!fieldList) return [];
        return fieldList.map((f) => ({
            value: f.name,
            label: f.label || f.name,
        }));
    }, [fieldList]);

    const handleAdvancedChange = (val: string | undefined) => {
        const v = val || '';
        try {
            if (v.trim() !== '') JSON.parse(v);
            setJsonError(null);
            onChange(v);
        } catch (e) {
            const msg = e instanceof Error ? e.message : String(e);
            setJsonError(msg);
            onChange(v); 
        }
    };

    const formatJSON = () => {
        try {
            const parsed = JSON.parse(value);
            onChange(JSON.stringify(parsed, null, 2));
            setJsonError(null);
        } catch (e) {
            const msg = e instanceof Error ? e.message : String(e);
            setJsonError(msg);
        }
    };

    const renderCell = (col: { key: string; type: string; options?: Array<{value: string, label?: string, labelKey?: string}> }, row: FlatConditionRow, index: number) => {
        const fieldKey = col.key as keyof FlatConditionRow;
        
        switch (col.type) {
            case 'checkbox':
                return (
                    <Checkbox
                        checked={!!row[fieldKey]}
                        onCheckedChange={(c) => handleChange(row.id!, fieldKey, !!c)}
                    />
                );
            case 'select':
                // For logical operator, hide on last row
                if (fieldKey === 'logicalOperator' && index === rows.length - 1) {
                    return <div className="h-8 text-muted-foreground flex items-center justify-center">-</div>;
                }
                return (
                    <Select value={(row[fieldKey] as string) || ''} onValueChange={(v) => handleChange(row.id!, fieldKey, v)}>
                        <SelectTrigger className="h-8 w-full"><SelectValue placeholder="-" /></SelectTrigger>
                        <SelectContent>
                            {col.options?.map((opt: any) => (
                                <SelectItem key={opt.value} value={opt.value}>
                                    {opt.labelKey ? t(opt.labelKey, { defaultValue: opt.label || opt.value }) : opt.label}
                                </SelectItem>
                            ))}
                        </SelectContent>
                    </Select>
                );
            case 'schema-select':
                return (
                    <Select value={(row[fieldKey] as string) || ''} onValueChange={(v) => handleChange(row.id!, fieldKey, v)}>
                        <SelectTrigger className={`h-8 w-full truncate ${!row[fieldKey] ? 'border-destructive/50 focus:ring-destructive' : ''}`}>
                            <SelectValue placeholder={t('admin.stepEditor.conditionBuilder.selectField', 'Select field...')} />
                        </SelectTrigger>
                        <SelectContent>
                            {dataFields.map((df) => (
                                <SelectItem key={df.value} value={df.value}>{df.label}</SelectItem>
                            ))}
                            {dataFields.length === 0 && (
                                <SelectItem value="none" disabled>{t('admin.stepEditor.conditionBuilder.noSchema', 'No schema')}</SelectItem>
                            )}
                        </SelectContent>
                    </Select>
                );
            case 'dynamic-value':
                if (row.isSchema) {
                    return (
                        <Select value={(row[fieldKey] as string) || ''} onValueChange={(v) => handleChange(row.id!, fieldKey, v)}>
                            <SelectTrigger className={`h-8 w-full truncate ${!row[fieldKey] ? 'border-destructive/50 focus:ring-destructive' : ''}`}>
                                <SelectValue placeholder={t('admin.stepEditor.conditionBuilder.selectField', 'Select field...')} />
                            </SelectTrigger>
                            <SelectContent>
                                {dataFields.map((df) => (
                                    <SelectItem key={df.value} value={df.value}>{df.label}</SelectItem>
                                ))}
                                {dataFields.length === 0 && (
                                    <SelectItem value="none" disabled>{t('admin.stepEditor.conditionBuilder.noSchema', 'No schema')}</SelectItem>
                                )}
                            </SelectContent>
                        </Select>
                    );
                }
                return (
                    <Input
                        className={`h-8 w-full bg-background ${row.operator === 'in' || row.operator === 'nin' ? 'font-mono text-xs' : ''}`}
                        value={(row[fieldKey] as string) || ''}
                        onChange={(e) => handleChange(row.id!, fieldKey, e.target.value)}
                        placeholder={row.operator === 'in' || row.operator === 'nin' ? t('admin.stepEditor.conditionBuilder.listPlaceholder', 'VAL1, VAL2...') : t('admin.stepEditor.conditionBuilder.valuePlaceholder', 'Value...')}
                    />
                );
            case 'actions':
                return (
                    <Button variant="ghost" size="sm" onClick={() => handleRemoveCondition(row.id!)} className="text-muted-foreground hover:text-destructive w-8 h-8 p-0">
                        <Trash2 className="w-4 h-4" />
                    </Button>
                );
            default:
                return null;
        }
    };

    return (
        <div className="space-y-4 rounded-xl border p-4 bg-muted/20">
            <div className="flex items-center justify-between">
                <div>
                    <h4 className="text-sm font-semibold tracking-wider text-foreground">
                        {t('admin.stepEditor.conditionBuilder.title', 'Step Trigger Conditions')}
                    </h4>
                    <p className="text-xs text-muted-foreground mt-1">
                        {t('admin.stepEditor.conditionBuilder.desc', 'This step will only execute if the conditions below are met')}
                    </p>
                </div>
                
                <Tabs value={mode} onValueChange={(v) => setMode(v as 'basic' | 'advanced')} className="w-72">
                    <TabsList className="grid w-full grid-cols-2">
                        <TabsTrigger value="basic" disabled={isAdvancedJson}>{t('admin.stepEditor.conditionBuilder.modeBasic', 'Basic Mode')}</TabsTrigger>
                        <TabsTrigger value="advanced">{t('admin.stepEditor.conditionBuilder.modeAdvanced', 'Advanced JSON')}</TabsTrigger>
                    </TabsList>
                </Tabs>
            </div>

            {mode === 'basic' && (
                <>
                    {validationError && (
                        <div className="flex items-center gap-2 text-sm text-destructive bg-destructive/10 p-3 rounded-lg border border-destructive/20 font-medium">
                            <AlertCircle className="w-4 h-4 shrink-0" />
                            {validationError}
                        </div>
                    )}
                    
                    {rows.length > 0 && (
                        <div className="overflow-x-auto">
                            <table className="w-full text-sm">
                                <thead>
                                    <tr className="text-left text-muted-foreground border-b">
                                        {builderSchema.columns.map((col) => (
                                            <th key={col.key} className={`pb-2 font-medium ${col.className || ''}`}>
                                                {col.labelKey ? t(col.labelKey, { defaultValue: col.labelKey.split('.').pop() || '' }) : ''}
                                            </th>
                                        ))}
                                    </tr>
                                </thead>
                                <tbody>
                                    {rows.map((row, index) => (
                                        <tr key={row.id} className={`border-b last:border-0 hover:bg-muted/30 ${!row.isActive ? 'opacity-50' : ''}`}>
                                            {builderSchema.columns.map((col) => (
                                                <td key={col.key} className={`py-2 pr-2 ${col.type === 'checkbox' ? 'text-center' : ''} ${col.type === 'actions' ? 'text-right' : ''} ${col.className || ''}`}>
                                                    {renderCell(col, row, index)}
                                                </td>
                                            ))}
                                        </tr>
                                    ))}
                                </tbody>
                            </table>
                        </div>
                    )}
                    
                    {rows.length === 0 && (
                        <div className="text-center py-6 text-muted-foreground text-sm border-2 border-dashed rounded-lg">
                            {t('admin.stepEditor.conditionBuilder.empty', 'No conditions added. The step will always execute.')}
                        </div>
                    )}

                    <div className="flex justify-end pt-2">
                        <Button variant="default" size="sm" onClick={handleAddCondition} className="rounded-full shadow-sm">
                            <Plus className="w-4 h-4 mr-2" />
                            {t('admin.stepEditor.conditionBuilder.add', 'Add Condition')}
                        </Button>
                    </div>
                </>
            )}

            {mode === 'advanced' && (
                <div className="space-y-4">
                    <div className="flex items-center justify-between">
                        <p className="text-xs text-muted-foreground">
                            {t('admin.stepEditor.conditionBuilder.advancedHint', 'Write raw JSON expressions (AST logic or flat array). Validates syntax on change.')}
                        </p>
                        <Button variant="outline" size="sm" onClick={formatJSON} className="h-8">{t('admin.stepEditor.conditionBuilder.formatJson', 'Format JSON')}</Button>
                    </div>
                    
                    {jsonError && (
                        <div className="text-xs text-destructive flex items-center gap-2">
                            <AlertCircle className="w-3 h-3" />
                            {jsonError}
                        </div>
                    )}
                    
                    <div className="border border-border rounded-lg overflow-hidden h-80">
                        <Editor
                            height="100%"
                            defaultLanguage="json"
                            value={value}
                            onChange={handleAdvancedChange}
                            options={{
                                minimap: { enabled: false },
                                scrollBeyondLastLine: false,
                                tabSize: 2,
                                wordWrap: 'on'
                            }}
                        />
                    </div>
                </div>
            )}
        </div>
    );
};
