import React from 'react';
import { Plus, Trash2, Users, ChevronDown, ChevronUp, ArrowUpDown, User } from 'lucide-react';
import {
    Button, Badge,
    Tabs, TabsList, TabsTrigger, TabsContent,
    Select, SelectTrigger, SelectValue, SelectContent, SelectItem,
    Input,
} from '@cnma/react-ui';

import { FieldSettingsEditor } from '../../FieldSettingsEditor';
import { ConditionBuilder } from './ConditionBuilder';

import { PrincipalPicker } from '../../PrincipalPicker';
import { useTranslation } from 'react-i18next';
import { DndContext, closestCenter, PointerSensor, useSensor, useSensors, DragEndEvent } from '@dnd-kit/core';
import { SortableContext, verticalListSortingStrategy, useSortable } from '@dnd-kit/sortable';
import { CSS } from '@dnd-kit/utilities';
import type { DraftStep, DraftApprover, ExpandSection } from '../types';

import type { PrincipalTypeOption, PrincipalSearchResult } from '../../../types';

function SortableApproverItem({
    approver, appIdx, isSequential, typeOptions, onSearchPrincipals, onResolvePrincipal,
    onDeleteApprover, onUpdateApprover
}: any) {
    const { attributes, listeners, setNodeRef, transform, transition, isDragging } = useSortable({ id: approver._key });
    const { t } = useTranslation('workflow');

    const style = {
        transform: CSS.Translate.toString(transform),
        transition,
        zIndex: isDragging ? 50 : 50 - appIdx,
        opacity: isDragging ? 0.5 : 1,
    };

    return (
        <div ref={setNodeRef} style={style} className={`bg-card border ${isDragging ? 'border-primary' : 'border-border'} rounded-2xl shadow-sm flex flex-col group transition-colors hover:border-primary/30 relative`}>
            <div className="flex items-center justify-between px-6 py-4 bg-muted/30 border-b border-border">
                <div className="flex items-center gap-3">
                    <div {...attributes} {...listeners} className="cursor-grab active:cursor-grabbing p-1 text-muted-foreground hover:text-foreground touch-none">
                        <ArrowUpDown className="w-4 h-4" />
                    </div>
                    <div className="w-8 h-8 rounded-xl bg-primary/10 flex items-center justify-center">
                        {approver.principalType === 'USER' ? <User className="w-4 h-4 text-primary" /> : <Users className="w-4 h-4 text-primary" />}
                    </div>
                    <span className="font-bold text-foreground text-sm">
                        {t('admin.stepEditor.approver', 'Approver {{index}}', { index: appIdx + 1 })}
                    </span>
                </div>
                <Button variant="ghost" size="icon" onClick={() => onDeleteApprover(approver._key)} className="text-muted-foreground hover:text-destructive hover:bg-destructive/10">
                    <Trash2 className="w-4 h-4" />
                </Button>
            </div>
            <div className="p-6">
                <div className="flex gap-4">
                    <Select value={approver.principalType} onValueChange={v => onUpdateApprover(approver._key, { principalType: v })}>
                        <SelectTrigger className="w-40 shrink-0">
                            <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                            {typeOptions.map((t: any) => (
                                <SelectItem key={t.code} value={t.code}>{t.label}</SelectItem>
                            ))}
                        </SelectContent>
                    </Select>
                    <div className="flex-1">
                        {onSearchPrincipals ? (
                            <PrincipalPicker
                                value={approver.principalId}
                                displayName={approver.principalName}
                                principalType={approver.principalType}
                                onSearch={onSearchPrincipals}
                                onResolve={onResolvePrincipal}
                                onSelect={(id, name) => onUpdateApprover(approver._key, { principalId: id, principalName: name || '' })}
                            />
                        ) : (
                            <Input
                                className="w-full"
                                placeholder={t('admin.stepEditor.principalIdPlaceholder', 'Principal ID (UUID)')}
                                value={approver.principalId}
                                onChange={e => onUpdateApprover(approver._key, { principalId: e.target.value })}
                            />
                        )}
                    </div>
                </div>
            </div>
        </div>
    );
}


interface StepCardProps {
    step: DraftStep;
    stepIdx: number;
    totalSteps: number;
    isExpanded: boolean;
    expandedSection: ExpandSection;
    typeOptions: PrincipalTypeOption[];
    fieldList?: Array<{ name: string; label?: string }>;
    onSearchPrincipals?: (t: string, q: string) => Promise<PrincipalSearchResult[]>;
    onResolvePrincipal?: (t: string, id: string) => Promise<PrincipalSearchResult | null>;
    onToggle: () => void;
    onSectionChange: (s: ExpandSection) => void;
    onUpdate: (changes: Partial<DraftStep>) => void;
    onMoveUp: () => void;
    onMoveDown: () => void;
    onDelete: () => void;
    onAddApprover: () => void;
    onDeleteApprover: (key: string) => void;
    onUpdateApprover: (key: string, changes: Partial<DraftApprover>) => void;
    onMoveApproverUp: (key: string) => void;
    onMoveApproverDown: (key: string) => void;
    onReorderApprover?: (sourceKey: string, targetKey: string) => void;
}

export function StepCard({
    step, stepIdx, totalSteps, isExpanded, expandedSection,
    typeOptions, fieldList, onSearchPrincipals, onResolvePrincipal,
    onToggle, onSectionChange, onUpdate, onMoveUp, onMoveDown, onDelete,
    onAddApprover, onDeleteApprover, onUpdateApprover, onMoveApproverUp, onMoveApproverDown, onReorderApprover
}: StepCardProps) {
    const { t } = useTranslation('workflow');
    const visibleApprovers = step.defaultApprovers
        .filter(a => !a._isDeleted)
        .sort((a, b) => (a.approverOrder ?? 0) - (b.approverOrder ?? 0));
    const isSequential = step.approverSeqMode === 'SEQUENTIAL';

    const sensors = useSensors(
        useSensor(PointerSensor, {
            activationConstraint: { distance: 5 },
        })
    );

    const handleDragEnd = (event: DragEndEvent) => {
        const { active, over } = event;
        if (over && active.id !== over.id) {
            onReorderApprover?.(active.id as string, over.id as string);
        }
    };

    return (
        <div className="bg-background">
            <header className="bg-card px-10 py-8 border-b border-border shrink-0">
                <div className="flex items-start justify-between">
                    <div className="flex items-center gap-4">
                        <div className="w-12 h-12 bg-primary/10 text-primary rounded-2xl flex items-center justify-center border border-primary/20 shadow-sm">
                            <Users className="w-6 h-6" />
                        </div>
                        <div>
                            <Input
                                className="font-bold text-foreground text-2xl bg-transparent border-none outline-none hover:bg-muted focus:bg-background focus:ring-2 focus:ring-ring rounded-lg px-2 -ml-2 transition-all w-full max-w-xl"
                                value={step.stepName}
                                onChange={e => onUpdate({ stepName: e.target.value })}
                                placeholder={t('admin.stepEditor.stepNamePlaceholder', 'Step name')}
                            />

                        </div>
                    </div>
                    <Button variant="ghost" size="icon" onClick={onDelete} className="text-muted-foreground hover:text-destructive hover:bg-destructive/10">
                        <Trash2 className="w-5 h-5" />
                    </Button>
                </div>

                <div className="grid grid-cols-2 gap-8 mt-8">
                    <div className="space-y-2">
                        <label className="text-sm font-bold text-muted-foreground tracking-wider">{t('admin.stepEditor.stepType', 'Step Type')}</label>
                        <Select value={step.approverSeqMode} onValueChange={v => onUpdate({ approverSeqMode: v })}>
                            <SelectTrigger className="w-full">
                                <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                                <SelectItem value="PARALLEL">{t('admin.stepEditor.parallel', 'Parallel')}</SelectItem>
                                <SelectItem value="SEQUENTIAL">{t('admin.stepEditor.sequential', 'Sequential')}</SelectItem>
                            </SelectContent>
                        </Select>
                    </div>
                    <div className="space-y-2">
                        <label className="text-sm font-bold text-muted-foreground tracking-wider">{t('admin.stepEditor.approvalCondition', 'Approval Condition')}</label>
                        <Select value={step.approvalMode} onValueChange={v => onUpdate({ approvalMode: v })}>
                            <SelectTrigger className="w-full">
                                <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                                <SelectItem value="ALL">{t('admin.stepEditor.allApprove', 'All Approve')}</SelectItem>
                                <SelectItem value="ANY_ONE">{t('admin.stepEditor.anyOne', 'Any One')}</SelectItem>
                            </SelectContent>
                        </Select>
                    </div>
                </div>
            </header>

            <Tabs
                value={expandedSection ?? 'approvers'}
                onValueChange={v => onSectionChange(v as ExpandSection)}
                className="flex flex-col"
            >
                <div className="px-10 border-b border-border bg-background">
                    <TabsList className="bg-transparent h-auto p-0 border-none space-x-8">
                        <TabsTrigger
                            value="approvers"
                            className="px-1 py-4 text-sm font-bold rounded-none border-b-2 border-transparent data-[state=active]:border-primary data-[state=active]:text-primary data-[state=active]:bg-transparent text-muted-foreground hover:text-foreground transition-all flex items-center gap-2"
                        >
                            {t('admin.stepEditor.approvers', 'Approvers')}
                            <Badge variant="secondary" className="ml-1">{visibleApprovers.length}</Badge>
                        </TabsTrigger>
                        <TabsTrigger
                            value="fields"
                            className="px-1 py-4 text-sm font-bold rounded-none border-b-2 border-transparent data-[state=active]:border-primary data-[state=active]:text-primary data-[state=active]:bg-transparent text-muted-foreground hover:text-foreground transition-all"
                        >
                            {t('admin.stepEditor.fieldSettings', 'Field Settings')}
                        </TabsTrigger>
                        <TabsTrigger
                            value="condition"
                            className="px-1 py-4 text-sm font-bold rounded-none border-b-2 border-transparent data-[state=active]:border-primary data-[state=active]:text-primary data-[state=active]:bg-transparent text-muted-foreground hover:text-foreground transition-all"
                        >
                            {t('admin.stepEditor.condition', 'Condition')}
                        </TabsTrigger>
                    </TabsList>
                </div>

                <div className="bg-card p-4 pb-48">
                    <TabsContent value="approvers" className="m-0 border-none outline-none">
                        <div className="max-w-4xl mx-auto space-y-4">
                            {isSequential && visibleApprovers.length > 1 && (
                                <div className="text-xs font-bold text-muted-foreground uppercase tracking-wider flex items-center gap-2 mb-4">
                                    <ArrowUpDown className="w-3 h-3" />
                                    {t('admin.stepEditor.sequentialModeHint', 'Sequential mode — use ▲/▼ to set execution order')}
                                </div>
                            )}
                            {visibleApprovers.length === 0 && (
                                <div className="text-center py-12 text-muted-foreground text-sm border-2 rounded-2xl border-dashed border-border bg-background">
                                    {t('admin.stepEditor.noApprovers', 'No approvers yet. Add someone to assign approval tasks.')}
                                </div>
                            )}
                            <DndContext sensors={sensors} collisionDetection={closestCenter} onDragEnd={handleDragEnd}>
                                <SortableContext items={visibleApprovers.map(a => a._key)} strategy={verticalListSortingStrategy}>
                                    {visibleApprovers.map((approver, appIdx) => (
                                        <SortableApproverItem
                                            key={approver._key}
                                            approver={approver}
                                            appIdx={appIdx}
                                            isSequential={isSequential}
                                            typeOptions={typeOptions}
                                            onSearchPrincipals={onSearchPrincipals}
                                            onResolvePrincipal={onResolvePrincipal}
                                            onDeleteApprover={onDeleteApprover}
                                            onUpdateApprover={onUpdateApprover}
                                        />
                                    ))}
                                </SortableContext>
                            </DndContext>
                            <Button
                                onClick={onAddApprover}
                                className="w-full py-6 mt-6 text-white font-bold text-sm flex items-center justify-center gap-2 shadow-md rounded-2xl transition-all"
                            >
                                <Plus className="w-4 h-4" /> {t('admin.stepEditor.addApprover', 'Add Approver')}
                            </Button>
                        </div>
                    </TabsContent>
                    <TabsContent value="fields" className="m-0 border-none outline-none">
                        <div className="max-w-4xl mx-auto">
                            <FieldSettingsEditor
                                value={step.fieldSettings}
                                fieldList={fieldList}
                                onChange={json => onUpdate({ fieldSettings: json })}
                            />
                        </div>
                    </TabsContent>
                    <TabsContent value="condition" className="m-0 border-none outline-none">
                        <ConditionBuilder
                            fieldList={fieldList}
                            value={step.conditionExpr || '[]'}
                            onChange={v => onUpdate({ conditionExpr: v })}
                        />
                    </TabsContent>
                </div>
            </Tabs>
        </div>
    );
}
