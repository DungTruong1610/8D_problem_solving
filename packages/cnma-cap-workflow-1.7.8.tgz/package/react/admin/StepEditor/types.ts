export interface DraftApprover {
    _key: string;       // React key (real ID or temp)
    _isNew: boolean;
    _isDeleted: boolean;
    _isDirty: boolean;
    ID: string;
    step_ID?: string;
    principalType: string;
    principalId: string;
    principalName?: string;
    approverOrder: number;
}

export interface DraftStep {
    _key: string;       // React key (real ID or temp)
    _isNew: boolean;
    _isDeleted: boolean;
    _isDirty: boolean;
    ID: string;
    definition_ID?: string;
    displayOrder: number;
    stepName: string;
    stepDescription?: string;
    approvalMode: string;
    approverSeqMode: string;
    fieldSettings?: string;
    conditionExpr?: string;
    defaultApprovers: DraftApprover[];
}

export interface DraftDependency {
    _key: string;
    _isNew: boolean;
    _isDeleted: boolean;
    ID: string;
    definition_ID: string;
    predecessor_ID: string;   // holds step _key (= real ID for existing steps)
    successor_ID: string;     // holds step _key (= real ID for existing steps)
}

export type ExpandSection = 'approvers' | 'fields' | 'condition' | null;
