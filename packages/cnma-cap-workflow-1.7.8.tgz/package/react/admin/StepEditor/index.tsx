import React, { useEffect, useState, useCallback, useRef, useImperativeHandle, forwardRef } from 'react';
import {
    Plus, Trash2, Loader2,
    User, Users, ChevronDown, ChevronUp, ArrowUpDown,
    GitBranch, Settings2, Save, AlertCircle,
} from 'lucide-react';
import {
    Button, Badge, cn,
    Tabs, TabsList, TabsTrigger, TabsContent,
    Select, SelectTrigger, SelectValue, SelectContent, SelectItem,
    Input, useConfirm
} from '@cnma/react-ui';
import { useTranslation } from 'react-i18next';
import { WorkflowAdminService } from '../../services/WorkflowAdminService';
import {
    DndContext,
    closestCenter,
    KeyboardSensor,
    PointerSensor,
    useSensor,
    useSensors,
    DragEndEvent
} from '@dnd-kit/core';
import {
    SortableContext,
    sortableKeyboardCoordinates,
    verticalListSortingStrategy,
    useSortable,
} from '@dnd-kit/sortable';
import { CSS } from '@dnd-kit/utilities';
import type {
    WorkflowHttpClient, WorkflowDefinition,
    WorkflowStepDefinition, DefaultStepApprover,
    StepDependency, PrincipalTypeOption, PrincipalSearchResult,
} from '../../types';
import { PrincipalPicker } from '../PrincipalPicker';
import { DependencyEditor } from '../DependencyEditor';
import { FieldSettingsEditor } from '../FieldSettingsEditor';
import { useStepEditorState } from './hooks/useStepEditorState';
import { SortableStepItem } from './components/SortableStepItem';
import { StepCard } from './components/StepCard';
import type { ExpandSection } from './types';

// ─── Component Props ──────────────────────────────────────────────────────────

interface StepEditorProps {
    activeMode?: 'workflow' | 'logic';
    httpClient: WorkflowHttpClient;
    baseUrl: string;
    definitionId: string;
    definitionName: string;
    principalTypes?: PrincipalTypeOption[];
    onSearchPrincipals?: (principalType: string, query: string) => Promise<PrincipalSearchResult[]>;
    onResolvePrincipal?: (principalType: string, id: string) => Promise<PrincipalSearchResult | null>;
    fieldList?: Array<{ name: string; label?: string }>;
    onError?: (message: string) => void;
    onSuccess?: (message: string) => void;
}

const DEFAULT_PRINCIPAL_TYPES: PrincipalTypeOption[] = [
    { code: 'USER', label: 'User' },
    { code: 'GROUP', label: 'Group' },
    { code: 'TEAM', label: 'Team' },
    { code: 'ROLE', label: 'Role' },
];

let _tmpCounter = 0;
const newTmpId = () => `__tmp_${++_tmpCounter}_${Date.now()}`;

// ─── StepEditor ───────────────────────────────────────────────────────────────

/**
 * StepEditor — Fully buffered step editor.
 *
 * All mutations (add/remove/reorder steps & approvers, change settings,
 * drag approver order, configure dependencies) operate on LOCAL STATE only —
 * no API calls while editing. Call save() from parent to persist all changes.
 *
 * Save sequence:
 *   1. DELETE removed approvers (existing only)
 *   2. DELETE removed steps (existing only)
 *   3. POST new steps → capture real IDs
 *   4. PATCH dirty existing steps
 *   5. POST new approvers (using real step IDs)
 *   6. PATCH dirty existing approvers
 *   7. DELETE removed dependencies (existing only)
 *   8. POST new dependencies (resolving temp step keys → real IDs)
 */
export const StepEditor = forwardRef(function StepEditor({

    httpClient, baseUrl, definitionId, definitionName: _definitionName, activeMode = 'workflow',
    principalTypes, onSearchPrincipals, onResolvePrincipal, fieldList,
    onError, onSuccess,
}: StepEditorProps, ref: React.Ref<{ save: () => Promise<void>; isDirty: boolean }>) {
    const { t } = useTranslation('workflow');
    const { confirm, ConfirmDialog } = useConfirm();
    const service = React.useMemo(
        () => new WorkflowAdminService(httpClient, baseUrl),
        [httpClient, baseUrl]
    );

    const {
        loading,
        isDirty,
        draftSteps,
        draftDeps,
        expandedStep,
        setExpandedStep,
        expandedSection,
        setExpandedSection,
        loadDefinition,
        addStep,
        deleteStep,
        updateStep,
        moveStep,
        reorderStep,
        addApprover,
        deleteApprover,
        updateApprover,
        moveApprover,
        reorderApprover,
        addDependency,
        deleteDependency,
        handleSave,
    } = useStepEditorState(service, definitionId, t, confirm, onError, onSuccess);

    const sensors = useSensors(
        useSensor(PointerSensor, {
            activationConstraint: {
                distance: 5,
            },
        }),
        useSensor(KeyboardSensor, {
            coordinateGetter: sortableKeyboardCoordinates,
        })
    );

    const handleDragEnd = (event: DragEndEvent) => {
        const { active, over } = event;
        if (over && active.id !== over.id) {
            reorderStep(active.id as string, over.id as string);
        }
    };

    const typeOptions = principalTypes?.length ? principalTypes : DEFAULT_PRINCIPAL_TYPES;

    useEffect(() => { loadDefinition(); }, [loadDefinition]);

    useImperativeHandle(ref, () => ({
        save: handleSave,
        isDirty,
    }), [handleSave, isDirty]);

    // ─── Render ───────────────────────────────────────────────────────────────

    if (loading) {
        return (
            <div className="flex items-center justify-center py-12">
                <Loader2 className="h-5 w-5 animate-spin text-muted-foreground" />
            </div>
        );
    }

    const visibleSteps = draftSteps
        .filter(s => !s._isDeleted)
        .sort((a, b) => a.displayOrder - b.displayOrder);
    const visibleDeps = draftDeps.filter(d => !d._isDeleted);

    // DependencyEditor receives steps with ID = _key so both new and existing steps
    // work as predecessor/successor references. Real IDs are resolved on save.
    const stepsForDeps: WorkflowStepDefinition[] = visibleSteps.map(s => ({ ...s, ID: s._key }));
    const depsForDeps: StepDependency[] = visibleDeps.map(d => ({ ...d, ID: d._key }));

    if (activeMode === 'logic') {
        return (
            <div className="flex-1 flex flex-col min-h-0 bg-background p-6 overflow-y-auto">
                <DependencyEditor
                    steps={stepsForDeps}
                    dependencies={depsForDeps}
                    definitionId={definitionId}
                    onAdd={addDependency}
                    onDelete={deleteDependency}
                />
            </div>
        );
    }

    return (
        <div className="flex h-full min-h-0 bg-background">
            {/* Left Sidebar */}
            <aside className="w-[30%] min-w-80 border-r border-border flex flex-col bg-background shrink-0 z-10">
                <div className="p-6 border-b border-border flex items-center justify-between shrink-0 bg-card">
                    <div className="flex items-center gap-3">
                        <span className="uppercase font-bold text-foreground">{t('admin.stepEditor.stepsText', 'Workflow Steps')}</span>
                        <Badge variant="secondary" className="border-0">{visibleSteps.length}</Badge>
                    </div>
                    {isDirty && (
                        <Badge variant="default" className="flex items-center gap-1.5 text-xs uppercase tracking-wider animate-pulse bg-primary/90 hover:bg-primary">
                            <AlertCircle className="w-3.5 h-3.5" />
                            {t('admin.stepEditor.unsavedChanges', 'Unsaved')}
                        </Badge>
                    )}
                </div>

                <div className="flex-1 overflow-y-auto p-4 space-y-3 bg-card/50">
                    {visibleSteps.length === 0 && (
                        <div className="text-center py-8 text-muted-foreground text-sm border-2 rounded-2xl border-dashed border-border bg-background">
                            {t('admin.stepEditor.noSteps', 'No steps yet. Click "Add New Step" below.')}
                        </div>
                    )}
                    <DndContext
                        sensors={sensors}
                        collisionDetection={closestCenter}
                        onDragEnd={handleDragEnd}
                    >
                        <SortableContext
                            items={visibleSteps.map(s => s._key)}
                            strategy={verticalListSortingStrategy}
                        >
                            {visibleSteps.map((step, stepIdx) => (
                                <SortableStepItem
                                    key={step._key}
                                    step={step}
                                    stepIdx={stepIdx}
                                    visibleStepsLength={visibleSteps.length}
                                    expandedStep={expandedStep}
                                    setExpandedStep={setExpandedStep}
                                    moveStep={moveStep}
                                    deleteStep={deleteStep}
                                    onResolvePrincipal={onResolvePrincipal}
                                    t={t}
                                />
                            ))}
                        </SortableContext>
                    </DndContext>
                </div>

                <div className="p-6 border-t border-border bg-background shrink-0">
                    <Button
                        onClick={addStep}
                        className="w-full py-6 text-sm font-bold rounded-xl flex items-center justify-center gap-2 shadow-md"
                    >
                        <Plus className="w-4 h-4" />
                        {t('admin.stepEditor.addStep', 'Add New Step')}
                    </Button>
                </div>
            </aside>

            {/* Main Content Area */}
            <main className="flex-1 flex flex-col min-h-0 bg-white relative overflow-y-auto">
                <div className="flex-1 flex flex-col min-h-0">
                    {expandedStep && draftSteps.find(s => s._key === expandedStep) ? (
                        <StepCard
                            key={expandedStep}
                            step={draftSteps.find(s => s._key === expandedStep)!}
                            stepIdx={visibleSteps.findIndex(s => s._key === expandedStep)}
                            totalSteps={visibleSteps.length}
                            isExpanded={true}
                            expandedSection={expandedSection}
                            typeOptions={typeOptions}
                            fieldList={fieldList}
                            onSearchPrincipals={onSearchPrincipals}
                            onResolvePrincipal={onResolvePrincipal}
                            onToggle={() => { }}
                            onSectionChange={(s: ExpandSection) => setExpandedSection(s)}
                            onUpdate={(changes: any) => updateStep(expandedStep, changes)}
                            onMoveUp={() => { }}
                            onMoveDown={() => { }}
                            onDelete={() => deleteStep(expandedStep)}
                            onAddApprover={() => addApprover(expandedStep)}
                            onDeleteApprover={(ak: string) => deleteApprover(expandedStep, ak)}
                            onUpdateApprover={(ak: string, changes: any) => updateApprover(expandedStep, ak, changes)}
                            onMoveApproverUp={(ak: string) => moveApprover(expandedStep, ak, 'up')}
                            onMoveApproverDown={(ak: string) => moveApprover(expandedStep, ak, 'down')}
                            onReorderApprover={(sourceKey: string, targetKey: string) => reorderApprover(expandedStep, sourceKey, targetKey)}
                        />
                    ) : (
                        <div className="flex flex-col items-center justify-center min-h-[300px] flex-1 text-muted-foreground gap-4">
                            <div className="w-16 h-16 bg-muted rounded-2xl flex items-center justify-center opacity-50">
                                <Settings2 className="w-8 h-8" />
                            </div>
                            <p className="text-sm font-medium">{t('admin.stepEditor.selectStepHint', 'Select a step from the sidebar to configure')}</p>
                        </div>
                    )}
                </div>
            </main>
            {ConfirmDialog}
        </div>
    );
});
