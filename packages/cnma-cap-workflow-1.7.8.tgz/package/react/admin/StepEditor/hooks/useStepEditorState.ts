import { useState, useCallback, useRef } from 'react';
import type { WorkflowAdminService } from '../../../services/WorkflowAdminService';
import type { DraftStep, DraftApprover, DraftDependency, ExpandSection } from '../types';
import type { WorkflowStepDefinition, StepDependency } from '../../../types';

let _tmpCounter = 0;
export const newTmpId = () => `__tmp_${++_tmpCounter}_${Date.now()}`;

function stepToDraft(s: WorkflowStepDefinition): DraftStep {
    return {
        ...s,
        _key: s.ID,
        _isNew: false,
        _isDeleted: false,
        _isDirty: false,
        defaultApprovers: (s.defaultApprovers || []).map(approverToDraft),
    };
}

function approverToDraft(a: any): DraftApprover {
    return { ...a, _key: a.ID, _isNew: false, _isDeleted: false, _isDirty: false };
}

function depToDraft(d: StepDependency): DraftDependency {
    return { ...d, _key: d.ID, _isNew: false, _isDeleted: false };
}

export function useStepEditorState(
    service: WorkflowAdminService,
    definitionId: string,
    t: any,
    confirmFn: (options: any) => Promise<boolean>,
    onError?: (msg: string) => void,
    onSuccess?: (msg: string) => void
) {
    const [loading, setLoading] = useState(true);
    const [saving, setSaving] = useState(false);
    const [isDirty, setIsDirty] = useState(false);
    const [definitionVersion, setDefinitionVersion] = useState(1);

    const [draftSteps, setDraftSteps] = useState<DraftStep[]>([]);
    const [draftDeps, setDraftDeps] = useState<DraftDependency[]>([]);

    const [expandedStep, setExpandedStep] = useState<string | null>(null);
    const [expandedSection, setExpandedSection] = useState<ExpandSection>('approvers');

    const initialExpandDone = useRef(false);

    const loadDefinition = useCallback(async () => {
        try {
            setLoading(true);
            const data = await service.getDefinition(definitionId);
            setDefinitionVersion(data.definitionVersion);

            const steps = [...(data.steps || [])]
                .sort((a, b) => a.displayOrder - b.displayOrder)
                .map(stepToDraft);
            setDraftSteps(steps);

            const deps = (data.stepDependencies || []).map(depToDraft);
            setDraftDeps(deps);

            setIsDirty(false);

            if (steps.length && !initialExpandDone.current) {
                initialExpandDone.current = true;
                setExpandedStep(steps[0]._key);
            }
        } catch (err: any) {
            onError?.(err.message || t('admin.definitions.loadFailed', 'Failed to load definition'));
        } finally {
            setLoading(false);
        }
    }, [service, definitionId, onError, t]);

    const markDirty = () => setIsDirty(true);

    const addStep = () => {
        const key = newTmpId();
        const maxOrder = draftSteps
            .filter(s => !s._isDeleted)
            .reduce((m, s) => Math.max(m, s.displayOrder), 0);
        const newStep: DraftStep = {
            _key: key, _isNew: true, _isDeleted: false, _isDirty: true,
            ID: key,
            definition_ID: definitionId,
            displayOrder: maxOrder + 1,
            stepName: `${t('admin.stepEditor.step', 'Step ')}${draftSteps.filter(s => !s._isDeleted).length + 1}`,
            approvalMode: 'ALL',
            approverSeqMode: 'PARALLEL',
            defaultApprovers: [],
        };
        setDraftSteps(prev => [...prev, newStep]);
        setExpandedStep(key);
        markDirty();
    };

    const deleteStep = async (key: string) => {
        const ok = await confirmFn({
            title: t('admin.stepEditor.confirmRemoveStepTitle', 'Remove Step'),
            description: t('admin.stepEditor.confirmRemoveStep', 'Remove this step from the draft?'),
            destructive: true,
        });
        if (!ok) return;
        setDraftSteps(prev => prev.map(s => s._key === key ? { ...s, _isDeleted: true } : s));
        setDraftDeps(prev => prev.map(d =>
            d.predecessor_ID === key || d.successor_ID === key ? { ...d, _isDeleted: true } : d
        ));
        markDirty();
    };

    const updateStep = (key: string, changes: Partial<DraftStep>) => {
        setDraftSteps(prev => prev.map(s =>
            s._key === key ? { ...s, ...changes, _isDirty: true } : s
        ));
        markDirty();
    };

    const moveStep = (key: string, dir: 'up' | 'down') => {
        setDraftSteps(prev => {
            const sorted = prev.filter(s => !s._isDeleted).sort((a, b) => a.displayOrder - b.displayOrder);
            const idx = sorted.findIndex(s => s._key === key);
            if (idx < 0) return prev;
            const swapIdx = dir === 'up' ? idx - 1 : idx + 1;
            if (swapIdx < 0 || swapIdx >= sorted.length) return prev;
            const curOrder = sorted[idx].displayOrder;
            const swapOrder = sorted[swapIdx].displayOrder;
            return prev.map(s => {
                if (s._key === sorted[idx]._key) return { ...s, displayOrder: swapOrder, _isDirty: true };
                if (s._key === sorted[swapIdx]._key) return { ...s, displayOrder: curOrder, _isDirty: true };
                return s;
            });
        });
        markDirty();
    };

    const reorderStep = (sourceKey: string, targetKey: string) => {
        setDraftSteps(prev => {
            const sorted = prev.filter(s => !s._isDeleted).sort((a, b) => a.displayOrder - b.displayOrder);
            const sourceIdx = sorted.findIndex(s => s._key === sourceKey);
            const targetIdx = sorted.findIndex(s => s._key === targetKey);
            if (sourceIdx < 0 || targetIdx < 0 || sourceIdx === targetIdx) return prev;

            const newSorted = [...sorted];
            const [moved] = newSorted.splice(sourceIdx, 1);
            newSorted.splice(targetIdx, 0, moved);

            return prev.map(s => {
                if (s._isDeleted) return s;
                const newIdx = newSorted.findIndex(ns => ns._key === s._key);
                if (newIdx !== -1 && s.displayOrder !== newIdx + 1) {
                    return { ...s, displayOrder: newIdx + 1, _isDirty: true };
                }
                return s;
            });
        });
        markDirty();
    };

    const addApprover = (stepKey: string) => {
        const key = newTmpId();
        setDraftSteps(prev => prev.map(s => {
            if (s._key !== stepKey) return s;
            const maxOrder = s.defaultApprovers
                .filter(a => !a._isDeleted)
                .reduce((m, a) => Math.max(m, a.approverOrder ?? 0), 0);
            const newApprover: DraftApprover = {
                _key: key, _isNew: true, _isDeleted: false, _isDirty: true,
                ID: key,
                step_ID: s._isNew ? undefined : s.ID,
                principalType: 'USER',
                principalId: '',
                approverOrder: maxOrder + 1,
            };
            return { ...s, defaultApprovers: [...s.defaultApprovers, newApprover] };
        }));
        markDirty();
    };

    const deleteApprover = (stepKey: string, approverKey: string) => {
        setDraftSteps(prev => prev.map(s => {
            if (s._key !== stepKey) return s;
            return {
                ...s,
                defaultApprovers: s.defaultApprovers.map(a =>
                    a._key === approverKey ? { ...a, _isDeleted: true } : a
                ),
            };
        }));
        markDirty();
    };

    const updateApprover = (stepKey: string, approverKey: string, changes: Partial<DraftApprover>) => {
        setDraftSteps(prev => prev.map(s => {
            if (s._key !== stepKey) return s;
            return {
                ...s,
                defaultApprovers: s.defaultApprovers.map(a =>
                    a._key === approverKey ? { ...a, ...changes, _isDirty: true } : a
                ),
            };
        }));
        markDirty();
    };

    const moveApprover = (stepKey: string, approverKey: string, dir: 'up' | 'down') => {
        setDraftSteps(prev => prev.map(s => {
            if (s._key !== stepKey) return s;
            const visible = s.defaultApprovers
                .filter(a => !a._isDeleted)
                .sort((a, b) => (a.approverOrder ?? 0) - (b.approverOrder ?? 0));
            const idx = visible.findIndex(a => a._key === approverKey);
            if (idx < 0) return s;
            const swapIdx = dir === 'up' ? idx - 1 : idx + 1;
            if (swapIdx < 0 || swapIdx >= visible.length) return s;
            const curOrder = visible[idx].approverOrder ?? idx + 1;
            const swapOrder = visible[swapIdx].approverOrder ?? swapIdx + 1;
            return {
                ...s,
                defaultApprovers: s.defaultApprovers.map(a => {
                    if (a._key === visible[idx]._key) return { ...a, approverOrder: swapOrder, _isDirty: true };
                    if (a._key === visible[swapIdx]._key) return { ...a, approverOrder: curOrder, _isDirty: true };
                    return a;
                }),
            };
        }));
        markDirty();
    };

    const reorderApprover = (stepKey: string, sourceKey: string, targetKey: string) => {
        setDraftSteps(prev => prev.map(s => {
            if (s._key !== stepKey) return s;
            const visible = s.defaultApprovers
                .filter(a => !a._isDeleted)
                .sort((a, b) => (a.approverOrder ?? 0) - (b.approverOrder ?? 0));
            const sourceIdx = visible.findIndex(a => a._key === sourceKey);
            const targetIdx = visible.findIndex(a => a._key === targetKey);
            if (sourceIdx < 0 || targetIdx < 0 || sourceIdx === targetIdx) return s;

            const newVisible = [...visible];
            const [moved] = newVisible.splice(sourceIdx, 1);
            newVisible.splice(targetIdx, 0, moved);

            return {
                ...s,
                defaultApprovers: s.defaultApprovers.map(a => {
                    if (a._isDeleted) return a;
                    const newIdx = newVisible.findIndex(nv => nv._key === a._key);
                    if (newIdx !== -1 && a.approverOrder !== newIdx + 1) {
                        return { ...a, approverOrder: newIdx + 1, _isDirty: true };
                    }
                    return a;
                }),
            };
        }));
        markDirty();
    };

    const addDependency = async (predecessorId: string, successorId: string): Promise<void> => {
        const key = newTmpId();
        setDraftDeps(prev => [...prev, {
            _key: key, _isNew: true, _isDeleted: false,
            ID: key,
            definition_ID: definitionId,
            predecessor_ID: predecessorId,
            successor_ID: successorId,
        }]);
        markDirty();
    };

    const deleteDependency = async (depKey: string): Promise<void> => {
        setDraftDeps(prev => prev.map(d => d._key === depKey ? { ...d, _isDeleted: true } : d));
        markDirty();
    };

    const handleSave = async () => {
        try {
            setSaving(true);
            const keyToId = new Map<string, string>();
            draftSteps.filter(s => !s._isNew).forEach(s => keyToId.set(s._key, s.ID));

            for (const step of draftSteps) {
                for (const a of step.defaultApprovers) {
                    if (a._isDeleted && !a._isNew) await service.deleteApprover(a.ID);
                }
            }

            for (const step of draftSteps) {
                if (step._isDeleted && !step._isNew) await service.deleteStep(step.ID);
            }

            for (const step of draftSteps) {
                if (step._isNew && !step._isDeleted) {
                    const created = await service.createStep({
                        definition_ID: definitionId,
                        stepName: step.stepName,
                        displayOrder: step.displayOrder,
                        approvalMode: step.approvalMode,
                        approverSeqMode: step.approverSeqMode,
                        stepDescription: step.stepDescription,
                        fieldSettings: step.fieldSettings,
                        conditionExpr: step.conditionExpr,
                    });
                    keyToId.set(step._key, created.ID);
                }
            }

            for (const step of draftSteps) {
                if (!step._isNew && !step._isDeleted && step._isDirty) {
                    await service.updateStep(step.ID, {
                        stepName: step.stepName,
                        displayOrder: step.displayOrder,
                        approvalMode: step.approvalMode,
                        approverSeqMode: step.approverSeqMode,
                        stepDescription: step.stepDescription,
                        fieldSettings: step.fieldSettings,
                        conditionExpr: step.conditionExpr,
                    });
                }
            }

            for (const step of draftSteps) {
                if (step._isDeleted) continue;
                const realStepId = keyToId.get(step._key);
                if (!realStepId) continue;
                for (const a of step.defaultApprovers) {
                    if (a._isNew && !a._isDeleted) {
                        await service.createApprover({
                            step_ID: realStepId,
                            principalType: a.principalType,
                            principalId: a.principalId,
                            approverOrder: a.approverOrder,
                        });
                    }
                }
            }

            for (const step of draftSteps) {
                if (step._isDeleted) continue;
                for (const a of step.defaultApprovers) {
                    if (!a._isNew && !a._isDeleted && a._isDirty) {
                        await service.updateApprover(a.ID, {
                            principalType: a.principalType,
                            principalId: a.principalId,
                            approverOrder: a.approverOrder,
                        });
                    }
                }
            }

            for (const dep of draftDeps) {
                if (dep._isDeleted && !dep._isNew) await service.deleteDependency(dep.ID);
            }

            for (const dep of draftDeps) {
                if (dep._isNew && !dep._isDeleted) {
                    const predId = keyToId.get(dep.predecessor_ID) ?? dep.predecessor_ID;
                    const succId = keyToId.get(dep.successor_ID) ?? dep.successor_ID;
                    try {
                        await service.createDependency({
                            definition_ID: definitionId,
                            predecessor_ID: predId,
                            successor_ID: succId,
                        });
                    } catch (err: any) {
                        const msg = err.message || t('admin.dependency.addFailed', 'Failed to add dependency');
                        if (msg.toLowerCase().includes('cycle') || msg.toLowerCase().includes('circular')) {
                            onError?.(t('admin.dependency.cycleDetected', '⚠️ Cycle detected: {{msg}}', { msg }));
                        } else {
                            onError?.(msg);
                        }
                    }
                }
            }

            await loadDefinition();
        } catch (err: any) {
            onError?.(err.message || t('admin.stepEditor.saveFailed', 'Failed to save steps'));
        } finally {
            setSaving(false);
        }
    };

    return {
        loading,
        saving,
        isDirty,
        draftSteps,
        draftDeps,
        expandedStep,
        setExpandedStep,
        expandedSection,
        setExpandedSection,
        loadDefinition,
        addStep,
        deleteStep,
        updateStep,
        moveStep,
        reorderStep,
        addApprover,
        deleteApprover,
        updateApprover,
        moveApprover,
        reorderApprover,
        addDependency,
        deleteDependency,
        handleSave,
    };
}
