/**
 * @cnma/cap-workflow — React barrel export
 *
 * Usage:
 *   import { ProcessFlow, ApprovalPanel, WorkflowManager } from '@cnma/cap-workflow/react';
 */

// Runtime Components
export { ProcessFlow } from './runtime/ProcessFlow';
export { ApprovalPanel } from './runtime/ApprovalPanel';
export { WorkflowTimeline } from './runtime/WorkflowTimeline';
export { WorkflowStatusBadge } from './common/WorkflowStatusBadge';
// Admin Components
export { WorkflowManager } from './admin/WorkflowManager';
export { DefinitionsTab } from './admin/DefinitionsTab';
export { StepEditor } from './admin/StepEditor';
export { ObjectTypesTab } from './admin/ObjectTypesTab';
export { PrincipalPicker } from './admin/PrincipalPicker';
export { DependencyEditor } from './admin/DependencyEditor';
export { FieldSettingsEditor } from './admin/FieldSettingsEditor';
export { NotificationSettingsEditor } from './admin/NotificationSettingsEditor';

// Services (for advanced usage)
export { WorkflowRuntimeService } from './services/WorkflowRuntimeService';
export { WorkflowAdminService } from './services/WorkflowAdminService';

// UI Primitives (re-export for external use)
export { Button, buttonVariants, Badge, badgeVariants, cn } from '@cnma/react-ui';

// Types
export type {
    // Status types
    WorkflowStatus,
    StepStatus,
    TaskStatus,
    // Runtime view types
    WorkflowInstance,
    StepInstance,
    ApprovalTask,
    WorkflowHistory,
    // Process flow types
    ProcessFlowStep,
    ProcessFlowTask,
    // Admin types
    WorkflowDefinition,
    WorkflowStepDefinition,
    DefaultStepApprover,
    WorkflowObjectType,
    StepDependency,
    FieldSetting,
    FieldSettingMode,
    // Component props
    WorkflowHttpClient,
    PrincipalTypeOption,
    PrincipalSearchResult,
    ProcessFlowProps,
    ApprovalPanelProps,
    WorkflowTimelineProps,
    WorkflowManagerProps,
    // Notification configuration types
    NotificationEventType,
    INotificationSettings,
    INotificationEventConfig,
    IStructuredTemplate,
} from './types';

export {
    NOTIFICATION_EVENT_TYPES,
    NOTIFICATION_EVENT_META,
    TEMPLATE_PLACEHOLDERS,
    INFO_FIELD_OPTIONS,
} from './types';
