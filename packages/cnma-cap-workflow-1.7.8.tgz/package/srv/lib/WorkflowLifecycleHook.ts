/**
 * @cnma/cap-workflow — WorkflowLifecycleHook
 *
 * Generic lifecycle hook for auto-cancelling workflows when the host app
 * sets a document to a terminal status (e.g., Posted, Obsoleted).
 *
 * Reads `autoCancelOnTerminalStatus` from the workflow definition to decide
 * whether to cancel. Defaults to true if not set.
 *
 * Usage (host app):
 *   await WorkflowLifecycleHook.onDocumentStatusChanged(
 *       docId, 'DocumentUpload', 'Posted', ['Posted', 'Obsoleted']
 *   );
 */

import cds from '@sap/cds';
import { WorkflowEngine } from './WorkflowEngine';
import { CDS_ENTITIES } from './types';

const LOG = cds.log('workflow.lifecycle-hook');

export class WorkflowLifecycleHook {

    /**
     * Called by the host app when a document's status changes.
     * If the new status is terminal and an active workflow exists,
     * auto-cancels the workflow (if definition allows it).
     *
     * @param referenceId  The document/entity ID
     * @param referenceType  The entity type (e.g., 'DocumentUpload')
     * @param newStatus  The new status being set
     * @param terminalStatuses  Array of statuses considered terminal
     * @returns  { cancelled: boolean; workflowId?: string }
     */
    static async onDocumentStatusChanged(
        referenceId: string,
        referenceType: string,
        newStatus: string,
        terminalStatuses: string[]
    ): Promise<{ cancelled: boolean; workflowId?: string; reason?: string }> {

        // 1. Only act on terminal statuses
        if (!terminalStatuses.includes(newStatus)) {
            return { cancelled: false, reason: 'Status is not terminal' };
        }

        try {
            // 2. Find active workflow for this document
            const activeWorkflow = await cds.run(
                SELECT.one.from(CDS_ENTITIES.WorkflowInstance)
                    .columns('ID', 'definition_ID', 'status')
                    .where({
                        referenceId,
                        referenceType,
                        status: 'ACTIVE'
                    })
            ) as { ID: string; definition_ID: string; status: string } | null;

            if (!activeWorkflow) {
                return { cancelled: false, reason: 'No active workflow found' };
            }

            // 3. Check if definition allows auto-cancel
            if (activeWorkflow.definition_ID) {
                const definition = await cds.run(
                    SELECT.one.from(CDS_ENTITIES.WorkflowDefinition)
                        .columns('autoCancelOnTerminalStatus')
                        .where({ ID: activeWorkflow.definition_ID })
                ) as { autoCancelOnTerminalStatus: boolean } | null;

                if (definition && definition.autoCancelOnTerminalStatus === false) {
                    LOG.info(`Workflow ${activeWorkflow.ID} skipped auto-cancel (disabled in definition)`);
                    return {
                        cancelled: false,
                        workflowId: activeWorkflow.ID,
                        reason: 'autoCancelOnTerminalStatus is disabled'
                    };
                }
            }

            // 4. Cancel the workflow
            LOG.info(`Auto-cancelling workflow ${activeWorkflow.ID} — document ${referenceId} set to ${newStatus}`);
            await WorkflowEngine.cancelWorkflow(
                activeWorkflow.ID,
                `Auto-cancelled: document status changed to ${newStatus}`
            );

            return { cancelled: true, workflowId: activeWorkflow.ID };

        } catch (err: any) {
            LOG.error(`Auto-cancel failed for ${referenceId}:`, err);
            // Best-effort — don't fail the status change
            return { cancelled: false, reason: `Error: ${err.message}` };
        }
    }

    /**
     * Also check DRAFT workflows — cancel those too since the document
     * is being finalized before the workflow even started.
     */
    static async cancelDraftWorkflows(
        referenceId: string,
        referenceType: string,
        reason: string
    ): Promise<number> {
        const drafts = await cds.run(
            SELECT.from(CDS_ENTITIES.WorkflowInstance)
                .columns('ID')
                .where({
                    referenceId,
                    referenceType,
                    status: 'DRAFT'
                })
        ) as { ID: string }[];

        let cancelled = 0;
        for (const draft of drafts) {
            try {
                await WorkflowEngine.cancelWorkflow(draft.ID, reason);
                cancelled++;
            } catch (err: any) {
                LOG.warn(`Failed to cancel draft workflow ${draft.ID}:`, err.message);
            }
        }

        return cancelled;
    }
}
