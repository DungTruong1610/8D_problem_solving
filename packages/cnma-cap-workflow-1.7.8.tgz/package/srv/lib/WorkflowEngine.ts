/**
 * @cnma/cap-workflow — Workflow Engine
 *
 * Lifecycle orchestrator for workflow instances: create, start, cancel, rerun, delete.
 * Delegates step-level logic to StepAdvancer.
 *
 * Responsibilities:
 *   - Create workflow instances from definitions (with optional approver overrides)
 *   - Start workflows (activate start steps)
 *   - Cancel workflows (cancel all active tasks)
 *   - Rerun workflows (new instance with runNumber+1)
 *   - Delete all workflow runtime data for a reference (inverse of create; ordered cascade)
 *   - Handle rejection modes (C6): BACK_TO_RESPONSIBLE, RESTART_STEP, NEW_RUN
 *   - Log all transitions to WorkflowHistory
 *
 * ⚠️ CONSTRAINT T2: All DB operations run within the caller's implicit CAP tx.
 */

import cds from '@sap/cds';
import { StepAdvancer } from './StepAdvancer';
import { WorkflowHistoryLogger } from './WorkflowHistoryLogger';
import { WorkflowNotifier, type IWorkflowNotificationContext } from './WorkflowNotifier';
import { PrincipalResolver } from './PrincipalResolver';
import { ConditionEvaluator } from './ConditionEvaluator';
import {
    CDS_ENTITIES,
    WorkflowEventType,
    type IWorkflowDefinition,
    type IWorkflowStepDefinition,
    type IWorkflowInstance,
    type IStepInstance,
    type IApprovalTask,
    type ICreateWorkflowInput,
    type IApproverOverride,
    type RejectionMode,
    type WorkflowStatus,
    type IWorkflowStatusChangedPayload,
} from './types';

const LOG = cds.log('workflow.engine');

export class WorkflowEngine {

    // ═══════════════════════════════════════════════════════════════════════
    // CREATE WORKFLOW
    // ═══════════════════════════════════════════════════════════════════════

    /**
     * Create a new workflow instance from a definition template.
     * Creates StepInstances (copies from definition) but does NOT start them.
     *
     * @param input Creation parameters
     * @returns The created WorkflowInstance ID
     */
    static async createWorkflow(input: ICreateWorkflowInput): Promise<string> {
        // 1. Load the definition with steps and approvers
        const definition = await cds.run(
            SELECT.one.from(CDS_ENTITIES.WorkflowDefinition)
                .where({ ID: input.definitionId, isActive: true })
        ) as IWorkflowDefinition | null;

        if (!definition) {
            throw new Error(`Workflow definition '${input.definitionId}' not found or inactive`);
        }

        const steps = await cds.run(
            SELECT.from(CDS_ENTITIES.WorkflowStepDefinition)
                .where({ definition_ID: definition.ID })
                .orderBy('displayOrder asc')
        ) as IWorkflowStepDefinition[];

        if (steps.length === 0) {
            throw new Error(`Workflow definition '${input.definitionId}' has no steps`);
        }

        // 2. Check for existing active workflow on the same reference
        const existingActive = await cds.run(
            SELECT.one.from(CDS_ENTITIES.WorkflowInstance)
                .where({
                    referenceId: input.referenceId,
                    referenceType: input.referenceType,
                    status: { in: ['DRAFT', 'ACTIVE'] },
                })
        ) as IWorkflowInstance | null;

        if (existingActive) {
            throw new Error(
                `An active workflow already exists for ${input.referenceType}:${input.referenceId} ` +
                `(ID: ${existingActive.ID}, status: ${existingActive.status})`
            );
        }

        // 3. Determine run number
        const lastRun = await cds.run(
            SELECT.one.from(CDS_ENTITIES.WorkflowInstance)
                .columns('runNumber')
                .where({
                    referenceId: input.referenceId,
                    referenceType: input.referenceType,
                })
                .orderBy('runNumber desc')
        ) as { runNumber: number } | null;

        const runNumber = (lastRun?.runNumber || 0) + 1;

        // 4. Create workflow instance
        const workflowId = cds.utils.uuid();
        const now = new Date().toISOString();

        await cds.run(
            INSERT.into(CDS_ENTITIES.WorkflowInstance).entries({
                ID: workflowId,
                referenceId: input.referenceId,
                referenceType: input.referenceType,
                definition_ID: definition.ID,
                workflowType: definition.workflowType,
                workflowTypeSource: 'MANUAL',
                runNumber,
                status: 'DRAFT',
                frozenDefinitionVersion: definition.definitionVersion,
                responsibleType: input.responsibleType || definition.responsibleType,
                responsibleId: input.responsibleId || definition.responsibleId,
                createdBy_ID: input.createdById,
            })
        );

        // 5. Create step instances from definition (H5: batched INSERT)
        const stepEntries = steps.map(step => {
            let initialStatus: 'PENDING' | 'SKIPPED' = 'PENDING';
            if (step.conditionExpr && input.documentData) {
                try {
                    const matches = ConditionEvaluator.evaluate(step.conditionExpr, input.documentData);
                    if (!matches) {
                        initialStatus = 'SKIPPED';
                        LOG.info(`Step '${step.stepName}' skipped based on conditionExpr evaluation`);
                    }
                } catch (err: any) {
                    LOG.warn(`Failed to evaluate conditionExpr for step '${step.stepName}', defaulting to PENDING:`, err.message);
                }
            }

            return {
                ID: cds.utils.uuid(),
                workflowInstance_ID: workflowId,
                stepDefinition_ID: step.ID,
                stepName: step.stepName,
                displayOrder: step.displayOrder,
                approvalMode: step.approvalMode,
                approverSeqMode: step.approverSeqMode,
                fieldSettings: step.fieldSettings,
                status: initialStatus,
                completedAt: initialStatus === 'SKIPPED' ? now : undefined,
            };
        });

        await cds.run(
            INSERT.into(CDS_ENTITIES.StepInstance).entries(stepEntries)
        );

        // 6. Apply approver overrides if provided
        if (input.approverOverrides && input.approverOverrides.length > 0) {
            await this.applyApproverOverrides(workflowId, input.approverOverrides);
        }

        // 7. Log history
        await this.logHistory(workflowId, null, null,
            WorkflowEventType.CREATED, '', '', 'DRAFT'
        );

        LOG.info('Workflow created', {
            workflowId,
            definitionId: definition.ID,
            referenceType: input.referenceType,
            referenceId: input.referenceId,
            runNumber,
            stepCount: steps.length,
        });

        return workflowId;
    }

    // ═══════════════════════════════════════════════════════════════════════
    // START WORKFLOW
    // ═══════════════════════════════════════════════════════════════════════

    /**
     * Start a workflow: set status to ACTIVE and activate start steps.
     *
     * @param workflowId The workflow instance to start
     */
    static async startWorkflow(workflowId: string): Promise<void> {
        const instance = await cds.run(
            SELECT.one.from(CDS_ENTITIES.WorkflowInstance)
                .where({ ID: workflowId })
        ) as IWorkflowInstance | null;

        if (!instance) {
            throw new Error(`Workflow instance '${workflowId}' not found`);
        }

        if (instance.status !== 'DRAFT') {
            throw new Error(
                `Cannot start workflow '${workflowId}': status is '${instance.status}', expected 'DRAFT'`
            );
        }

        // Set to ACTIVE
        const now = new Date().toISOString();
        await cds.run(
            UPDATE(CDS_ENTITIES.WorkflowInstance)
                .set({ status: 'ACTIVE', startedAt: now })
                .where({ ID: workflowId })
        );

        // Log history
        await this.logHistory(workflowId, null, null,
            WorkflowEventType.STARTED, '', 'DRAFT', 'ACTIVE'
        );

        // Activate start steps (delegates to StepAdvancer)
        await StepAdvancer.activateStartSteps(workflowId);

        LOG.info('Workflow started', { workflowId });
    }

    // ═══════════════════════════════════════════════════════════════════════
    // CANCEL WORKFLOW
    // ═══════════════════════════════════════════════════════════════════════

    /**
     * Cancel a workflow: set status to CANCELLED, cancel all active/pending tasks.
     *
     * @param workflowId The workflow instance to cancel
     * @param reason Cancellation reason (logged in history)
     */
    static async cancelWorkflow(workflowId: string, reason?: string): Promise<void> {
        const instance = await cds.run(
            SELECT.one.from(CDS_ENTITIES.WorkflowInstance)
                .where({ ID: workflowId })
        ) as IWorkflowInstance | null;

        if (!instance) {
            throw new Error(`Workflow instance '${workflowId}' not found`);
        }

        if (instance.status === 'COMPLETED' || instance.status === 'CANCELLED') {
            throw new Error(
                `Cannot cancel workflow '${workflowId}': status is '${instance.status}' (terminal)`
            );
        }

        const previousStatus = instance.status;
        const now = new Date().toISOString();

        // Cancel workflow
        await cds.run(
            UPDATE(CDS_ENTITIES.WorkflowInstance)
                .set({ status: 'CANCELLED', completedAt: now })
                .where({ ID: workflowId })
        );

        // Cancel all active/pending step instances
        await cds.run(
            UPDATE(CDS_ENTITIES.StepInstance)
                .set({ status: 'SKIPPED', completedAt: now })
                .where({
                    workflowInstance_ID: workflowId,
                    status: { in: ['PENDING', 'ACTIVE'] },
                })
        );

        // Cancel all pending approval tasks for this workflow's steps
        const stepIds = await cds.run(
            SELECT.from(CDS_ENTITIES.StepInstance)
                .columns('ID')
                .where({ workflowInstance_ID: workflowId })
        ) as { ID: string }[];

        const stepIdSet = new Set(stepIds.map(s => s.ID));

        // Update pending tasks in bulk — use CANCELLED (not REJECTED) to distinguish
        // forced cancellation from a genuine approval rejection (L1)
        if (stepIdSet.size > 0) {
            await cds.run(
                UPDATE(CDS_ENTITIES.ApprovalTask)
                    .set({ status: 'CANCELLED' as any })
                    .where({
                        stepInstance_ID: { in: [...stepIdSet] },
                        status: 'PENDING',
                    })
            );
        }

        // Log history
        await this.logHistory(workflowId, null, null,
            WorkflowEventType.CANCELLED, '', previousStatus, 'CANCELLED',
            undefined, reason
        );

        LOG.info('Workflow cancelled', { workflowId, reason });
    }

    // ═══════════════════════════════════════════════════════════════════════
    // DELETE WORKFLOWS BY REFERENCE
    // ═══════════════════════════════════════════════════════════════════════

    /**
     * Hard-delete ALL workflow runtime data for a business object.
     *
     * The object → workflow link is a generic `referenceId`/`referenceType`
     * string pair (not a CDS association), so CAP performs no auto-cascade —
     * a consuming app must purge the rows itself when it deletes the object.
     * This is the inverse of {@link createWorkflow} and centralises the runtime
     * FK graph so callers never hardcode it.
     *
     * Deletes every run for the reference (DRAFT/ACTIVE/COMPLETED/REJECTED/…).
     * Ordered leaf-first: WorkflowHistory FK-references both ApprovalTask and
     * StepInstance, so it MUST be deleted before them; then ApprovalTask
     * (FK → StepInstance), then StepInstance (FK → WorkflowInstance), then the
     * WorkflowInstance. SAP HANA enforces these constraints (a wrong order
     * throws), so the steps are sequential, not parallel.
     *
     * ⚠️ CONSTRAINT T2: runs on the caller's implicit CAP tx (via `cds.run`).
     *
     * @param referenceId    The referenced object's ID (e.g. DocumentUpload.ID)
     * @param referenceType  The referenceType literal (e.g. 'DocumentUpload')
     * @returns The number of WorkflowInstances deleted
     */
    static async deleteForReference(referenceId: string, referenceType: string): Promise<number> {
        const instances = await cds.run(
            SELECT.from(CDS_ENTITIES.WorkflowInstance).columns('ID')
                .where({ referenceId, referenceType })
        ) as { ID: string }[];
        const wfIds = instances.map(w => w.ID);
        if (wfIds.length === 0) return 0;

        const steps = await cds.run(
            SELECT.from(CDS_ENTITIES.StepInstance).columns('ID')
                .where({ workflowInstance_ID: { in: wfIds } })
        ) as { ID: string }[];
        const stepIds = steps.map(s => s.ID);

        // Ordered, NOT parallel — respect the runtime FK graph (see doc above).
        await cds.run(DELETE.from(CDS_ENTITIES.WorkflowHistory).where({ workflowInstance_ID: { in: wfIds } }));
        if (stepIds.length > 0) {
            await cds.run(DELETE.from(CDS_ENTITIES.ApprovalTask).where({ stepInstance_ID: { in: stepIds } }));
            await cds.run(DELETE.from(CDS_ENTITIES.StepInstance).where({ ID: { in: stepIds } }));
        }
        await cds.run(DELETE.from(CDS_ENTITIES.WorkflowInstance).where({ ID: { in: wfIds } }));

        LOG.info('Workflows deleted for reference', { referenceType, referenceId, instances: wfIds.length, steps: stepIds.length });
        return wfIds.length;
    }

    // ═══════════════════════════════════════════════════════════════════════
    // RERUN WORKFLOW
    // ═══════════════════════════════════════════════════════════════════════

    /**
     * Rerun a workflow: create a new instance with runNumber+1.
     * The old instance stays in its current state (REJECTED/CANCELLED).
     *
     * @param workflowId The previous workflow instance
     * @param approverOverrides Optional approver changes for the new run
     * @returns The new WorkflowInstance ID
     */
    static async rerunWorkflow(
        workflowId: string,
        approverOverrides?: IApproverOverride[]
    ): Promise<string> {
        const instance = await cds.run(
            SELECT.one.from(CDS_ENTITIES.WorkflowInstance)
                .where({ ID: workflowId })
        ) as IWorkflowInstance | null;

        if (!instance) {
            throw new Error(`Workflow instance '${workflowId}' not found`);
        }

        if (!instance.definition_ID) {
            throw new Error(`Workflow instance '${workflowId}' has no definition reference`);
        }

        // Create new instance with same definition
        const newWorkflowId = await this.createWorkflow({
            referenceId: instance.referenceId,
            referenceType: instance.referenceType,
            definitionId: instance.definition_ID,
            responsibleType: instance.responsibleType,
            responsibleId: instance.responsibleId,
            createdById: instance.createdBy_ID,
            approverOverrides,
        });

        // Log rerun on old instance
        await this.logHistory(workflowId, null, null,
            WorkflowEventType.RERUN, '', instance.status, instance.status,
            undefined, undefined, JSON.stringify({ newWorkflowId })
        );

        LOG.info('Workflow rerun created', { oldWorkflowId: workflowId, newWorkflowId });

        return newWorkflowId;
    }

    // ═══════════════════════════════════════════════════════════════════════
    // REJECTION HANDLING (C6)
    // ═══════════════════════════════════════════════════════════════════════

    /**
     * Handle rejection based on the workflow definition's rejectionMode.
     *
     * @param workflowId The workflow instance
     * @param rejectedStepId The step that was rejected
     * @param comment Rejection comment
     */
    static async handleRejection(
        workflowId: string,
        rejectedStepId: string,
        comment: string | undefined,
        notificationCtx: IWorkflowNotificationContext | null
    ): Promise<{ action: string; newWorkflowId?: string }> {
        // Get workflow instance and its definition's rejection mode
        const instance = await cds.run(
            SELECT.one.from(CDS_ENTITIES.WorkflowInstance)
                .where({ ID: workflowId })
        ) as IWorkflowInstance | null;

        if (!instance || !instance.definition_ID) {
            throw new Error(`Workflow instance '${workflowId}' not found`);
        }

        const definition = await cds.run(
            SELECT.one.from(CDS_ENTITIES.WorkflowDefinition)
                .columns('rejectionMode')
                .where({ ID: instance.definition_ID })
        ) as { rejectionMode: RejectionMode } | null;

        const rejectionMode = definition?.rejectionMode || 'BACK_TO_RESPONSIBLE';

        LOG.info('Handling rejection', { workflowId, rejectedStepId, rejectionMode });

        // Notify responsible person about rejection (fire-and-forget)
        // Resolve rejector name from the rejected step's latest task
        this.resolveRejectorName(workflowId, rejectedStepId)
            .then(rejectorName =>
                cds.spawn({}, async () => {
                    // MUST await: cds.spawn commits its detached tx as soon as this callback
                    // resolves. Without await the notifier's first DB read acquires a pooled
                    // connection AFTER that commit (which no-ops on !dbc) — the connection is
                    // then orphaned and never released → permanent pool leak (1 per call).
                    await WorkflowNotifier.notifyWorkflowRejected(
                        workflowId, rejectorName, comment, notificationCtx
                    ).catch(err => LOG.warn('Failed to send WORKFLOW_REJECTED notification:', err.message));
                })
            ).catch(() => {});

        switch (rejectionMode) {
            case 'BACK_TO_RESPONSIBLE':
                return this.handleBackToResponsible(workflowId, rejectedStepId, comment);

            case 'RESTART_STEP':
                return this.handleRestartStep(workflowId, rejectedStepId, comment);

            case 'NEW_RUN':
                return this.handleNewRun(workflowId, rejectedStepId, comment);

            default:
                throw new Error(`Unknown rejection mode: ${rejectionMode}`);
        }
    }

    /**
     * BACK_TO_RESPONSIBLE: All active steps cancelled, status → REJECTED.
     * Responsible person can fix data and re-submit (re-activates from step 1).
     */
    private static async handleBackToResponsible(
        workflowId: string,
        rejectedStepId: string,
        comment?: string
    ): Promise<{ action: string }> {
        const now = new Date().toISOString();

        // Set workflow to REJECTED
        await cds.run(
            UPDATE(CDS_ENTITIES.WorkflowInstance)
                .set({ status: 'REJECTED' })
                .where({ ID: workflowId })
        );

        // Preserve completed/approved/rejected steps — only reset undecided steps
        await cds.run(
            UPDATE(CDS_ENTITIES.StepInstance)
                .set({ status: 'PENDING', activatedAt: null, completedAt: null })
                .where({
                    workflowInstance_ID: workflowId,
                    status: { in: ['ACTIVE', 'PENDING'] },
                })
        );

        // M5: Soft-delete — reset undecided tasks instead of hard-DELETE
        // Decided tasks (APPROVED/REJECTED) keep their status for audit trail
        const stepIds = await cds.run(
            SELECT.from(CDS_ENTITIES.StepInstance)
                .columns('ID')
                .where({ workflowInstance_ID: workflowId })
        ) as { ID: string }[];

        if (stepIds.length > 0) {
            const ids = stepIds.map(s => s.ID);
            // Only reset PENDING tasks — decided tasks keep their historical status (L1)
            await cds.run(
                UPDATE(CDS_ENTITIES.ApprovalTask)
                    .set({ status: 'CANCELLED' as any, comment: 'Reset: workflow returned to responsible' })
                    .where({ stepInstance_ID: { in: ids }, status: 'PENDING' })
            );
        }

        await this.logHistory(workflowId, rejectedStepId, null,
            WorkflowEventType.REJECTED, '', 'ACTIVE', 'REJECTED',
            undefined, comment,
            JSON.stringify({ rejectionMode: 'BACK_TO_RESPONSIBLE' })
        );

        return { action: 'BACK_TO_RESPONSIBLE' };
    }

    /**
     * RESTART_STEP: Only the rejected step goes back to PENDING.
     * Workflow stays ACTIVE. Other completed steps are preserved.
     */
    private static async handleRestartStep(
        workflowId: string,
        rejectedStepId: string,
        comment?: string
    ): Promise<{ action: string }> {
        // Reset only the rejected step
        await cds.run(
            UPDATE(CDS_ENTITIES.StepInstance)
                .set({ status: 'PENDING', activatedAt: null, completedAt: null })
                .where({ ID: rejectedStepId })
        );

        // H1: Soft-cancel tasks instead of hard DELETE — preserves audit trail.
        // Tasks will be re-created from DefaultStepApprovers on re-activation.
        // Decided tasks (APPROVED/REJECTED) are left untouched for history.
        await cds.run(
            UPDATE(CDS_ENTITIES.ApprovalTask)
                .set({ status: 'CANCELLED' as any })
                .where({ stepInstance_ID: rejectedStepId, status: 'PENDING' })
        );

        await this.logHistory(workflowId, rejectedStepId, null,
            WorkflowEventType.STEP_RESET, '', 'REJECTED', 'PENDING',
            undefined, comment,
            JSON.stringify({ rejectionMode: 'RESTART_STEP' })
        );

        return { action: 'RESTART_STEP' };
    }

    /**
     * NEW_RUN: Workflow instance closed as REJECTED.
     * A new workflow instance must be created (new run number).
     */
    private static async handleNewRun(
        workflowId: string,
        rejectedStepId: string,
        comment?: string
    ): Promise<{ action: string; newWorkflowId?: string }> {
        const now = new Date().toISOString();

        // Set workflow to REJECTED (final)
        await cds.run(
            UPDATE(CDS_ENTITIES.WorkflowInstance)
                .set({ status: 'REJECTED', completedAt: now })
                .where({ ID: workflowId })
        );

        // Cancel remaining active steps/tasks
        await cds.run(
            UPDATE(CDS_ENTITIES.StepInstance)
                .set({ status: 'SKIPPED', completedAt: now })
                .where({
                    workflowInstance_ID: workflowId,
                    status: { in: ['PENDING', 'ACTIVE'] },
                })
        );

        const stepIds = await cds.run(
            SELECT.from(CDS_ENTITIES.StepInstance)
                .columns('ID')
                .where({ workflowInstance_ID: workflowId })
        ) as { ID: string }[];

        if (stepIds.length > 0) {
            await cds.run(
                UPDATE(CDS_ENTITIES.ApprovalTask)
                    .set({ status: 'CANCELLED' as any })
                    .where({
                        stepInstance_ID: { in: stepIds.map(s => s.ID) },
                        status: 'PENDING',
                    })
            );
        }

        await this.logHistory(workflowId, rejectedStepId, null,
            WorkflowEventType.REJECTED, '', 'ACTIVE', 'REJECTED',
            undefined, comment,
            JSON.stringify({ rejectionMode: 'NEW_RUN' })
        );

        return { action: 'NEW_RUN' };
    }

    // ═══════════════════════════════════════════════════════════════════════
    // APPROVER OVERRIDES
    // ═══════════════════════════════════════════════════════════════════════

    /**
     * Apply approver overrides to step instances.
     * Creates ApprovalTask entries directly on the step instances.
     * When StepAdvancer.activateStep() runs, it checks for pre-existing tasks
     * before looking at DefaultStepApprover entries.
     *
     * @param workflowId The workflow instance
     * @param overrides Array of step overrides with approver assignments
     */
    private static async applyApproverOverrides(
        workflowId: string,
        overrides: IApproverOverride[]
    ): Promise<void> {
        // Get all step instances for this workflow
        const stepInstances = await cds.run(
            SELECT.from(CDS_ENTITIES.StepInstance)
                .where({ workflowInstance_ID: workflowId })
        ) as IStepInstance[];

        // Map: stepDefinition_ID → StepInstance
        const defToInstance = new Map<string, IStepInstance>();
        for (const si of stepInstances) {
            if (si.stepDefinition_ID) {
                defToInstance.set(si.stepDefinition_ID, si);
            }
        }

        let totalTasks = 0;

        for (const override of overrides) {
            const stepInstance = defToInstance.get(override.stepDefinitionId);
            if (!stepInstance) {
                LOG.warn(`Override for unknown step definition '${override.stepDefinitionId}', skipping`);
                continue;
            }

            // Create an ApprovalTask for each approver in the override
            for (let i = 0; i < override.approvers.length; i++) {
                const approver = override.approvers[i];

                // H4: Validate principalType before inserting
                const isValidType = await PrincipalResolver.validatePrincipalType(approver.principalType);
                if (!isValidType) {
                    const validTypes = await PrincipalResolver.getEnabledTypes();
                    throw new Error(
                        `Invalid approver type '${approver.principalType}' in override for step '${stepInstance.stepName}'. ` +
                        `Valid types: ${validTypes.join(', ')}`
                    );
                }

                // H4: Validate the principal UUID exists
                const exists = approver.principalType === 'USER'
                    ? await cds.run(SELECT.one.from('cnma.identity.ShadowUsers').columns('ID').where({ ID: approver.principalId }))
                    : await cds.run(SELECT.one.from('cnma.identity.ShadowGroups').columns('ID').where({ ID: approver.principalId }));
                if (!exists) {
                    throw new Error(
                        `Approver principal '${approver.principalId}' (type: ${approver.principalType}) not found in identity store. ` +
                        `Check that the UUID is correct.`
                    );
                }
                const taskId = cds.utils.uuid();

                await cds.run(
                    INSERT.into(CDS_ENTITIES.ApprovalTask).entries({
                        ID: taskId,
                        stepInstance_ID: stepInstance.ID,
                        assigneeType: approver.principalType,
                        assigneeId: approver.principalId,
                        taskOrder: approver.approverOrder ?? i,
                        status: 'PENDING',
                        assignmentSource: 'MANUAL',
                    })
                );
                totalTasks++;
            }

            LOG.info('Approver override applied', {
                stepName: stepInstance.stepName,
                stepInstanceId: stepInstance.ID,
                approverCount: override.approvers.length,
            });
        }

        LOG.info('Approver overrides complete', {
            workflowId,
            overrideCount: overrides.length,
            totalTasks,
        });
    }

    // ═══════════════════════════════════════════════════════════════════════
    // STATUS CHANGE EVENT (T7)
    // ═══════════════════════════════════════════════════════════════════════

    /**
     * Build and return the status changed payload for synchronous event emission.
     * The caller (service handler) is responsible for emitting via `srv.emit()`.
     *
     * @param workflowId The workflow instance
     * @returns Payload for the workflow.statusChanged event
     */
    static async buildStatusChangedPayload(workflowId: string): Promise<IWorkflowStatusChangedPayload> {
        const instance = await cds.run(
            SELECT.one.from(CDS_ENTITIES.WorkflowInstance)
                .where({ ID: workflowId })
        ) as IWorkflowInstance | null;

        if (!instance) {
            throw new Error(`Workflow instance '${workflowId}' not found`);
        }

        // Get current active step
        const activeStep = await cds.run(
            SELECT.one.from(CDS_ENTITIES.StepInstance)
                .columns('ID', 'stepName')
                .where({
                    workflowInstance_ID: workflowId,
                    status: 'ACTIVE',
                })
                .orderBy('displayOrder asc')
        ) as IStepInstance | null;

        // Get current approvers summary
        let currentApprovers: string | null = null;
        if (activeStep) {
            const tasks = await cds.run(
                SELECT.from(CDS_ENTITIES.ApprovalTask)
                    .columns('assigneeType', 'assigneeId', 'status')
                    .where({
                        stepInstance_ID: activeStep.ID,
                        status: 'PENDING',
                    })
            ) as IApprovalTask[];

            if (tasks.length > 0) {
                currentApprovers = JSON.stringify(
                    tasks.map(t => ({
                        type: t.assigneeType,
                        id: t.assigneeId,
                    }))
                );
            }
        }

        return {
            referenceId: instance.referenceId,
            referenceType: instance.referenceType,
            workflowId: instance.ID,
            status: instance.status,
            workflowType: instance.workflowType,
            currentStepName: activeStep?.stepName || null,
            currentApprovers,
        };
    }

    // ═══════════════════════════════════════════════════════════════════════
    // UTILITIES
    // ═══════════════════════════════════════════════════════════════════════

    /**
     * Resolve the name of the person who rejected a step.
     * Looks at the most recent REJECTED task on the given step.
     */
    private static async resolveRejectorName(
        workflowId: string,
        rejectedStepId: string
    ): Promise<string> {
        try {
            const task = await cds.run(
                SELECT.one.from(CDS_ENTITIES.ApprovalTask)
                    .columns('decidedById', 'decidedByType')
                    .where({ stepInstance_ID: rejectedStepId, status: 'REJECTED' })
                    .orderBy('decidedAt desc')
            ) as { decidedById?: string; decidedByType?: string } | null;

            if (task?.decidedById) {
                const name = await PrincipalResolver.resolveName(
                    task.decidedByType || 'USER', task.decidedById
                );
                return name || 'Unknown';
            }
        } catch {
            // Swallow — notification will use fallback
        }
        return 'Unknown';
    }

    /** Delegate to shared WorkflowHistoryLogger (H3 DRY fix). */
    private static async logHistory(
        workflowInstanceId: string,
        stepInstanceId: string | null,
        approvalTaskId: string | null,
        eventType: string,
        stepName: string,
        previousValue: string,
        newValue: string,
        performedById?: string,
        comment?: string,
        metadata?: string,
    ): Promise<void> {
        await WorkflowHistoryLogger.log(
            workflowInstanceId, stepInstanceId, approvalTaskId,
            eventType as any, stepName, previousValue, newValue,
            performedById, comment, !performedById,  // System action when no performer
            metadata
        );
    }
}
