/**
 * @cnma/cap-workflow — WorkflowResolver
 *
 * Resolves the correct workflow definition for a document based on:
 *   1. objectType match
 *   2. orgKeyValue match (optional scope)
 *   3. conditionExpr evaluation against document data
 *   4. Priority ordering (higher priority = checked first)
 *
 * Resolution strategy:
 *   - Load all active definitions for the objectType, ordered by priority DESC
 *   - For each: check orgKeyValue match, then evaluate conditionExpr
 *   - First match wins
 *   - Definitions without conditionExpr act as catch-all (match any document)
 *
 * @example
 * ```typescript
 * const definition = await WorkflowResolver.resolveDefinition(
 *     'INV',
 *     { companyCode: '1000', totalAmount: 50000 },
 *     '1000' // optional orgKeyValue
 * );
 * if (definition) {
 *     const wfId = await WorkflowEngine.createWorkflow({ definitionId: definition.ID, ... });
 * }
 * ```
 */

import cds from '@sap/cds';
import { ConditionEvaluator } from './ConditionEvaluator';
import { CDS_ENTITIES, type IWorkflowDefinition } from './types';

const LOG = cds.log('workflow.resolver');

export class WorkflowResolver {

    /**
     * Find the best-matching workflow definition for a document.
     *
     * @param objectType  The document's object type (e.g., 'INV')
     * @param documentData  The document's extraction data (for conditionExpr evaluation)
     * @param orgKeyValue  Optional org-scope value (e.g., company code '1000')
     * @returns The matched definition, or null if no match
     */
    static async resolveDefinition(
        objectType: string,
        documentData: Record<string, unknown> = {},
        orgKeyValue?: string | null,
        triggerAction: string = 'submitForApproval'
    ): Promise<IWorkflowDefinition | null> {

        // 1. Load all active definitions for this objectType, priority DESC, including steps
        const definitions = await cds.run(
            SELECT.from(CDS_ENTITIES.WorkflowDefinition, (d: any) => {
                d('*');
                d.steps((s: any) => {
                    s.ID, s.conditionExpr, s.isActive
                });
            })
                .where('objectType =', objectType, 'and (triggerAction =', triggerAction, 'or triggerAction is null) and isActive =', true)
                .orderBy('priority desc', 'definitionVersion desc')
        ) as (IWorkflowDefinition & { steps?: { ID: string, conditionExpr?: string, isActive?: boolean }[] })[];

        if (definitions.length === 0) {
            LOG.info(`No active definitions for objectType '${objectType}'`);
            return null;
        }

        LOG.info(`Evaluating ${definitions.length} definitions for objectType '${objectType}'`);

        // 2. Evaluate each definition in priority order
        for (const def of definitions) {

            // 2a. orgKeyValue scope check (if definition has one)
            if (def.orgKeyValue) {
                if (!orgKeyValue || def.orgKeyValue !== orgKeyValue) {
                    LOG.debug(`Skipped '${def.workflowType}' — orgKeyValue mismatch (${def.orgKeyValue} !== ${orgKeyValue})`);
                    continue;
                }
            }

            // 2b. conditionExpr evaluation
            if (def.conditionExpr) {
                try {
                    const matches = ConditionEvaluator.evaluate(def.conditionExpr, documentData);
                    if (!matches) {
                        LOG.debug(`Skipped '${def.workflowType}' — conditionExpr did not match`);
                        continue;
                    }
                    LOG.info(`Matched '${def.workflowType}' (priority ${def.priority}) via conditionExpr`);
                } catch (err: any) {
                    LOG.warn(`conditionExpr error in '${def.workflowType}': ${err.message}`);
                    continue; // Skip malformed expressions
                }
            } else {
                LOG.info(`Matched '${def.workflowType}' (priority ${def.priority}) as catch-all (no conditionExpr)`);
            }

            // 2c. Step condition evaluation
            let hasAtLeastOnePassingStep = false;
            if (def.steps && def.steps.length > 0) {
                for (const step of def.steps) {
                    if (step.isActive === false) continue;
                    if (!step.conditionExpr) {
                        hasAtLeastOnePassingStep = true;
                        break;
                    }
                    try {
                        if (ConditionEvaluator.evaluate(step.conditionExpr, documentData)) {
                            hasAtLeastOnePassingStep = true;
                            break;
                        }
                    } catch {
                        // Ignore evaluation errors for individual steps
                    }
                }
            }
            if (!hasAtLeastOnePassingStep) {
                LOG.debug(`Skipped '${def.workflowType}' — all steps skipped (or no steps configured)`);
                continue;
            }

            return def;
        }

        LOG.info(`No matching definition for objectType '${objectType}'`);
        return null;
    }

    /**
     * Find all matching definitions (for debugging/admin preview).
     * Returns all definitions that would match, not just the first.
     */
    static async resolveAllMatches(
        objectType: string,
        documentData: Record<string, unknown> = {},
        orgKeyValue?: string | null,
        triggerAction: string = 'submitForApproval'
    ): Promise<Array<{ definition: IWorkflowDefinition; matchReason: string }>> {
        const definitions = await cds.run(
            SELECT.from(CDS_ENTITIES.WorkflowDefinition, (d: any) => {
                d('*');
                d.steps((s: any) => {
                    s.ID; s.conditionExpr;
                });
            })
            .where('objectType =', objectType, 'and (triggerAction =', triggerAction, 'or triggerAction is null) and isActive =', true)
            .orderBy('priority desc', 'definitionVersion desc')
        );

        const matches: Array<{definition: any, matchReason: string}> = [];

        for (const def of definitions) {
            // 2a. orgKeyValue scope check
            if (def.orgKeyValue) {
                if (!orgKeyValue || def.orgKeyValue !== orgKeyValue) {
                    continue;
                }
            }

            // 2b. conditionExpr evaluation
            if (def.conditionExpr) {
                try {
                    if (ConditionEvaluator.evaluate(def.conditionExpr, documentData)) {
                        matches.push({ definition: def, matchReason: `conditionExpr matched (priority ${def.priority})` });
                    }
                } catch {
                    continue;
                }
            } else {
                // If there's no main condition, we check if any step passes
                let hasAtLeastOnePassingStep = false;
                if (def.steps && def.steps.length > 0) {
                    for (const step of def.steps) {
                        if (!step.conditionExpr) {
                            hasAtLeastOnePassingStep = true;
                            break;
                        }
                        try {
                            if (ConditionEvaluator.evaluate(step.conditionExpr, documentData)) {
                                hasAtLeastOnePassingStep = true;
                                break;
                            }
                        } catch {
                            // ignore
                        }
                    }
                }

                if (hasAtLeastOnePassingStep) {
                    matches.push({ definition: def, matchReason: `catch-all but steps matched (priority ${def.priority})` });
                }
            }
        }
        return matches;
    }
}
