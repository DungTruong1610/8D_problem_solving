/**
 * @cnma/cap-workflow — WorkflowHistoryLogger
 *
 * Shared utility for inserting WorkflowHistory records.
 * Extracted from WorkflowEngine, ApprovalHandler, and StepAdvancer (H3 DRY fix).
 *
 * All three classes had near-identical logHistory methods — this consolidates
 * them into a single, well-typed utility.
 */

import cds from '@sap/cds';
import { CDS_ENTITIES, type WorkflowEventTypeValue } from './types';

const LOG = cds.log('workflow.history-logger');

export class WorkflowHistoryLogger {

    /**
     * Insert a WorkflowHistory entry.
     *
     * @param workflowInstanceId  The workflow instance this event belongs to
     * @param stepInstanceId      The step instance (nullable for workflow-level events)
     * @param approvalTaskId      The approval task (nullable for step/workflow-level events)
     * @param eventType           The event type constant
     * @param stepName            Human-readable step name (nullable)
     * @param previousValue       The previous status value (nullable)
     * @param newValue            The new status value (nullable)
     * @param performedById       Who performed the action — ShadowUser UUID or system (nullable)
     * @param comment             Optional comment
     * @param isSystemAction      Whether this was a system-initiated action (default: false)
     * @param metadata             Optional JSON metadata (e.g., reassignment details)
     */
    static async log(
        workflowInstanceId: string,
        stepInstanceId: string | null,
        approvalTaskId: string | null,
        eventType: WorkflowEventTypeValue,
        stepName: string,
        previousValue: string,
        newValue: string,
        performedById?: string | null,
        comment?: string | null,
        isSystemAction: boolean = false,
        metadata?: string | null,
    ): Promise<void> {
        try {
            await cds.run(
                INSERT.into(CDS_ENTITIES.WorkflowHistory).entries({
                    ID: cds.utils.uuid(),
                    workflowInstance_ID: workflowInstanceId,
                    stepInstance_ID: stepInstanceId,
                    approvalTask_ID: approvalTaskId,
                    eventType,
                    stepName,
                    performedById: performedById || null,
                    isSystemAction,
                    performedAt: new Date().toISOString(),
                    previousValue,
                    newValue,
                    comment: comment || null,
                    metadata: metadata || null,
                })
            );
        } catch (err) {
            // Best-effort: history logging should never fail the main operation
            LOG.warn(`Failed to log history event '${eventType}':`, err);
        }
    }
}
