/**
 * @cnma/cap-workflow — Approval Handler
 *
 * Handles individual approval/rejection/reassignment of tasks.
 * Implements pessimistic locking with forUpdate() for concurrency control (F1).
 *
 * Flow:
 *   1. Lock task with forUpdate() (pessimistic lock within tx)
 *   2. Validate status (must be PENDING)
 *   3. Update task decision
 *   4. Delegate to StepAdvancer for step/workflow advancement
 *   5. If rejection → delegate to WorkflowEngine.handleRejection()
 *
 * ⚠️ CONSTRAINT T2: All operations within caller's implicit CAP transaction.
 *   The forUpdate() lock is held until the implicit COMMIT at the end of the
 *   service handler. This prevents race conditions where two users approve
 *   the same task simultaneously.
 *
 * ⚠️ CONSTRAINT F1: Optimistic locking via @odata.etag on modifiedAt.
 *   The OData layer validates etag before reaching the handler.
 *   forUpdate() provides the pessimistic lock as a second layer.
 */

import cds from '@sap/cds';
import { StepAdvancer } from './StepAdvancer';
import { WorkflowEngine } from './WorkflowEngine';
import { WorkflowHistoryLogger } from './WorkflowHistoryLogger';
import { PrincipalResolver } from './PrincipalResolver';
import { WorkflowNotifier } from './WorkflowNotifier';
import {
    CDS_ENTITIES,
    WorkflowEventType,
    type IApprovalTask,
    type IStepInstance,
    type IWorkflowInstance,
    type IApproveTaskInput,
    type IRejectTaskInput,
    type IReassignTaskInput,
} from './types';

const LOG = cds.log('workflow.approval');

export class ApprovalHandler {

    // ═══════════════════════════════════════════════════════════════════════
    // APPROVE TASK
    // ═══════════════════════════════════════════════════════════════════════

    /**
     * Approve an approval task.
     *
     * Flow:
     *   1. loadAndValidateTask: lock, status check, auth check, load step, resolve UUID
     *   2. Update task: status → APPROVED
     *   3. Log + advance step + advance workflow
     *   4. Fire-and-forget notification
     *
     * @param input Approval input
     * @returns The updated task
     */
    static async approveTask(input: IApproveTaskInput): Promise<IApprovalTask> {
        const { task, stepInstance, decidedByUUID } = await this.loadAndValidateTask(
            input.taskId, input.userId
        );

        const now = new Date().toISOString();
        await cds.run(
            UPDATE(CDS_ENTITIES.ApprovalTask)
                .set({
                    status: 'APPROVED',
                    decidedByType: 'USER',
                    decidedById: decidedByUUID,
                    decidedAt: now,
                    comment: input.comment || null,
                })
                .where({ ID: task.ID })
        );

        LOG.info('Task approved', {
            taskId: task.ID,
            stepName: stepInstance.stepName,
            userId: input.userId,
            decidedByUUID,
        });

        await this.logHistory(
            stepInstance.workflowInstance_ID, stepInstance.ID, task.ID,
            WorkflowEventType.TASK_APPROVED, stepInstance.stepName || '',
            'PENDING', 'APPROVED', decidedByUUID, input.comment
        );

        await StepAdvancer.tryAdvanceStep(stepInstance.ID, stepInstance.workflowInstance_ID);
        await StepAdvancer.tryAdvanceWorkflow(stepInstance.workflowInstance_ID);

        // Pre-fetch notification context in the main tx context (before cds.spawn)
        // so the spawned tx doesn't need to query WorkflowInstance.
        const ctx = await WorkflowNotifier.preloadNotificationContext(stepInstance.workflowInstance_ID);

        PrincipalResolver.resolveName('USER', decidedByUUID)
            .then(name =>
                cds.spawn({}, async () => {
                    // MUST await: cds.spawn commits its detached tx as soon as this callback
                    // resolves. Without await the notifier's first DB read acquires a pooled
                    // connection AFTER that commit (which no-ops on !dbc) — the connection is
                    // then orphaned and never released → permanent pool leak (1 per call).
                    await WorkflowNotifier.notifyTaskDecided(
                        task.ID, name || 'Approver', 'APPROVED',
                        input.comment, stepInstance.stepName || '',
                        stepInstance.workflowInstance_ID, ctx
                    ).catch(err => LOG.warn('Failed to send TASK_APPROVED notification:', err.message));
                })
            ).catch(err => LOG.warn('Failed to send TASK_APPROVED notification:', err.message));

        return {
            ...task,
            status: 'APPROVED',
            decidedByType: 'USER',
            decidedById: decidedByUUID,
            decidedAt: now,
            comment: input.comment || null,
        } as IApprovalTask;
    }

    // ═══════════════════════════════════════════════════════════════════════
    // REJECT TASK
    // ═══════════════════════════════════════════════════════════════════════

    /**
     * Reject an approval task. Comment is REQUIRED.
     *
     * Flow:
     *   1. loadAndValidateTask: lock, status check, auth check, load step, resolve UUID
     *   2. Update task: status → REJECTED
     *   3. Log + advance step → if step REJECTED, trigger WorkflowEngine.handleRejection
     *   4. Fire-and-forget notification
     *
     * @param input Rejection input (comment required)
     * @returns The updated task
     */
    static async rejectTask(input: IRejectTaskInput): Promise<IApprovalTask> {
        if (!input.comment || input.comment.trim().length === 0) {
            throw new Error('A comment is required when rejecting a task');
        }

        const { task, stepInstance, decidedByUUID } = await this.loadAndValidateTask(
            input.taskId, input.userId
        );

        const now = new Date().toISOString();
        await cds.run(
            UPDATE(CDS_ENTITIES.ApprovalTask)
                .set({
                    status: 'REJECTED',
                    decidedByType: 'USER',
                    decidedById: decidedByUUID,
                    decidedAt: now,
                    comment: input.comment,
                })
                .where({ ID: task.ID })
        );

        LOG.info('Task rejected', {
            taskId: task.ID,
            stepName: stepInstance.stepName,
            userId: input.userId,
            decidedByUUID,
            comment: input.comment,
        });

        await this.logHistory(
            stepInstance.workflowInstance_ID, stepInstance.ID, task.ID,
            WorkflowEventType.TASK_REJECTED, stepInstance.stepName || '',
            'PENDING', 'REJECTED', decidedByUUID, input.comment
        );

        // Pre-fetch notification context BEFORE handleRejection (in main tx context).
        // handleRejection holds multiple write locks (UPDATE WorkflowInstance,
        // StepInstances, ApprovalTasks) so a cds.spawn'd tx cannot read
        // WorkflowInstance until the main tx commits → race condition.
        const ctx = await WorkflowNotifier.preloadNotificationContext(stepInstance.workflowInstance_ID);

        await StepAdvancer.tryAdvanceStep(stepInstance.ID, stepInstance.workflowInstance_ID);

        const updatedStep = await cds.run(
            SELECT.one.from(CDS_ENTITIES.StepInstance)
                .columns('status')
                .where({ ID: stepInstance.ID })
        ) as { status: string } | null;

        if (updatedStep?.status === 'REJECTED') {
            await WorkflowEngine.handleRejection(
                stepInstance.workflowInstance_ID,
                stepInstance.ID,
                input.comment,
                ctx
            );
        }

        PrincipalResolver.resolveName('USER', decidedByUUID)
            .then(name =>
                cds.spawn({}, async () => {
                    // MUST await — see notifyTaskDecided (APPROVED) above.
                    // Pass preloaded ctx to avoid DB read race with handleRejection locks.
                    await WorkflowNotifier.notifyTaskDecided(
                        task.ID, name || 'Approver', 'REJECTED',
                        input.comment, stepInstance.stepName || '',
                        stepInstance.workflowInstance_ID, ctx
                    ).catch(err => LOG.warn('Failed to send TASK_REJECTED notification:', err.message));
                })
            ).catch(err => LOG.warn('Failed to send TASK_REJECTED notification:', err.message));

        return {
            ...task,
            status: 'REJECTED',
            decidedByType: 'USER',
            decidedById: decidedByUUID,
            decidedAt: now,
            comment: input.comment,
        } as IApprovalTask;
    }

    // ═══════════════════════════════════════════════════════════════════════
    // REASSIGN TASK
    // ═══════════════════════════════════════════════════════════════════════

    /**
     * Reassign an approval task to a different principal.
     * Logs old → new assignee in history metadata.
     *
     * @param input Reassignment input
     * @returns The updated task
     */
    static async reassignTask(input: IReassignTaskInput): Promise<IApprovalTask> {
        if (!input.reason || input.reason.trim().length === 0) {
            throw new Error('A reason is required when reassigning a task');
        }

        // Validate the new assignee type
        const isValidType = await PrincipalResolver.validatePrincipalType(input.newAssigneeType);
        if (!isValidType) {
            const validTypes = await PrincipalResolver.getEnabledTypes();
            throw new Error(
                `Invalid assignee type '${input.newAssigneeType}'. Valid: ${validTypes.join(', ')}`
            );
        }

        // 1. Lock the task
        const task = await cds.run(
            SELECT.one.from(CDS_ENTITIES.ApprovalTask)
                .where({ ID: input.taskId })
                .forUpdate()
        ) as IApprovalTask | null;

        if (!task) {
            throw new Error(`Approval task '${input.taskId}' not found`);
        }

        // 2. Validate status
        if (task.status !== 'PENDING') {
            throw Object.assign(
                new Error(`Cannot reassign task '${input.taskId}': already decided (status: ${task.status})`),
                { code: 409 }
            );
        }

        // 3. Authorize the caller (C3): must be the current assignee OR the workflow's responsible person
        const isAssignee = task.assigneeType === 'USER'
            ? await (async () => {
                if (task.assigneeId === input.userId) return true;
                const su = await cds.run(
                    SELECT.one.from('cnma.identity.ShadowUsers').columns('ID').where({ userId: input.userId })
                ) as { ID: string } | null;
                return su?.ID === task.assigneeId;
            })()
            : await PrincipalResolver.isMember(input.userId, task.assigneeId);

        if (!isAssignee) {
            // Not the assignee — check if caller is the workflow's responsible person
            const stepForAuth = await cds.run(
                SELECT.one.from(CDS_ENTITIES.StepInstance)
                    .columns('workflowInstance_ID')
                    .where({ ID: task.stepInstance_ID })
            ) as { workflowInstance_ID: string } | null;

            const instanceForAuth = stepForAuth ? await cds.run(
                SELECT.one.from(CDS_ENTITIES.WorkflowInstance)
                    .columns((c: any) => { c.responsibleType, c.responsibleId, c.createdBy((u: any) => u.userId) })
                    .where({ ID: stepForAuth.workflowInstance_ID })
            ) as any : null;

            let isResponsible = false;
            if (instanceForAuth) {
                if (instanceForAuth?.createdBy?.userId === input.userId) {
                    isResponsible = true;
                } else {
                    isResponsible = await PrincipalResolver.isResponsiblePerson(
                        input.userId,
                        instanceForAuth.responsibleType,
                        instanceForAuth.responsibleId
                    );
                }
            }

            if (!isResponsible) {
                LOG.warn('Unauthorized reassign attempt', {
                    taskId: task.ID,
                    callerId: input.userId,
                    assigneeId: task.assigneeId,
                });
                throw Object.assign(
                    new Error(
                        'Only the task assignee or the workflow responsible person can reassign this task.'
                    ),
                    { code: 403 }
                );
            }
        }

        // 4. Get context
        const stepInstance = await cds.run(
            SELECT.one.from(CDS_ENTITIES.StepInstance)
                .where({ ID: task.stepInstance_ID })
        ) as IStepInstance | null;

        if (!stepInstance) {
            throw new Error(`Step instance '${task.stepInstance_ID}' not found`);
        }

        // 4.1 Enforce 4-eyes principle if reassigning to a specific user
        if (input.newAssigneeType === 'USER') {
            const targetUUID = await PrincipalResolver.resolveUUID(input.newAssigneeId);
            if (targetUUID) {
                await this.enforceFourEyesPrinciple(
                    stepInstance.workflowInstance_ID,
                    targetUUID,
                    'reassign'
                );
            }
        }

        // 4.2 Store old assignee for history
        const oldAssignee = {
            type: task.assigneeType,
            id: task.assigneeId,
        };

        // 5. Update task
        await cds.run(
            UPDATE(CDS_ENTITIES.ApprovalTask)
                .set({
                    assigneeType: input.newAssigneeType,
                    assigneeId: input.newAssigneeId,
                })
                .where({ ID: task.ID })
        );

        LOG.info('Task reassigned', {
            taskId: task.ID,
            stepName: stepInstance.stepName,
            from: oldAssignee,
            to: { type: input.newAssigneeType, id: input.newAssigneeId },
            reason: input.reason,
        });

        // 6. Log history with metadata
        await this.logHistory(
            stepInstance.workflowInstance_ID,
            stepInstance.ID,
            task.ID,
            WorkflowEventType.TASK_REASSIGNED,
            stepInstance.stepName || '',
            '', '',
            input.userId,
            input.reason,
            JSON.stringify({
                oldAssignee,
                newAssignee: {
                    type: input.newAssigneeType,
                    id: input.newAssigneeId,
                },
            })
        );

        // 7. Notify the new assignee (fire-and-forget)
        const newAssigneeName = await PrincipalResolver.resolveName(
            input.newAssigneeType, input.newAssigneeId
        ).catch(() => input.newAssigneeId);
        const reassignerUuid = await PrincipalResolver.resolveUUID(input.userId);
        const reassignerName = await PrincipalResolver.resolveName(
            'USER', reassignerUuid
        ).catch(() => input.userId);

        const reassignCtx = await WorkflowNotifier.preloadNotificationContext(stepInstance.workflowInstance_ID);
        cds.spawn({}, async () => {
            // MUST await — see notifyTaskDecided (APPROVED) above: missing await
            // orphans the pooled connection acquired inside the spawn tx.
            await WorkflowNotifier.notifyTaskReassigned(
                task.ID,
                input.newAssigneeId,
                newAssigneeName,
                input.newAssigneeType,
                reassignerName,
                input.reason,
                stepInstance.stepName || '',
                stepInstance.workflowInstance_ID,
                reassignCtx,
            ).catch(err => LOG.warn('Failed to send TASK_REASSIGNED notification:', err.message));
        });

        return {
            ...task,
            assigneeType: input.newAssigneeType,
            assigneeId: input.newAssigneeId,
        } as IApprovalTask;
    }

    // ═══════════════════════════════════════════════════════════════════════
    // AUTHORIZATION
    // ═══════════════════════════════════════════════════════════════════════

    /**
     * Validate that the user is authorized to act on this task.
     *
     * Authorization rules (C9):
     *   - If assigneeType is USER → must be that specific user
     *   - If assigneeType is GROUP/TEAM/etc. → must be a member of that group
     *
     * Self-approval guard (M1):
     *   After confirming the user IS the assignee, also check they are NOT the
     *   workflow's responsible person. The submitter cannot approve their own document.
     *
     * Also handles SEQUENTIAL mode: only the current sequential task's
     * assignee can act (previous tasks must all be decided).
     */
    private static async validateTaskAuthorization(
        task: IApprovalTask,
        userId: string
    ): Promise<void> {
        if (task.assigneeType === 'USER') {
            // The userId from req.user.id is the IDP identity (email/subject),
            // but task.assigneeId may be the ShadowUser UUID.
            // We need to check both: direct match AND ShadowUser lookup.
            if (task.assigneeId === userId) {
                // Direct match (assigneeId is the IDP userId itself)
                // OK — authorized as assignee, proceed to self-approval check below
            } else {
                // Try resolving: is the current user's ShadowUser UUID === assigneeId?
                const shadowUser = await cds.run(
                    SELECT.one.from('cnma.identity.ShadowUsers')
                        .columns('ID', 'userId')
                        .where({ userId: userId })
                ) as { ID: string; userId: string } | null;

                const currentUserUUID = shadowUser?.ID;

                // Also check reverse: maybe assigneeId is a userId, not a UUID
                const assigneeShadowUser = await cds.run(
                    SELECT.one.from('cnma.identity.ShadowUsers')
                        .columns('ID', 'userId')
                        .where({ ID: task.assigneeId })
                ) as { ID: string; userId: string } | null;

                const isAuthorized =
                    // Current user's UUID matches the assigneeId
                    (currentUserUUID && currentUserUUID === task.assigneeId) ||
                    // Or the assignee's IDP userId matches the current user's IDP userId
                    (assigneeShadowUser && assigneeShadowUser.userId === userId);

                if (!isAuthorized) {
                    LOG.warn('Authorization failed', {
                        taskAssigneeId: task.assigneeId,
                        currentUserId: userId,
                        currentUserUUID,
                        assigneeShadowUserId: assigneeShadowUser?.userId,
                    });
                    throw Object.assign(
                        new Error(
                            'This approval task is assigned to a different person. ' +
                            'Only the designated approver can approve or reject this step.'
                        ),
                        { code: 403 }
                    );
                }
            }
        } else {
            // Group-type assignment — check membership
            const isMember = await PrincipalResolver.isMember(userId, task.assigneeId);
            if (!isMember) {
                throw Object.assign(
                    new Error(
                        'This task is assigned to a group you are not a member of. ' +
                        'Please contact your administrator if you believe you should have access.'
                    ),
                    { code: 403 }
                );
            }
        }

        // ── Self-approval guard (M1) ─────────────────────────────────────
        // The user is confirmed to be the assignee. Now check they are NOT also
        // the responsible person (submitter) of this workflow, nor any previous approver.
        const stepForSelfCheck = await cds.run(
            SELECT.one.from(CDS_ENTITIES.StepInstance)
                .columns('workflowInstance_ID', 'approverSeqMode')
                .where({ ID: task.stepInstance_ID })
        ) as { workflowInstance_ID: string; approverSeqMode: string } | null;

        if (stepForSelfCheck?.workflowInstance_ID) {
            const callerUUID = await PrincipalResolver.resolveUUID(userId);
            if (callerUUID) {
                try {
                    await this.enforceFourEyesPrinciple(
                        stepForSelfCheck.workflowInstance_ID,
                        callerUUID,
                        'approve'
                    );
                } catch (err: any) {
                    LOG.warn('Self-approval attempt blocked', {
                        taskId: task.ID,
                        userId,
                        workflowId: stepForSelfCheck.workflowInstance_ID,
                        reason: err.message
                    });
                    throw err;
                }
            }
        }

        // ── Sequential ordering check ────────────────────────────────────
        if (stepForSelfCheck?.approverSeqMode === 'SEQUENTIAL') {
            const allTasks = await cds.run(
                SELECT.from(CDS_ENTITIES.ApprovalTask)
                    .columns('ID', 'taskOrder', 'status')
                    .where({ stepInstance_ID: task.stepInstance_ID })
                    .orderBy('taskOrder asc')
            ) as IApprovalTask[];

            for (const t of allTasks) {
                if (t.ID === task.ID) break;
                if (t.status === 'PENDING') {
                    throw Object.assign(
                        new Error(
                            'This task cannot be acted on yet — previous sequential approvers have not decided'
                        ),
                        { code: 409 }
                    );
                }
            }
        }
    }

    // ═══════════════════════════════════════════════════════════════════════
    // TASK LOADING
    // ═══════════════════════════════════════════════════════════════════════

    /**
     * Lock, validate, and load full context for a task action (approve/reject).
     * Shared by approveTask and rejectTask to eliminate duplicated boilerplate.
     *
     * Steps:
     *   1. Lock task with forUpdate() — pessimistic lock held until tx COMMIT
     *   2. Validate status is PENDING
     *   3. Validate caller authorization
     *   4. Load step instance
     *   5. Resolve caller's ShadowUser UUID (store UUID, not IDP identity)
     */
    private static async loadAndValidateTask(
        taskId: string,
        userId: string
    ): Promise<{ task: IApprovalTask; stepInstance: IStepInstance; decidedByUUID: string }> {
        const task = await cds.run(
            SELECT.one.from(CDS_ENTITIES.ApprovalTask)
                .where({ ID: taskId })
                .forUpdate()
        ) as IApprovalTask | null;

        if (!task) {
            throw new Error(`Approval task '${taskId}' not found`);
        }

        if (task.status !== 'PENDING') {
            throw Object.assign(
                new Error(`Task '${taskId}' has already been decided (status: ${task.status})`),
                { code: 409 }
            );
        }

        await this.validateTaskAuthorization(task, userId);

        const stepInstance = await cds.run(
            SELECT.one.from(CDS_ENTITIES.StepInstance)
                .where({ ID: task.stepInstance_ID })
        ) as IStepInstance | null;

        if (!stepInstance) {
            throw new Error(`Step instance '${task.stepInstance_ID}' not found`);
        }

        const decidedByUUID = await PrincipalResolver.resolveUUID(userId);

        return { task, stepInstance, decidedByUUID };
    }

    // ═══════════════════════════════════════════════════════════════════════
    // UTILITIES
    // ═══════════════════════════════════════════════════════════════════════

    /** Delegate to shared WorkflowHistoryLogger (H3 DRY fix). */
    private static async logHistory(
        workflowInstanceId: string,
        stepInstanceId: string | null,
        approvalTaskId: string | null,
        eventType: string,
        stepName: string,
        previousValue: string,
        newValue: string,
        performedById?: string,
        comment?: string,
        metadata?: string,
    ): Promise<void> {
        await WorkflowHistoryLogger.log(
            workflowInstanceId, stepInstanceId, approvalTaskId,
            eventType as any, stepName, previousValue, newValue,
            performedById, comment, false,  // ApprovalHandler actions are always user-initiated
            metadata
        );
    }

    // ═══════════════════════════════════════════════════════════════════════
    // FOUR EYES PRINCIPLE
    // ═══════════════════════════════════════════════════════════════════════

    /**
     * Enforce 4-eyes principle.
     * Checks if the given user (ShadowUser ID) has already participated in the workflow.
     * Participation includes:
     * 1. Being the creator (submitter) of the workflow instance.
     * 2. Having decided (APPROVED/REJECTED) any previous task in this workflow instance.
     * 
     * @param workflowInstanceId The workflow instance ID
     * @param shadowUserId The ShadowUser UUID of the user to check
     * @param action 'approve' | 'reassign' - determines the error message format
     * @throws Error with code 403 if 4-eyes principle is violated
     */
    private static async enforceFourEyesPrinciple(
        workflowInstanceId: string,
        shadowUserId: string,
        action: 'approve' | 'reassign'
    ): Promise<void> {
        const instance = await cds.run(
            SELECT.one.from(CDS_ENTITIES.WorkflowInstance)
                .columns('definition_ID', 'createdBy_ID')
                .where({ ID: workflowInstanceId })
        ) as (IWorkflowInstance & { definition_ID?: string, createdBy_ID?: string }) | null;

        if (!instance) return;

        // Check if 4-eyes is enforced
        let fourEyesEnforced = true;
        if (instance.definition_ID) {
            const def = await cds.run(
                SELECT.one.from(CDS_ENTITIES.WorkflowDefinition)
                    .columns('enforceFourEyes')
                    .where({ ID: instance.definition_ID })
            ) as { enforceFourEyes?: boolean } | null;
            if (def?.enforceFourEyes === false) {
                fourEyesEnforced = false;
            }
        }

        if (!fourEyesEnforced) return;

        // 1. Check if user is the submitter
        if (instance.createdBy_ID === shadowUserId) {
            if (action === 'reassign') {
                throw Object.assign(
                    new Error(
                        'Reassignment failed: The selected user submitted this document. ' +
                        'Reassignment is not permitted under the 4-Eyes principle.'
                    ),
                    { code: 403 }
                );
            } else {
                throw Object.assign(
                    new Error(
                        'Self-approval is not permitted. ' +
                        'The person who submitted this document cannot approve it.'
                    ),
                    { code: 403 }
                );
            }
        }

        // 2. Check if user has already decided any task in this workflow instance
        const previousTasks = await cds.run(
            SELECT.from(CDS_ENTITIES.ApprovalTask)
                .columns('ID')
                .where({
                    decidedById: shadowUserId,
                    status: { 'in': ['APPROVED', 'REJECTED'] },
                    stepInstance_ID: {
                        'in': SELECT.from(CDS_ENTITIES.StepInstance)
                            .columns('ID')
                            .where({ workflowInstance_ID: workflowInstanceId })
                    }
                })
        ) as any[];

        if (previousTasks && previousTasks.length > 0) {
            if (action === 'reassign') {
                throw Object.assign(
                    new Error(
                        'Reassignment failed: The selected user has already approved or rejected a previous step in this workflow. ' +
                        'Reassignment is not permitted under the 4-Eyes principle.'
                    ),
                    { code: 403 }
                );
            } else {
                throw Object.assign(
                    new Error(
                        'Self-approval is not permitted. ' +
                        'You have already approved or rejected a previous step in this workflow.'
                    ),
                    { code: 403 }
                );
            }
        }
    }
}
