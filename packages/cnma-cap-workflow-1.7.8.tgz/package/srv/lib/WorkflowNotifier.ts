/**
 * @cnma/cap-workflow — WorkflowNotifier
 *
 * Notification orchestrator for workflow events. Decides WHEN and WHO to notify.
 * Delegates actual email delivery to an IEmailSender (provided by host app).
 *
 * Notification strategy:
 *   - TASK_ASSIGNED → notify the assignee (USER or GROUP)
 *   - TASK_APPROVED/REJECTED → notify the responsible person (USER or GROUP)
 *   - TASK_REMINDER → notify the current approver(s) (manual trigger by responsible person)
 *   - WORKFLOW_COMPLETED → notify the responsible person (fallback: submitter if no responsible)
 *   - WORKFLOW_REJECTED → notify the responsible person (fallback: submitter if no responsible)
 *
 * GROUP support:
 *   When principal is a GROUP, email delivery respects the group's emailNotificationMode:
 *   - GROUP_ONLY   → send to groupEmail only (default — avoids spam)
 *   - MEMBERS_ONLY → send to each member's individual email
 *   - BOTH         → send to groupEmail + each member's email
 *
 * Registration:
 *   WorkflowNotifier.registerEmailSender(myGraphEmailSender);
 *   WorkflowNotifier.setDocumentLinkResolver((refId, refType) => `https://app.com/doc/${refId}`);
 */

import cds from '@sap/cds';
import { PrincipalResolver } from './PrincipalResolver';
import { CDS_ENTITIES, IDENTITY_ENTITIES } from './types';
import type { INotificationSettings, INotificationBusinessField, IStructuredTemplate, NotificationEventType } from './types';
import type { IEmailSender, IBatchEmailSender } from './IEmailSender';
import { renderEmailTemplate, renderStructuredTemplate, type EmailTemplateType, type EmailTemplateVars } from './email-templates';

const LOG = cds.log('workflow.notifier');

/**
 * Pre-fetched workflow info passed from the caller's transaction context.
 * Solves the cds.spawn() race condition where the spawned context cannot
 * see uncommitted data (WorkflowInstance just inserted in the same tx).
 */
export interface IPreloadedWorkflowInfo {
    referenceId: string;
    referenceType: string;
    workflowType: string;
    objectType?: string;
    notificationSettings?: INotificationSettings | null;
}

/**
 * Full workflow notification context, pre-fetched from the caller's transaction.
 * Extends IPreloadedWorkflowInfo with responsible/submitter fields needed by
 * notifyTaskDecided to resolve recipients without a DB query inside cds.spawn.
 */
export interface IWorkflowNotificationContext extends IPreloadedWorkflowInfo {
    responsibleType: string;
    responsibleId: string;
    responsibleName?: string;
    submitterId?: string;
    submitterName?: string;
}

/** Placeholder value used in test email previews for business fields */
const SAMPLE_BUSINESS_FIELD_VALUE = 'Sample Value';

/** Sample data used when sending test/preview emails from admin UI. */
const SAMPLE_EMAIL_TEST_VARS: EmailTemplateVars = {
    assigneeName: 'John Smith',
    stepName: 'Cost Center Approval',
    workflowType: 'Invoice Approval',
    documentReference: 'DOC-2024-TEST-001',
    documentLink: '#',
    objectType: 'INV',
    approverName: 'Jane Doe',
    comment: 'This is a test email. No action required.',
    responsibleName: 'Alex Johnson',
    reassignerName: 'Maria Garcia',
};

// ─── Type for document link resolution ──────────────────────────────────────

type DocumentLinkResolver = (referenceId: string, referenceType: string) => string;

// ─── Type for document reference resolution (UUID → friendly name) ──────────

type DocumentReferenceResolver = (referenceId: string, referenceType: string) => Promise<string | null>;

// ─── Type for business fields resolution (extraction data lookup) ───────────

type BusinessFieldsResolver = (
    referenceId: string,
    referenceType: string,
    requestedFields: INotificationBusinessField[]
) => Promise<Array<{ label: string; value: string }>>;

// ─── Global state namespace (Symbol-based for collision safety) ─────────────

const WF_NS = Symbol.for('cap-workflow.WorkflowNotifier');

interface NotifierGlobals {
    emailSender: IEmailSender | null;
    linkResolver: DocumentLinkResolver | null;
    referenceResolver: DocumentReferenceResolver | null;
    businessFieldsResolver: BusinessFieldsResolver | null;
}

function getGlobals(): NotifierGlobals {
    const g = globalThis as any;
    if (!g[WF_NS]) {
        g[WF_NS] = { emailSender: null, linkResolver: null, referenceResolver: null, businessFieldsResolver: null };
    }
    return g[WF_NS];
}

// ─── Notifier ───────────────────────────────────────────────────────────────

export class WorkflowNotifier {

    // ---------------------------------------------------------------------------------------------
    // Email Sender Registration (Host App Dependency)
    // ---------------------------------------------------------------------------------------------

    static get emailSender(): IEmailSender | null {
        return getGlobals().emailSender;
    }
    static set emailSender(sender: IEmailSender | null) {
        getGlobals().emailSender = sender;
    }

    static get linkResolver(): DocumentLinkResolver | null {
        return getGlobals().linkResolver;
    }
    static set linkResolver(resolver: DocumentLinkResolver | null) {
        getGlobals().linkResolver = resolver;
    }

    static get referenceResolver(): DocumentReferenceResolver | null {
        return getGlobals().referenceResolver;
    }
    static set referenceResolver(resolver: DocumentReferenceResolver | null) {
        getGlobals().referenceResolver = resolver;
    }

    static get businessFieldsResolver(): BusinessFieldsResolver | null {
        return getGlobals().businessFieldsResolver;
    }
    static set businessFieldsResolver(resolver: BusinessFieldsResolver | null) {
        getGlobals().businessFieldsResolver = resolver;
    }

    /**
     * Register the email sender implementation (provided by host app).
     * Must be called during server startup.
     */
    static registerEmailSender(sender: IEmailSender): void {
        this.emailSender = sender;
        LOG.info('Email sender registered');
    }

    /**
     * Set a function that resolves a document link URL from referenceId + referenceType.
     * Used in email templates for "View Document" buttons.
     */
    static setDocumentLinkResolver(resolver: DocumentLinkResolver): void {
        this.linkResolver = resolver;
    }

    /**
     * Set a function that resolves a human-readable document reference from referenceId.
     * E.g. UUID → fileName. Falls back to raw referenceId if not registered or returns null.
     */
    static setDocumentReferenceResolver(resolver: DocumentReferenceResolver): void {
        this.referenceResolver = resolver;
        LOG.info('Document reference resolver registered');
    }

    /**
     * Set a function that resolves dynamic business field values from extraction data.
     * Called with the requested fields from notificationSettings.businessFields.
     * Host app reads extractionData JSON and returns label-value pairs.
     */
    static setBusinessFieldsResolver(resolver: BusinessFieldsResolver): void {
        this.businessFieldsResolver = resolver;
        LOG.info('Business fields resolver registered');
    }

    /**
     * Check if notifications are enabled (email sender registered).
     */
    static get isEnabled(): boolean {
        return this.emailSender !== null;
    }

    // ═════════════════════════════════════════════════════════════════════════
    // Notification Methods
    // ═════════════════════════════════════════════════════════════════════════

    /**
     * Notify an approver that they have been assigned a task.
     * Supports both USER and GROUP assignees.
     *
     * @param ctx Pre-fetched notification context from the caller's transaction.
     *   Avoids the cds.spawn() race condition where the spawned context cannot
     *   see uncommitted data.
     */
    static async notifyTaskAssigned(
        taskId: string,
        assigneeId: string,
        assigneeName: string,
        stepName: string,
        workflowId: string,
        assigneeType: string,
        ctx: IWorkflowNotificationContext | null
    ): Promise<void> {
        if (!this.emailSender || !ctx) return;

        try {
            LOG.info(`Resolving TASK_ASSIGNED recipients: type=${assigneeType}, id=${assigneeId}`);

            const wfInfo = ctx;

            // Check if this event is enabled for this workflow
            if (!this.isEventEnabled('TASK_ASSIGNED', wfInfo?.notificationSettings)) {
                LOG.info(`TASK_ASSIGNED notification disabled for workflow ${workflowId}`);
                return;
            }

            const recipients = await this.resolveRecipients(assigneeType, assigneeId);
            if (recipients.length === 0) {
                LOG.warn(`No recipients resolved for TASK_ASSIGNED: type=${assigneeType}, id=${assigneeId}`);
                return;
            }

            const vars: EmailTemplateVars = {
                assigneeName,
                stepName,
                workflowType: wfInfo?.workflowType,
                documentReference: wfInfo
                    ? await this.resolveDocumentReference(wfInfo.referenceId, wfInfo.referenceType)
                    : undefined,
                documentLink: wfInfo
                    ? this.resolveLink(wfInfo.referenceId, wfInfo.referenceType)
                    : undefined,
                objectType: wfInfo?.objectType,
                businessFields: wfInfo
                    ? await this.resolveBusinessFields(wfInfo.referenceId, wfInfo.referenceType, wfInfo.notificationSettings)
                    : undefined,
            };

            const { subject, htmlBody } = this.renderEmail('TASK_ASSIGNED', vars, wfInfo?.notificationSettings);
            await this.sendToRecipients(recipients, subject, htmlBody);
            LOG.info(`Sent TASK_ASSIGNED to ${recipients.join(', ')} for task ${taskId}`);
        } catch (err: any) {
            LOG.warn(`Failed to send TASK_ASSIGNED for task ${taskId}:`, err.message);
        }
    }

    /**
     * Notify the responsible person that a task was decided (approved/rejected).
     *
     * @param ctx Pre-fetched notification context from the caller's transaction.
     *   Avoids the cds.spawn() race condition where the spawned context cannot
     *   see uncommitted data (e.g. after handleRejection writes).
     */
    static async notifyTaskDecided(
        taskId: string,
        deciderName: string,
        decision: 'APPROVED' | 'REJECTED',
        comment: string | undefined,
        stepName: string,
        workflowId: string,
        ctx: IWorkflowNotificationContext | null
    ): Promise<void> {
        if (!this.emailSender || !ctx) return;

        try {
            const wfInfo = ctx;

            const eventType: NotificationEventType = decision === 'APPROVED' ? 'TASK_APPROVED' : 'TASK_REJECTED';

            // Check if this event is enabled for this workflow
            if (!this.isEventEnabled(eventType, wfInfo.notificationSettings)) {
                LOG.info(`${eventType} notification disabled for workflow ${workflowId}`);
                return;
            }

            // Resolve recipients: use Responsible Person if configured,
            // fallback to the Submitter (workflow creator) when responsibleId is absent.
            let recipients: string[] = [];
            if (wfInfo.responsibleId) {
                recipients = await this.resolveRecipients(wfInfo.responsibleType, wfInfo.responsibleId);
                if (recipients.length === 0) {
                    LOG.warn(`${eventType}: responsible ${wfInfo.responsibleId} resolved to no email — skipped`);
                    return;
                }
            } else if (wfInfo.submitterId) {
                // No responsible configured — fall back to the submitter (createdBy)
                LOG.info(`${eventType}: no responsible configured, falling back to submitter ${wfInfo.submitterId}`);
                recipients = await this.resolveRecipients('USER', wfInfo.submitterId);
            }

            if (recipients.length === 0) {
                LOG.warn(`${eventType}: no recipients resolved for task ${taskId} — notification skipped`);
                return;
            }

            const template: EmailTemplateType = decision === 'APPROVED' ? 'TASK_APPROVED' : 'TASK_REJECTED';
            const recipientName = wfInfo.responsibleName || wfInfo.submitterName || 'Unknown';
            const vars: EmailTemplateVars = {
                approverName: deciderName,
                responsibleName: recipientName,
                stepName,
                workflowType: wfInfo.workflowType,
                documentReference: await this.resolveDocumentReference(wfInfo.referenceId, wfInfo.referenceType),
                documentLink: this.resolveLink(wfInfo.referenceId, wfInfo.referenceType),
                comment,
                objectType: wfInfo.objectType,
                businessFields: await this.resolveBusinessFields(wfInfo.referenceId, wfInfo.referenceType, wfInfo.notificationSettings),
            };

            const { subject, htmlBody } = this.renderEmail(eventType, vars, wfInfo.notificationSettings);
            await this.sendToRecipients(recipients, subject, htmlBody);
            LOG.info(`Sent ${template} to ${recipients.join(', ')} for task ${taskId}`);
        } catch (err: any) {
            LOG.warn(`Failed to send task decision notification:`, err.message);
        }
    }

    /**
     * Notify the responsible person that the workflow is completed.
     *
     * @param ctx Pre-fetched notification context from the caller's transaction.
     */
    static async notifyWorkflowCompleted(
        workflowId: string,
        ctx: IWorkflowNotificationContext | null
    ): Promise<void> {
        if (!this.emailSender || !ctx) return;

        try {
            const wfInfo = ctx;

            // Check if this event is enabled for this workflow
            if (!this.isEventEnabled('WORKFLOW_COMPLETED', wfInfo.notificationSettings)) {
                LOG.info(`WORKFLOW_COMPLETED notification disabled for workflow ${workflowId}`);
                return;
            }

            // Resolve recipients: use Responsible Person if configured,
            // fallback to the Submitter (workflow creator) when responsibleId is absent.
            let recipients: string[] = [];
            if (wfInfo.responsibleId) {
                recipients = await this.resolveRecipients(wfInfo.responsibleType, wfInfo.responsibleId);
                LOG.info(`WORKFLOW_COMPLETED: using responsibleId=${wfInfo.responsibleId} (${recipients.length} recipients)`);
                if (recipients.length === 0) {
                    LOG.warn(`WORKFLOW_COMPLETED: responsible ${wfInfo.responsibleId} resolved to no email — skipped (no submitter fallback when responsible is configured)`);
                    return;
                }
            } else if (wfInfo.submitterId) {
                // No responsible configured — fall back to the submitter (createdBy)
                LOG.info(`WORKFLOW_COMPLETED: no responsible configured, falling back to submitter ${wfInfo.submitterId}`);
                recipients = await this.resolveRecipients('USER', wfInfo.submitterId);
            }

            if (recipients.length === 0) {
                LOG.warn(`WORKFLOW_COMPLETED: no recipients resolved for workflow ${workflowId}, notification skipped`);
                return;
            }

            const recipientName = wfInfo.responsibleName || wfInfo.submitterName || 'Unknown';

            const vars: EmailTemplateVars = {
                workflowType: wfInfo.workflowType,
                documentReference: await this.resolveDocumentReference(wfInfo.referenceId, wfInfo.referenceType),
                responsibleName: recipientName,
                documentLink: this.resolveLink(wfInfo.referenceId, wfInfo.referenceType),
                businessFields: await this.resolveBusinessFields(wfInfo.referenceId, wfInfo.referenceType, wfInfo.notificationSettings),
            };

            const { subject, htmlBody } = this.renderEmail('WORKFLOW_COMPLETED', vars, wfInfo.notificationSettings);
            await this.sendToRecipients(recipients, subject, htmlBody);
            LOG.info(`Sent WORKFLOW_COMPLETED to ${recipients.join(', ')} for workflow ${workflowId}`);
        } catch (err: any) {
            LOG.warn(`Failed to send WORKFLOW_COMPLETED:`, err.message);
        }
    }

    /**
     * Notify the responsible person that the workflow was rejected.
     *
     * @param ctx Pre-fetched notification context from the caller's transaction.
     */
    static async notifyWorkflowRejected(
        workflowId: string,
        rejectorName: string,
        comment: string | undefined,
        ctx: IWorkflowNotificationContext | null
    ): Promise<void> {
        if (!this.emailSender || !ctx) return;

        try {
            const wfInfo = ctx;

            // Check if this event is enabled for this workflow
            if (!this.isEventEnabled('WORKFLOW_REJECTED', wfInfo.notificationSettings)) {
                LOG.info(`WORKFLOW_REJECTED notification disabled for workflow ${workflowId}`);
                return;
            }

            let recipients: string[] = [];
            if (wfInfo.responsibleId) {
                recipients = await this.resolveRecipients(wfInfo.responsibleType, wfInfo.responsibleId);
                LOG.info(`WORKFLOW_REJECTED: using responsibleId=${wfInfo.responsibleId} (${recipients.length} recipients)`);
                if (recipients.length === 0) {
                    LOG.warn(`WORKFLOW_REJECTED: responsible ${wfInfo.responsibleId} resolved to no email — skipped (no submitter fallback when responsible is configured)`);
                    return;
                }
            } else if (wfInfo.submitterId) {
                LOG.info(`WORKFLOW_REJECTED: no responsible configured, falling back to submitter ${wfInfo.submitterId}`);
                recipients = await this.resolveRecipients('USER', wfInfo.submitterId);
            }

            if (recipients.length === 0) {
                LOG.warn(`WORKFLOW_REJECTED: no recipients resolved for workflow ${workflowId}, notification skipped`);
                return;
            }

            const recipientName = wfInfo.responsibleName || wfInfo.submitterName || 'Unknown';

            const vars: EmailTemplateVars = {
                workflowType: wfInfo.workflowType,
                documentReference: await this.resolveDocumentReference(wfInfo.referenceId, wfInfo.referenceType),
                approverName: rejectorName,
                responsibleName: recipientName,
                objectType: wfInfo.objectType,
                comment,
                documentLink: this.resolveLink(wfInfo.referenceId, wfInfo.referenceType),
                businessFields: await this.resolveBusinessFields(wfInfo.referenceId, wfInfo.referenceType, wfInfo.notificationSettings),
            };

            const { subject, htmlBody } = this.renderEmail('WORKFLOW_REJECTED', vars, wfInfo.notificationSettings);
            await this.sendToRecipients(recipients, subject, htmlBody);
            LOG.info(`Sent WORKFLOW_REJECTED to ${recipients.join(', ')} for workflow ${workflowId}`);
        } catch (err: any) {
            LOG.warn(`Failed to send WORKFLOW_REJECTED:`, err.message);
        }
    }

    /**
     * Notify the new assignee that a task has been reassigned to them.
     *
     * @param ctx Pre-fetched notification context from the caller's transaction.
     */
    static async notifyTaskReassigned(
        taskId: string,
        newAssigneeId: string,
        newAssigneeName: string,
        newAssigneeType: string,
        reassignerName: string,
        reason: string,
        stepName: string,
        workflowId: string,
        ctx: IWorkflowNotificationContext | null
    ): Promise<void> {
        if (!this.emailSender) return;

        try {
            LOG.info(`Resolving TASK_REASSIGNED recipients: type=${newAssigneeType}, id=${newAssigneeId}`);
            const wfInfo = ctx;

            // Check if this event is enabled for this workflow
            if (!this.isEventEnabled('TASK_REASSIGNED', wfInfo?.notificationSettings)) {
                LOG.info(`TASK_REASSIGNED notification disabled for workflow ${workflowId}`);
                return;
            }

            const recipients = await this.resolveRecipients(newAssigneeType, newAssigneeId);
            if (recipients.length === 0) {
                LOG.warn(`No recipients resolved for TASK_REASSIGNED: type=${newAssigneeType}, id=${newAssigneeId}`);
                return;
            }

            const vars: EmailTemplateVars = {
                assigneeName: newAssigneeName,
                reassignerName,
                comment: reason,
                stepName,
                workflowType: wfInfo?.workflowType,
                documentReference: wfInfo
                    ? await this.resolveDocumentReference(wfInfo.referenceId, wfInfo.referenceType)
                    : undefined,
                documentLink: wfInfo
                    ? this.resolveLink(wfInfo.referenceId, wfInfo.referenceType)
                    : undefined,
                objectType: wfInfo?.objectType,
                businessFields: wfInfo
                    ? await this.resolveBusinessFields(wfInfo.referenceId, wfInfo.referenceType, wfInfo.notificationSettings)
                    : undefined,
            };

            const { subject, htmlBody } = this.renderEmail('TASK_REASSIGNED', vars, wfInfo?.notificationSettings);
            await this.sendToRecipients(recipients, subject, htmlBody);
            LOG.info(`Sent TASK_REASSIGNED to ${recipients.join(', ')} for task ${taskId}`);
        } catch (err: any) {
            LOG.warn(`Failed to send TASK_REASSIGNED for task ${taskId}:`, err.message);
        }
    }

    /**
     * Send a reminder email to the currently assigned approver(s) of a workflow.
     * Triggered manually by the responsible person from the "My Requests" view.
     *
     * Finds the ACTIVE step → PENDING tasks → resolves assignee emails → sends reminder.
     *
     * @param workflowId The workflow instance to remind approvers for
     */
    static async notifyTaskReminder(workflowId: string): Promise<{ reminded: number }> {
        if (!this.emailSender) {
            throw new Error('Email sender not registered. Cannot send reminder.');
        }

        const wfInfo = await this.getWorkflowInfo(workflowId);
        if (!wfInfo) {
            throw new Error(`Workflow '${workflowId}' not found`);
        }

        // Check if this event is enabled
        if (!this.isEventEnabled('TASK_REMINDER', wfInfo.notificationSettings)) {
            LOG.info(`TASK_REMINDER notification disabled for workflow ${workflowId}`);
            return { reminded: 0 };
        }

        // Find the active step
        const activeStep = await cds.run(
            SELECT.one.from(CDS_ENTITIES.StepInstance)
                .columns('ID', 'stepName')
                .where({ workflowInstance_ID: workflowId, status: 'ACTIVE' })
        ) as { ID: string; stepName?: string } | null;

        if (!activeStep) {
            LOG.warn(`No active step found for workflow ${workflowId} — no reminder sent`);
            return { reminded: 0 };
        }

        // Find pending tasks on the active step
        const pendingTasks = await cds.run(
            SELECT.from(CDS_ENTITIES.ApprovalTask)
                .columns('ID', 'assigneeId', 'assigneeType')
                .where({ stepInstance_ID: activeStep.ID, status: 'PENDING' })
        ) as { ID: string; assigneeId: string; assigneeType: string }[];

        if (pendingTasks.length === 0) {
            LOG.warn(`No pending tasks on active step for workflow ${workflowId}`);
            return { reminded: 0 };
        }

        let remindedCount = 0;

        for (const task of pendingTasks) {
            try {
                const recipients = await this.resolveRecipients(task.assigneeType, task.assigneeId);
                if (recipients.length === 0) continue;

                const assigneeName = await PrincipalResolver.resolveName(task.assigneeType, task.assigneeId);

                const vars: EmailTemplateVars = {
                    assigneeName: assigneeName || 'Approver',
                    stepName: activeStep.stepName,
                    workflowType: wfInfo.workflowType,
                    documentReference: await this.resolveDocumentReference(wfInfo.referenceId, wfInfo.referenceType),
                    documentLink: this.resolveLink(wfInfo.referenceId, wfInfo.referenceType),
                    objectType: wfInfo.objectType,
                    responsibleName: wfInfo.responsibleName,
                    businessFields: await this.resolveBusinessFields(wfInfo.referenceId, wfInfo.referenceType, wfInfo.notificationSettings),
                };

                const { subject, htmlBody } = this.renderEmail('TASK_REMINDER', vars, wfInfo.notificationSettings);
                await this.sendToRecipients(recipients, subject, htmlBody);
                remindedCount++;
                LOG.info(`Sent TASK_REMINDER to ${recipients.join(', ')} for task ${task.ID}`);
            } catch (err: any) {
                LOG.warn(`Failed to send TASK_REMINDER for task ${task.ID}:`, err.message);
            }
        }

        LOG.info(`TASK_REMINDER: reminded ${remindedCount}/${pendingTasks.length} approvers for workflow ${workflowId}`);
        return { reminded: remindedCount };
    }

    /**
     * Send a test email to a specific recipient using a rendered template.
     * Used by admin UI to preview how emails look in actual email clients.
     *
     * @param eventType The notification event type to render
     * @param recipientEmail Email address to send the test to
     * @param notificationSettingsJson Optional notification settings JSON (for custom templates)
     */
    static async sendTestEmail(
        eventType: string,
        recipientEmail: string,
        notificationSettingsJson?: string
    ): Promise<void> {
        if (!this.emailSender) {
            throw new Error('Email sender not registered. Cannot send test email.');
        }

        // Parse notification settings if provided
        let settings: INotificationSettings | null = null;
        if (notificationSettingsJson) {
            try {
                settings = JSON.parse(notificationSettingsJson);
            } catch {
                LOG.warn('Invalid notificationSettings JSON for test email');
            }
        }

        const testVars = { ...SAMPLE_EMAIL_TEST_VARS };
        if (settings?.businessFields) {
            testVars.businessFields = settings.businessFields.map(bf => ({
                label: bf.label,
                fieldKey: bf.fieldKey,
                value: SAMPLE_BUSINESS_FIELD_VALUE
            }));
        }

        const { subject, htmlBody } = this.renderEmail(
            eventType as any,
            testVars,
            settings
        );

        const testSubject = `[TEST] ${subject}`;
        await this.emailSender.sendEmail(recipientEmail, testSubject, htmlBody);
        LOG.info(`Sent test email (${eventType}) to ${recipientEmail}`);
    }

    // ═════════════════════════════════════════════════════════════════════════
    // Internal Helpers
    // ═════════════════════════════════════════════════════════════════════════

    /**
     * Pre-fetch notification context within the caller's transaction.
     * Call this BEFORE cds.spawn() to avoid race conditions where the spawned
     * context cannot see uncommitted data.
     */
    static async preloadNotificationContext(
        workflowId: string
    ): Promise<IWorkflowNotificationContext | null> {
        return this.getWorkflowInfo(workflowId);
    }

    private static async getWorkflowInfo(workflowId: string): Promise<{
        referenceId: string;
        referenceType: string;
        workflowType: string;
        responsibleType: string;
        responsibleId: string;
        responsibleName?: string;
        /** UUID of the person who submitted/created the workflow (createdBy_ID). Used as fallback recipient. */
        submitterId?: string;
        submitterName?: string;
        objectType?: string;
        notificationSettings?: INotificationSettings | null;
    } | null> {
        const wf = await cds.run(
            SELECT.one.from(CDS_ENTITIES.WorkflowInstance)
                .columns('referenceId', 'referenceType', 'workflowType',
                    'responsibleType', 'responsibleId', 'definition_ID', 'createdBy_ID')
                .where({ ID: workflowId })
        ) as any;

        if (!wf) {
            LOG.warn(`Workflow ${workflowId} not found for notification`);
            return null;
        }

        // Resolve the responsible person's display name (responsibleName is virtual — not in DB)
        let responsibleName: string | undefined;
        if (wf.responsibleId) {
            try {
                responsibleName = await PrincipalResolver.resolveName(
                    wf.responsibleType || 'USER', wf.responsibleId
                );
            } catch (e: any) {
                LOG.warn(`Failed to resolve responsible name for ${wf.responsibleId}: ${e.message}`);
                responsibleName = undefined;
            }
        }

        // Resolve the submitter's display name (createdBy = who submitted the workflow)
        let submitterName: string | undefined;
        if (wf.createdBy_ID) {
            try {
                submitterName = await PrincipalResolver.resolveName('USER', wf.createdBy_ID);
            } catch (e: any) {
                LOG.warn(`Failed to resolve submitter name for ${wf.createdBy_ID}: ${e.message}`);
                submitterName = undefined;
            }
        }

        // Resolve objectType and notificationSettings from the definition
        let objectType: string | undefined;
        let notificationSettings: INotificationSettings | null = null;
        if (wf.definition_ID) {
            try {
                const def = await cds.run(
                    SELECT.one.from(CDS_ENTITIES.WorkflowDefinition)
                        .columns('objectType', 'notificationSettings')
                        .where({ ID: wf.definition_ID })
                ) as { objectType?: string; notificationSettings?: string } | null;
                objectType = def?.objectType;

                // Parse notification settings JSON
                if (def?.notificationSettings) {
                    try {
                        notificationSettings = JSON.parse(def.notificationSettings) as INotificationSettings;
                    } catch (parseErr) {
                        LOG.warn(`Invalid notificationSettings JSON for definition ${wf.definition_ID}`);
                    }
                }
            } catch {
                objectType = undefined;
            }
        }

        return {
            referenceId: wf.referenceId,
            referenceType: wf.referenceType,
            workflowType: wf.workflowType,
            responsibleType: wf.responsibleType || 'USER',
            responsibleId: wf.responsibleId,
            responsibleName,
            submitterId: wf.createdBy_ID || undefined,
            submitterName,
            objectType,
            notificationSettings,
        };
    }

    // ─── Notification Settings Helpers ───────────────────────────────────────

    /**
     * Check if a notification event is enabled for the given workflow settings.
     * Opt-out model: null/missing settings = all enabled; missing event key = enabled.
     */
    private static isEventEnabled(
        eventType: NotificationEventType,
        settings?: INotificationSettings | null
    ): boolean {
        if (!settings || !settings.events) return true; // All enabled by default
        const eventConfig = settings.events[eventType];
        if (!eventConfig) return true; // Event not mentioned = enabled
        return eventConfig.enabled !== false;
    }

    /**
     * Resolve a human-readable document reference from referenceId.
     * Falls back to raw referenceId if resolver is not registered or returns null.
     */
    private static async resolveDocumentReference(
        referenceId: string, referenceType: string
    ): Promise<string> {
        if (!this.referenceResolver) return referenceId;
        try {
            const resolved = await this.referenceResolver(referenceId, referenceType);
            return resolved || referenceId;
        } catch (err: any) {
            LOG.warn(`Document reference resolver failed for ${referenceId}: ${err.message}`);
            return referenceId;
        }
    }

    /**
     * Resolve dynamic business field values from notificationSettings.businessFields.
     * Returns empty array if resolver is not registered or no fields configured.
     */
    private static async resolveBusinessFields(
        referenceId: string, referenceType: string,
        settings?: INotificationSettings | null
    ): Promise<Array<{ label: string; value: string; fieldKey?: string }>> {
        const fields = settings?.businessFields;
        if (!fields || fields.length === 0) return [];
        if (!this.businessFieldsResolver) {
            LOG.warn('resolveBusinessFields: businessFieldsResolver is not registered');
            return [];
        }
        try {
            const resolved = await this.businessFieldsResolver(referenceId, referenceType, fields);
            LOG.debug(`resolveBusinessFields: resolver returned ${resolved.length} fields for ${referenceId}`);
            return resolved.map(r => {
                const config = fields.find(f => f.label === r.label);
                return { ...r, fieldKey: config?.fieldKey };
            });
        } catch (err: any) {
            LOG.warn(`Business fields resolver failed for ${referenceId}: ${err.message}`);
            return [];
        }
    }

    /**
     * Render email using custom template if configured, otherwise use default.
     */
    private static renderEmail(
        eventType: NotificationEventType,
        vars: EmailTemplateVars,
        settings?: INotificationSettings | null
    ): { subject: string; htmlBody: string } {
        // Check for custom template
        const customTemplate = settings?.events?.[eventType]?.template;
        if (customTemplate) {
            LOG.info(`Using custom template for ${eventType}`);
            return renderStructuredTemplate(customTemplate, vars);
        }
        // Fallback to default template
        return renderEmailTemplate(eventType as EmailTemplateType, vars);
    }

    /**
     * Resolve email recipients based on principal type.
     *
     * USER  → [user.email]
     * GROUP → depends on emailNotificationMode:
     *   GROUP_ONLY   → [groupEmail]
     *   MEMBERS_ONLY → [member1.email, member2.email, ...]
     *   BOTH         → [groupEmail, member1.email, ...]
     */
    private static async resolveRecipients(
        principalType: string,
        principalId?: string
    ): Promise<string[]> {
        if (!principalId) return [];

        try {
            if (principalType === 'USER') {
                const email = await this.resolveUserEmail(principalId);
                return email ? [email] : [];
            }

            // GROUP, TEAM, DEPARTMENT, etc. — all look up ShadowGroups
            return await this.resolveGroupRecipients(principalId);
        } catch (err: any) {
            LOG.warn(`Failed to resolve recipients for ${principalType}/${principalId}:`, err.message);
            return [];
        }
    }

    /**
     * Resolve a single user's email from ShadowUsers.
     */
    private static async resolveUserEmail(shadowUserId: string): Promise<string | null> {
        try {
            const user = await cds.run(
                SELECT.one.from(IDENTITY_ENTITIES.ShadowUsers)
                    .columns('email')
                    .where({ ID: shadowUserId })
            ) as { email: string } | null;
            if (!user) {
                LOG.warn(`ShadowUser not found for ID=${shadowUserId}`);
            } else if (!user.email) {
                LOG.warn(`ShadowUser ${shadowUserId} has no email address`);
            }
            return user?.email || null;
        } catch (err: any) {
            LOG.warn(`Failed to resolve email for user ${shadowUserId}:`, err.message);
            return null;
        }
    }

    /**
     * Resolve email recipients for a GROUP based on its emailNotificationMode.
     *
     * GROUP_ONLY (default) → [groupEmail]
     * MEMBERS_ONLY         → [each member's email]
     * BOTH                 → [groupEmail, each member's email]
     */
    private static async resolveGroupRecipients(groupId: string): Promise<string[]> {
        // Fetch group with notification settings
        const group = await cds.run(
            SELECT.one.from(IDENTITY_ENTITIES.ShadowGroups)
                .columns('groupEmail', 'emailNotificationMode')
                .where({ ID: groupId })
        ) as { groupEmail?: string; emailNotificationMode?: string } | null;

        if (!group) {
            LOG.warn(`Group ${groupId} not found for notification`);
            return [];
        }

        const mode = group.emailNotificationMode || 'GROUP_ONLY';
        LOG.info(`Group ${groupId}: mode=${mode}, groupEmail=${group.groupEmail || '(none)'}`);
        const recipients: string[] = [];

        // Add group email if mode includes it
        if ((mode === 'GROUP_ONLY' || mode === 'BOTH') && group.groupEmail) {
            recipients.push(group.groupEmail);
        }

        // Add member emails if mode includes them
        if (mode === 'MEMBERS_ONLY' || mode === 'BOTH') {
            const memberEmails = await this.resolveGroupMemberEmails(groupId);
            LOG.info(`Group ${groupId}: resolved ${memberEmails.length} member emails: ${memberEmails.join(', ') || '(none)'}`);
            recipients.push(...memberEmails);
        }

        // Warn if GROUP_ONLY but no groupEmail configured
        if (mode === 'GROUP_ONLY' && !group.groupEmail) {
            LOG.warn(
                `Group ${groupId} has emailNotificationMode=GROUP_ONLY but no groupEmail configured — no notification sent`
            );
        }

        // Deduplicate (e.g., groupEmail could also be a member's email)
        const deduped = [...new Set(recipients)];
        LOG.info(`Group ${groupId}: final recipients (${deduped.length}): ${deduped.join(', ')}`);
        return deduped;
    }

    /**
     * Resolve all active member emails from a group.
     */
    private static async resolveGroupMemberEmails(groupId: string): Promise<string[]> {
        try {
            const members = await cds.run(
                SELECT.from(IDENTITY_ENTITIES.GroupMembers)
                    .columns('user_ID')
                    .where({ group_ID: groupId })
            ) as { user_ID: string }[];

            if (!members || members.length === 0) {
                LOG.warn(`Group ${groupId}: no members found in GroupMembers table`);
                return [];
            }

            LOG.info(`Group ${groupId}: found ${members.length} members, resolving emails...`);
            const emails: string[] = [];
            for (const member of members) {
                const email = await this.resolveUserEmail(member.user_ID);
                if (email) emails.push(email);
            }
            return emails;
        } catch (err: any) {
            LOG.error(`Group ${groupId}: FAILED to resolve member emails: ${err.message}`);
            return [];
        }
    }

    /**
     * Send an email to one or more recipients.
     * Uses sendBatch() if available and multiple recipients, otherwise falls back to individual sends.
     */
    private static async sendToRecipients(
        recipients: string[],
        subject: string,
        htmlBody: string
    ): Promise<void> {
        if (!this.emailSender || recipients.length === 0) return;

        if (recipients.length === 1) {
            await this.emailSender.sendEmail(recipients[0], subject, htmlBody);
        } else if (this.isBatchSender(this.emailSender)) {
            await this.emailSender.sendBatch(recipients, subject, htmlBody);
        } else {
            // Fallback: send individually
            for (const to of recipients) {
                await this.emailSender.sendEmail(to, subject, htmlBody);
            }
        }
    }

    /** Type guard: check if sender supports batch sending */
    private static isBatchSender(sender: IEmailSender): sender is IBatchEmailSender {
        return 'sendBatch' in sender && typeof (sender as any).sendBatch === 'function';
    }

    private static resolveLink(referenceId: string, referenceType: string): string | undefined {
        return this.linkResolver
            ? this.linkResolver(referenceId, referenceType)
            : undefined;
    }
}
