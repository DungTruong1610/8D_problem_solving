/**
 * @cnma/cap-workflow — DAG Validator
 *
 * Validates step dependency graphs using Kahn's algorithm for topological sorting.
 * Pure logic — no database dependency. Fully testable in isolation.
 *
 * Architecture Finding F4:
 *   Validates on StepDependency writes to prevent:
 *   - Circular dependencies (infinite loops)
 *   - Self-references (A → A)
 *   - Duplicate edges (A → B defined twice)
 *   - Orphaned graphs (no entry/exit points)
 *
 * @example
 * ```typescript
 * const result = DAGValidator.validate([
 *     { predecessor_ID: 'A', successor_ID: 'C' },
 *     { predecessor_ID: 'B', successor_ID: 'C' },
 *     { predecessor_ID: 'C', successor_ID: 'D' },
 * ], ['A', 'B', 'C', 'D']);
 *
 * if (!result.isValid) {
 *     throw new Error(result.errors.join('; '));
 * }
 * // result.topologicalOrder = ['A', 'B', 'C', 'D'] (or ['B', 'A', 'C', 'D'])
 * // result.startSteps = ['A', 'B']
 * // result.endSteps = ['D']
 * ```
 */

export interface IDAGEdge {
    predecessor_ID: string;
    successor_ID: string;
}

export interface IDAGValidationResult {
    isValid: boolean;
    errors: string[];
    topologicalOrder: string[];
    startSteps: string[];   // Steps with no predecessors (entry points)
    endSteps: string[];     // Steps with no successors (exit points)
}

export class DAGValidator {

    /**
     * Validate a DAG and return topological order.
     *
     * @param edges Array of dependency edges (predecessor → successor)
     * @param stepIds Array of all step IDs in the workflow definition
     * @returns Validation result with topological order if valid
     */
    static validate(edges: IDAGEdge[], stepIds: string[]): IDAGValidationResult {
        const errors: string[] = [];

        // ─── Phase 1: Structural validation ─────────────────────────────

        // Check for self-references
        for (const edge of edges) {
            if (edge.predecessor_ID === edge.successor_ID) {
                errors.push(
                    `Self-reference detected: step '${edge.predecessor_ID}' cannot depend on itself`
                );
            }
        }

        // Check for duplicate edges
        const edgeSet = new Set<string>();
        for (const edge of edges) {
            const key = `${edge.predecessor_ID}→${edge.successor_ID}`;
            if (edgeSet.has(key)) {
                errors.push(
                    `Duplicate dependency: '${edge.predecessor_ID}' → '${edge.successor_ID}' is defined more than once`
                );
            }
            edgeSet.add(key);
        }

        // Check that all referenced step IDs exist
        const stepIdSet = new Set(stepIds);
        for (const edge of edges) {
            if (!stepIdSet.has(edge.predecessor_ID)) {
                errors.push(
                    `Unknown step ID '${edge.predecessor_ID}' in dependency predecessor`
                );
            }
            if (!stepIdSet.has(edge.successor_ID)) {
                errors.push(
                    `Unknown step ID '${edge.successor_ID}' in dependency successor`
                );
            }
        }

        // If structural errors found, abort before topological sort
        if (errors.length > 0) {
            return {
                isValid: false,
                errors,
                topologicalOrder: [],
                startSteps: [],
                endSteps: [],
            };
        }

        // ─── Phase 2: Build adjacency and in-degree maps ────────────────

        const adjacency = new Map<string, string[]>();    // node → successors
        const inDegree = new Map<string, number>();       // node → number of predecessors

        // Initialize all steps
        for (const id of stepIds) {
            adjacency.set(id, []);
            inDegree.set(id, 0);
        }

        // Populate from edges
        for (const edge of edges) {
            adjacency.get(edge.predecessor_ID)!.push(edge.successor_ID);
            inDegree.set(edge.successor_ID, (inDegree.get(edge.successor_ID) || 0) + 1);
        }

        // ─── Phase 3: Kahn's algorithm — topological sort ───────────────

        // Start steps = nodes with in-degree 0 (no predecessors)
        const startSteps: string[] = [];
        const queue: string[] = [];

        for (const [id, degree] of inDegree.entries()) {
            if (degree === 0) {
                queue.push(id);
                startSteps.push(id);
            }
        }

        const topologicalOrder: string[] = [];

        while (queue.length > 0) {
            const node = queue.shift()!;
            topologicalOrder.push(node);

            for (const successor of adjacency.get(node) || []) {
                const newDegree = (inDegree.get(successor) || 1) - 1;
                inDegree.set(successor, newDegree);
                if (newDegree === 0) {
                    queue.push(successor);
                }
            }
        }

        // ─── Phase 4: Detect cycles ─────────────────────────────────────

        if (topologicalOrder.length !== stepIds.length) {
            // Some nodes not processed → cycle exists
            const cycleNodes = stepIds.filter(id => !topologicalOrder.includes(id));
            errors.push(
                `Circular dependency detected involving steps: ${cycleNodes.join(', ')}. ` +
                `A step cannot directly or indirectly depend on itself.`
            );
            return {
                isValid: false,
                errors,
                topologicalOrder: [],
                startSteps: [],
                endSteps: [],
            };
        }

        // ─── Phase 5: Identify end steps ────────────────────────────────

        // End steps = nodes with no successors
        const endSteps = stepIds.filter(id => {
            const successors = adjacency.get(id) || [];
            return successors.length === 0;
        });

        // ─── Phase 6: Entry/exit point validation ───────────────────────

        if (edges.length > 0) {
            // Only validate entry/exit when there ARE dependencies
            if (startSteps.length === 0) {
                errors.push(
                    'No start steps found: at least one step must have no predecessors (entry point)'
                );
            }
            if (endSteps.length === 0) {
                errors.push(
                    'No end steps found: at least one step must have no successors (exit point)'
                );
            }
        }

        return {
            isValid: errors.length === 0,
            errors,
            topologicalOrder,
            startSteps,
            endSteps,
        };
    }

    /**
     * Quick check: would adding a new edge create a cycle?
     * Useful for real-time validation in the admin UI.
     *
     * @param existingEdges Current edges
     * @param newEdge The proposed new edge
     * @param stepIds All step IDs
     * @returns true if the new edge would create a cycle
     */
    static wouldCreateCycle(
        existingEdges: IDAGEdge[],
        newEdge: IDAGEdge,
        stepIds: string[]
    ): boolean {
        const allEdges = [...existingEdges, newEdge];
        const result = this.validate(allEdges, stepIds);
        return !result.isValid;
    }

    /**
     * Get the execution order for steps based on dependencies.
     * If no dependencies exist, falls back to displayOrder-based sequential chain.
     *
     * @param edges Dependency edges
     * @param steps Step definitions with displayOrder
     * @returns Ordered array of step IDs for activation
     */
    static getExecutionOrder(
        edges: IDAGEdge[],
        steps: Array<{ ID: string; displayOrder: number }>
    ): string[] {
        if (edges.length === 0) {
            // No dependencies → sequential fallback based on displayOrder
            return steps
                .sort((a, b) => a.displayOrder - b.displayOrder)
                .map(s => s.ID);
        }

        const result = this.validate(edges, steps.map(s => s.ID));
        if (!result.isValid) {
            throw new Error(`Invalid DAG: ${result.errors.join('; ')}`);
        }
        return result.topologicalOrder;
    }
}
