/**
 * @cnma/cap-workflow — Step Advancer
 *
 * The core DAG traversal engine that advances workflow steps based on
 * dependency completion and approval mode rules.
 *
 * ⚠️ CRITICAL CONSTRAINT T2:
 *   All methods operate WITHIN the caller's implicit CAP transaction.
 *   NEVER call cds.tx(), cds.run() with new connection, or cds.outboxed().
 *   The forUpdate() pessimistic lock is only held within the current tx.
 *
 * Responsibilities:
 *   - Determine which steps can be activated (all predecessors complete)
 *   - Activate steps by creating ApprovalTasks from DefaultStepApprovers
 *   - Handle SEQUENTIAL vs PARALLEL approverSeqMode within steps
 *   - Handle ANY_ONE vs ALL approvalMode for step completion
 *   - Advance workflow status when all steps reach terminal state
 *   - Sequential fallback when no StepDependency rows exist
 */

import cds from '@sap/cds';
import {
    CDS_ENTITIES,
    WorkflowEventType,
    type IStepInstance,
    type IApprovalTask,
    type IStepDependency,
    type IDefaultStepApprover,
    type StepStatus,
    type ApprovalMode,
    type ApproverSeqMode,
} from './types';
import { WorkflowHistoryLogger } from './WorkflowHistoryLogger';
import { WorkflowNotifier } from './WorkflowNotifier';
import { PrincipalResolver } from './PrincipalResolver';
import { ConditionEvaluator } from './ConditionEvaluator';


/** Lightweight logger scoped to StepAdvancer */
const LOG = cds.log('workflow.step-advancer');

export class StepAdvancer {

    // ═══════════════════════════════════════════════════════════════════════
    // PUBLIC API
    // ═══════════════════════════════════════════════════════════════════════

    /**
     * Check which steps in a workflow definition have no pre-configured approvers.
     * These steps require manual approver assignment by the submitter.
     * H5: Uses batch SELECT instead of N+1 per-step queries.
     *
     * @param definitionId The workflow definition ID
     * @returns Array of steps needing manual approver assignment (empty = all steps have approvers)
     */
    static async getStepsNeedingApprovers(
        definitionId: string,
        documentData?: Record<string, unknown>
    ): Promise<Array<{
        stepDefinitionId: string;
        stepName: string;
        displayOrder: number;
        approvalMode: string;
    }>> {
        const steps = await cds.run(
            SELECT.from(CDS_ENTITIES.WorkflowStepDefinition)
                .where({ definition_ID: definitionId })
                .orderBy('displayOrder asc')
        ) as any[];

        if (steps.length === 0) return [];

        // H5: Single batch SELECT instead of N queries
        const stepIds = steps.map(s => s.ID);
        const allApprovers = await cds.run(
            SELECT.from(CDS_ENTITIES.DefaultStepApprover)
                .columns('step_ID')
                .where({ step_ID: { in: stepIds } })
        ) as Array<{ step_ID: string }>;

        // Build set of step IDs that have at least one approver
        const stepsWithApprovers = new Set(allApprovers.map(a => a.step_ID));

        const needsApprovers = steps
            .filter(step => {
                // If it already has approvers, we don't need manual assignment
                if (stepsWithApprovers.has(step.ID)) return false;
                
                // If condition evaluates to false, step will be skipped, so no approver needed
                if (step.conditionExpr && documentData) {
                    try {
                        const matches = ConditionEvaluator.evaluate(step.conditionExpr, documentData);
                        if (!matches) return false;
                    } catch (err: any) {
                        LOG.warn(`Failed to evaluate conditionExpr for step '${step.stepName}':`, err.message);
                    }
                }
                
                return true;
            })
            .map(step => ({
                stepDefinitionId: step.ID,
                stepName: step.stepName,
                displayOrder: step.displayOrder,
                approvalMode: step.approvalMode || 'ALL',
            }));

        LOG.info(`Definition ${definitionId}: ${needsApprovers.length}/${steps.length} steps need approver assignment`);
        return needsApprovers;
    }

    /**
     * After a task decision, check if the step should be completed,
     * and if so, check which successor steps can be activated.
     *
     * Call this AFTER updating an ApprovalTask status.
     * Runs within the caller's transaction (T2).
     *
     * @param stepInstanceId The step instance that was just acted upon
     * @param workflowInstanceId The parent workflow instance
     */
    static async tryAdvanceStep(stepInstanceId: string, workflowInstanceId: string): Promise<void> {
        const step = await cds.run(
            SELECT.one.from(CDS_ENTITIES.StepInstance)
                .where({ ID: stepInstanceId })
        ) as IStepInstance | null;

        if (!step || step.status !== 'ACTIVE') {
            LOG.debug('Step not active, skipping advance', { stepInstanceId, status: step?.status });
            return;
        }

        // Get all tasks for this step
        const tasks = await cds.run(
            SELECT.from(CDS_ENTITIES.ApprovalTask)
                .where({ stepInstance_ID: stepInstanceId })
        ) as IApprovalTask[];

        // Determine if the step should be completed
        const stepResult = this.evaluateStepCompletion(
            tasks,
            step.approvalMode as ApprovalMode || 'ALL'
        );

        if (stepResult === null) {
            // Step not yet complete — check for sequential approver activation
            if (step.approverSeqMode === 'SEQUENTIAL') {
                await this.activateNextSequentialApprover(stepInstanceId, tasks);
            }
            return;
        }

        // Step is complete (APPROVED or REJECTED)
        const now = new Date().toISOString();
        await cds.run(
            UPDATE(CDS_ENTITIES.StepInstance)
                .set({ status: stepResult, completedAt: now })
                .where({ ID: stepInstanceId })
        );

        LOG.info('Step completed', { stepInstanceId, result: stepResult, stepName: step.stepName });

        // Log history
        await this.logHistory(workflowInstanceId, stepInstanceId, null,
            stepResult === 'APPROVED' ? WorkflowEventType.STEP_COMPLETED : WorkflowEventType.STEP_REJECTED,
            step.stepName || '', 'ACTIVE', stepResult, true
        );

        if (stepResult === 'APPROVED') {
            // Activate successor steps
            await this.activateReadySuccessors(workflowInstanceId, stepInstanceId);
        }
        // If REJECTED, the workflow-level rejection is handled by the caller (WorkflowEngine/ApprovalHandler)
    }

    /**
     * Check if all steps in the workflow are in a terminal state.
     * If so, mark the workflow as COMPLETED.
     *
     * Call this AFTER tryAdvanceStep().
     * Runs within the caller's transaction (T2).
     *
     * @param workflowInstanceId The workflow instance to check
     * @returns The new workflow status, or null if not yet terminal
     */
    static async tryAdvanceWorkflow(workflowInstanceId: string): Promise<'COMPLETED' | null> {
        const steps = await cds.run(
            SELECT.from(CDS_ENTITIES.StepInstance)
                .columns('ID', 'status', 'stepName')
                .where({ workflowInstance_ID: workflowInstanceId })
        ) as IStepInstance[];

        // All steps must be in a terminal state (APPROVED, REJECTED, or SKIPPED)
        const terminalStatuses: StepStatus[] = ['APPROVED', 'REJECTED', 'SKIPPED'];
        const allTerminal = steps.every(s => terminalStatuses.includes(s.status));

        if (!allTerminal) {
            return null;
        }

        // Check if any step was rejected — if so, workflow rejection is handled separately
        const anyRejected = steps.some(s => s.status === 'REJECTED');
        if (anyRejected) {
            // Rejection handling is done by ApprovalHandler → WorkflowEngine.handleRejection()
            return null;
        }

        // All steps approved → workflow completed
        const now = new Date().toISOString();
        await cds.run(
            UPDATE(CDS_ENTITIES.WorkflowInstance)
                .set({ status: 'COMPLETED', completedAt: now })
                .where({ ID: workflowInstanceId })
        );

        LOG.info('Workflow completed — all steps approved', { workflowInstanceId });

        // Log history
        await this.logHistory(workflowInstanceId, null, null,
            WorkflowEventType.COMPLETED, '', 'ACTIVE', 'COMPLETED', true
        );

        // Pre-fetch notification context in main tx before cds.spawn
        const ctx = await WorkflowNotifier.preloadNotificationContext(workflowInstanceId);

        // Notify responsible person (fire-and-forget)
        cds.spawn({}, async () => {
            // MUST await: cds.spawn commits its detached tx as soon as this callback
            // resolves — without await the connection is orphaned → pool leak.
            await WorkflowNotifier.notifyWorkflowCompleted(workflowInstanceId, ctx)
                .catch(err => LOG.warn('Failed to send WORKFLOW_COMPLETED notification:', err.message));
        });

        return 'COMPLETED';
    }

    /**
     * Activate the initial start steps when a workflow is started.
     * Start steps are those with no predecessors in the DAG,
     * or the first step by displayOrder if no dependencies exist.
     *
     * @param workflowInstanceId The workflow instance being started
     */
    static async activateStartSteps(workflowInstanceId: string): Promise<void> {
        const instance = await cds.run(
            SELECT.one.from(CDS_ENTITIES.WorkflowInstance)
                .columns('ID', 'definition_ID')
                .where({ ID: workflowInstanceId })
        ) as { ID: string; definition_ID: string } | null;

        if (!instance?.definition_ID) {
            throw new Error(`Workflow instance '${workflowInstanceId}' not found or has no definition`);
        }

        // Get step instances
        const stepInstances = await cds.run(
            SELECT.from(CDS_ENTITIES.StepInstance)
                .where({ workflowInstance_ID: workflowInstanceId })
                .orderBy('displayOrder asc')
        ) as IStepInstance[];

        if (stepInstances.length === 0) {
            throw new Error(`Workflow instance '${workflowInstanceId}' has no step instances`);
        }

        // Get dependencies from the template
        const dependencies = await cds.run(
            SELECT.from(CDS_ENTITIES.StepDependency)
                .where({ definition_ID: instance.definition_ID })
        ) as IStepDependency[];

        // Build step definition → instance mapping
        const defToInstance = new Map<string, IStepInstance>();
        for (const si of stepInstances) {
            if (si.stepDefinition_ID) {
                defToInstance.set(si.stepDefinition_ID, si);
            }
        }

        if (dependencies.length === 0) {
            // Sequential fallback: activate the first step only
            LOG.info('No dependencies — sequential fallback, activating first step');
            await this.activateStep(stepInstances[0].ID, workflowInstanceId);
        } else {
            // DAG mode: find start steps (steps whose definition has no predecessors)
            const hasPrecessor = new Set(dependencies.map(d => d.successor_ID));

            for (const si of stepInstances) {
                if (si.stepDefinition_ID && !hasPrecessor.has(si.stepDefinition_ID)) {
                    await this.activateStep(si.ID, workflowInstanceId);
                }
            }
        }
    }

    // ═══════════════════════════════════════════════════════════════════════
    // STEP ACTIVATION
    // ═══════════════════════════════════════════════════════════════════════

    /**
     * Activate a step: set status to ACTIVE, create ApprovalTasks from
     * the DefaultStepApprovers. Respects approverSeqMode (C13).
     *
     * @param stepInstanceId The step instance to activate
     * @param workflowInstanceId The parent workflow instance
     */
    static async activateStep(stepInstanceId: string, workflowInstanceId: string): Promise<void> {
        const step = await cds.run(
            SELECT.one.from(CDS_ENTITIES.StepInstance)
                .where({ ID: stepInstanceId })
        ) as IStepInstance | null;

        if (!step) {
            throw new Error(`Step instance '${stepInstanceId}' not found`);
        }

        if (step.status !== 'PENDING') {
            LOG.debug('Step not in PENDING state, skipping activation', {
                stepInstanceId, status: step.status
            });
            return;
        }

        // ── Check for pre-existing tasks (created by approverOverrides) ──
        const existingTasks = await cds.run(
            SELECT.from(CDS_ENTITIES.ApprovalTask)
                .where({ stepInstance_ID: stepInstanceId })
        ) as IApprovalTask[];

        if (existingTasks.length > 0) {
            // Tasks already created by WorkflowEngine.applyApproverOverrides().
            // Set the step to ACTIVE — tasks are ready.
            //
            // M2 (SEQUENTIAL + overrides): All override tasks are stored as PENDING.
            // We do NOT set non-first tasks to a separate "waiting" state here because
            // TaskStatus has no WAITING value and the sequential ordering is enforced
            // at decision time by ApprovalHandler.validateTaskAuthorization(), which
            // blocks any task whose predecessors (by taskOrder) are still PENDING.
            // The UI should use the `isActionable` flag from getProcessFlow() to
            // indicate which task is currently active for the user.
            const now = new Date().toISOString();
            await cds.run(
                UPDATE(CDS_ENTITIES.StepInstance)
                    .set({ status: 'ACTIVE', activatedAt: now })
                    .where({ ID: stepInstanceId })
            );

            LOG.info('Step activated with pre-assigned approvers', {
                stepInstanceId,
                stepName: step.stepName,
                taskCount: existingTasks.length,
            });

            await this.logHistory(workflowInstanceId, stepInstanceId, null,
                WorkflowEventType.STEP_ACTIVATED, step.stepName || '', 'PENDING', 'ACTIVE', true
            );

            // Notify pre-assigned approvers (fire-and-forget)
            // Pre-fetch notification context INSIDE the transaction to avoid cds.spawn()
            // race condition (spawned context can't see uncommitted data).
            const ctx = await WorkflowNotifier.preloadNotificationContext(workflowInstanceId);
            for (const task of existingTasks) {
                PrincipalResolver.resolveName(task.assigneeType, task.assigneeId)
                    .then(name =>
                        cds.spawn({}, async () => {
                            // MUST await — orphans the pooled connection without it.
                            await WorkflowNotifier.notifyTaskAssigned(
                                task.ID, task.assigneeId, name || 'Approver',
                                step.stepName || '', workflowInstanceId,
                                task.assigneeType, ctx
                            ).catch(err => LOG.warn('Failed to send TASK_ASSIGNED notification:', err.message));
                        })
                    ).catch(() => {});
            }

            return;
        }

        // ── Fallback: create tasks from DefaultStepApprovers (template) ──
        const defaultApprovers = await cds.run(
            SELECT.from(CDS_ENTITIES.DefaultStepApprover)
                .where({ step_ID: step.stepDefinition_ID })
                .orderBy('approverOrder asc')
        ) as IDefaultStepApprover[];

        if (defaultApprovers.length === 0) {
            // Safety net: step has no approvers from either source
            const errorMsg = `Step '${step.stepName}' (${stepInstanceId}) has no approvers. ` +
                `Assign approvers via the admin page or during workflow submission.`;
            LOG.error(errorMsg);
            throw new Error(errorMsg);
        }

        // Set step to ACTIVE
        const now = new Date().toISOString();
        await cds.run(
            UPDATE(CDS_ENTITIES.StepInstance)
                .set({ status: 'ACTIVE', activatedAt: now })
                .where({ ID: stepInstanceId })
        );

        // Create approval tasks (H5: batched INSERT)
        const approverSeqMode = (step.approverSeqMode || 'PARALLEL') as ApproverSeqMode;

        const taskEntries = defaultApprovers.map((approver, i) => ({
            ID: cds.utils.uuid(),
            stepInstance_ID: stepInstanceId,
            assigneeType: approver.principalType,
            assigneeId: approver.principalId,
            taskOrder: approver.approverOrder,
            status: 'PENDING' as const,
            assignmentSource: 'MANUAL' as const,
        }));

        await cds.run(
            INSERT.into(CDS_ENTITIES.ApprovalTask).entries(taskEntries)
        );

        // Log TASK_ACTIVATED history for actionable tasks
        for (let i = 0; i < taskEntries.length; i++) {
            if (approverSeqMode === 'PARALLEL' || i === 0) {
                await this.logHistory(workflowInstanceId, stepInstanceId, taskEntries[i].ID,
                    WorkflowEventType.TASK_ACTIVATED, step.stepName || '',
                    '', 'PENDING', true
                );
            }
        }

        // Notify assignees (fire-and-forget)
        // Pre-fetch notification context INSIDE the transaction to avoid cds.spawn()
        // race condition (spawned context can't see uncommitted data).
        const ctx = await WorkflowNotifier.preloadNotificationContext(workflowInstanceId);
        for (const entry of taskEntries) {
            PrincipalResolver.resolveName(entry.assigneeType, entry.assigneeId)
                .then(name =>
                        cds.spawn({}, async () => {
                        // MUST await — orphans the pooled connection without it.
                        await WorkflowNotifier.notifyTaskAssigned(
                            entry.ID, entry.assigneeId, name || 'Approver',
                            step.stepName || '', workflowInstanceId,
                            entry.assigneeType, ctx
                        ).catch(err => LOG.warn('Failed to send TASK_ASSIGNED notification:', err.message));
                    })
                ).catch(() => {});
        }

        LOG.info('Step activated', {
            stepInstanceId,
            stepName: step.stepName,
            approverCount: defaultApprovers.length,
            mode: approverSeqMode,
        });

        await this.logHistory(workflowInstanceId, stepInstanceId, null,
            WorkflowEventType.STEP_ACTIVATED, step.stepName || '', 'PENDING', 'ACTIVE', true
        );
    }

    // ═══════════════════════════════════════════════════════════════════════
    // INTERNAL: Approval Mode Evaluation
    // ═══════════════════════════════════════════════════════════════════════

    /**
     * Evaluate whether a step should be completed based on its tasks and approval mode.
     *
     * @param tasks All tasks for this step
     * @param approvalMode ANY_ONE or ALL
     * @returns 'APPROVED' | 'REJECTED' | null (not yet decided)
     */
    private static evaluateStepCompletion(
        tasks: IApprovalTask[],
        approvalMode: ApprovalMode
    ): 'APPROVED' | 'REJECTED' | null {
        if (tasks.length === 0) return null; // No tasks → step shouldn't be active without approvers

        if (approvalMode === 'ANY_ONE') {
            // ANY_ONE: First decision wins
            const decided = tasks.find(t => t.status === 'APPROVED' || t.status === 'REJECTED');
            if (decided) {
                return decided.status as 'APPROVED' | 'REJECTED';
            }
            return null; // No one has decided yet
        }

        // ALL mode: Check if everyone has decided
        const approved = tasks.filter(t => t.status === 'APPROVED');
        const rejected = tasks.filter(t => t.status === 'REJECTED');
        const pending = tasks.filter(t => t.status === 'PENDING');

        // If any rejection in ALL mode → step is rejected
        if (rejected.length > 0) {
            return 'REJECTED';
        }

        // If all approved → step is approved
        if (approved.length === tasks.length) {
            return 'APPROVED';
        }

        // Still waiting for more decisions
        return null;
    }

    // ═══════════════════════════════════════════════════════════════════════
    // INTERNAL: Sequential Approver Activation
    // ═══════════════════════════════════════════════════════════════════════

    /**
     * In SEQUENTIAL mode, after one approver decides,
     * activate the next approver in taskOrder sequence.
     * Logs a TASK_ACTIVATED event so the audit trail and notifications know
     * which approver is now "current".
     */
    private static async activateNextSequentialApprover(
        stepInstanceId: string,
        tasks: IApprovalTask[]
    ): Promise<void> {
        // Sort by taskOrder
        const sorted = [...tasks].sort((a, b) => a.taskOrder - b.taskOrder);

        // Find the step instance for logging
        const stepInstance = await cds.run(
            SELECT.one.from(CDS_ENTITIES.StepInstance)
                .columns('workflowInstance_ID', 'stepName')
                .where({ ID: stepInstanceId })
        ) as { workflowInstance_ID: string; stepName?: string } | null;

        if (!stepInstance) {
            LOG.warn('activateNextSequentialApprover: step instance not found', { stepInstanceId });
            return;
        }

        // Find the first PENDING task that hasn't been activated yet
        // (i.e., the task right after the last decided task)
        let foundDecided = false;
        for (const task of sorted) {
            if (task.status === 'APPROVED' || task.status === 'REJECTED') {
                foundDecided = true;
                continue;
            }
            if (task.status === 'PENDING' && foundDecided) {
                LOG.info('Activating next sequential approver', {
                    stepInstanceId,
                    taskId: task.ID,
                    taskOrder: task.taskOrder,
                    assigneeId: task.assigneeId,
                });

                // Log TASK_ACTIVATED so the history shows the handoff
                await this.logHistory(
                    stepInstance.workflowInstance_ID,
                    stepInstanceId,
                    task.ID,
                    WorkflowEventType.TASK_ACTIVATED,
                    stepInstance.stepName || '',
                    '', 'PENDING',
                    true // System-initiated sequential activation
                );

                break;
            }
        }
    }

    // ═══════════════════════════════════════════════════════════════════════
    // INTERNAL: DAG Successor Activation
    // ═══════════════════════════════════════════════════════════════════════

    /**
     * After a step completes, check if any successor steps can be activated.
     * A successor is ready when ALL its predecessor steps are in terminal state.
     */
    private static async activateReadySuccessors(
        workflowInstanceId: string,
        completedStepInstanceId: string
    ): Promise<void> {
        const completedStep = await cds.run(
            SELECT.one.from(CDS_ENTITIES.StepInstance)
                .columns('ID', 'stepDefinition_ID', 'workflowInstance_ID')
                .where({ ID: completedStepInstanceId })
        ) as IStepInstance | null;

        if (!completedStep) return;

        const instance = await cds.run(
            SELECT.one.from(CDS_ENTITIES.WorkflowInstance)
                .columns('ID', 'definition_ID')
                .where({ ID: workflowInstanceId })
        ) as { ID: string; definition_ID: string } | null;

        if (!instance?.definition_ID) return;

        // Get all dependencies for this workflow definition
        const dependencies = await cds.run(
            SELECT.from(CDS_ENTITIES.StepDependency)
                .where({ definition_ID: instance.definition_ID })
        ) as IStepDependency[];

        if (dependencies.length === 0) {
            // Sequential fallback: activate the next step by displayOrder
            await this.activateNextSequentialStep(workflowInstanceId, completedStepInstanceId);
            return;
        }

        // Find successor step definitions for the completed step
        const successorDefIds = dependencies
            .filter(d => d.predecessor_ID === completedStep.stepDefinition_ID)
            .map(d => d.successor_ID);

        if (successorDefIds.length === 0) return; // End step, no successors

        // Get all step instances for this workflow
        const allSteps = await cds.run(
            SELECT.from(CDS_ENTITIES.StepInstance)
                .where({ workflowInstance_ID: workflowInstanceId })
        ) as IStepInstance[];

        // Build definition → instance mapping
        const defToInstance = new Map<string, IStepInstance>();
        for (const si of allSteps) {
            if (si.stepDefinition_ID) {
                defToInstance.set(si.stepDefinition_ID, si);
            }
        }

        // For each successor, check if ALL its predecessors are complete
        for (const successorDefId of successorDefIds) {
            const predecessorDefIds = dependencies
                .filter(d => d.successor_ID === successorDefId)
                .map(d => d.predecessor_ID);

            const allPredecessorsComplete = predecessorDefIds.every(predDefId => {
                const predInstance = defToInstance.get(predDefId);
                return predInstance && this.isTerminal(predInstance.status);
            });

            if (allPredecessorsComplete) {
                const successorInstance = defToInstance.get(successorDefId);
                if (successorInstance && successorInstance.status === 'PENDING') {
                    LOG.info('Fan-in gate satisfied, activating successor', {
                        successorStepName: successorInstance.stepName,
                        predecessorCount: predecessorDefIds.length,
                    });
                    await this.activateStep(successorInstance.ID, workflowInstanceId);
                }
            }
        }
    }

    /**
     * Sequential fallback: when no StepDependency rows exist,
     * activate the next step by displayOrder.
     */
    private static async activateNextSequentialStep(
        workflowInstanceId: string,
        completedStepInstanceId: string
    ): Promise<void> {
        const allSteps = await cds.run(
            SELECT.from(CDS_ENTITIES.StepInstance)
                .where({ workflowInstance_ID: workflowInstanceId })
                .orderBy('displayOrder asc')
        ) as IStepInstance[];

        const completedIndex = allSteps.findIndex(s => s.ID === completedStepInstanceId);
        if (completedIndex === -1 || completedIndex === allSteps.length - 1) return;

        const nextStep = allSteps[completedIndex + 1];
        if (nextStep && nextStep.status === 'PENDING') {
            await this.activateStep(nextStep.ID, workflowInstanceId);
        }
    }

    // ═══════════════════════════════════════════════════════════════════════
    // UTILITIES
    // ═══════════════════════════════════════════════════════════════════════

    /** Check if a step status is terminal (won't change again) */
    private static isTerminal(status: StepStatus): boolean {
        return status === 'APPROVED' || status === 'REJECTED' || status === 'SKIPPED';
    }



    /** Delegate to shared WorkflowHistoryLogger (H3 DRY fix). */
    private static async logHistory(
        workflowInstanceId: string,
        stepInstanceId: string | null,
        approvalTaskId: string | null,
        eventType: string,
        stepName: string,
        previousValue: string,
        newValue: string,
        isSystemAction: boolean,
        performedById?: string,
        comment?: string,
    ): Promise<void> {
        await WorkflowHistoryLogger.log(
            workflowInstanceId, stepInstanceId, approvalTaskId,
            eventType as any, stepName, previousValue, newValue,
            performedById, comment, isSystemAction
        );
    }
}
