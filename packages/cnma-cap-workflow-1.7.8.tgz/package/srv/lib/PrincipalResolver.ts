import cds from '@sap/cds';

/**
 * PrincipalResolver — Batch-capable display name resolution for principals.
 *
 * Resolves ShadowUsers and ShadowGroups display names from @cnma/cap-identity
 * using a batch pattern that ensures max 2 DB queries regardless of row count.
 *
 * Technical Constraint T1:
 *   Every READ handler that populates virtual display name fields
 *   (responsibleName, principalName, assigneeName, decidedByName)
 *   MUST use resolveNames() (batch), never resolveName() per row.
 *
 * Identity Resolution:
 *   Shadow users are scoped by IDP origin. When resolving a userId (email)
 *   to a ShadowUser UUID, we use the current user's origin from the JWT
 *   to find the correct record. This ensures proper multi-tenant isolation
 *   where the same email under different IDPs are treated as separate identities.
 *
 * Entities affected:
 *   WorkflowDefinition, DefaultStepApprover, ApprovalTask,
 *   WorkflowInstance, WorkflowHistory (7 virtual fields across 5 entities)
 */

export interface IPrincipal {
    type: string;
    id: string;
}

const LOG = cds.log('workflow.principal');

export class PrincipalResolver {

    // ═════════════════════════════════════════════════════════════════════
    // BATCH RESOLUTION (for list views) — USE THIS
    // ═════════════════════════════════════════════════════════════════════

    /**
     * Batch-resolve display names for multiple principals at once.
     * Groups by type (USER vs GROUP*) → 2 queries max regardless of row count.
     *
     * @example
     * ```typescript
     * const nameMap = await PrincipalResolver.resolveNames(
     *     results.map(r => ({ type: r.responsibleType, id: r.responsibleId }))
     * );
     * results.forEach(r => r.responsibleName = nameMap.get(r.responsibleId) || 'Unknown');
     * ```
     *
     * @param principals Array of { type, id } objects
     * @returns Map<string, string> — Maps principal ID → display name
     */
    static async resolveNames(principals: IPrincipal[]): Promise<Map<string, string>> {
        const nameMap = new Map<string, string>();
        const userIds = new Set<string>();
        const groupIds = new Set<string>();

        // Classify principals by type
        for (const p of principals) {
            if (!p.type || !p.id) continue;
            if (p.type === 'USER') {
                userIds.add(p.id);
            } else {
                // GROUP, TEAM, DEPARTMENT, ROLE, POSITION — all stored in ShadowGroups
                groupIds.add(p.id);
            }
        }

        // Query 1: All users in one shot
        if (userIds.size > 0) {
            const users = await cds.run(
                SELECT.from('cnma.identity.ShadowUsers')
                    .columns('ID', 'displayName')
                    .where({ ID: { in: [...userIds] } })
            );
            for (const u of users) {
                nameMap.set(u.ID, u.displayName || 'Unknown User');
            }
        }

        // Query 2: All groups in one shot
        if (groupIds.size > 0) {
            const groups = await cds.run(
                SELECT.from('cnma.identity.ShadowGroups')
                    .columns('ID', 'name')
                    .where({ ID: { in: [...groupIds] } })
            );
            for (const g of groups) {
                nameMap.set(g.ID, g.name || 'Unknown Group');
            }
        }

        return nameMap; // Max 2 DB queries, regardless of row count
    }

    // ═════════════════════════════════════════════════════════════════════
    // SINGLE RESOLUTION (for detail views only)
    // ═════════════════════════════════════════════════════════════════════

    /**
     * Resolve a single principal's display name.
     * Delegates to batch method internally.
     *
     * @param type SupportTypes.code (USER, GROUP, TEAM, etc.)
     * @param id ShadowUsers.ID or ShadowGroups.ID
     * @returns Display name string
     */
    static async resolveName(type: string, id: string): Promise<string> {
        const map = await this.resolveNames([{ type, id }]);
        return map.get(id) || id;
    }

    /**
     * Resolve an IDP userId to a ShadowUser UUID.
     * Falls back to the raw userId if no ShadowUser is found.
     * Uses origin-scoped resolution (M4) — scoped to the current user's IDP origin.
     *
     * @param userId IDP identity (req.user.id) or ShadowUser UUID
     * @returns ShadowUser UUID, or raw userId if not found
     */
    static async resolveUUID(userId: string): Promise<string> {
        const uuid = await this._resolveShadowUUID(userId);
        return uuid ?? userId;
    }

    // ═════════════════════════════════════════════════════════════════════
    // GROUP MEMBERSHIP
    // ═════════════════════════════════════════════════════════════════════

    /**
     * Expand a group/team/department to its individual user member IDs.
     * Used when activating approval tasks for GROUP-type assignments.
     *
     * @param groupId ShadowGroups.ID
     * @returns Array of ShadowUsers.ID strings
     */
    static async expandMembers(groupId: string): Promise<string[]> {
        const members = await cds.run(
            SELECT.from('cnma.identity.GroupMembers')
                .columns('user_ID')
                .where({ group_ID: groupId })
        );
        return members.map((m: { user_ID: string }) => m.user_ID);
    }

    /**
     * Check if a user is a member of a group (any group type).
     *
     * Handles identity resolution: userId can be either a ShadowUser UUID
     * or an IDP identity (email/subject). GroupMembers stores UUIDs,
     * so we resolve the IDP identity to UUID first (origin-scoped).
     *
     * M4 — Request-scoped caching:
     *   Both the IDP→UUID resolution and the membership result are cached on
     *   `cds.context` for the lifetime of the current request.
     *
     * @param userId ShadowUsers.ID or IDP userId (email/subject from req.user.id)
     * @param groupId ShadowGroups.ID
     * @returns true if user is a member
     */
    static async isMember(userId: string, groupId: string): Promise<boolean> {
        const memberCache = this._getRequestCache<boolean>('_wf_membershipCache');
        const memberKey = `${userId}:${groupId}`;
        if (memberCache.has(memberKey)) return memberCache.get(memberKey)!;

        // Resolve the ShadowUser UUID (origin-scoped, cached)
        const resolvedUUID = await this._resolveShadowUUID(userId);

        // Build lookup keys — try both the raw userId and the resolved UUID
        const lookupIds = [...new Set([userId, ...(resolvedUUID ? [resolvedUUID] : [])])];

        for (const id of lookupIds) {
            const hit = await cds.run(
                SELECT.one.from('cnma.identity.GroupMembers')
                    .where({ group_ID: groupId, user_ID: id })
            );
            if (hit) {
                memberCache.set(memberKey, true);
                if (resolvedUUID && resolvedUUID !== userId) {
                    memberCache.set(`${resolvedUUID}:${groupId}`, true);
                }
                return true;
            }
        }

        memberCache.set(memberKey, false);
        if (resolvedUUID && resolvedUUID !== userId) {
            memberCache.set(`${resolvedUUID}:${groupId}`, false);
        }
        return false;
    }

    // ═════════════════════════════════════════════════════════════════════
    // PRIVATE: ORIGIN-SCOPED SHADOW USER RESOLUTION (M4)
    // ═════════════════════════════════════════════════════════════════════

    /**
     * Extract the IDP origin from the current CAP request context.
     * Reads the JWT payload via authInfo.token API.
     *
     * @returns The IDP origin string (e.g., 'sap.default', 'httpsXYZ.accounts.ondemand.com')
     *          or null if no origin can be determined.
     */
    private static _getCurrentOrigin(): string | null {
        try {
            const user = cds.context?.user;
            if (!user) return null;

            // Primary: Extract origin from JWT payload
            const authInfo = (user as any).authInfo;
            if (authInfo?.token?.getPayload) {
                const payload = authInfo.token.getPayload();
                if (payload?.origin) return payload.origin;
            }

            // Fallback: Check attribute locations
            const attr = user.attr as Record<string, any> | undefined;
            return (user as any).origin
                ?? attr?.origin
                ?? attr?.ext_attr?.origin
                ?? attr?.['xs.user.attributes']?.origin?.[0]
                ?? attr?.zdn
                ?? 'sap.default'; // Default for mocked auth
        } catch {
            return null;
        }
    }

    /**
     * Resolve an IDP userId to a ShadowUser UUID with origin-scoped, request-cached lookup.
     *
     * Resolution strategy:
     *   1. If origin is available → look up by (origin, userId) — exact match
     *   2. If no origin or no match → fall back to userId-only lookup
     *
     * This ensures proper multi-tenant isolation: the same email under different
     * IDPs are treated as separate identities with separate group memberships.
     */
    private static async _resolveShadowUUID(userId: string): Promise<string | null> {
        const uuidCache = this._getRequestCache<string | null>('_wf_uuidCache');
        if (uuidCache.has(userId)) return uuidCache.get(userId)!;

        try {
            // Try origin-scoped lookup first
            const origin = this._getCurrentOrigin();

            if (origin) {
                const scoped = await cds.run(
                    SELECT.one.from('cnma.identity.ShadowUsers')
                        .columns('ID')
                        .where({ origin, userId })
                ) as { ID: string } | null;

                if (scoped) {
                    uuidCache.set(userId, scoped.ID);
                    return scoped.ID;
                }
                LOG.debug(`No shadow user found for origin='${origin}', userId='${userId}', trying fallback`);
            }

            // Fallback: userId-only (for backward compatibility or when origin is unknown)
            const fallback = await cds.run(
                SELECT.one.from('cnma.identity.ShadowUsers')
                    .columns('ID')
                    .where({ userId })
            ) as { ID: string } | null;

            const result = fallback?.ID ?? null;
            uuidCache.set(userId, result);
            return result;
        } catch {
            uuidCache.set(userId, null);
            return null;
        }
    }

    /**
     * Get or create a named Map on the current CAP request context.
     * Each Map is scoped to exactly one request and discarded automatically.
     * Falls back to a transient Map when no active context exists (e.g. unit tests).
     */
    private static _getRequestCache<T>(name: string): Map<string, T> {
        const ctx = cds.context as any;
        if (!ctx) return new Map<string, T>(); // No active context (e.g. unit tests)
        if (!ctx[name]) ctx[name] = new Map<string, T>();
        return ctx[name] as Map<string, T>;
    }

    // ═════════════════════════════════════════════════════════════════════
    // VALIDATION
    // ═════════════════════════════════════════════════════════════════════

    /**
     * Validate that a principalType exists in SupportTypes and is enabled.
     * Called on CREATE/UPDATE of DefaultStepApprover, WorkflowDefinition, etc.
     *
     * @param type The principalType value to validate (e.g., 'USER', 'GROUP')
     * @returns true if the type exists and is enabled in SupportTypes
     */
    static async validatePrincipalType(type: string): Promise<boolean> {
        const valid = await cds.run(
            SELECT.one.from('cnma.identity.SupportTypes')
                .where({ code: type, isEnabled: true })
        );
        return !!valid;
    }

    /**
     * Get all enabled principal types.
     * Used for validation error messages.
     *
     * @returns Array of enabled SupportTypes codes
     */
    static async getEnabledTypes(): Promise<string[]> {
        const types = await cds.run(
            SELECT.from('cnma.identity.SupportTypes')
                .columns('code')
                .where({ isEnabled: true })
        );
        return types.map((t: { code: string }) => t.code);
    }

    // ═════════════════════════════════════════════════════════════════════
    // USER SCOPE (for row-level security and authorization checks)
    // ═════════════════════════════════════════════════════════════════════

    /**
     * Return all group IDs the user belongs to.
     * Uses origin-scoped resolution to find the correct shadow user.
     *
     * @param userId IDP identity or ShadowUser UUID
     * @returns Array of ShadowGroups.ID values
     */
    static async getUserGroups(userId: string): Promise<string[]> {
        if (!userId) return [];

        // Try direct match (userId is already a UUID stored in GroupMembers)
        const direct = await cds.run(
            SELECT.from('cnma.identity.GroupMembers')
                .columns('group_ID')
                .where({ user_ID: userId })
        ) as { group_ID: string }[];

        if (direct.length > 0) {
            return direct.map(r => r.group_ID);
        }

        // userId is an IDP identity — resolve to ShadowUser UUID (origin-scoped)
        const resolvedUUID = await this._resolveShadowUUID(userId);

        if (!resolvedUUID) return [];

        const resolved = await cds.run(
            SELECT.from('cnma.identity.GroupMembers')
                .columns('group_ID')
                .where({ user_ID: resolvedUUID })
        ) as { group_ID: string }[];

        return resolved.map(r => r.group_ID);
    }

    /**
     * Resolve the full identity scope for a user: their ShadowUser UUID
     * and all group IDs they belong to.
     *
     * Uses origin-scoped resolution to find the correct shadow user record.
     *
     * @param userId IDP identity (req.user.id)
     * @returns { shadowUserId, groupIds, allIds } — allIds = [shadowUserId, ...groupIds]
     */
    static async resolveUserScope(userId: string): Promise<{
        shadowUserId: string | null;
        groupIds: string[];
        allIds: string[];
    }> {
        if (!userId) return { shadowUserId: null, groupIds: [], allIds: [] };

        // Origin-scoped UUID resolution (M4)
        const shadowUserId = await this._resolveShadowUUID(userId).catch(() => null);

        const groupIds = shadowUserId
            ? (await cds.run(
                SELECT.from('cnma.identity.GroupMembers')
                    .columns('group_ID')
                    .where({ user_ID: shadowUserId })
            ) as { group_ID: string }[]).map(r => r.group_ID)
            : await this.getUserGroups(userId);

        const allIds = [...new Set([
            ...(shadowUserId ? [shadowUserId] : []),
            ...groupIds,
        ])];

        return { shadowUserId, groupIds, allIds };
    }

    /**
     * Check if a user is the responsible person for a workflow definition or instance.
     *
     * Rules:
     *   - If responsibleType is 'USER': match current user's ShadowUser.ID (origin-scoped)
     *   - If responsibleType is a group type: check group membership via isMember()
     *
     * @param userId IDP identity (req.user.id)
     * @param responsibleType 'USER', 'GROUP', 'TEAM', etc.
     * @param responsibleId ShadowUsers.ID or ShadowGroups.ID
     * @returns true if the user is the responsible person (or member of responsible group)
     */
    static async isResponsiblePerson(
        userId: string,
        responsibleType: string,
        responsibleId: string
    ): Promise<boolean> {
        if (!userId || !responsibleType || !responsibleId) return false;

        if (responsibleType === 'USER') {
            // Origin-scoped UUID resolution (M4)
            const shadowUserId = await this._resolveShadowUUID(userId).catch(() => null);
            return shadowUserId === responsibleId;
        } else {
            // GROUP, TEAM, DEPARTMENT, etc. — check membership
            try {
                return await this.isMember(userId, responsibleId);
            } catch {
                return false;
            }
        }
    }

    // ═════════════════════════════════════════════════════════════════════
    // READ HANDLER HELPERS
    // ═════════════════════════════════════════════════════════════════════

    /**
     * Populate virtual name fields on a READ result set.
     * Convenience method for use in after-READ handlers.
     *
     * @example
     * ```typescript
     * srv.after('READ', 'WorkflowDefinitions', async (results) => {
     *     await PrincipalResolver.populateVirtualNames(results, [
     *         { typeField: 'responsibleType', idField: 'responsibleId', nameField: 'responsibleName' }
     *     ]);
     * });
     * ```
     */
    static async populateVirtualNames(
        results: unknown,
        mappings: Array<{ typeField: string; idField: string; nameField: string }>
    ): Promise<void> {
        if (!results) return;
        const rows = Array.isArray(results) ? results : [results];
        if (rows.length === 0) return;

        // Collect all principals across all mappings
        const allPrincipals: IPrincipal[] = [];
        for (const row of rows) {
            for (const mapping of mappings) {
                const record = row as Record<string, unknown>;
                const type = record[mapping.typeField] as string;
                const id = record[mapping.idField] as string;
                if (type && id) {
                    allPrincipals.push({ type, id });
                }
            }
        }

        // Single batch resolve for all principals
        const nameMap = await this.resolveNames(allPrincipals);

        // Populate virtual fields
        for (const row of rows) {
            for (const mapping of mappings) {
                const record = row as Record<string, unknown>;
                const id = record[mapping.idField] as string;
                if (id) {
                    record[mapping.nameField] = nameMap.get(id) || 'Unknown';
                }
            }
        }
    }
}
