/**
 * @cnma/cap-workflow — ConditionEvaluator
 *
 * Safe JSON predicate evaluator for conditionExpr fields.
 * NO eval(), NO Function(), NO string parsing — security by construction.
 *
 * Syntax:
 *   Simple:   { "field": "companyCode", "op": "eq", "value": "1000" }
 *   Array:    { "field": "objectType", "op": "in", "value": ["INV", "ASN"] }
 *   Compound: { "and": [ { ...predicate }, { ...predicate } ] }
 *             { "or":  [ { ...predicate }, { ...predicate } ] }
 *   Negation: { "not": { ...predicate } }
 *   Nested field: { "field": "header.companyCode", "op": "eq", "value": "1000" }
 *
 * Supported operators:
 *   eq, ne, gt, lt, gte, lte, in, nin, contains, startsWith, endsWith, exists
 *
 * @example
 * ```typescript
 * const expr = '{"and":[{"field":"companyCode","op":"eq","value":"1000"},{"field":"totalAmount","op":"gt","value":10000}]}';
 * const data = { companyCode: "1000", totalAmount: 25000 };
 * ConditionEvaluator.evaluate(expr, data); // true
 * ```
 */

import cds from '@sap/cds';

const LOG = cds.log('workflow.condition-evaluator');

// ─── Types ──────────────────────────────────────────────────────────────────

export interface SimplePredicate {
    field: string;
    op: PredicateOperator;
    value: unknown;
}

export interface CompoundPredicate {
    and?: Predicate[];
    or?: Predicate[];
    not?: Predicate;
}

export type Predicate = SimplePredicate | CompoundPredicate;

export type PredicateOperator =
    | 'eq' | 'ne'
    | 'gt' | 'lt' | 'gte' | 'lte'
    | 'in' | 'nin'
    | 'contains' | 'startsWith' | 'endsWith'
    | 'exists';

const VALID_OPERATORS = new Set<string>([
    'eq', 'ne', 'gt', 'lt', 'gte', 'lte',
    'in', 'nin', 'contains', 'startsWith', 'endsWith', 'exists'
]);

// ─── Evaluator ──────────────────────────────────────────────────────────────

export class ConditionEvaluator {

    /**
     * Evaluate a conditionExpr JSON string against document data.
     *
     * @param conditionExpr  JSON string representing the predicate tree
     * @param data  The document's extraction data (flat or nested object)
     * @returns true if the condition matches
     * @throws Error if the expression is malformed
     */
    static evaluate(conditionExpr: string, data: Record<string, unknown>): boolean {
        if (!conditionExpr || conditionExpr.trim() === '') {
            return true; // Empty expression = always matches (catch-all)
        }

        let parsed: unknown;
        try {
            parsed = JSON.parse(conditionExpr);
        } catch (err) {
            LOG.error(`Invalid conditionExpr JSON: ${conditionExpr}`);
            throw new Error(`conditionExpr is not valid JSON: ${(err as Error).message}`);
        }

        if (Array.isArray(parsed)) {
            return this.evaluateFlatArray(parsed, data);
        }

        return this.evaluatePredicate(parsed as Predicate, data);
    }

    /**
     * Validate a conditionExpr without evaluating it.
     * Used at definition-create/update time.
     *
     * @returns { valid: boolean; errors: string[] }
     */
    static validate(conditionExpr: string): { valid: boolean; errors: string[] } {
        const errors: string[] = [];

        if (!conditionExpr || conditionExpr.trim() === '') {
            return { valid: true, errors: [] }; // Empty is valid (catch-all)
        }

        let parsed: unknown;
        try {
            parsed = JSON.parse(conditionExpr);
        } catch {
            return { valid: false, errors: ['Invalid JSON syntax'] };
        }

        if (Array.isArray(parsed)) {
            this.validateFlatArray(parsed, errors);
        } else {
            this.validatePredicate(parsed as Predicate, errors, '$');
        }
        return { valid: errors.length === 0, errors };
    }

    // ─── Core Evaluation ────────────────────────────────────────────────

    private static evaluateFlatArray(rows: any[], data: Record<string, unknown>): boolean {
        const activeRows = rows.filter(r => r.isActive !== false);
        if (activeRows.length === 0) return true; // empty = always matches

        const tokens: Array<string | boolean> = [];

        for (let i = 0; i < activeRows.length; i++) {
            const row = activeRows[i];

            const leftStr = row.leftBracket || '';
            for (const char of leftStr) {
                if (char === '(') tokens.push('(');
            }

            let valueToCompare = row.value;
            if (row.isSchema) {
                valueToCompare = this.resolveField(row.value, data);
            }

            const simplePred: SimplePredicate = {
                field: row.field,
                op: row.operator as PredicateOperator,
                value: valueToCompare
            };

            let rowResult = false;
            try {
                rowResult = this.evaluateSimple(simplePred, data);
            } catch (err) {
                LOG.error(`Error evaluating row field ${row.field}:`, err);
                rowResult = false;
            }
            tokens.push(rowResult);

            const rightStr = row.rightBracket || '';
            for (const char of rightStr) {
                if (char === ')') tokens.push(')');
            }

            if (i < activeRows.length - 1) {
                const op = row.logicalOperator?.toLowerCase();
                if (op === 'or') tokens.push('or');
                else tokens.push('and');
            }
        }

        return this.evaluateBooleanTokens(tokens);
    }

    private static evaluateBooleanTokens(tokens: Array<string | boolean>): boolean {
        try {
            const parser = new TokenParser(tokens);
            return parser.parse();
        } catch (err) {
            LOG.error('Error evaluating flat boolean condition:', err);
            return false;
        }
    }

    private static evaluatePredicate(predicate: Predicate, data: Record<string, unknown>): boolean {
        // Compound: AND
        if ('and' in predicate && Array.isArray(predicate.and)) {
            return predicate.and.every(p => this.evaluatePredicate(p, data));
        }

        // Compound: OR
        if ('or' in predicate && Array.isArray(predicate.or)) {
            return predicate.or.some(p => this.evaluatePredicate(p, data));
        }

        // Compound: NOT
        if ('not' in predicate && predicate.not) {
            return !this.evaluatePredicate(predicate.not, data);
        }

        // Simple predicate
        if ('field' in predicate && 'op' in predicate) {
            return this.evaluateSimple(predicate as SimplePredicate, data);
        }

        LOG.warn('Unknown predicate shape:', predicate);
        return false;
    }

    private static evaluateSimple(predicate: SimplePredicate, data: Record<string, unknown>): boolean {
        const { field, op, value } = predicate;

        if (!VALID_OPERATORS.has(op)) {
            throw new Error(`Unknown operator: '${op}'`);
        }

        // Resolve nested field paths (e.g., "header.companyCode")
        const fieldValue = this.resolveField(field, data);

        // Smart type-casting for values coming from UI strings
        let finalValue = value;
        if (typeof fieldValue === 'number' && typeof value === 'string' && !isNaN(Number(value)) && value.trim() !== '') {
            finalValue = Number(value);
        } else if (typeof fieldValue === 'boolean' && typeof value === 'string') {
            finalValue = value.toLowerCase() === 'true';
        }

        switch (op) {
            case 'eq':
                return fieldValue === finalValue;

            case 'ne':
                return fieldValue !== finalValue;

            case 'gt':
                return typeof fieldValue === 'number' && typeof finalValue === 'number'
                    ? fieldValue > finalValue : String(fieldValue) > String(finalValue);

            case 'lt':
                return typeof fieldValue === 'number' && typeof finalValue === 'number'
                    ? fieldValue < finalValue : String(fieldValue) < String(finalValue);

            case 'gte':
                return typeof fieldValue === 'number' && typeof finalValue === 'number'
                    ? fieldValue >= finalValue : String(fieldValue) >= String(finalValue);

            case 'lte':
                return typeof fieldValue === 'number' && typeof finalValue === 'number'
                    ? fieldValue <= finalValue : String(fieldValue) <= String(finalValue);

            case 'in': {
                let inArr: any = finalValue;
                if (typeof finalValue === 'string') {
                    try {
                        const parsed = JSON.parse(finalValue);
                        inArr = Array.isArray(parsed) ? parsed : finalValue.split(',').map((s: string) => s.trim());
                    } catch {
                        inArr = finalValue.split(',').map((s: string) => s.trim());
                    }
                }
                if (!Array.isArray(inArr)) return false;
                if (typeof fieldValue === 'number') {
                    return inArr.some((v: any) => Number(v) === fieldValue);
                }
                return inArr.includes(fieldValue);
            }

            case 'nin': {
                let ninArr: any = finalValue;
                if (typeof finalValue === 'string') {
                    try {
                        const parsed = JSON.parse(finalValue);
                        ninArr = Array.isArray(parsed) ? parsed : finalValue.split(',').map((s: string) => s.trim());
                    } catch {
                        ninArr = finalValue.split(',').map((s: string) => s.trim());
                    }
                }
                if (!Array.isArray(ninArr)) return true;
                if (typeof fieldValue === 'number') {
                    return !ninArr.some((v: any) => Number(v) === fieldValue);
                }
                return !ninArr.includes(fieldValue);
            }

            case 'contains':
                return typeof fieldValue === 'string' && typeof value === 'string'
                    ? fieldValue.toLowerCase().includes(value.toLowerCase()) : false;

            case 'startsWith':
                return typeof fieldValue === 'string' && typeof value === 'string'
                    ? fieldValue.toLowerCase().startsWith(value.toLowerCase()) : false;

            case 'endsWith':
                return typeof fieldValue === 'string' && typeof value === 'string'
                    ? fieldValue.toLowerCase().endsWith(value.toLowerCase()) : false;

            case 'exists':
                return value === true
                    ? fieldValue !== undefined && fieldValue !== null
                    : fieldValue === undefined || fieldValue === null;

            default:
                return false;
        }
    }

    /**
     * Resolve a dot-separated field path from a data object.
     * "header.companyCode" → data.header.companyCode
     */
    private static resolveField(fieldPath: string, data: Record<string, unknown>): unknown {
        const parts = fieldPath.split('.');
        let current: unknown = data;

        for (const part of parts) {
            if (current === null || current === undefined) return undefined;
            if (typeof current !== 'object') return undefined;
            current = (current as Record<string, unknown>)[part];
        }

        // Auto-unwrap objects that contain a 'value' property (e.g. AI extracted fields)
        if (current !== null && typeof current === 'object' && 'value' in (current as Record<string, unknown>)) {
            return (current as Record<string, unknown>).value;
        }

        return current;
    }

    // ─── Validation ─────────────────────────────────────────────────────

    private static validatePredicate(predicate: Predicate, errors: string[], path: string): void {
        if (!predicate || typeof predicate !== 'object') {
            errors.push(`${path}: must be an object`);
            return;
        }

        // Compound: AND
        if ('and' in predicate) {
            if (!Array.isArray(predicate.and)) {
                errors.push(`${path}.and: must be an array`);
            } else {
                predicate.and.forEach((p, i) => this.validatePredicate(p, errors, `${path}.and[${i}]`));
            }
            return;
        }

        // Compound: OR
        if ('or' in predicate) {
            if (!Array.isArray(predicate.or)) {
                errors.push(`${path}.or: must be an array`);
            } else {
                predicate.or.forEach((p, i) => this.validatePredicate(p, errors, `${path}.or[${i}]`));
            }
            return;
        }

        // Compound: NOT
        if ('not' in predicate) {
            if (!predicate.not || typeof predicate.not !== 'object') {
                errors.push(`${path}.not: must be an object`);
            } else {
                this.validatePredicate(predicate.not, errors, `${path}.not`);
            }
            return;
        }

        // Simple predicate — cast to generic record because TypeScript has narrowed
        // the union to 'never' after exhausting compound predicate branches above.
        // This section validates malformed or simple predicates.
        const p = predicate as unknown as Record<string, unknown>;

        if (!('field' in p)) {
            errors.push(`${path}: missing 'field' property`);
        } else if (typeof p.field !== 'string' || (p.field as string).trim() === '') {
            errors.push(`${path}.field: must be a non-empty string`);
        }

        if (!('op' in p)) {
            errors.push(`${path}: missing 'op' property`);
        } else if (!VALID_OPERATORS.has(p.op as string)) {
            errors.push(`${path}.op: unknown operator '${p.op}'. Valid: ${[...VALID_OPERATORS].join(', ')}`);
        }

        // 'value' is required for all ops except 'exists'
        if ('op' in p && p.op !== 'exists' && !('value' in p)) {
            errors.push(`${path}: missing 'value' property (required for '${p.op}')`);
        }

        // 'in' and 'nin' require array values
        if ('op' in p && (p.op === 'in' || p.op === 'nin')) {
            if ('value' in p && !Array.isArray(p.value)) {
                errors.push(`${path}.value: must be an array for '${p.op}' operator`);
            }
        }
    }

    private static validateFlatArray(rows: any[], errors: string[]): void {
        rows.forEach((row, idx) => {
            if (row.isActive === false) return; // ignore inactive
            if (!row.field || typeof row.field !== 'string') {
                errors.push(`Row ${idx + 1}: missing or invalid 'field'`);
            }
            if (!row.operator || !VALID_OPERATORS.has(row.operator)) {
                errors.push(`Row ${idx + 1}: unknown operator '${row.operator}'`);
            }
        });
        
        // Count brackets
        let openBrackets = 0;
        rows.forEach(row => {
            const left = row.leftBracket || '';
            const right = row.rightBracket || '';
            for (const c of left) if (c === '(') openBrackets++;
            for (const c of right) if (c === ')') openBrackets--;
        });
        if (openBrackets !== 0) {
            errors.push('Unbalanced brackets in condition expression.');
        }
    }
}

class TokenParser {
    private pos = 0;
    constructor(private tokens: Array<string | boolean>) {}

    parse(): boolean {
        const result = this.parseOr();
        if (this.pos < this.tokens.length) {
            throw new Error('Unbalanced or extra tokens at end of expression');
        }
        return result;
    }

    private parseOr(): boolean {
        let left = this.parseAnd();
        while (this.pos < this.tokens.length && this.tokens[this.pos] === 'or') {
            this.pos++;
            const right = this.parseAnd();
            left = left || right;
        }
        return left;
    }

    private parseAnd(): boolean {
        let left = this.parsePrimary();
        while (this.pos < this.tokens.length && this.tokens[this.pos] === 'and') {
            this.pos++;
            const right = this.parsePrimary();
            left = left && right;
        }
        return left;
    }

    private parsePrimary(): boolean {
        if (this.pos >= this.tokens.length) throw new Error('Missing token or empty expression');
        const token = this.tokens[this.pos];
        if (token === '(') {
            this.pos++;
            const val = this.parseOr();
            if (this.pos >= this.tokens.length || this.tokens[this.pos] !== ')') {
                throw new Error('Missing closing parenthesis');
            }
            this.pos++;
            return val;
        }
        if (typeof token === 'boolean') {
            this.pos++;
            return token;
        }
        throw new Error(`Unexpected token at position ${this.pos}: ${token}`);
    }
}
