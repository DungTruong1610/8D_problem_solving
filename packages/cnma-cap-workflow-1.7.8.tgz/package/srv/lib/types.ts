/**
 * @cnma/cap-workflow — Shared Types for Engine Classes
 *
 * TypeScript interfaces matching the CDS entity shapes from db/workflow.cds
 * and db/workflow-runtime.cds. Used by all engine classes for type safety.
 *
 * Note: These will eventually be replaced by cds-typer generated types.
 */

// ─── CDS Enum Values ────────────────────────────────────────────────────────

export type DecisionSource = 'MANUAL' | 'AI_SUGGESTED' | 'AUTO';
export type ApprovalMode = 'ANY_ONE' | 'ALL';
export type ApproverSeqMode = 'SEQUENTIAL' | 'PARALLEL';
export type RejectionMode = 'BACK_TO_RESPONSIBLE' | 'RESTART_STEP' | 'NEW_RUN';
export type CompletionPolicy = 'RESPONSIBLE_ONLY' | 'RESPONSIBLE_MEMBERS' | 'ANY_AUTHORIZED' | 'AUTO_COMPLETE';

// ─── Notification Configuration Types ────────────────────────────────────────

/** Email events that can be configured per workflow definition */
export type NotificationEventType =
    | 'TASK_ASSIGNED'
    | 'TASK_APPROVED'
    | 'TASK_REJECTED'
    | 'TASK_REASSIGNED'
    | 'TASK_REMINDER'
    | 'WORKFLOW_COMPLETED'
    | 'WORKFLOW_REJECTED';

/** All known notification event types (used by UI to render toggles) */
export const NOTIFICATION_EVENT_TYPES: NotificationEventType[] = [
    'TASK_ASSIGNED',
    'TASK_APPROVED',
    'TASK_REJECTED',
    'TASK_REASSIGNED',
    'TASK_REMINDER',
    'WORKFLOW_COMPLETED',
    'WORKFLOW_REJECTED',
];

/** A dynamic business field to display in notification emails.
 *  fieldKey maps to an extractionData JSON field name from ObjectSchema. */
export interface INotificationBusinessField {
    fieldKey: string;   // extractionData field name (e.g. 'invoicingParty', 'supplierInvoiceNo')
    label: string;      // Display label in email (e.g. 'Invoicing Party', 'Supplier Invoice No')
}

/** Structured template for custom email content (not raw HTML) */
export interface IStructuredTemplate {
    subject: string;           // e.g. "🔔 Please Review: {{objectType}}"
    greeting: string;          // e.g. "Dear {{assigneeName}},"
    bodyText: string;          // Plain text with {{placeholders}}
    infoFields: string[];      // e.g. ["workflow", "step", "document", "objectType"]
    buttonLabel?: string;      // e.g. "Review & Approve" (empty = no button)
    buttonColor?: string;      // e.g. "#1a56db"
}

/** Per-event notification configuration */
export interface INotificationEventConfig {
    enabled: boolean;
    template?: IStructuredTemplate;
}

/** Top-level notification settings stored as JSON on WorkflowDefinition */
export interface INotificationSettings {
    events: Partial<Record<NotificationEventType, INotificationEventConfig>>;
    /** Dynamic fields from extractionData to display in notification emails.
     *  Each entry maps a JSON field key to a human-readable label.
     *  Values are resolved at send time by the host app's BusinessFieldsResolver. */
    businessFields?: INotificationBusinessField[];
}

export type WorkflowStatus = 'DRAFT' | 'ACTIVE' | 'COMPLETED' | 'REJECTED' | 'CANCELLED';
export type StepStatus = 'PENDING' | 'ACTIVE' | 'APPROVED' | 'REJECTED' | 'SKIPPED';
export type TaskStatus = 'PENDING' | 'APPROVED' | 'REJECTED';

// ─── Template Layer Interfaces ───────────────────────────────────────────────

export interface IWorkflowObjectType {
    ID: string;
    objectType: string;
    displayName?: string;
    orgKeyField?: string;
    isActive: boolean;
}

export interface IWorkflowDefinition {
    ID: string;
    objectType: string;
    orgKeyValue?: string | null;
    triggerAction?: string;
    workflowType: string;
    description?: string;
    responsibleType?: string;
    responsibleId?: string;
    rejectionMode: RejectionMode;
    completionPolicy: CompletionPolicy;
    definitionVersion: number;
    conditionExpr?: string;
    priority: number;
    autoCancelOnTerminalStatus: boolean;
    isActive: boolean;
    notificationSettings?: string; // JSON: INotificationSettings
    steps?: IWorkflowStepDefinition[];
    stepDependencies?: IStepDependency[];
}

export interface IWorkflowStepDefinition {
    ID: string;
    definition_ID?: string;
    displayOrder: number;
    stepName: string;
    stepDescription?: string;
    approvalMode: ApprovalMode;
    approverSeqMode: ApproverSeqMode;
    fieldSettings?: string;
    conditionExpr?: string;
    defaultApprovers?: IDefaultStepApprover[];
}

export interface IDefaultStepApprover {
    ID: string;
    step_ID?: string;
    principalType: string;
    principalId: string;
    approverOrder: number;
    conditionExpr?: string;
}

export interface IStepDependency {
    ID: string;
    definition_ID?: string;
    predecessor_ID: string;
    successor_ID: string;
}

// ─── Runtime Layer Interfaces ────────────────────────────────────────────────

export interface IWorkflowInstance {
    ID: string;
    referenceId: string;
    referenceType: string;
    definition_ID?: string;
    workflowType?: string;
    workflowTypeSource?: DecisionSource;
    runNumber: number;
    status: WorkflowStatus;
    frozenDefinitionVersion?: number;
    responsibleType?: string;
    responsibleId?: string;
    startedAt?: string;
    completedAt?: string;
    createdBy?: string;
    createdBy_ID?: string;
    modifiedAt?: string;
    stepInstances?: IStepInstance[];
    history?: IWorkflowHistory[];
}

export interface IStepInstance {
    ID: string;
    workflowInstance_ID: string;
    stepDefinition_ID?: string;
    stepName?: string;
    displayOrder?: number;
    approvalMode?: ApprovalMode;
    approverSeqMode?: ApproverSeqMode;
    fieldSettings?: string;
    status: StepStatus;
    activatedAt?: string;
    completedAt?: string;
    tasks?: IApprovalTask[];
}

export interface IApprovalTask {
    ID: string;
    stepInstance_ID: string;
    assigneeType: string;
    assigneeId: string;
    taskOrder: number;
    status: TaskStatus;
    decidedByType?: string;
    decidedById?: string;
    decidedAt?: string;
    comment?: string;
    assignmentSource?: DecisionSource;
    modifiedAt?: string;
}

export interface IWorkflowHistory {
    ID: string;
    workflowInstance_ID: string;
    stepInstance_ID?: string;
    approvalTask_ID?: string;
    eventType: string;
    performedById?: string;
    isSystemAction: boolean;
    performedAt?: string;
    stepName?: string;
    previousValue?: string;
    newValue?: string;
    comment?: string;
    metadata?: string;
}

// ─── Engine Input / Output Types ─────────────────────────────────────────────

export interface ICreateWorkflowInput {
    referenceId: string;
    referenceType: string;
    definitionId: string;
    responsibleType?: string;
    responsibleId?: string;
    approverOverrides?: IApproverOverride[];
    documentData?: Record<string, unknown>;
    createdById?: string;
}

export interface IApproverOverride {
    stepDefinitionId: string;
    approvers: Array<{
        principalType: string;
        principalId: string;
        approverOrder?: number;
    }>;
}

export interface IApproveTaskInput {
    taskId: string;
    comment?: string;
    userId: string;
}

export interface IRejectTaskInput {
    taskId: string;
    comment: string; // Required for rejection
    userId: string;
}

export interface IReassignTaskInput {
    taskId: string;
    newAssigneeType: string;
    newAssigneeId: string;
    reason: string;
    userId: string;
}

// ─── Event Types ─────────────────────────────────────────────────────────────

/** Event types for WorkflowHistory logging */
export const WorkflowEventType = {
    CREATED: 'CREATED',
    STARTED: 'STARTED',
    CANCELLED: 'CANCELLED',
    COMPLETED: 'COMPLETED',
    REJECTED: 'REJECTED',
    RERUN: 'RERUN',
    STEP_ACTIVATED: 'STEP_ACTIVATED',
    STEP_COMPLETED: 'STEP_COMPLETED',
    STEP_REJECTED: 'STEP_REJECTED',
    STEP_RESET: 'STEP_RESET',
    TASK_APPROVED: 'TASK_APPROVED',
    TASK_REJECTED: 'TASK_REJECTED',
    TASK_REASSIGNED: 'TASK_REASSIGNED',
    TASK_ACTIVATED: 'TASK_ACTIVATED',
    TASK_CANCELLED: 'TASK_CANCELLED',
} as const;

export type WorkflowEventTypeValue = typeof WorkflowEventType[keyof typeof WorkflowEventType];

/** Payload for the synchronous workflow.statusChanged event (T7) */
export interface IWorkflowStatusChangedPayload {
    referenceId: string;
    referenceType: string;
    workflowId: string;
    status: WorkflowStatus;
    workflowType?: string;
    currentStepName?: string | null;
    currentApprovers?: string | null; // JSON stringified
}

// ─── CDS Entity Name Constants ───────────────────────────────────────────────

/** Fully-qualified CDS entity names for SELECT/UPDATE/INSERT/DELETE */
export const CDS_ENTITIES = {
    // Template
    WorkflowObjectType: 'cnma.workflow.WorkflowObjectType',
    WorkflowDefinition: 'cnma.workflow.WorkflowDefinition',
    WorkflowStepDefinition: 'cnma.workflow.WorkflowStepDefinition',
    DefaultStepApprover: 'cnma.workflow.DefaultStepApprover',
    StepDependency: 'cnma.workflow.StepDependency',
    // Runtime
    WorkflowInstance: 'cnma.workflow.runtime.WorkflowInstance',
    StepInstance: 'cnma.workflow.runtime.StepInstance',
    ApprovalTask: 'cnma.workflow.runtime.ApprovalTask',
    WorkflowHistory: 'cnma.workflow.runtime.WorkflowHistory',
} as const;

export const IDENTITY_ENTITIES = {
    ShadowUsers: 'cnma.identity.ShadowUsers',
    ShadowGroups: 'cnma.identity.ShadowGroups',
    GroupMembers: 'cnma.identity.GroupMembers',
} as const;
