/**
 * @cnma/cap-workflow — IEmailSender Interface
 *
 * Abstraction for email delivery. Host app provides the implementation
 * (e.g., Graph API sendMail, SMTP via nodemailer, etc.).
 *
 * @example Host app implementation:
 * ```typescript
 * class GraphEmailSender implements IEmailSender {
 *     async sendEmail(to, subject, htmlBody) {
 *         await GraphMailClient.sendMail(destination, sender, to, subject, htmlBody);
 *     }
 * }
 * ```
 */

export interface IEmailSender {
    /**
     * Send an email.
     * @param to  Recipient email address
     * @param subject  Email subject line
     * @param htmlBody  Full HTML body
     */
    sendEmail(to: string, subject: string, htmlBody: string): Promise<void>;
}

/**
 * Extended interface for batch sending.
 */
export interface IBatchEmailSender extends IEmailSender {
    /**
     * Send the same email to multiple recipients.
     * Default: calls sendEmail() for each recipient.
     */
    sendBatch(recipients: string[], subject: string, htmlBody: string): Promise<void>;
}
