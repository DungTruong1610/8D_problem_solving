/**
 * @cnma/cap-workflow — CompletionPolicyChecker (F2)
 *
 * After a workflow reaches COMPLETED status, this checker determines
 * who is authorized to perform the post-approval action (e.g., posting).
 *
 * CompletionPolicy values:
 *   - RESPONSIBLE_ONLY:    Only the responsible person (definition/instance level)
 *   - RESPONSIBLE_MEMBERS: Any member of the responsible group
 *   - ANY_AUTHORIZED:      Any user with workflow-related roles
 *   - AUTO_COMPLETE:       System auto-executes (Phase 3 — not implemented)
 *
 * Used by the host app's WorkflowActionProvider to determine if the current
 * user can see/execute the "Post" action after workflow completion.
 */

import cds from '@sap/cds';
import { PrincipalResolver } from './PrincipalResolver';
import {
    CDS_ENTITIES,
    type IWorkflowInstance,
    type IWorkflowDefinition,
    type CompletionPolicy,
} from './types';

const LOG = cds.log('workflow.completion-policy');

export class CompletionPolicyChecker {

    /**
     * Check if a user is authorized to perform the completion action
     * (e.g., posting) for a completed workflow.
     *
     * @param workflowId The completed workflow instance ID
     * @param userId The user attempting the action
     * @returns { authorized: boolean; reason: string; policy: CompletionPolicy }
     */
    static async canComplete(
        workflowId: string,
        userId: string
    ): Promise<{ authorized: boolean; reason: string; policy: CompletionPolicy }> {
        // 1. Load workflow instance
        const instance = await cds.run(
            SELECT.one.from(CDS_ENTITIES.WorkflowInstance)
                .where({ ID: workflowId })
        ) as IWorkflowInstance | null;

        if (!instance) {
            return { authorized: false, reason: 'Workflow instance not found', policy: 'RESPONSIBLE_ONLY' };
        }

        if (instance.status !== 'COMPLETED') {
            return { authorized: false, reason: `Workflow is not completed (status: ${instance.status})`, policy: 'RESPONSIBLE_ONLY' };
        }

        // 2. Load definition for completion policy
        const definition = instance.definition_ID
            ? await cds.run(
                  SELECT.one.from(CDS_ENTITIES.WorkflowDefinition)
                      .columns('completionPolicy', 'responsibleType', 'responsibleId')
                      .where({ ID: instance.definition_ID })
              ) as Pick<IWorkflowDefinition, 'completionPolicy' | 'responsibleType' | 'responsibleId'> | null
            : null;

        const policy: CompletionPolicy = definition?.completionPolicy || 'RESPONSIBLE_ONLY';

        // 3. Determine responsible from instance (overrides definition)
        const responsibleType = instance.responsibleType || definition?.responsibleType;
        const responsibleId = instance.responsibleId || definition?.responsibleId;

        // 4. Resolve IDP userId → ShadowUser UUID (H7 fix: userId is IDP identity, responsibleId is UUID)
        let resolvedUserId = userId;
        try {
            const shadowUser = await cds.run(
                SELECT.one.from('cnma.identity.ShadowUsers')
                    .columns('ID')
                    .where({ userId })
            ) as { ID: string } | null;
            if (shadowUser) resolvedUserId = shadowUser.ID;
        } catch {
            LOG.warn(`Failed to resolve ShadowUser UUID for '${userId}', using raw value`);
        }

        LOG.info('Checking completion policy', { workflowId, userId, resolvedUserId, policy, responsibleType, responsibleId });

        // 5. Apply policy
        switch (policy) {
            case 'RESPONSIBLE_ONLY':
                return this.checkResponsibleOnly(resolvedUserId, responsibleType, responsibleId, policy);

            case 'RESPONSIBLE_MEMBERS':
                return this.checkResponsibleMembers(resolvedUserId, responsibleType, responsibleId, policy);

            case 'ANY_AUTHORIZED':
                return { authorized: true, reason: 'ANY_AUTHORIZED policy — all authorized users may act', policy };

            case 'AUTO_COMPLETE':
                return { authorized: false, reason: 'AUTO_COMPLETE policy — system will auto-execute (Phase 3)', policy };

            default:
                return { authorized: false, reason: `Unknown completion policy: ${policy}`, policy };
        }
    }

    /**
     * RESPONSIBLE_ONLY: The user must be the specific responsible person.
     * If responsible is a USER → exact match.
     * If responsible is a GROUP → user must be the group's primary owner.
     */
    private static async checkResponsibleOnly(
        userId: string,
        responsibleType: string | undefined,
        responsibleId: string | undefined,
        policy: CompletionPolicy
    ): Promise<{ authorized: boolean; reason: string; policy: CompletionPolicy }> {
        if (!responsibleType || !responsibleId) {
            return { authorized: false, reason: 'No responsible person defined on workflow', policy };
        }

        if (responsibleType === 'USER') {
            // Direct user match via ShadowUsers.ID
            // responsibleId IS the ShadowUsers.ID; userId is also a ShadowUsers.ID
            const authorized = userId === responsibleId;
            return {
                authorized,
                reason: authorized
                    ? 'User is the designated responsible person'
                    : 'Only the designated responsible person can complete this workflow',
                policy
            };
        }

        // Group-type responsible — for RESPONSIBLE_ONLY, we still need membership
        // since there's no "owner" concept; strictest check is isMember
        const authorized = await PrincipalResolver.isMember(userId, responsibleId);
        return {
            authorized,
            reason: authorized
                ? 'User is a member of the responsible entity'
                : 'Only the designated responsible person (group owner) can complete this workflow',
            policy
        };
    }

    /**
     * RESPONSIBLE_MEMBERS: Any member of the responsible group can act.
     * If responsible is a USER → only that user.
     * If responsible is a GROUP → any group member.
     */
    private static async checkResponsibleMembers(
        userId: string,
        responsibleType: string | undefined,
        responsibleId: string | undefined,
        policy: CompletionPolicy
    ): Promise<{ authorized: boolean; reason: string; policy: CompletionPolicy }> {
        if (!responsibleType || !responsibleId) {
            return { authorized: false, reason: 'No responsible person defined on workflow', policy };
        }

        if (responsibleType === 'USER') {
            const authorized = userId === responsibleId;
            return {
                authorized,
                reason: authorized
                    ? 'User is the designated responsible person'
                    : 'Only the designated responsible person can complete this workflow',
                policy
            };
        }

        // Group-type → check membership
        const isMember = await PrincipalResolver.isMember(userId, responsibleId);
        return {
            authorized: isMember,
            reason: isMember
                ? 'User is a member of the responsible group'
                : 'Only members of the responsible group can complete this workflow',
            policy
        };
    }
}
