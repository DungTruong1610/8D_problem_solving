/**
 * @cnma/cap-workflow — Email Templates
 *
 * HTML email templates for workflow notifications.
 * Inline CSS for email client compatibility (Outlook, Gmail, etc.).
 *
 * Template variables: {{variableName}} — replaced at render time.
 */

// ─── Base Layout ────────────────────────────────────────────────────────────

function baseLayout(title: string, bodyContent: string): string {
    return `<!DOCTYPE html>
<html xmlns:v="urn:schemas-microsoft-com:vml" xmlns:o="urn:schemas-microsoft-com:office:office">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<!--[if mso]>
<xml><o:OfficeDocumentSettings><o:AllowPNG/><o:PixelsPerInch>96</o:PixelsPerInch></o:OfficeDocumentSettings></xml>
<![endif]-->
</head>
<body style="margin:0;padding:0;background-color:#f4f5f7;font-family:'Segoe UI',Roboto,'Helvetica Neue',Arial,sans-serif;">
<table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0" style="background-color:#f4f5f7;padding:24px 0;">
<tr><td align="center">
<table role="presentation" width="600" cellpadding="0" cellspacing="0" border="0" style="max-width:600px;width:100%;background-color:#ffffff;border-radius:8px;">
    <!-- Header -->
    <tr>
        <td style="background-color:#1a56db;border-radius:8px 8px 0 0;padding:24px 32px;" bgcolor="#1a56db">
            <!--[if mso]><table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0"><tr><td bgcolor="#1a56db" style="padding:24px 32px;"><![endif]-->
            <h1 style="margin:0;color:#ffffff;font-size:18px;font-weight:600;font-family:'Segoe UI',Roboto,'Helvetica Neue',Arial,sans-serif;">${title}</h1>
            <!--[if mso]></td></tr></table><![endif]-->
        </td>
    </tr>
    <!-- Body -->
    <tr><td style="padding:32px;">
        ${bodyContent}
    </td></tr>
    <!-- Footer -->
    <tr><td style="padding:16px 32px;border-top:1px solid #e5e7eb;text-align:center;">
        <p style="margin:0;color:#9ca3af;font-size:11px;font-family:'Segoe UI',Roboto,'Helvetica Neue',Arial,sans-serif;">This is an automated notification from the Workflow Engine. Do not reply to this email.</p>
    </td></tr>
</table>
</td></tr>
</table>
</body>
</html>`;
}

// ─── HTML Sanitization (M7 security fix) ────────────────────────────────────

/** Escape HTML special characters to prevent injection in email bodies. */
function escapeHtml(str: string): string {
    return str
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#39;');
}

/** Sanitize all string values in template vars. URLs (documentLink) are excluded. */
function sanitizeVars(vars: EmailTemplateVars): EmailTemplateVars {
    const sanitized: EmailTemplateVars = {};
    for (const [key, value] of Object.entries(vars)) {
        if (key === 'businessFields' && Array.isArray(value)) {
            // Sanitize each business field label and value
            sanitized.businessFields = value.map((f: { label: string; value: string; fieldKey?: string }) => ({
                label: escapeHtml(f.label),
                value: escapeHtml(f.value),
                fieldKey: f.fieldKey,
            }));
        } else if (typeof value === 'string' && key !== 'documentLink') {
            (sanitized as any)[key] = escapeHtml(value);
        } else {
            (sanitized as any)[key] = value;
        }
    }
    return sanitized;
}

// ─── Shared Fragments ───────────────────────────────────────────────────────

function actionButton(label: string, url: string, color: string = '#1a56db'): string {
    return `<table role="presentation" cellpadding="0" cellspacing="0" border="0" width="100%">
<tr><td style="padding:24px 0 8px 0;" align="left">
<table role="presentation" cellpadding="0" cellspacing="0" border="0">
<tr><td align="center" bgcolor="${color}" style="border-radius:6px;padding:12px 28px;">
    <a href="${url}" target="_blank" style="color:#ffffff;display:block;font-family:'Segoe UI',Roboto,'Helvetica Neue',Arial,sans-serif;font-size:14px;font-weight:600;line-height:1.2;text-decoration:none;white-space:nowrap;">${label}</a>
</td></tr>
</table>
</td></tr>
</table>`;
}

function infoRow(label: string, value: string, isLast: boolean = false): string {
    const borderStyle = isLast ? '' : 'border-bottom:1px solid #e5e7eb;';
    return `<tr>
    <td style="padding:10px 16px;color:#6b7280;font-size:13px;white-space:nowrap;width:35%;${borderStyle}font-family:'Segoe UI',Roboto,'Helvetica Neue',Arial,sans-serif;">${label}</td>
    <td style="padding:10px 16px;font-size:13px;font-weight:600;color:#111827;${borderStyle}font-family:'Segoe UI',Roboto,'Helvetica Neue',Arial,sans-serif;">${value}</td>
</tr>`;
}

function infoTable(rows: Array<[string, string]>): string {
    return `<table role="presentation" cellpadding="0" cellspacing="0" border="0" width="100%" style="border:1px solid #e5e7eb;border-radius:6px;margin:16px 0;border-collapse:collapse;">
    ${rows.map(([l, v], i) => infoRow(l, v, i === rows.length - 1)).join('')}
</table>`;
}

/** Render additional business field rows as a second info table (if any). */
function renderBusinessFields(vars: EmailTemplateVars, excludeKeys?: Set<string>): string {
    if (!vars.businessFields || vars.businessFields.length === 0) return '';
    const filtered = excludeKeys 
        ? vars.businessFields.filter(f => !excludeKeys.has(f.fieldKey || f.label))
        : vars.businessFields;
    
    if (filtered.length === 0) return '';
    const rows: Array<[string, string]> = filtered.map(f => [f.label, f.value || '—']);
    return infoTable(rows);
}

// ─── Templates ──────────────────────────────────────────────────────────────

export type EmailTemplateType =
    | 'TASK_ASSIGNED'
    | 'TASK_APPROVED'
    | 'TASK_REJECTED'
    | 'TASK_REASSIGNED'
    | 'TASK_REMINDER'
    | 'WORKFLOW_COMPLETED'
    | 'WORKFLOW_REJECTED';

export interface EmailTemplateVars {
    assigneeName?: string;
    assigneeEmail?: string;
    stepName?: string;
    workflowType?: string;
    documentReference?: string;
    documentLink?: string;
    approverName?: string;
    comment?: string;
    responsibleName?: string;
    objectType?: string;
    reassignerName?: string;
    /** Dynamic business fields resolved from extractionData (e.g. Invoicing Party, Supplier Invoice No) */
    businessFields?: Array<{ fieldKey?: string; label: string; value: string }>;
}

/**
 * Render an email template with the given variables.
 * Returns { subject, htmlBody }.
 */
export function renderEmailTemplate(
    template: EmailTemplateType,
    rawVars: EmailTemplateVars
): { subject: string; htmlBody: string } {
    const vars = sanitizeVars(rawVars);
    switch (template) {
        case 'TASK_ASSIGNED':
            return {
                subject: `🔔 Approval Required: ${vars.workflowType || 'Workflow'} — ${vars.stepName || 'Step'}`,
                htmlBody: baseLayout('Approval Task Assigned', `
                    <p style="margin:0 0 16px;color:#374151;font-size:14px;">
                        Hello <strong>${vars.assigneeName || 'Approver'}</strong>,
                    </p>
                    <p style="margin:0 0 16px;color:#374151;font-size:14px;">
                        You have been assigned an approval task for the following document:
                    </p>
                    ${infoTable([
                        ['Workflow', vars.workflowType || '—'],
                        ['Step', vars.stepName || '—'],
                        ['Document', vars.documentReference || '—'],
                        ['Object Type', vars.objectType || '—'],
                    ])}
                    ${renderBusinessFields(vars)}
                    ${vars.documentLink ? actionButton('Review & Approve', vars.documentLink) : ''}
                    <p style="margin:16px 0 0;color:#6b7280;font-size:12px;">
                        Please review the document and decide to approve or reject.
                    </p>
                `),
            };

        case 'TASK_APPROVED':
            return {
                subject: `✅ Approved: ${vars.workflowType || 'Workflow'} — ${vars.stepName || 'Step'}`,
                htmlBody: baseLayout('Task Approved', `
                    <p style="margin:0 0 16px;color:#374151;font-size:14px;">
                        The approval task for step <strong>"${vars.stepName || '—'}"</strong> has been <span style="color:#059669;font-weight:600;">approved</span>.
                    </p>
                    ${infoTable([
                        ['Approved by', vars.approverName || '—'],
                        ['Workflow', vars.workflowType || '—'],
                        ['Document', vars.documentReference || '—'],
                        ...(vars.comment ? [['Comment', vars.comment] as [string, string]] : []),
                    ])}
                    ${renderBusinessFields(vars)}
                    ${vars.documentLink ? actionButton('View Document', vars.documentLink, '#059669') : ''}
                `),
            };

        case 'TASK_REJECTED':
            return {
                subject: `❌ Rejected: ${vars.workflowType || 'Workflow'} — ${vars.stepName || 'Step'}`,
                htmlBody: baseLayout('Task Rejected', `
                    <p style="margin:0 0 16px;color:#374151;font-size:14px;">
                        The approval task for step <strong>"${vars.stepName || '—'}"</strong> has been <span style="color:#dc2626;font-weight:600;">rejected</span>.
                    </p>
                    ${infoTable([
                        ['Rejected by', vars.approverName || '—'],
                        ['Workflow', vars.workflowType || '—'],
                        ['Document', vars.documentReference || '—'],
                        ['Reason', vars.comment || 'No reason provided'],
                    ])}
                    ${renderBusinessFields(vars)}
                    ${vars.documentLink ? actionButton('View Document', vars.documentLink, '#dc2626') : ''}
                `),
            };

        case 'WORKFLOW_COMPLETED':
            return {
                subject: `🎉 Workflow Completed: ${vars.workflowType || 'Workflow'}`,
                htmlBody: baseLayout('Workflow Completed', `
                    <p style="margin:0 0 16px;color:#374151;font-size:14px;">
                        The workflow <strong>"${vars.workflowType || '—'}"</strong> has been 
                        <span style="color:#059669;font-weight:600;">completed</span>. All approval steps have been passed.
                    </p>
                    ${infoTable([
                        ['Workflow', vars.workflowType || '—'],
                        ['Document', vars.documentReference || '—'],
                        ['Responsible', vars.responsibleName || '—'],
                    ])}
                    ${renderBusinessFields(vars)}
                    ${vars.documentLink ? actionButton('View Document', vars.documentLink, '#059669') : ''}
                    <p style="margin:16px 0 0;color:#6b7280;font-size:12px;">
                        The document is now ready for posting.
                    </p>
                `),
            };

        case 'WORKFLOW_REJECTED':
            return {
                subject: `⚠️ Workflow Rejected: ${vars.workflowType || 'Workflow'}`,
                htmlBody: baseLayout('Workflow Rejected', `
                    <p style="margin:0 0 16px;color:#374151;font-size:14px;">
                        The workflow <strong>"${vars.workflowType || '—'}"</strong> has been 
                        <span style="color:#dc2626;font-weight:600;">rejected</span>.
                    </p>
                    ${infoTable([
                        ['Workflow', vars.workflowType || '—'],
                        ['Document', vars.documentReference || '—'],
                        ['Rejected by', vars.approverName || '—'],
                        ['Reason', vars.comment || 'No reason provided'],
                    ])}
                    ${renderBusinessFields(vars)}
                    ${vars.documentLink ? actionButton('View Document', vars.documentLink, '#dc2626') : ''}
                    <p style="margin:16px 0 0;color:#6b7280;font-size:12px;">
                        Please review the document and take corrective action.
                    </p>
                `),
            };

        case 'TASK_REASSIGNED':
            return {
                subject: `🔄 Task Reassigned: ${vars.workflowType || 'Workflow'} — ${vars.stepName || 'Step'}`,
                htmlBody: baseLayout('Task Reassigned to You', `
                    <p style="margin:0 0 16px;color:#374151;font-size:14px;">
                        Dear <strong>${vars.assigneeName || 'Colleague'}</strong>,
                    </p>
                    <p style="margin:0 0 16px;color:#374151;font-size:14px;">
                        A task has been <span style="color:#7c3aed;font-weight:600;">reassigned to you</span>
                        for step <strong>"${vars.stepName || '—'}"</strong>
                        in workflow <strong>"${vars.workflowType || '—'}"</strong>.
                    </p>
                    ${infoTable([
                        ['Workflow', vars.workflowType || '—'],
                        ['Step', vars.stepName || '—'],
                        ['Document', vars.documentReference || '—'],
                        ['Reassigned by', vars.reassignerName || '—'],
                        ['Reason', vars.comment || 'No reason provided'],
                    ])}
                    ${renderBusinessFields(vars)}
                    ${vars.documentLink ? actionButton('Review Document', vars.documentLink) : ''}
                `),
            };

        case 'TASK_REMINDER':
            return {
                subject: `⏰ Reminder: ${vars.workflowType || 'Workflow'} — ${vars.stepName || 'Step'}`,
                htmlBody: baseLayout('Approval Reminder', `
                    <p style="margin:0 0 16px;color:#374151;font-size:14px;">
                        Dear <strong>${vars.assigneeName || 'Approver'}</strong>,
                    </p>
                    <p style="margin:0 0 16px;color:#374151;font-size:14px;">
                        This is a friendly reminder that you have a <span style="color:#d97706;font-weight:600;">pending approval task</span>
                        for step <strong>"${vars.stepName || '—'}"</strong>
                        in workflow <strong>"${vars.workflowType || '—'}"</strong>.
                    </p>
                    <p style="margin:0 0 16px;color:#374151;font-size:14px;">
                        The responsible person has requested your timely review.
                    </p>
                    ${infoTable([
                        ['Workflow', vars.workflowType || '—'],
                        ['Step', vars.stepName || '—'],
                        ['Document', vars.documentReference || '—'],
                        ['Object Type', vars.objectType || '—'],
                        ['Requested by', vars.responsibleName || '—'],
                    ])}
                    ${renderBusinessFields(vars)}
                    ${vars.documentLink ? actionButton('Review & Approve', vars.documentLink, '#d97706') : ''}
                    <p style="margin:16px 0 0;color:#6b7280;font-size:12px;">
                        Please review the document and take action at your earliest convenience.
                    </p>
                `),
            };

        default:
            throw new Error(`Unknown email template: ${template}`);
    }
}

// ─── Structured Template Rendering ──────────────────────────────────────────

import type { IStructuredTemplate } from './types';

/** Map of info field keys to their labels and variable names */
const INFO_FIELD_MAP: Record<string, { label: string; varKey: keyof EmailTemplateVars }> = {
    workflow:    { label: 'Workflow',    varKey: 'workflowType' },
    step:        { label: 'Step',        varKey: 'stepName' },
    document:    { label: 'Document',    varKey: 'documentReference' },
    objectType:  { label: 'Object Type', varKey: 'objectType' },
    approver:    { label: 'Approved by', varKey: 'approverName' },
    rejector:    { label: 'Rejected by', varKey: 'approverName' },
    responsible: { label: 'Responsible', varKey: 'responsibleName' },
    comment:     { label: 'Comment',     varKey: 'comment' },
    reassigner:  { label: 'Reassigned by', varKey: 'reassignerName' },
};

/**
 * Replace {{variable}} placeholders in a string with values from vars.
 */
function replacePlaceholders(text: string, vars: EmailTemplateVars): string {
    return text.replace(/\{\{(\w+)\}\}/g, (_, key) => {
        return (vars as any)[key] || '';
    });
}

/**
 * Render a structured template (from admin UI) into email-safe HTML.
 * Uses the shared baseLayout() for consistent branding.
 *
 * @param template The structured template (subject, greeting, bodyText, infoFields, etc.)
 * @param rawVars Template variables (assigneeName, stepName, etc.)
 * @returns { subject, htmlBody } ready for IEmailSender.sendEmail()
 */
export function renderStructuredTemplate(
    template: IStructuredTemplate,
    rawVars: EmailTemplateVars
): { subject: string; htmlBody: string } {
    const vars = sanitizeVars(rawVars);

    // Subject — replace placeholders (not HTML, no sanitization needed on output)
    const subject = replacePlaceholders(template.subject, vars);

    // Greeting
    const greetingHtml = template.greeting
        ? `<p style="margin:0 0 16px;color:#374151;font-size:14px;">${replacePlaceholders(template.greeting, vars)}</p>`
        : '';

    // Body text — convert newlines to <br> for email
    const bodyHtml = template.bodyText
        ? `<p style="margin:0 0 16px;color:#374151;font-size:14px;">${replacePlaceholders(template.bodyText, vars).replace(/\n/g, '<br>')}</p>`
        : '';

    // Info table — build rows from selected fields
    const infoRows: Array<[string, string]> = [];
    const usedBusinessFields = new Set<string>();

    for (const fieldKey of (template.infoFields || [])) {
        const mapping = INFO_FIELD_MAP[fieldKey];
        if (mapping) {
            const value = (vars as any)[mapping.varKey] || '—';
            infoRows.push([mapping.label, value]);
        } else if (vars.businessFields) {
            // Find custom business field by fieldKey OR fallback to label
            const bf = vars.businessFields.find(f => f.fieldKey === fieldKey || f.label === fieldKey);
            if (bf) {
                infoRows.push([bf.label, bf.value || '—']);
                usedBusinessFields.add(bf.fieldKey || bf.label);
            }
        }
    }
    const infoTableHtml = infoRows.length > 0 ? infoTable(infoRows) : '';

    // Action button
    const buttonHtml = (template.buttonLabel && vars.documentLink)
        ? actionButton(
            replacePlaceholders(template.buttonLabel, vars),
            vars.documentLink,
            template.buttonColor || '#1a56db'
        )
        : '';

    // Assemble into base layout
    const htmlBody = baseLayout('Workflow Notification', `
        ${greetingHtml}
        ${bodyHtml}
        ${infoTableHtml}
        ${renderBusinessFields(vars, usedBusinessFields)}
        ${buttonHtml}
    `);

    return { subject, htmlBody };
}
