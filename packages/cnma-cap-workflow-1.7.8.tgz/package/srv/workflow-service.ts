import cds from '@sap/cds';
import { WorkflowEngine } from './lib/WorkflowEngine';
import { ApprovalHandler } from './lib/ApprovalHandler';
import { StepAdvancer } from './lib/StepAdvancer';
import { PrincipalResolver } from './lib/PrincipalResolver';
import { WorkflowNotifier } from './lib/WorkflowNotifier';
import { CDS_ENTITIES } from './lib/types';
import type {
    IWorkflowInstance,
    IStepInstance,
    IApprovalTask,
    IWorkflowDefinition,
} from './lib/types';

const LOG = cds.log('workflow.service');

/**
 * WorkflowService — CAP runtime service handler
 *
 * Wires OData actions to engine classes:
 *   - startWorkflow → WorkflowEngine.createWorkflow + startWorkflow
 *   - approveStep → ApprovalHandler.approveTask
 *   - rejectStep → ApprovalHandler.rejectTask
 *   - reassignApprover → ApprovalHandler.reassignTask
 *   - cancelWorkflow → WorkflowEngine.cancelWorkflow
 *   - rerunWorkflow → WorkflowEngine.rerunWorkflow
 *
 * Emits synchronous `workflow.statusChanged` events (T7).
 */
export default class WorkflowServiceHandler extends cds.ApplicationService {
    async init() {

        // ─── READ handlers: row-level security (C4) ─────────────────────
        // Filter all runtime projections to records the calling user can see:
        //   - Workflows where the user is the responsible person (direct or via group)
        //   - Workflows where the user has at least one approval task (direct or via group)
        // Admin users bypass these filters.

        this.before('READ', ['WorkflowInstances', 'StepInstances', 'WorkflowHistories'], async (req: any) => {
            if (req.user?.is('admin')) return;

            const userId = req.user?.id;
            const accessibleIds = await this.resolveAccessibleWorkflowIds(userId);

            if (accessibleIds.length === 0) {
                // No accessible workflows — force an empty result
                req.query.where({ ID: null });
                return;
            }

            if (req.entity.endsWith('WorkflowInstances')) {
                req.query.where({ ID: { in: accessibleIds } });
            } else {
                // StepInstances and WorkflowHistories — filter by parent workflow
                req.query.where({ workflowInstance_ID: { in: accessibleIds } });
            }
        });

        this.before('READ', 'ApprovalTasks', async (req: any) => {
            if (req.user?.is('admin')) return;

            const userId = req.user?.id;
            const { allIds } = await PrincipalResolver.resolveUserScope(userId);

            if (allIds.length === 0) {
                req.query.where({ ID: null });
                return;
            }

            // Show tasks where the user is the assignee or the decider
            req.query.where({ assigneeId: { in: allIds } });
        });

        // ─── READ handlers: populate virtual name fields (T1) ────────────

        this.after('READ', 'WorkflowInstances', async (results: any[]) => {
            await PrincipalResolver.populateVirtualNames(results, [
                { typeField: 'responsibleType', idField: 'responsibleId', nameField: 'responsibleName' },
            ]);
        });

        this.after('READ', 'ApprovalTasks', async (results: any[]) => {
            await PrincipalResolver.populateVirtualNames(results, [
                { typeField: 'assigneeType', idField: 'assigneeId', nameField: 'assigneeName' },
                { typeField: 'decidedByType', idField: 'decidedById', nameField: 'decidedByName' },
            ]);
        });

        this.after('READ', 'WorkflowHistories', async (results: any[]) => {
            // Resolve performedById → performedByName
            // History records always track by USER (no performedByType field)
            if (!results) return;
            const rows = Array.isArray(results) ? results : [results];
            const principals = rows
                .filter((r: any) => r.performedById && !r.isSystemAction)
                .map((r: any) => ({ type: 'USER', id: r.performedById }));

            if (principals.length > 0) {
                const nameMap = await PrincipalResolver.resolveNames(principals);
                for (const row of rows) {
                    if (row.performedById) {
                        row.performedByName = row.isSystemAction
                            ? 'System'
                            : (nameMap.get(row.performedById) || 'Unknown');
                    }
                }
            }
        });

        // ─── Actions ─────────────────────────────────────────────────────

        this.on('startWorkflow', async (req: any) => {
            const { referenceId, referenceType, definitionId, responsibleType, responsibleId, approverOverrides, documentData } = req.data;

            // ── Responsible person authorization guard ──────────────────
            const definition = await cds.run(
                SELECT.one.from(CDS_ENTITIES.WorkflowDefinition)
                    .where({ ID: definitionId, isActive: true })
            ) as IWorkflowDefinition | null;

            if (!definition) {
                return req.error(404, `Workflow definition '${definitionId}' not found or inactive`);
            }

            if (definition.responsibleType && definition.responsibleId) {
                const userId = req.user?.id;
                const isAuthorized = await PrincipalResolver.isResponsiblePerson(userId, definition.responsibleType, definition.responsibleId);
                if (!isAuthorized) {
                    LOG.warn('Unauthorized workflow start attempt', {
                        userId, definitionId,
                        responsibleType: definition.responsibleType,
                        responsibleId: definition.responsibleId,
                    });
                    return req.error(403, 'You are not authorized to start this workflow. Only the responsible person (or group member) can submit workflows.');
                }
            }

            // Parse approverOverrides if provided as JSON string
            let parsedOverrides;
            if (approverOverrides) {
                try {
                    parsedOverrides = typeof approverOverrides === 'string'
                        ? JSON.parse(approverOverrides)
                        : approverOverrides;
                } catch (e) {
                    return req.error(400, 'Invalid approverOverrides JSON');
                }
            }

            // Parse documentData if provided as JSON string
            let parsedDocumentData;
            if (documentData) {
                try {
                    parsedDocumentData = typeof documentData === 'string'
                        ? JSON.parse(documentData)
                        : documentData;
                } catch (e) {
                    return req.error(400, 'Invalid documentData JSON');
                }
            }

            try {
                // Create + start in one operation
                const workflowId = await WorkflowEngine.createWorkflow({
                    referenceId,
                    referenceType,
                    definitionId,
                    responsibleType,
                    responsibleId,
                    approverOverrides: parsedOverrides,
                    documentData: parsedDocumentData,
                });

                await WorkflowEngine.startWorkflow(workflowId);

                // Emit status changed (T7 — synchronous within this tx)
                await this.emitStatusChanged(workflowId);

                LOG.info('Workflow started via action', { workflowId, referenceType, referenceId });

                return { workflowId, status: 'ACTIVE' };
            } catch (err: any) {
                LOG.error('Failed to start workflow', err);
                return req.error(err.code || 500, err.message);
            }
        });

        this.on('approveStep', async (req: any) => {
            const { taskId, comment } = req.data;
            const userId = req.user?.id;

            try {
                const result = await ApprovalHandler.approveTask({ taskId, comment, userId });

                // Get the workflow ID for status change event
                const step = await cds.run(
                    SELECT.one.from(CDS_ENTITIES.StepInstance)
                        .columns('workflowInstance_ID')
                        .where({ ID: result.stepInstance_ID })
                ) as { workflowInstance_ID: string } | null;

                if (step) {
                    await this.emitStatusChanged(step.workflowInstance_ID);
                }

                return { taskId: result.ID, status: result.status };
            } catch (err: any) {
                LOG.error('Failed to approve task', err);
                return req.error(err.code || 500, err.message);
            }
        });

        this.on('rejectStep', async (req: any) => {
            const { taskId, comment } = req.data;
            const userId = req.user?.id;

            try {
                const result = await ApprovalHandler.rejectTask({ taskId, comment, userId });

                const step = await cds.run(
                    SELECT.one.from(CDS_ENTITIES.StepInstance)
                        .columns('workflowInstance_ID')
                        .where({ ID: result.stepInstance_ID })
                ) as { workflowInstance_ID: string } | null;

                if (step) {
                    await this.emitStatusChanged(step.workflowInstance_ID);
                }

                return { taskId: result.ID, status: result.status };
            } catch (err: any) {
                LOG.error('Failed to reject task', err);
                return req.error(err.code || 500, err.message);
            }
        });

        this.on('reassignApprover', async (req: any) => {
            const { taskId, newAssigneeType, newAssigneeId, reason } = req.data;
            const userId = req.user?.id;

            try {
                const result = await ApprovalHandler.reassignTask({
                    taskId, newAssigneeType, newAssigneeId, reason, userId,
                });

                const step = await cds.run(
                    SELECT.one.from(CDS_ENTITIES.StepInstance)
                        .columns('workflowInstance_ID')
                        .where({ ID: result.stepInstance_ID })
                ) as { workflowInstance_ID: string } | null;

                if (step) {
                    await this.emitStatusChanged(step.workflowInstance_ID);
                }

                return { taskId: result.ID, status: result.status };
            } catch (err: any) {
                LOG.error('Failed to reassign task', err);
                return req.error(err.code || 500, err.message);
            }
        });

        this.on('cancelWorkflow', async (req: any) => {
            const { workflowId, reason } = req.data;
            const userId = req.user?.id;

            // C1: Only the responsible person (or an admin) can cancel a workflow
            if (!req.user?.is('admin')) {
                const instance = await cds.run(
                    SELECT.one.from(CDS_ENTITIES.WorkflowInstance)
                        .columns((c: any) => { c.responsibleType, c.responsibleId, c.status, c.createdBy((u: any) => u.userId) })
                        .where({ ID: workflowId })
                ) as any;

                if (!instance) {
                    return req.error(404, `Workflow '${workflowId}' not found`);
                }

                let isAuthorized = false;
                if (instance?.createdBy?.userId === userId) {
                    isAuthorized = true;
                } else if (instance.responsibleType && instance.responsibleId) {
                    isAuthorized = await PrincipalResolver.isResponsiblePerson(
                        userId, instance.responsibleType, instance.responsibleId
                    );
                }
                if (!isAuthorized) {
                    LOG.warn('Unauthorized cancel attempt', { userId, workflowId });
                    return req.error(403, 'Only the workflow responsible person (or submitter) can cancel this workflow.');
                }
            }

            try {
                await WorkflowEngine.cancelWorkflow(workflowId, reason);
                await this.emitStatusChanged(workflowId);

                return { workflowId, status: 'CANCELLED' };
            } catch (err: any) {
                LOG.error('Failed to cancel workflow', err);
                return req.error(err.code || 500, err.message);
            }
        });

        this.on('rerunWorkflow', async (req: any) => {
            const { workflowId, approverOverrides } = req.data;
            const userId = req.user?.id;

            // C2: Only the responsible person (or an admin) can rerun a workflow
            if (!req.user?.is('admin')) {
                const instance = await cds.run(
                    SELECT.one.from(CDS_ENTITIES.WorkflowInstance)
                        .columns((c: any) => { c.responsibleType, c.responsibleId, c.status, c.createdBy((u: any) => u.userId) })
                        .where({ ID: workflowId })
                ) as any;

                if (!instance) {
                    return req.error(404, `Workflow '${workflowId}' not found`);
                }

                let isAuthorized = false;
                if (instance?.createdBy?.userId === userId) {
                    isAuthorized = true;
                } else if (instance.responsibleType && instance.responsibleId) {
                    isAuthorized = await PrincipalResolver.isResponsiblePerson(
                        userId, instance.responsibleType, instance.responsibleId
                    );
                }
                if (!isAuthorized) {
                    LOG.warn('Unauthorized rerun attempt', { userId, workflowId });
                    return req.error(403, 'Only the workflow responsible person (or submitter) can rerun this workflow.');
                }
            }

            try {
                const newWorkflowId = await WorkflowEngine.rerunWorkflow(workflowId, approverOverrides);
                await WorkflowEngine.startWorkflow(newWorkflowId);
                await this.emitStatusChanged(newWorkflowId);

                return { newWorkflowId, status: 'ACTIVE' };
            } catch (err: any) {
                LOG.error('Failed to rerun workflow', err);
                return req.error(err.code || 500, err.message);
            }
        });

        this.on('remindApprovers', async (req: any) => {
            const { workflowId } = req.data;
            const userId = req.user?.id;

            // Only the responsible person (or an admin) can send reminders
            if (!req.user?.is('admin')) {
                const instance = await cds.run(
                    SELECT.one.from(CDS_ENTITIES.WorkflowInstance)
                        .columns((c: any) => { c.responsibleType, c.responsibleId, c.status, c.createdBy((u: any) => u.userId) })
                        .where({ ID: workflowId })
                ) as any;

                if (!instance) {
                    return req.error(404, `Workflow '${workflowId}' not found`);
                }

                if (instance.status !== 'ACTIVE') {
                    return req.error(400, 'Reminders can only be sent for active workflows.');
                }

                let isAuthorized = false;
                if (instance?.createdBy?.userId === userId) {
                    isAuthorized = true;
                } else if (instance.responsibleType && instance.responsibleId) {
                    isAuthorized = await PrincipalResolver.isResponsiblePerson(
                        userId, instance.responsibleType, instance.responsibleId
                    );
                }
                if (!isAuthorized) {
                    LOG.warn('Unauthorized reminder attempt', { userId, workflowId });
                    return req.error(403, 'Only the workflow responsible person (or submitter) can send reminders.');
                }
            }

            try {
                const result = await WorkflowNotifier.notifyTaskReminder(workflowId);
                LOG.info('Reminder sent', { workflowId, reminded: result.reminded });
                return { reminded: result.reminded };
            } catch (err: any) {
                LOG.error('Failed to send reminder', err);
                return req.error(err.code || 500, err.message);
            }
        });

        // ─── Functions ───────────────────────────────────────────────────

        this.on('getProcessFlow', async (req: any) => {
            const { workflowId } = req.data;
            const userId = req.user?.id;

            const steps = await cds.run(
                SELECT.from(CDS_ENTITIES.StepInstance)
                    .where({ workflowInstance_ID: workflowId })
                    .orderBy('displayOrder asc')
            ) as IStepInstance[];

            // Resolve current user's ShadowUser UUID (origin-scoped)
            let currentUserUUID: string | null = null;
            try {
                currentUserUUID = await PrincipalResolver.resolveUUID(userId);
                // resolveUUID returns userId as-is if no shadow user found
                if (currentUserUUID === userId) currentUserUUID = null;
            } catch (e) {
                LOG.warn('Failed to resolve ShadowUser for process flow:', e);
            }

            // Resolve whether the caller is the workflow's responsible person
            // (used for isReassignable — OOO delegation)
            let isResponsiblePerson = false;
            let fourEyesEnforced = true; // Default: self-approval blocked
            try {
                const instance = await cds.run(
                    SELECT.one.from(CDS_ENTITIES.WorkflowInstance)
                        .columns((c: any) => { c.responsibleType, c.responsibleId, c.definition_ID, c.createdBy((u: any) => u.userId) })
                        .where({ ID: workflowId })
                ) as any;

                if (instance?.createdBy?.userId === userId) {
                    isResponsiblePerson = true;
                } else if (instance?.responsibleType && instance?.responsibleId) {
                    isResponsiblePerson = await PrincipalResolver.isResponsiblePerson(
                        userId, instance.responsibleType, instance.responsibleId
                    );
                }

                if (instance?.definition_ID) {
                    const def = await cds.run(
                        SELECT.one.from(CDS_ENTITIES.WorkflowDefinition)
                            .columns('enforceFourEyes')
                            .where({ ID: instance.definition_ID })
                    ) as { enforceFourEyes?: boolean } | null;
                    if (def?.enforceFourEyes === false) {
                        fourEyesEnforced = false;
                    }
                }
            } catch (e) {
                LOG.warn('Failed to resolve responsible person for process flow:', e);
            }

            const result = [];
            for (const step of steps) {
                const tasks = await cds.run(
                    SELECT.from(CDS_ENTITIES.ApprovalTask)
                        .where({ stepInstance_ID: step.ID })
                        .orderBy('taskOrder asc')
                ) as IApprovalTask[];

                // Batch-resolve assignee names for tasks
                const nameMap = await PrincipalResolver.resolveNames(
                    tasks.map(t => ({ type: t.assigneeType, id: t.assigneeId }))
                );

                // Batch-resolve decidedBy names for decided tasks
                const decidedTasks = tasks.filter(t => t.decidedById);
                const decidedByMap = decidedTasks.length > 0
                    ? await PrincipalResolver.resolveNames(
                        decidedTasks.map(t => ({ type: t.decidedByType || 'USER', id: t.decidedById! }))
                    )
                    : new Map<string, string>();

                // Per-task authorization: determine if current user can act on each task
                const taskResults = [];
                for (const t of tasks) {
                    let isActionable = false;
                    let isReassignable = false;

                    // Only pending tasks in active steps can be actionable
                    if (t.status === 'PENDING' && step.status === 'ACTIVE' && currentUserUUID) {
                        if (t.assigneeType === 'USER') {
                            // Direct user match (origin-scoped)
                            isActionable = t.assigneeId === currentUserUUID;
                        } else {
                            // Group membership check
                            try {
                                isActionable = await PrincipalResolver.isMember(userId, t.assigneeId);
                            } catch (e) {
                                LOG.warn('Group membership check failed in processFlow:', e);
                            }
                        }
                    }

                    // 4-eyes principle check for UI: if actionable but blocked by 4-eyes, revoke actionability
                    // so the UI hides Approve/Reject and falls back to Reassign.
                    if (isActionable && fourEyesEnforced && isResponsiblePerson) {
                        isActionable = false;
                    }

                    // Responsible person can reassign any pending task (OOO delegation)
                    // but CANNOT approve/reject (those stay gated by isActionable)
                    if (!isActionable && t.status === 'PENDING' && step.status === 'ACTIVE' && isResponsiblePerson) {
                        isReassignable = true;
                    }

                    taskResults.push({
                        taskId: t.ID,
                        assigneeName: nameMap.get(t.assigneeId) || 'Unknown',
                        assigneeType: t.assigneeType,
                        status: t.status,
                        decidedAt: t.decidedAt,
                        decidedByName: t.decidedById ? (decidedByMap.get(t.decidedById) || undefined) : undefined,
                        decidedByType: t.decidedByType || undefined,
                        comment: t.comment,
                        isActionable,
                        isReassignable,
                    });
                }

                result.push({
                    stepId: step.ID,
                    stepName: step.stepName,
                    displayOrder: step.displayOrder,
                    status: step.status,
                    approvalMode: step.approvalMode,
                    approverSeqMode: step.approverSeqMode,
                    activatedAt: step.activatedAt,
                    completedAt: step.completedAt,
                    tasks: taskResults,
                });
            }

            return result;
        });

        this.on('getAvailableWorkflows', async (req: any) => {
            const { objectType, orgKeyValue } = req.data;
            const userId = req.user?.id;

            // Find all active definitions for this objectType, ordered by priority
            const definitions = await cds.run(
                SELECT.from(CDS_ENTITIES.WorkflowDefinition)
                    .where({ objectType, isActive: true })
                    .orderBy('priority desc')
            ) as IWorkflowDefinition[];

            LOG.info(`[getAvailableWorkflows] objectType='${objectType}', orgKeyValue='${orgKeyValue}', found=${definitions.length}`);

            // Resolution strategy:
            // - If orgKeyValue provided: return org-specific matches + global (null/empty) fallbacks
            // - If orgKeyValue empty/null: return ALL definitions (backend couldn't determine org,
            //   so let the user see all options or auto-pick if only one exists)
            const hasOrgKey = orgKeyValue && orgKeyValue.trim() !== '';
            const isGlobal = (d: IWorkflowDefinition) => !d.orgKeyValue || d.orgKeyValue.trim() === '';

            const matched = hasOrgKey
                ? definitions.filter(d => d.orgKeyValue === orgKeyValue || isGlobal(d))
                : definitions; // Return ALL when we can't filter by org

            // ── Responsible person filter: only show workflows the user can start ──
            const authorized: IWorkflowDefinition[] = [];
            for (const d of matched) {
                if (!d.responsibleType || !d.responsibleId) {
                    // No responsible person set → anyone can start
                    authorized.push(d);
                    continue;
                }
                const isResp = await PrincipalResolver.isResponsiblePerson(userId, d.responsibleType, d.responsibleId);
                if (isResp) {
                    authorized.push(d);
                } else {
                    LOG.debug(`[getAvailableWorkflows] Filtered out '${d.workflowType}': user '${userId}' is not responsible (${d.responsibleType}:${d.responsibleId})`);
                }
            }

            return authorized.map(d => ({
                definitionId: d.ID,
                workflowType: d.workflowType,
                description: d.description,
            }));
        });

        // ─── Get steps needing manual approver assignment ─────────────────

        this.on('getStepsNeedingApprovers', async (req: any) => {
            const { definitionId } = req.data;

            try {
                return await StepAdvancer.getStepsNeedingApprovers(definitionId);
            } catch (err: any) {
                LOG.error('Failed to get steps needing approvers', err);
                return req.error(err.code || 500, err.message);
            }
        });

        // ─── Get active step field settings for current user ─────────────
        // Returns whether the calling user is the current approver and, if so,
        // the step's field-level editability settings (mandatory/editable/readonly).

        this.on('getActiveStepFieldSettings', async (req: any) => {
            const { workflowId } = req.data;

            try {
                // 1. Get the active step instance
                const activeStep = await cds.run(
                    SELECT.one.from(CDS_ENTITIES.StepInstance)
                        .where({ workflowInstance_ID: workflowId, status: 'ACTIVE' })
                        .orderBy('displayOrder asc')
                ) as IStepInstance | null;

                if (!activeStep) {
                    return { isCurrentApprover: false, isResponsiblePerson: false, stepName: null, pendingTaskCount: 0, fieldSettings: null };
                }

                // 2. Get pending tasks for this step
                const pendingTasks = await cds.run(
                    SELECT.from(CDS_ENTITIES.ApprovalTask)
                        .where({ stepInstance_ID: activeStep.ID, status: 'PENDING' })
                ) as IApprovalTask[];

                if (pendingTasks.length === 0) {
                    return { isCurrentApprover: false, isResponsiblePerson: false, stepName: activeStep.stepName, pendingTaskCount: 0, fieldSettings: null };
                }

                // 3. Resolve current user's ShadowUser UUID (origin-scoped)
                const userId = req.user.id;
                let currentUserUUID: string | null = null;
                try {
                    const resolved = await PrincipalResolver.resolveUUID(userId);
                    currentUserUUID = resolved !== userId ? resolved : null;
                } catch (e) {
                    LOG.warn('Failed to resolve ShadowUser for field settings check:', e);
                }

                // 4. Check if current user has a pending task (direct or group member)
                let isCurrentApprover = false;
                for (const task of pendingTasks) {
                    // Direct user match (origin-scoped)
                    if (task.assigneeType === 'USER' && task.assigneeId === currentUserUUID) {
                        isCurrentApprover = true;
                        break;
                    }
                    // Group membership check
                    if (task.assigneeType !== 'USER') {
                        try {
                            const isMember = await PrincipalResolver.isMember(userId, task.assigneeId);
                            if (isMember) {
                                isCurrentApprover = true;
                                break;
                            }
                        } catch (e) {
                            LOG.warn('Group membership check failed:', e);
                        }
                    }
                }

                // 5. Check if the caller is the workflow's responsible person
                //    Enables the Reassign button for the submitter (OOO delegation)
                let isResponsiblePerson = false;
                const instance = await cds.run(
                    SELECT.one.from(CDS_ENTITIES.WorkflowInstance)
                        .columns('responsibleType', 'responsibleId')
                        .where({ ID: workflowId })
                ) as IWorkflowInstance | null;

                if (instance?.responsibleType && instance?.responsibleId) {
                    isResponsiblePerson = await PrincipalResolver.isResponsiblePerson(
                        userId, instance.responsibleType, instance.responsibleId
                    );
                }

                return {
                    isCurrentApprover,
                    isResponsiblePerson,
                    stepName: activeStep.stepName,
                    pendingTaskCount: pendingTasks.length,
                    fieldSettings: isCurrentApprover ? (activeStep.fieldSettings || null) : null,
                };
            } catch (err: any) {
                // M3: Log the actual error so "not an approver" is distinguishable from a real failure
                LOG.error('Failed to get active step field settings', { workflowId, error: err.message });
                return { isCurrentApprover: false, isResponsiblePerson: false, stepName: null, pendingTaskCount: 0, fieldSettings: null };
            }
        });

        await super.init();
    }

    // ─── Row-Level Security Helper (C4) ──────────────────────────────────

    /**
     * Return all WorkflowInstance IDs the calling user is allowed to see:
     *   - Workflows where they are the responsible person (direct or via group)
     *   - Workflows where they have at least one approval task (direct or via group)
     *
     * @param userId IDP identity (req.user.id)
     * @returns Deduplicated array of WorkflowInstance IDs
     */
    private async resolveAccessibleWorkflowIds(userId: string): Promise<string[]> {
        const { allIds } = await PrincipalResolver.resolveUserScope(userId);

        if (allIds.length === 0) return [];

        // Workflows where user is the responsible person
        const responsibleRows = await cds.run(
            SELECT.from(CDS_ENTITIES.WorkflowInstance)
                .columns('ID')
                .where({ responsibleId: { in: allIds } })
        ) as { ID: string }[];

        // Workflows where user has any approval task
        const taskRows = await cds.run(
            SELECT.from(CDS_ENTITIES.ApprovalTask)
                .columns('stepInstance_ID')
                .where({ assigneeId: { in: allIds } })
        ) as { stepInstance_ID: string }[];

        let taskWorkflowIds: string[] = [];
        if (taskRows.length > 0) {
            const stepIds = [...new Set(taskRows.map(t => t.stepInstance_ID))];
            const stepRows = await cds.run(
                SELECT.from(CDS_ENTITIES.StepInstance)
                    .columns('workflowInstance_ID')
                    .where({ ID: { in: stepIds } })
            ) as { workflowInstance_ID: string }[];
            taskWorkflowIds = stepRows.map(s => s.workflowInstance_ID);
        }

        return [...new Set([
            ...responsibleRows.map(r => r.ID),
            ...taskWorkflowIds,
        ])];
    }

    // ─── Status Change Event (T7) ────────────────────────────────────────

    /**
     * Emit a synchronous workflow.statusChanged event.
     * The host app subscribes to this to update denormalized fields.
     *
     * ⚠️ T7: This MUST be synchronous (within the same transaction).
     * Do NOT use cds.outboxed() here.
     */
    private async emitStatusChanged(workflowId: string): Promise<void> {
        try {
            const payload = await WorkflowEngine.buildStatusChangedPayload(workflowId);
            await this.emit('workflow.statusChanged', payload);
            LOG.debug('Status changed event emitted', { workflowId, status: payload.status });
        } catch (err: any) {
            LOG.error('Failed to emit status changed event', err);
            // Don't throw — status sync failure shouldn't block the action
        }
    }
}
