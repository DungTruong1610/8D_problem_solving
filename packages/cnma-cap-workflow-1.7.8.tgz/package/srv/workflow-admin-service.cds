/**
 * @cnma/cap-workflow — Admin Service (Workflow Configuration)
 *
 * Full CRUD for managing workflow definitions, steps, approvers, and dependencies.
 * Only users with 'admin' scope can access this service.
 *
 * Authorization: @requires 'admin'
 * Path: /workflow-admin
 *
 * NOTE: No @impl annotation — handler auto-discovered by CAP sibling convention (T4).
 */
using { cnma.workflow as tmpl } from '../db/workflow';

@requires: 'admin'
service WorkflowAdminService @(path: '/workflow-admin') {

    // Object Type Registry — admin can manage registered object types
    entity WorkflowObjectType as projection on tmpl.WorkflowObjectType
        order by objectType asc;

    // Workflow Definitions — full CRUD with deep insert (steps + approvers)
    entity WorkflowDefinitions as projection on tmpl.WorkflowDefinition;

    // Step Definitions — managed via deep operations on WorkflowDefinitions
    entity WorkflowStepDefinitions as projection on tmpl.WorkflowStepDefinition;

    // Default Approvers — managed via deep operations on Steps
    entity DefaultStepApprovers as projection on tmpl.DefaultStepApprover;

    // Step Dependencies (DAG edges) — managed via deep operations on Definitions
    entity StepDependencies as projection on tmpl.StepDependency;

    // Send a test email to verify template rendering in real email clients
    action sendTestEmail(
        eventType : String not null,
        recipientEmail : String not null,
        notificationSettings : LargeString
    );
}
