/**
 * @cnma/cap-workflow — Backend barrel export
 *
 * Usage:
 *   import { PrincipalResolver, DAGValidator, WorkflowEngine } from '@cnma/cap-workflow/srv';
 */

// Sprint 1: Principal resolution
export { PrincipalResolver } from './lib/PrincipalResolver';
export type { IPrincipal } from './lib/PrincipalResolver';

// Sprint 2: Engine core
export { DAGValidator } from './lib/DAGValidator';
export type { IDAGEdge, IDAGValidationResult } from './lib/DAGValidator';

export { StepAdvancer } from './lib/StepAdvancer';
export { WorkflowEngine } from './lib/WorkflowEngine';
export { ApprovalHandler } from './lib/ApprovalHandler';
export { WorkflowHistoryLogger } from './lib/WorkflowHistoryLogger';

// Shared types
export {
    WorkflowEventType,
    CDS_ENTITIES,
} from './lib/types';

export type {
    // Enums
    DecisionSource,
    ApprovalMode,
    ApproverSeqMode,
    RejectionMode,
    CompletionPolicy,
    WorkflowStatus,
    StepStatus,
    TaskStatus,
    // Template interfaces
    IWorkflowObjectType,
    IWorkflowDefinition,
    IWorkflowStepDefinition,
    IDefaultStepApprover,
    IStepDependency,
    // Runtime interfaces
    IWorkflowInstance,
    IStepInstance,
    IApprovalTask,
    IWorkflowHistory,
    // Engine input/output
    ICreateWorkflowInput,
    IApproverOverride,
    IApproveTaskInput,
    IRejectTaskInput,
    IReassignTaskInput,
    IWorkflowStatusChangedPayload,
    WorkflowEventTypeValue,
    // Notification configuration
    NotificationEventType,
    INotificationSettings,
    INotificationEventConfig,
    INotificationBusinessField,
    IStructuredTemplate,
} from './lib/types';

export { NOTIFICATION_EVENT_TYPES } from './lib/types';

// Sprint 3 exports:
// export { WorkflowActionProvider } from './lib/WorkflowActionProvider';

// P2+ features: Notifications
export { WorkflowNotifier } from './lib/WorkflowNotifier';
export type { IPreloadedWorkflowInfo } from './lib/WorkflowNotifier';
export type { IEmailSender, IBatchEmailSender } from './lib/IEmailSender';

// P2+ features: Advanced engine
export { ConditionEvaluator } from './lib/ConditionEvaluator';
export { WorkflowResolver } from './lib/WorkflowResolver';
export { CompletionPolicyChecker } from './lib/CompletionPolicyChecker';
export { WorkflowLifecycleHook } from './lib/WorkflowLifecycleHook';
