import cds from '@sap/cds';
import { PrincipalResolver } from './lib/PrincipalResolver';
import { DAGValidator } from './lib/DAGValidator';
import { WorkflowNotifier } from './lib/WorkflowNotifier';
import { CDS_ENTITIES, NOTIFICATION_EVENT_TYPES } from './lib/types';
import type { IStepDependency, IWorkflowStepDefinition } from './lib/types';

const LOG = cds.log('workflow.admin-service');

/**
 * WorkflowAdminService — CAP service handler
 *
 * Discovered by CAP convention (filename matches CDS file).
 * Handles:
 *   - Virtual field population via PrincipalResolver batch (T1)
 *   - DAG validation on StepDependency writes (F4)
 *   - Auto-increment definitionVersion on UPDATE (F5)
 *   - PrincipalType validation against SupportTypes (C10)
 */
export default class WorkflowAdminServiceHandler extends cds.ApplicationService {
    async init() {

        // ─── READ handlers: populate virtual name fields (T1) ────────────

        this.after('READ', 'WorkflowDefinitions', async (results: any) => {
            await PrincipalResolver.populateVirtualNames(results, [
                { typeField: 'responsibleType', idField: 'responsibleId', nameField: 'responsibleName' },
            ]);
        });

        this.after('READ', 'DefaultStepApprovers', async (results: any) => {
            await PrincipalResolver.populateVirtualNames(results, [
                { typeField: 'principalType', idField: 'principalId', nameField: 'principalName' },
            ]);
        });

        // ─── BEFORE handlers: validation ─────────────────────────────────

        // Validate principalType on WorkflowDefinition (responsible)
        this.before(['CREATE', 'UPDATE'], 'WorkflowDefinitions', async (req: any) => {
            const data = req.data;

            // ── Unique combination check: objectType + orgKeyValue + workflowType ──
            if (data.objectType && data.workflowType) {
                const where: Record<string, any> = {
                    objectType: data.objectType,
                    workflowType: data.workflowType,
                    // orgKeyValue can be null (global), so match null explicitly
                    orgKeyValue: data.orgKeyValue ?? null,
                };

                const recordId = data.ID ?? (req.params && req.params[0] && req.params[0].ID);

                let existing: any;
                if (recordId) {
                    existing = await cds.run(
                        SELECT.one.from(CDS_ENTITIES.WorkflowDefinition)
                            .where(where)
                            .and({ ID: { '!=': recordId } })
                    );
                } else {
                    existing = await cds.run(
                        SELECT.one.from(CDS_ENTITIES.WorkflowDefinition).where(where)
                    );
                }

                if (existing) {
                    const orgLabel = data.orgKeyValue ? ` / ${data.orgKeyValue}` : ' (global)';
                    LOG.warn(`Duplicate definition blocked: found=${existing.ID}, incoming=${recordId}, event=${req.event}`);
                    return req.error(
                        409,
                        `A Workflow Definition for "${data.objectType}${orgLabel} — ${data.workflowType}" already exists. ` +
                        `The combination of Object Type, Company Code and Workflow Type must be unique.`
                    );
                }
            }

            // Validate responsibleType if provided
            if (data.responsibleType) {
                const isValid = await PrincipalResolver.validatePrincipalType(data.responsibleType);
                if (!isValid) {
                    const validTypes = await PrincipalResolver.getEnabledTypes();
                    return req.error(400,
                        `Invalid responsibleType '${data.responsibleType}'. Valid types: ${validTypes.join(', ')}`
                    );
                }
            }
        });

        // Validate principalType on DefaultStepApprover
        this.before(['CREATE', 'UPDATE'], 'DefaultStepApprovers', async (req: any) => {
            const data = req.data;

            if (data.principalType) {
                const isValid = await PrincipalResolver.validatePrincipalType(data.principalType);
                if (!isValid) {
                    const validTypes = await PrincipalResolver.getEnabledTypes();
                    return req.error(400,
                        `Invalid principalType '${data.principalType}'. Valid types: ${validTypes.join(', ')}`
                    );
                }
            }
        });

        // Auto-increment definitionVersion on UPDATE (F5)
        this.before('UPDATE', 'WorkflowDefinitions', async (req: any) => {
            const current = await cds.run(
                SELECT.one.from(CDS_ENTITIES.WorkflowDefinition)
                    .columns('definitionVersion')
                    .where({ ID: req.data.ID })
            ) as { definitionVersion: number } | null;

            if (current) {
                req.data.definitionVersion = (current.definitionVersion || 0) + 1;
                LOG.info('Definition version incremented', {
                    definitionId: req.data.ID,
                    newVersion: req.data.definitionVersion,
                });
            }
        });

        // ─── DAG Validation on StepDependency writes (F4) ───────────────

        this.before(['CREATE', 'UPDATE'], 'StepDependencies', async (req: any) => {
            const data = req.data;

            // Self-reference check (quick fail)
            if (data.predecessor_ID === data.successor_ID) {
                return req.error(400, 'A step cannot depend on itself');
            }

            // Get the definition ID from the dependency or from the predecessor step
            let definitionId = data.definition_ID;
            if (!definitionId && data.predecessor_ID) {
                const predStep = await cds.run(
                    SELECT.one.from(CDS_ENTITIES.WorkflowStepDefinition)
                        .columns('definition_ID')
                        .where({ ID: data.predecessor_ID })
                ) as { definition_ID: string } | null;
                definitionId = predStep?.definition_ID;
            }

            if (!definitionId) {
                return req.error(400, 'Cannot determine definition for DAG validation');
            }

            // Get all existing dependencies for this definition
            const existingDeps = await cds.run(
                SELECT.from(CDS_ENTITIES.StepDependency)
                    .where({ definition_ID: definitionId })
            ) as IStepDependency[];

            // Get all steps for this definition
            const steps = await cds.run(
                SELECT.from(CDS_ENTITIES.WorkflowStepDefinition)
                    .columns('ID', 'displayOrder')
                    .where({ definition_ID: definitionId })
            ) as IWorkflowStepDefinition[];

            // Build edge list: existing + new (or replace if updating)
            const edges = existingDeps
                .filter(d => d.ID !== data.ID) // Exclude current if updating
                .map(d => ({ predecessor_ID: d.predecessor_ID, successor_ID: d.successor_ID }));

            edges.push({
                predecessor_ID: data.predecessor_ID,
                successor_ID: data.successor_ID,
            });

            // Validate the full graph
            const result = DAGValidator.validate(edges, steps.map(s => s.ID));

            if (!result.isValid) {
                return req.error(400, `Invalid dependency graph: ${result.errors.join('; ')}`);
            }

            LOG.debug('DAG validation passed', {
                definitionId,
                edgeCount: edges.length,
                topologicalOrder: result.topologicalOrder,
            });
        });

        // ─── Block deletion if workflow has been used (has instances) ────

        this.before('DELETE', 'WorkflowDefinitions', async (req: any) => {
            const id = req.params?.[req.params.length - 1]?.ID ?? req.data?.ID;
            if (!id) return;

            const definition = await cds.run(
                SELECT.one.from(CDS_ENTITIES.WorkflowDefinition)
                    .columns('objectType', 'workflowType')
                    .where({ ID: id })
            ) as { objectType: string; workflowType: string } | null;

            if (!definition) return;

            const usageRow = await cds.run(
                SELECT.one`count(*) as count`
                    .from(CDS_ENTITIES.WorkflowInstance)
                    .where({ definition_ID: id })
            ) as { count: number } | null;

            const count = Number(usageRow?.count ?? 0);

            if (count > 0) {
                LOG.info(`Delete blocked for WorkflowDefinition "${definition.workflowType}" (${definition.objectType}) — ${count} instance(s) in use`);
                return req.error(
                    409,
                    `Cannot delete workflow "${definition.workflowType}" (${definition.objectType}) because it has ${count} workflow instance(s) associated with it. ` +
                    `Please deactivate the workflow definition instead.`
                );
            }
        });

        // ─── sendTestEmail action ────────────────────────────────────────

        this.on('sendTestEmail', async (req: any) => {
            const { eventType, recipientEmail, notificationSettings } = req.data;

            // Validate event type
            if (!NOTIFICATION_EVENT_TYPES.includes(eventType)) {
                return req.error(400, `Invalid event type: ${eventType}`);
            }

            // Basic email validation
            if (!recipientEmail || !recipientEmail.includes('@')) {
                return req.error(400, 'Invalid recipient email address');
            }

            try {
                await WorkflowNotifier.sendTestEmail(
                    eventType,
                    recipientEmail,
                    notificationSettings
                );
                LOG.info(`Test email sent: ${eventType} → ${recipientEmail}`);
            } catch (err: any) {
                LOG.error('Failed to send test email:', err.message);
                return req.error(500, `Failed to send test email: ${err.message}`);
            }
        });

        await super.init();
    }
}
