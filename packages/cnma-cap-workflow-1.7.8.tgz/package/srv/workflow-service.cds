/**
 * @cnma/cap-workflow — Runtime Service (Workflow Execution)
 *
 * OData actions for starting workflows, approving/rejecting steps,
 * reassigning approvers, and querying process flow state.
 *
 * Authorization: @requires 'authenticated-user'
 * Path: /workflow
 *
 * NOTE: No @impl annotation — handler auto-discovered by CAP sibling convention (T4).
 */
using { cnma.workflow as tmpl } from '../db/workflow';
using { cnma.workflow.runtime as rt } from '../db/workflow-runtime';

@requires: 'authenticated-user'
service WorkflowService @(path: '/workflow') {

    // ─── Read-Only Projections ──────────────────────────────────────────

    @readonly
    entity WorkflowInstances as projection on rt.WorkflowInstance;

    @readonly
    entity StepInstances as projection on rt.StepInstance;

    @readonly
    entity ApprovalTasks as projection on rt.ApprovalTask;

    @readonly
    entity WorkflowHistories as projection on rt.WorkflowHistory;

    // Object type registry (read-only in runtime service)
    @readonly
    entity WorkflowObjectTypes as projection on tmpl.WorkflowObjectType
        where isActive = true;

    // Workflow definitions (read-only in runtime service)
    @readonly
    entity AvailableDefinitions as projection on tmpl.WorkflowDefinition
        where isActive = true;

    // ─── Actions ────────────────────────────────────────────────────────

    // Start a new workflow for a business object
    action startWorkflow(
        referenceId        : UUID not null,
        referenceType      : String(100) not null,
        definitionId       : UUID not null,
        responsibleType    : String(20),
        responsibleId      : UUID,
        approverOverrides  : LargeString,  // JSON: IApproverOverride[]
        documentData       : LargeString   // JSON: business document data for evaluating step conditions
    ) returns {
        workflowId : UUID;
        status     : String;
    };

    // Approve a task
    action approveStep(
        taskId  : UUID not null,
        comment : String
    ) returns {
        taskId : UUID;
        status : String;
    };

    // Reject a task (comment required)
    action rejectStep(
        taskId  : UUID not null,
        comment : String not null
    ) returns {
        taskId : UUID;
        status : String;
    };

    // Reassign a task
    action reassignApprover(
        taskId          : UUID not null,
        newAssigneeType : String(20) not null,
        newAssigneeId   : UUID not null,
        reason          : String not null
    ) returns {
        taskId : UUID;
        status : String;
    };

    // Cancel a workflow
    action cancelWorkflow(
        workflowId : UUID not null,
        reason     : String
    ) returns {
        workflowId : UUID;
        status     : String;
    };

    // Send reminder to current approver(s) of a workflow
    action remindApprovers(
        workflowId : UUID not null
    ) returns {
        reminded : Integer;
    };

    // Rerun a workflow (creates new instance)
    action rerunWorkflow(
        workflowId : UUID not null,
        approverOverrides : LargeString
    ) returns {
        newWorkflowId : UUID;
        status        : String;
    };

    // ─── Functions ──────────────────────────────────────────────────────

    // Get process flow visualization data
    function getProcessFlow(
        workflowId : UUID not null
    ) returns array of {
        stepId        : UUID;
        stepName      : String;
        displayOrder  : Integer;
        status        : String;
        approvalMode  : String;
        activatedAt   : DateTime;
        completedAt   : DateTime;
        tasks         : array of {
            taskId       : UUID;
            assigneeName : String;
            assigneeType : String;
            status       : String;
            decidedAt    : DateTime;
            comment      : String;
        };
    };

    // Get available workflow definitions for an object type
    function getAvailableWorkflows(
        objectType  : String(50) not null,
        orgKeyValue : String(50)
    ) returns array of {
        definitionId : UUID;
        workflowType : String;
        description  : String;
    };

    // Get steps that need manual approver assignment (have no pre-configured approvers)
    function getStepsNeedingApprovers(
        definitionId : UUID not null
    ) returns array of {
        stepDefinitionId : UUID;
        stepName         : String;
        displayOrder     : Integer;
        approvalMode     : String;
    };

    // Get the active step's field settings for the current user
    // Returns: isCurrentApprover=true if calling user has a pending task,
    // along with the step's fieldSettings JSON for form-level editability override.
    function getActiveStepFieldSettings(
        workflowId : UUID not null
    ) returns {
        isCurrentApprover   : Boolean;
        isResponsiblePerson : Boolean;
        stepName            : String;
        pendingTaskCount    : Integer;
        fieldSettings       : LargeString;
    };
}
