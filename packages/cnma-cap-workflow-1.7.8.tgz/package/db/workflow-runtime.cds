/**
 * @cnma/cap-workflow — Runtime Layer (Workflow Execution State)
 *
 * Runtime entities tracking the execution state of each running workflow:
 * instances, step instances, approval tasks, and audit history.
 *
 * Usage in consuming apps:
 *   using { cnma.workflow.runtime } from '@cnma/cap-workflow/db/workflow-runtime';
 *
 * Design Decisions Applied:
 *   C14: Only responsible, no initiator (createdBy = who started it)
 *   C15: WorkflowHistory links to approvalTask for task-level granularity
 *   C17: Generic referenceType + referenceId (not document-specific)
 *   F1:  @odata.etag for optimistic locking on ApprovalTask + WorkflowInstance
 *   F5:  frozenDefinitionVersion captured at workflow creation
 *   F7:  isSystemAction flag instead of performedByType
 */
namespace cnma.workflow.runtime;

using { cnma.workflow } from './workflow';
using { cuid } from '@sap/cds/common';
using { cnma.identity.managedWithUser } from '@cnma/cap-identity/db/common';

// ─── Runtime Statuses ───────────────────────────────────────────────────────

type WorkflowStatus : String enum {
    DRAFT;       // Created but not started
    ACTIVE;      // In progress — steps being processed
    COMPLETED;   // All steps approved, ready for completion action
    REJECTED;    // One or more steps rejected
    CANCELLED;   // Manually cancelled or auto-cancelled (e.g., Obsolete)
}

type StepStatus : String enum {
    PENDING;     // Not yet activated (predecessors not complete)
    ACTIVE;      // Currently being processed by approvers
    APPROVED;    // All required approvals received
    REJECTED;    // At least one required approver rejected
    SKIPPED;     // Skipped (future: conditional steps)
}

type TaskStatus : String enum {
    PENDING;     // Awaiting decision
    APPROVED;    // Approver approved
    REJECTED;    // Approver rejected
    CANCELLED;   // Workflow was cancelled before this task was decided
}

// ─── Runtime: Workflow Instance ─────────────────────────────────────────────

entity WorkflowInstance : cuid, managedWithUser {
    // ← (C17): Generic reference — package doesn't know what business object it serves
    // ai-agent-extraction: referenceType='DocumentUpload', referenceId=DocumentUpload.ID
    // flexible-request-management: referenceType='Request', referenceId=Request.ID
    // Any future project: referenceType='PurchaseOrder', referenceId=PO.ID
    referenceId        : UUID not null;                 // The business object's primary key
    referenceType      : String(100) not null;          // The business object's entity name

    // Template reference
    definition         : Association to workflow.WorkflowDefinition;
    workflowType       : String(100);                   // Denormalized for display
    workflowTypeSource : workflow.DecisionSource default 'MANUAL';

    // Run tracking
    runNumber          : Integer default 1;

    // Status
    status             : WorkflowStatus default 'DRAFT';

    // ← (F5): Frozen version at creation time
    frozenDefinitionVersion : Integer;

    // ← (C14): Only responsible, no initiator. createdBy = who started it.
    responsibleType    : String(20);                    // SupportTypes.code
    responsibleId      : UUID;                          // Who receives it after final approval
    virtual responsibleName : String(255);

    // Timestamps
    startedAt          : DateTime;
    completedAt        : DateTime;

    // Compositions
    stepInstances      : Composition of many StepInstance on stepInstances.workflowInstance = $self;
    history            : Composition of many WorkflowHistory on history.workflowInstance = $self;
}

// ─── Runtime: Step Instance ─────────────────────────────────────────────────

entity StepInstance : cuid, managedWithUser {
    workflowInstance   : Association to WorkflowInstance;
    stepDefinition     : Association to workflow.WorkflowStepDefinition;

    // Denormalized for display (captured from template at creation)
    stepName           : String(100);
    displayOrder       : Integer;                       // ← (C12)
    approvalMode       : workflow.ApprovalMode;
    approverSeqMode    : workflow.ApproverSeqMode;
    fieldSettings      : LargeString;

    // Status
    status             : StepStatus default 'PENDING';

    // Timestamps
    activatedAt        : DateTime;
    completedAt        : DateTime;

    // Tasks
    tasks              : Composition of many ApprovalTask on tasks.stepInstance = $self;
}

// ─── Runtime: Approval Task ─────────────────────────────────────────────────

entity ApprovalTask : cuid, managedWithUser {
    stepInstance       : Association to StepInstance;

    // ← (C5/C11): Single principalType + principalId
    assigneeType       : String(20) not null;           // SupportTypes.code
    assigneeId         : UUID not null;                 // ShadowUsers.ID or ShadowGroups.ID
    virtual assigneeName : String(255);

    taskOrder          : Integer default 0;             // ← (C13): For SEQUENTIAL within step

    // Decision
    status             : TaskStatus default 'PENDING';
    decidedByType      : String(20);                   // Who actually clicked (always USER)
    decidedById        : UUID;                         // ShadowUsers.ID of the person
    virtual decidedByName : String(255);
    decidedAt          : DateTime;
    comment            : LargeString;

    // Source tracking
    assignmentSource   : workflow.DecisionSource default 'MANUAL';
}

// ← (F1): Optimistic locking for concurrent approval prevention
annotate ApprovalTask with { modifiedAt @odata.etag; };
annotate WorkflowInstance with { modifiedAt @odata.etag; };

// ← (M2 perf fix): DB indexes on hot query columns to prevent full table scans at scale
annotate WorkflowInstance with @(
    Capabilities.Indexes: [{
        Columns: ['referenceId', 'referenceType', 'status'],
        Name   : 'IDX_WF_REF_STATUS'
    }]
);
annotate StepInstance with @(
    Capabilities.Indexes: [{
        Columns: ['workflowInstance_ID', 'status'],
        Name   : 'IDX_STEP_WF_STATUS'
    }]
);
annotate ApprovalTask with @(
    Capabilities.Indexes: [
        {
            Columns: ['stepInstance_ID', 'status'],
            Name   : 'IDX_TASK_STEP_STATUS'
        },
        {
            Columns: ['assigneeId'],
            Name   : 'IDX_TASK_ASSIGNEE'
        }
    ]
);

// ─── Audit: Workflow History ────────────────────────────────────────────────

@sql.append: 'PAGE LOADABLE'
entity WorkflowHistory : cuid, managedWithUser {
    workflowInstance   : Association to WorkflowInstance;
    stepInstance       : Association to StepInstance;
    approvalTask       : Association to ApprovalTask;   // ← (C15): task-level granularity

    eventType          : String(50) not null;

    performedById      : UUID;                          // ShadowUsers.ID
    virtual performedByName : String(255);
    isSystemAction     : Boolean default false;          // ← (F7): true for auto-advance
    performedAt        : DateTime;

    // Context
    stepName           : String(100);
    previousValue      : String(100);
    newValue           : String(100);
    comment            : LargeString;
    metadata           : LargeString;                   // JSON: additional context
}
