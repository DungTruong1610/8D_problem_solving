/**
 * @cnma/cap-workflow — Template Layer (Workflow Definitions)
 *
 * Configurable, DAG-based workflow definitions for multi-step approval workflows.
 * Domain-agnostic — uses generic orgKeyValue instead of hardcoded companyCode.
 *
 * Usage in consuming apps:
 *   using { cnma.workflow } from '@cnma/cap-workflow/db/workflow';
 *
 * Design Decisions Applied:
 *   C4:  Generic org scope (orgKeyValue instead of companyCode)
 *   C5:  Single principalType + principalId (not dual associations)
 *   C10: No fixed PrincipalType enum — String(20) validated against SupportTypes
 *   C12: displayOrder for UI position, StepDependency for execution
 *   C13: approverSeqMode controls parallel vs sequential within a step
 *   F2:  CompletionPolicy for post-approval authorization
 *   F3:  WorkflowObjectType registry prevents magic-string mismatches
 *   F5:  definitionVersion for template versioning
 */
namespace cnma.workflow;

using { cuid } from '@sap/cds/common';
using { cnma.identity.managedWithUser } from '@cnma/cap-identity/db/common';

// ─── Enums ──────────────────────────────────────────────────────────────────

type DecisionSource : String enum {
    MANUAL;          // Human decision
    AI_SUGGESTED;    // AI recommended, human confirmed
    AUTO;            // System auto-decided
}

type ApprovalMode : String enum {
    ANY_ONE;         // First approval completes the step
    ![ALL];          // All approvers must approve
}

type ApproverSeqMode : String enum {
    SEQUENTIAL;      // Approvers activated one-by-one in approverOrder
    PARALLEL;        // All approvers activated simultaneously
}

type RejectionMode : String enum {
    BACK_TO_RESPONSIBLE;  // Entire workflow returns to responsible
    RESTART_STEP;         // Only rejected step resets to PENDING
    NEW_RUN;              // Workflow closed, new instance required
}

// ← NEW (F2): Who can act after final approval
type CompletionPolicy : String enum {
    RESPONSIBLE_ONLY;      // Only the responsible person/group
    RESPONSIBLE_MEMBERS;   // Any member of the responsible group
    ANY_AUTHORIZED;        // Any user with the appropriate role
    AUTO_COMPLETE;         // System auto-executes (Phase 3)
}

// ─── Registry: Validated Object Types ───────────────────────────────────────
// ← (F3): Prevents magic-string objectType mismatches between host and package

entity WorkflowObjectType : cuid, managedWithUser {
    objectType  : String(50) not null @assert.unique;  // INV, SO, ASN, POC, QUO
    displayName : String(100);                          // "Invoice", "Sales Order"
    orgKeyField : String(100);                          // "header.companyCode", "header.salesOrg"
    isActive    : Boolean default true;
}

// ─── Template: Workflow Definition ──────────────────────────────────────────

entity WorkflowDefinition : cuid, managedWithUser {
    objectType       : String(50) not null;         // INV, ASN, POC, QUO, SO, ...

    // ← (C4): Generic org scope instead of hardcoded companyCode
    orgKeyValue      : String(50);                  // "1000", "DE01", null = global default

    triggerAction    : String(50) default 'submitForApproval'; // UI Action this workflow handles (e.g. submitForApproval, requestForGR)
    workflowType     : String(100) not null;        // "Cost Center Based", "WBS Element Based"
    description      : String(500);

    // ← (C5): Single principalType + principalId pattern
    responsibleType  : String(20);                  // SupportTypes.code: USER, GROUP, TEAM, ...
    responsibleId    : UUID;                        // ShadowUsers.ID or ShadowGroups.ID
    virtual responsibleName : String(255);          // Populated in READ handler

    // Rejection behavior (C6)
    rejectionMode    : RejectionMode default 'BACK_TO_RESPONSIBLE';

    // ← (F2): Generic completion authorization
    completionPolicy : CompletionPolicy default 'RESPONSIBLE_ONLY' @assert.range;

    // ← (F5): Versioning — incremented on every change
    definitionVersion : Integer default 1;

    // Auto-determination (Phase 2)
    conditionExpr    : LargeString;                 // JSON: ConditionExpression interface
    priority         : Integer default 0;           // Higher = evaluated first

    // ← (F4): Auto-cancel workflow when host sets terminal status
    autoCancelOnTerminalStatus : Boolean default true;

    isActive         : Boolean default true;

    // ← (P2+): Per-workflow email notification config (null = all enabled with defaults)
    // JSON: INotificationSettings — controls which events send emails + custom templates
    notificationSettings : LargeString;

    // ← 4-Eyes Principle: when true, the submitter cannot approve their own submission.
    // Default true = safe default (existing behavior preserved).
    enforceFourEyes  : Boolean default true;

    // Compositions
    steps            : Composition of many WorkflowStepDefinition on steps.definition = $self;
    stepDependencies : Composition of many StepDependency on stepDependencies.definition = $self;
}

annotate WorkflowDefinition with @assert.unique: {
    workflowKey: [ objectType, orgKeyValue, workflowType ]  // ← (C4)
};

// ─── Template: Step Definition ──────────────────────────────────────────────

entity WorkflowStepDefinition : cuid, managedWithUser {
    definition       : Association to WorkflowDefinition;

    // ← (C12): Renamed from stepOrder to displayOrder
    displayOrder     : Integer not null;               // UI display position only (NOT execution order)

    stepName         : String(100) not null;           // "Cost Center Approval"
    stepDescription  : String(500);

    // How approvers within this step work together
    approvalMode     : ApprovalMode default 'ALL';     // ANY_ONE = first wins; ALL = everyone
    approverSeqMode  : ApproverSeqMode default 'PARALLEL'; // ← (C13): PARALLEL = all at once

    // Dynamic UI field config per step
    // JSON: { "costCenter": "mandatory", "internalOrder": "readonly", "purchaseOrder": "editable" }
    fieldSettings    : LargeString;

    // Condition logic for step execution (Phase 2)
    conditionExpr    : LargeString;                 // JSON: ConditionExpression interface

    // Default approvers
    defaultApprovers : Composition of many DefaultStepApprover on defaultApprovers.step = $self;
}

// ─── Template: Default Approver ─────────────────────────────────────────────

entity DefaultStepApprover : cuid, managedWithUser {
    step             : Association to WorkflowStepDefinition;

    // ← (C11): Single principalType + principalId
    principalType    : String(20) not null;            // SupportTypes.code: USER, GROUP, TEAM, etc.
    principalId      : UUID not null;                  // ShadowUsers.ID or ShadowGroups.ID
    virtual principalName : String(255);               // Populated in READ handler

    approverOrder    : Integer default 0;              // ← (C13): Only meaningful for SEQUENTIAL mode

    // Condition for dynamic resolution (Phase 2)
    conditionExpr    : LargeString;
}

// ─── Template: Step Dependencies (DAG) ──────────────────────────────────────
// Note: No managedWithUser — pure edge table (intentional)

entity StepDependency : cuid {
    definition       : Association to WorkflowDefinition;
    predecessor      : Association to WorkflowStepDefinition;  // must complete BEFORE
    successor        : Association to WorkflowStepDefinition;  // can activate AFTER
}

// ← (H2 perf fix): Index on FK columns queried on every workflow start and DAG validation
annotate StepDependency with @(
    Capabilities.Indexes: [{
        Columns: ['definition_ID'],
        Name   : 'IDX_DEP_DEF'
    }]
);

annotate DefaultStepApprover with @(
    Capabilities.Indexes: [{
        Columns: ['step_ID'],
        Name   : 'IDX_APPROVER_STEP'
    }]
);
