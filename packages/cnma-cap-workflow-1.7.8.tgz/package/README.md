# @cnma/cap-workflow

> Reusable DAG-based workflow engine for SAP CAP — configurable multi-step approval workflows for any domain object.

[![TypeScript](https://img.shields.io/badge/TypeScript-5.x-blue.svg)](https://www.typescriptlang.org/)
[![CAP](https://img.shields.io/badge/SAP_CAP-9.x-0FAAFF.svg)](https://cap.cloud.sap/)
[![React](https://img.shields.io/badge/React-18.x-61DAFB.svg)](https://react.dev/)

## Features

- **DAG-Based**: Topologically validated step dependencies (parallel, sequential, fan-out/fan-in)
- **Domain Agnostic**: Works with any CDS entity via `referenceType + referenceId`
- **Configurable**: Admin UI for defining workflows, steps, and approver chains
- **3 Rejection Modes**: BACK_TO_RESPONSIBLE, RESTART_STEP, NEW_RUN
- **Concurrency Safe**: Optimistic locking (`@odata.etag`) + pessimistic locking (`forUpdate()`)
- **Batch Optimized**: N+1 prevention with `PrincipalResolver` (max 2 queries per batch)
- **Transaction Safe**: All operations within caller's implicit CAP transaction
- **React Components**: ProcessFlow, ApprovalPanel, WorkflowTimeline, WorkflowManager

## Installation

```bash
npm install @cnma/cap-workflow
```

**Peer dependencies** (host app must provide):
- `@sap/cds` ≥ 7.0.0
- `react` ≥ 18.0.0 (only if using React components)
- `clsx`, `tailwind-merge`, `class-variance-authority`, `lucide-react` (only if using React components)

## Quick Start

### 1. Import CDS Models

Create `srv/workflow.cds` in your host app:

```cds
using from '@cnma/cap-workflow/srv/workflow-admin-service';
using from '@cnma/cap-workflow/srv/workflow-service';
```

### 2. Seed Object Types

Create `db/data/cnma.workflow-WorkflowObjectType.csv`:

```csv
ID;objectType;displayName;orgKeyField;isActive
<uuid>;INV;Invoice;header.companyCode;true
```

### 3. Subscribe to Status Events

```typescript
// srv/server.ts
cds.on('served', async () => {
    const workflowService = await cds.connect.to('WorkflowService');
    workflowService.on('workflow.statusChanged', async (msg) => {
        const { referenceId, status, currentStepName } = msg.data;
        await UPDATE('MyEntity').set({ workflowStatus: status }).where({ ID: referenceId });
    });
});
```

### 4. Use React Components

```tsx
import { ProcessFlow, ApprovalPanel, WorkflowManager } from '@cnma/cap-workflow/react';

// Runtime: Show workflow progress
<ProcessFlow
    httpClient={httpClient}
    workflowId="..."
    onApprove={(taskId) => openApprovalDialog(taskId)}
/>

// Runtime: Approve/reject a task
<ApprovalPanel
    httpClient={httpClient}
    taskId="..."
    onComplete={(action) => refetchWorkflow()}
/>

// Admin: Configure workflows
<WorkflowManager
    httpClient={httpClient}
    adminBaseUrl="/workflow-admin"
/>
```

## Architecture

```
┌──────────────────────────────────────────────────────────┐
│                    Host Application                       │
│  ┌─────────────┐  ┌──────────────┐  ┌────────────────┐  │
│  │ React UI    │  │ CDS Service  │  │ StatusSync     │  │
│  │ ProcessFlow │  │ Handlers     │  │ Handler (T7)   │  │
│  └──────┬──────┘  └──────┬───────┘  └────────┬───────┘  │
│         │                │                    │          │
├─────────┼────────────────┼────────────────────┼──────────┤
│         │    @cnma/cap-workflow               │          │
│  ┌──────▼──────┐  ┌──────▼───────┐  ┌────────▼───────┐  │
│  │ Workflow    │  │ Workflow     │  │ Approval       │  │
│  │ Service     │  │ Admin Svc    │  │ Handler        │  │
│  │ (6 actions) │  │ (CRUD+DAG)   │  │ (forUpdate)    │  │
│  └──────┬──────┘  └──────┬───────┘  └────────┬───────┘  │
│         │                │                    │          │
│  ┌──────▼────────────────▼────────────────────▼───────┐  │
│  │              Engine Core                           │  │
│  │  WorkflowEngine  │  StepAdvancer  │  DAGValidator  │  │
│  └────────────────────────────────────────────────────┘  │
│  ┌────────────────────────────────────────────────────┐  │
│  │              CDS Data Model                        │  │
│  │  Template Layer (5 entities) │ Runtime (4 entities) │  │
│  └────────────────────────────────────────────────────┘  │
└──────────────────────────────────────────────────────────┘
```

## API Reference

### OData Actions (WorkflowService)

| Action | Method | Description |
|--------|--------|-------------|
| `startWorkflow` | POST | Create + start a workflow for a business object |
| `approveStep` | POST | Approve a pending task |
| `rejectStep` | POST | Reject a task (comment required) |
| `reassignApprover` | POST | Reassign a task to a different principal |
| `cancelWorkflow` | POST | Cancel an active workflow |
| `rerunWorkflow` | POST | Create new instance with runNumber+1 |

### OData Functions (WorkflowService)

| Function | Method | Description |
|----------|--------|-------------|
| `getProcessFlow` | POST | Step/task visualization data |
| `getAvailableWorkflows` | POST | Definitions for an object type |

### Engine Classes (Backend)

```typescript
import { WorkflowEngine, ApprovalHandler, DAGValidator } from '@cnma/cap-workflow/srv';

// Create + start
const workflowId = await WorkflowEngine.createWorkflow({ ... });
await WorkflowEngine.startWorkflow(workflowId);

// Approve
await ApprovalHandler.approveTask({ taskId, userId, comment });

// Validate DAG
const result = DAGValidator.validate(edges, stepIds);
```

### React Components

| Component | Import | Description |
|-----------|--------|-------------|
| `ProcessFlow` | `react` | Visual step-flow with task details |
| `ApprovalPanel` | `react` | Approve/reject/reassign action forms |
| `WorkflowTimeline` | `react` | Chronological event timeline |
| `WorkflowManager` | `react` | Admin tabbed UI (definitions + types) |
| `DefinitionsTab` | `react` | Definition list with CRUD |
| `StepEditor` | `react` | Step + approver management |
| `ObjectTypesTab` | `react` | Object type registry |

## Design Decisions

| ID | Decision | Impact |
|----|----------|--------|
| T1 | Batch name resolution (max 2 queries) | No N+1 on list views |
| T2 | No sub-transactions in engine | Uses caller's implicit CAP tx |
| T3 | Strict exports map | No `ERR_PACKAGE_PATH_NOT_EXPORTED` |
| F1 | `@odata.etag` + `forUpdate()` | Race-condition safe approvals |
| F4 | Kahn's algorithm on dependency writes | No cycles in step graphs |
| C6 | 3 rejection modes | Flexible rejection handling |
| C17 | `referenceType + referenceId` | Domain-agnostic — any CDS entity |
| T7 | Synchronous `statusChanged` event | Atomic state sync within tx |

## Development

```bash
# Build
npm run build            # srv + react
npm run build:srv        # Backend only
npm run build:react      # React only

# Test
npm test                 # Jest unit tests

# Clean
npm run clean            # Remove dist/
```

## License

UNLICENSED — Conarum Development Kit internal package.
